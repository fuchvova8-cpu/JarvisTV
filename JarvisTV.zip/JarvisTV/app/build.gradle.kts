import org.gradle.api.tasks.bundling.Zip

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

// Mark LVII, byte-for-byte as shipped, lives in app/jarvis. It is zipped into the
// APK's assets at build time and unpacked on the TV into a writable folder, so
// the original's own `Path(__file__)`-relative config/memory/plugins just work.
val zipJarvis = tasks.register<Zip>("zipJarvis") {
    from("jarvis")
    archiveFileName.set("jarvis.zip")
    destinationDirectory.set(layout.buildDirectory.dir("generated/jarvisAssets"))
}

android {
    namespace = "com.jarvis.tv"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.jarvis.tv"
        minSdk = 26
        // Android 9 (API 28) is the TV's own level. Staying at 28 keeps the two
        // things Mark LVII relies on legal: running helper scripts from app
        // storage and file:// hand-offs. (Not a Play Store build.)
        targetSdk = 28
        versionCode = 1
        versionName = "57.0-tv"

        // Pick one with -PabiOnly=armeabi-v7a to halve the APK; default is both.
        val only = (project.findProperty("abiOnly") as String?)?.trim().orEmpty()
        ndk {
            abiFilters += if (only.isNotEmpty()) listOf(only) else listOf("armeabi-v7a", "arm64-v8a")
        }
    }

    buildFeatures { buildConfig = true }

    sourceSets {
        getByName("main") {
            assets.srcDir(layout.buildDirectory.dir("generated/jarvisAssets"))
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    packaging {
        resources.excludes += setOf("META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/DEPENDENCIES",
            "META-INF/INDEX.LIST", "META-INF/*.kotlin_module")
    }
}

tasks.configureEach {
    if (name.startsWith("merge") && name.endsWith("Assets")) dependsOn(zipJarvis)
    if (name.startsWith("lintVital") || name.startsWith("lintAnalyze")) dependsOn(zipJarvis)
}

chaquopy {
    defaultConfig {
        version = "3.12"
        pip {
            // Everything in Mark LVII's requirements.txt that exists for Android.
            // Not listed on purpose (and why):
            //   PyQt6, sounddevice, mss, pyautogui, pyperclip, psutil -> replaced by python/ shims
            //   playwright, opencv-python, pdfplumber, ddgs, pynvml, win32 -> no Android wheels
            install("numpy")
            install("pillow")
            install("requests")
            install("certifi")
            install("beautifulsoup4")
            install("cryptography")
            install("pydantic")
            install("httpx")
            install("websockets")
            install("google-genai>=2.8.0,<3")
            install("fastapi")
            install("uvicorn")
            install("python-multipart")
            install("qrcode")
            install("yt-dlp")
            install("python-pptx")
            install("python-docx")
            install("PyPDF2")
            install("openpyxl")
            install("send2trash")
            install("youtube-transcript-api")
            install("google-api-python-client")
            install("google-auth-oauthlib")
            install("tinytuya")
            install("paho-mqtt")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.4.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")
    // Talks to the TV's own adbd over 127.0.0.1 (keys, taps, screenshots).
    implementation("dev.mobile:dadb:1.2.10")
}
