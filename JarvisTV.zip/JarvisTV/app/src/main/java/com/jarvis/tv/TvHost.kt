package com.jarvis.tv

import android.app.SearchManager
import android.app.SearchableInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import com.chaquo.python.Python
import org.json.JSONArray
import org.json.JSONObject
import kotlin.concurrent.thread

/**
 * What Python plugins reach through android_bridge: search providers of other apps (ContentResolver, no root),
 * the poster/results screen, opening a title in its app, launching apps. Ported from Mark TV's Host.
 * Every method may be called from any Python thread.
 */
object TvHost {
    private val app: Context get() = Bridge.app
    private val main = Handler(Looper.getMainLooper())

    // What ResultsActivity shows.
    @Volatile var lastTitle = ""
    @Volatile var lastResults = ""

    /** Calls tvshim.entry.<fn>(*args) synchronously; "" on failure. */
    fun py(fn: String, vararg a: Any?): String = try {
        Python.getInstance().getModule("tvshim.entry").callAttr(fn, *a).toString()
    } catch (t: Throwable) {
        "ERR: ${t.message}"
    }

    private fun log(msg: String) = Bridge.log("SYS: $msg")

    // ── results screen ──
    fun showResults(title: String, json: String) {
        lastTitle = title
        lastResults = json
        log("На экран: $title")
        main.post {
            try {
                app.startActivity(
                    Intent(app, ResultsActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                )
            } catch (e: Throwable) {
                log("Не удалось открыть экран результатов: ${e.message}")
            }
        }
    }

    /** Bring the last results back (after "Свернуть"). False if there is nothing to show. */
    fun reopenResults(): Boolean {
        if (lastResults.isEmpty() && lastTitle.isEmpty()) return false
        main.post {
            try {
                app.startActivity(
                    Intent(app, ResultsActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                )
            } catch (e: Throwable) {
                log("Не удалось открыть экран результатов: ${e.message}")
            }
        }
        return true
    }

    fun hideResults() {
        main.post { try { ResultsActivity.current?.finish() } catch (_: Throwable) {} }
    }

    fun resultsVisible(): Boolean = ResultsActivity.current?.let { !it.isFinishing } ?: false

    // ── opening a title ──
    /** [json] = [{name, action, data, comp, pkg, extras:{k:v}}], tried in turn. "ok:<name>" or "ERR: ...". */
    fun openIntents(title: String, json: String): String {
        val arr = try { JSONArray(json) } catch (e: Throwable) { return "ERR: bad json" }
        var last = "нет вариантов"
        for (n in 0 until arr.length()) {
            val o = arr.getJSONObject(n)
            val name = o.optString("name")
            try {
                val i = Intent()
                o.optString("action").takeIf { it.isNotEmpty() }?.let { i.action = it }
                o.optString("data").takeIf { it.isNotEmpty() }?.let { i.data = Uri.parse(it) }
                val comp = o.optString("comp")
                val pkg = o.optString("pkg")
                if (comp.isNotEmpty()) ComponentName.unflattenFromString(comp)?.let { i.component = it }
                else if (pkg.isNotEmpty()) i.setPackage(pkg)
                o.optJSONObject("extras")?.let { ex ->
                    val keys = ex.keys()
                    while (keys.hasNext()) { val k = keys.next(); i.putExtra(k, ex.getString(k)) }
                }
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                app.startActivity(i)
                log("Открыто «$title»: вариант $name")
                return "ok:$name"
            } catch (e: Throwable) {
                last = "$name: ${e.javaClass.simpleName}: ${e.message}"
                log("Открыть «$title»: $last")
            }
        }
        return "ERR: $last"
    }

    /** Card chosen on the results screen: intents first, then shell commands over ADB. */
    fun openCard(title: String, intentsJson: String, cmds: List<String>) {
        thread(name = "open-card") {
            var res = if (intentsJson.isNotEmpty() && intentsJson != "[]") openIntents(title, intentsJson) else "ERR: -"
            if (res.startsWith("ERR")) {
                for (c in cmds) {
                    val out = try { Adb.shell(c) } catch (t: Throwable) { "ADB: ${t.message}" }
                    log("Открыть «$title»: $c → ${out.take(80)}")
                    val low = out.lowercase()
                    val bad = out.startsWith("ADB:") || low.contains("error") || low.contains("unable to resolve") ||
                        low.contains("does not exist") || low.contains("exception") || low.contains("permission denial")
                    if (!bad) { res = "ok:shell"; break }
                    res = "ERR: ${out.take(100)}"
                }
            }
            val ok = res.startsWith("ok")
            main.post {
                Toast.makeText(app, if (ok) "Открываю: $title" else "Не открылось: ${res.take(140)}", Toast.LENGTH_LONG).show()
            }
        }
    }

    // ── apps ──
    /** Launchable apps as JSON: [{pkg, label, tv}]. */
    fun listApps(): String {
        val pm = app.packageManager
        val out = JSONArray()
        val seen = HashSet<String>()
        fun add(category: String, tv: Boolean) {
            val i = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (ri in pm.queryIntentActivities(i, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == app.packageName || !seen.add(pkg)) continue
                val o = JSONObject()
                o.put("pkg", pkg)
                o.put("label", ri.loadLabel(pm).toString())
                o.put("tv", tv)
                out.put(o)
            }
        }
        add(Intent.CATEGORY_LEANBACK_LAUNCHER, true)
        add(Intent.CATEGORY_LAUNCHER, false)
        return out.toString()
    }

    fun launchApp(pkg: String): String = try {
        val pm = app.packageManager
        val i = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg)
        if (i == null) "ERR: у приложения нет значка запуска" else {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            app.startActivity(i)
            "ok"
        }
    } catch (e: Throwable) {
        "ERR: ${describe(e)}"
    }

    // ── search providers ──
    private class Spec(
        val pkg: String, val path: String, val selection: String?,
        val action: String?, val data: String?, val comp: String? = null
    )

    private val specs = java.util.concurrent.ConcurrentHashMap<String, Spec>()

    private fun describe(e: Throwable): String {
        val sb = StringBuilder("${e.javaClass.simpleName}: ${e.message}")
        var c = e.cause
        var n = 0
        while (c != null && n < 2) { sb.append(" <- ${c.javaClass.simpleName}: ${c.message}"); c = c.cause; n++ }
        return sb.toString()
    }

    /** The system global search list (hidden API through reflection). */
    @Suppress("UNCHECKED_CAST")
    private fun scanSearchManager() {
        val sm = app.getSystemService(Context.SEARCH_SERVICE) as SearchManager
        val m = SearchManager::class.java.getMethod("getSearchablesInGlobalSearch")
        val list = m.invoke(sm) as? List<SearchableInfo> ?: return
        for (si in list) {
            val auth = si.suggestAuthority ?: continue
            val pkg = si.searchActivity?.packageName ?: continue
            specs[auth] = Spec(pkg, si.suggestPath ?: "", si.suggestSelection, si.suggestIntentAction,
                si.suggestIntentData, si.searchActivity?.flattenToString())
        }
    }

    /** Fallback when the hidden API is blocked: exported providers whose authority looks like search. */
    @Suppress("DEPRECATION")
    private fun scanPackages() {
        val pm = app.packageManager
        for (ai in pm.getInstalledApplications(0)) {
            val pi = try { pm.getPackageInfo(ai.packageName, PackageManager.GET_PROVIDERS) } catch (e: Throwable) { continue }
            for (pr in pi.providers ?: continue) {
                val auth = pr.authority ?: continue
                if (!pr.exported) continue
                if (!(auth.contains("search", true) || auth.contains("suggest", true))) continue
                for (a in auth.split(";")) if (!specs.containsKey(a)) specs[a] = Spec(ai.packageName, "", null, null, null)
            }
        }
    }

    /** One "authority|package" per line, or "ERR: ...". */
    fun searchProviders(): String {
        specs.clear()
        try { scanSearchManager() } catch (e: Throwable) { log("Провайдеры: SearchManager недоступен (${describe(e)}), сканирую пакеты") }
        try { scanPackages() } catch (e: Throwable) { if (specs.isEmpty()) return "ERR: ${describe(e)}" }
        val out = StringBuilder()
        for ((a, sp) in specs) out.append(a).append('|').append(sp.pkg).append('\n')
        log("Провайдеров поиска: ${specs.size}")
        return out.toString()
    }

    /** Queries a provider as the system search does. JSON rows or "ERR: ...". */
    fun searchQuery(authority: String, query: String, limit: Int): String {
        val sp = specs[authority] ?: Spec("", "", null, null, null)
        return try {
            val b = Uri.Builder().scheme("content").authority(authority)
            if (sp.path.isNotEmpty()) b.appendEncodedPath(sp.path)
            b.appendPath("search_suggest_query")
            var args: Array<String>? = null
            if (sp.selection != null) args = arrayOf(query) else b.appendPath(query)
            b.appendQueryParameter("limit", limit.toString())
            val rows = readRows(b.build(), sp.selection, args)
            for (i in 0 until rows.length()) {
                val o = rows.getJSONObject(i)
                sp.action?.let { o.put("_default_action", it) }
                sp.data?.let { o.put("_default_data", it) }
                sp.comp?.let { o.put("_component", it) }
            }
            rows.toString()
        } catch (e: Throwable) {
            val err = describe(e)
            log("Поиск $authority: $err")
            "ERR: $err"
        }
    }

    fun queryUri(uri: String, selection: String?, arg: String?): String = try {
        readRows(Uri.parse(uri), selection, if (arg != null) arrayOf(arg) else null).toString()
    } catch (e: Throwable) {
        "ERR: ${describe(e)}"
    }

    fun providerSpec(authority: String): String {
        val sp = specs[authority] ?: return "{}"
        val o = JSONObject()
        o.put("pkg", sp.pkg); o.put("path", sp.path)
        o.put("selection", sp.selection ?: JSONObject.NULL)
        o.put("action", sp.action ?: JSONObject.NULL)
        o.put("data", sp.data ?: JSONObject.NULL)
        o.put("comp", sp.comp ?: JSONObject.NULL)
        return o.toString()
    }

    private fun readRows(uri: Uri, selection: String?, args: Array<String>?): JSONArray {
        val rows = JSONArray()
        val c = app.contentResolver.query(uri, null, selection, args, null) ?: return rows
        c.use {
            val names = it.columnNames
            while (it.moveToNext()) {
                val o = JSONObject()
                for (i in names.indices) {
                    try { o.put(names[i], it.getString(i) ?: "") } catch (_: Throwable) {}
                }
                rows.put(o)
            }
        }
        return rows
    }
}
