package com.jarvis.tv

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import java.io.ByteArrayInputStream
import java.io.File

/** The user's own background picture (plugin_data/wallpaper.jpg), picked from the gallery or a file path. */
object Wallpaper {
    private const val MAX = 1920

    fun file(): File = File(File(AssetInstaller.targetDir(Bridge.app), "plugin_data"), "wallpaper.jpg")

    @Volatile private var cached: Bitmap? = null
    @Volatile private var cachedStamp = -1L

    /** The saved picture (decoded once per change), or null when there is none. */
    @Synchronized
    fun bitmap(): Bitmap? {
        val f = file()
        if (!f.exists()) return null
        val st = f.lastModified() xor f.length()
        if (st != cachedStamp || cached == null) {
            cached = try { BitmapFactory.decodeFile(f.path) } catch (_: Throwable) { null }
            cachedStamp = st
        }
        return cached
    }

    /** Decodes [data], fixes the EXIF rotation, shrinks it to at most 1920 px and stores it as the wallpaper. */
    fun save(data: ByteArray): Boolean {
        return try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(data, 0, data.size, o)
            if (o.outWidth <= 0 || o.outHeight <= 0) return false
            var sample = 1
            while (maxOf(o.outWidth, o.outHeight) / (sample * 2) >= MAX) sample *= 2
            val opt = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp = BitmapFactory.decodeByteArray(data, 0, data.size, opt) ?: return false
            val rot = try {
                when (ExifInterface(ByteArrayInputStream(data)).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } catch (_: Throwable) { 0f }
            val big = maxOf(bmp.width, bmp.height)
            val k = if (big > MAX) MAX.toFloat() / big else 1f
            if (rot != 0f || k < 1f) {
                val m = Matrix().apply { if (rot != 0f) postRotate(rot); if (k < 1f) postScale(k, k) }
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            val f = file()
            f.parentFile?.mkdirs()
            f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            synchronized(this) { cached = null; cachedStamp = -1L }
            Skin.touch()
            true
        } catch (t: Throwable) {
            Bridge.log("SYS: фон: ${t.message}")
            false
        }
    }

    fun saveFrom(ctx: Context, uri: Uri): Boolean =
        try { ctx.contentResolver.openInputStream(uri)?.use { save(it.readBytes()) } ?: false } catch (t: Throwable) { false }

    fun saveFromPath(path: String): Boolean =
        try { val f = File(path.trim()); f.isFile && save(f.readBytes()) } catch (t: Throwable) { false }
}

/** Invisible activity that opens the system picture chooser and stores the result as the wallpaper. */
class WallpaperPickActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tries = listOf(
            Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE) },
            Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE) },
            Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        )
        for (i in tries) {
            try { startActivityForResult(i, 77); return } catch (_: ActivityNotFoundException) {} catch (_: SecurityException) {}
        }
        Toast.makeText(this, "На этом ТВ нет приложения для выбора картинок. Впишите путь к файлу в настройках.", Toast.LENGTH_LONG).show()
        finish()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) { finish(); return }
        Toast.makeText(this, "Загружаю фон…", Toast.LENGTH_SHORT).show()
        Thread {
            val ok = Wallpaper.saveFrom(applicationContext, uri)
            runOnUiThread {
                Toast.makeText(this, if (ok) "Фон установлен" else "Не удалось прочитать картинку", Toast.LENGTH_LONG).show()
                finish()
            }
        }.start()
    }
}

/** Picture as a full-screen background (centre-crop) with a dark veil so the glass and text stay readable. */
class ImageBgDrawable(private val bmp: Bitmap, dimPct: Int) : Drawable() {
    private val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val veil = (dimPct.coerceIn(0, 90) * 255 / 100) shl 24
    private val src = Rect()

    override fun draw(c: Canvas) {
        val b = bounds
        if (b.width() <= 0 || b.height() <= 0) return
        val bw = bmp.width.toFloat(); val bh = bmp.height.toFloat()
        val s = maxOf(b.width() / bw, b.height() / bh)
        val vw = (b.width() / s).toInt(); val vh = (b.height() / s).toInt()
        val l = ((bw - vw) / 2).toInt(); val t = ((bh - vh) / 2).toInt()
        src.set(l, t, l + vw, t + vh)
        c.drawBitmap(bmp, src, b, p)
        if (veil ushr 24 > 0) c.drawColor(veil)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}
