package com.jarvis.tv

import android.content.Context
import java.io.File
import java.util.zip.ZipInputStream

/**
 * Unpacks the untouched Mark LVII (assets/jarvis.zip) into a writable folder:
 *   /sdcard/Android/data/com.jarvis.tv/files/Jarvis   (visible over USB / file managers)
 * so the original's `Path(__file__)`-relative config, memory, reports and
 * plugins\ work as on a PC. On an app update code is refreshed; the user's own
 * data (API key, memory, their plugins and agents) is never overwritten.
 */
object AssetInstaller {
    fun targetDir(ctx: Context): File {
        val ext = ctx.getExternalFilesDir(null)
        val base = if (ext != null && (ext.exists() || ext.mkdirs())) ext else ctx.filesDir
        return File(base, "Jarvis")
    }

    private fun isUserData(rel: String): Boolean {
        if (rel.startsWith("config/") && !rel.endsWith(".py")) return true
        if (rel.startsWith("memory/") && !rel.endsWith(".py")) return true
        if (rel.startsWith("agents/")) return true
        if (rel.startsWith("plugins/") && rel != "plugins/__init__.py" && rel != "plugins/_template.py") return true
        return false
    }

    fun install(ctx: Context): File {
        val dir = targetDir(ctx)
        dir.mkdirs()
        val stamp = File(dir, ".tvshim_version")
        val version = BuildConfig.VERSION_CODE.toString()
        if (stamp.exists() && stamp.readText().trim() == version && File(dir, "main.py").exists()) return dir

        val root = dir.canonicalPath + File.separator
        ctx.assets.open("jarvis.zip").use { raw ->
            ZipInputStream(raw.buffered()).use { zin ->
                var e = zin.nextEntry
                while (e != null) {
                    val rel = e.name.replace('\\', '/').trimStart('/')
                    val out = File(dir, rel)
                    if (!out.canonicalPath.startsWith(root)) { e = zin.nextEntry; continue }   // zip-slip guard
                    if (e.isDirectory) {
                        out.mkdirs()
                    } else if (!(out.exists() && isUserData(rel))) {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { zin.copyTo(it) }
                    }
                    e = zin.nextEntry
                }
            }
        }
        stamp.writeText(version)
        return dir
    }
}
