package com.jarvis.tv

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.widget.TextView

/**
 * Look shared by the Service menu (MenuPanel) and the plugin settings pages (PluginSettingsActivity):
 * one set of rows, section headings and "＋ На главный" chips, so every menu level looks the same.
 * With a screen skin (plugin screen_style) the colours come from its theme, otherwise from the classic
 * cyan HUD palette.
 */
object MenuKit {
    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    val accent: Int get() = Skin.theme()?.accent ?: Color.rgb(0, 214, 255)
    val muted: Int get() = Skin.theme()?.muted ?: Color.rgb(140, 175, 190)
    val ink: Int get() = Skin.theme()?.text ?: Color.rgb(222, 244, 250)
    val surface: Int get() = Skin.theme()?.surface ?: Color.rgb(10, 32, 48)
    val card: Int get() = Skin.theme()?.bg ?: Color.rgb(4, 15, 24)
    private val radius: Int get() = if (Skin.theme() != null) 16 else 12

    fun alpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    fun shape(ctx: Context, fill: Int, stroke: Int, strokeDp: Float, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(ctx, radiusDp).toFloat()
            if (strokeDp > 0f) setStroke(maxOf(1, (strokeDp * ctx.resources.displayMetrics.density).toInt()), stroke)
        }

    /** A menu row / pill. Focus (remote) = accent ring, so the current position is always obvious. */
    fun button(ctx: Context, text: CharSequence, startAligned: Boolean = true, onClick: () -> Unit): TextView {
        val ac = accent
        val tv = TextView(ctx)
        tv.text = text
        tv.textSize = 15f
        tv.setTextColor(ink)
        tv.gravity = if (startAligned) Gravity.START or Gravity.CENTER_VERTICAL else Gravity.CENTER
        tv.setPadding(dp(ctx, 18), dp(ctx, 8), dp(ctx, 18), dp(ctx, 8))
        tv.isFocusable = true
        tv.isClickable = true
        val st = StateListDrawable()
        st.addState(intArrayOf(android.R.attr.state_focused), shape(ctx, alpha(ac, 0x40), ac, 3f, radius))
        st.addState(intArrayOf(android.R.attr.state_pressed), shape(ctx, alpha(ac, 0x70), ac, 2f, radius))
        st.addState(intArrayOf(), shape(ctx, surface, alpha(ac, 0x40), 1f, radius))
        tv.background = st
        tv.setOnClickListener { onClick() }
        return tv
    }

    /** The "＋ На главный" / "✔ На главном" switch that sits next to an item. */
    fun pinChip(ctx: Context, pinned: Boolean, onClick: () -> Unit): TextView {
        val ac = accent
        val tv = TextView(ctx)
        tv.text = if (pinned) "✔ На главном" else "＋ На главный"
        tv.textSize = 13f
        tv.setTextColor(if (pinned) ac else muted)
        tv.gravity = Gravity.CENTER
        tv.setPadding(dp(ctx, 10), dp(ctx, 6), dp(ctx, 10), dp(ctx, 6))
        tv.isFocusable = true
        tv.isClickable = true
        val st = StateListDrawable()
        st.addState(intArrayOf(android.R.attr.state_focused), shape(ctx, alpha(ac, 0x40), ac, 3f, radius))
        st.addState(intArrayOf(android.R.attr.state_pressed), shape(ctx, alpha(ac, 0x70), ac, 2f, radius))
        st.addState(intArrayOf(),
            if (pinned) shape(ctx, alpha(ac, 0x30), ac, 1.5f, radius) else shape(ctx, Color.TRANSPARENT, alpha(ac, 0x30), 1f, radius))
        tv.background = st
        tv.setOnClickListener { onClick() }
        return tv
    }

    /** Title (bold, a bit larger) + grey caption + optional accent status line. */
    fun lines(title: String, sub: String = "", status: String = ""): CharSequence {
        val s = SpannableStringBuilder(title)
        s.setSpan(StyleSpan(Typeface.BOLD), 0, title.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        s.setSpan(RelativeSizeSpan(1.12f), 0, title.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (sub.isNotEmpty()) {
            val from = s.length + 1
            s.append("\n").append(sub)
            s.setSpan(RelativeSizeSpan(0.82f), from, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            s.setSpan(ForegroundColorSpan(muted), from, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        if (status.isNotEmpty()) {
            val from = s.length + 1
            s.append("\n").append(status)
            s.setSpan(RelativeSizeSpan(0.82f), from, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            s.setSpan(ForegroundColorSpan(accent), from, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return s
    }

    fun note(ctx: Context, text: String): TextView = TextView(ctx).apply {
        this.text = text
        textSize = 13f
        setTextColor(muted)
        setPadding(dp(ctx, 4), dp(ctx, 4), dp(ctx, 4), dp(ctx, 8))
    }

    /** Small caps heading that groups the rows below it. */
    fun heading(ctx: Context, text: String): TextView = TextView(ctx).apply {
        this.text = text
        textSize = 12f
        isAllCaps = true
        letterSpacing = 0.12f
        setTextColor(accent)
        setTypeface(typeface, Typeface.BOLD)
        setPadding(dp(ctx, 6), dp(ctx, 16), dp(ctx, 6), dp(ctx, 6))
    }
}
