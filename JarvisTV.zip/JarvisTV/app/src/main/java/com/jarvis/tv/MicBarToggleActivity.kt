package com.jarvis.tv

/** Bottom strip + "microphone always on": first press turns it on, second press turns it off. */
class MicBarToggleActivity : OverlayActivity() {
    override val continuousMode: Boolean = true
}
