package com.jarvis.tv

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

/** Completely invisible "press the core": listens for ONE command; a second press stops it. */
class MicHiddenActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!VoiceLoop.hasPermission()) {
            Toast.makeText(this, "JARVIS: нет разрешения на микрофон", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, MainActivity::class.java))
        } else {
            JarvisService.start(this)
            if (VoiceLoop.continuous) VoiceLoop.setContinuous(false) else VoiceLoop.listenOnce()
        }
        finish()
    }
}
