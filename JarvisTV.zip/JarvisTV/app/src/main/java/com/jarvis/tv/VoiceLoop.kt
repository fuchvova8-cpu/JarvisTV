package com.jarvis.tv

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Speech in through the system recognizer — the only way an app can hear the remote's own microphone —
 * handed to JARVIS as a typed command. Two modes: one phrase, or "always on" (restarts by itself, and waits
 * for JARVIS to finish talking so it never hears itself). Main thread only.
 *
 * While it listens, our own AudioRecord (USB / Bluetooth mic into Gemini Live) is released: Android 9 gives
 * the microphone to one capturer at a time.
 */
object VoiceLoop {
    enum class S { IDLE, LISTENING, WAITING }

    private val main = Handler(Looper.getMainLooper())
    private val ctx: Context get() = Bridge.app

    var state = S.IDLE
        private set
    var continuous = false
        private set
    var rms = 0f
        private set

    val stateListeners = CopyOnWriteArrayList<() -> Unit>()
    val levelListeners = CopyOnWriteArrayList<() -> Unit>()
    val partialListeners = CopyOnWriteArrayList<(String) -> Unit>()

    private var rec: SpeechRecognizer? = null
    private var onFinished: (() -> Unit)? = null
    private var errStreak = 0
    private var gen = 0                 // bumped on every start/abort, so stale callbacks do nothing

    fun hasPermission(): Boolean =
        ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun set(s: S) {
        state = s
        for (l in stateListeners) l()
    }

    private fun say(msg: String) = Bridge.log("SYS: $msg")

    private fun toast(msg: String) {
        try { Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show() } catch (_: Throwable) {}
    }

    // ── public ──
    /** One phrase; [finished] is called when it is over (for any reason). */
    fun listenOnce(finished: (() -> Unit)? = null) {
        if (continuous) {            // pressing the button while "always on" switches it off
            setContinuous(false)
            finished?.invoke()
            return
        }
        if (state != S.IDLE) {
            // a second press: stop
            abortListening()
            finished?.invoke()
            return
        }
        onFinished = finished
        begin()
    }

    fun setContinuous(on: Boolean) {
        if (continuous == on) return
        continuous = on
        errStreak = 0
        say(if (on) "Микрофон постоянно: ВКЛ" else "Микрофон постоянно: ВЫКЛ")
        toast(if (on) "JARVIS: микрофон постоянно ВКЛ" else "JARVIS: микрофон постоянно ВЫКЛ")
        if (on) {
            try { JarvisService.start(ctx) } catch (_: Throwable) {}
            if (state == S.IDLE) begin()
        } else {
            abortListening()
        }
        set(state)
    }

    /** Stop listening now; leaves "always on" as it is unless [alsoContinuous]. */
    fun abort(alsoContinuous: Boolean = true) {
        if (alsoContinuous && continuous) { continuous = false; say("Микрофон постоянно: ВЫКЛ") }
        abortListening()
    }

    fun cancelOneShot() {
        if (continuous) return
        onFinished = null
        abortListening()
    }

    // ── internals ──
    private fun abortListening() {
        gen++
        try { rec?.cancel() } catch (_: Throwable) {}
        try { rec?.destroy() } catch (_: Throwable) {}
        rec = null
        if (!continuous) Bridge.micPaused = false
        val wasIdle = state == S.IDLE
        set(S.IDLE)
        if (!wasIdle) finishOnce()
    }

    private fun finishOnce() {
        val f = onFinished
        onFinished = null
        f?.invoke()
    }

    private fun begin() {
        if (state != S.IDLE) return
        if (!hasPermission()) {
            say("Нет разрешения на микрофон — откройте JARVIS и разрешите")
            finishOnce()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            say("На ТВ нет службы распознавания речи (приложение Google)")
            toast("Нет службы распознавания речи")
            if (continuous) continuous = false
            finishOnce()
            return
        }
        val my = ++gen
        // let go of our own capture first, then give the system a moment to take the mic
        Bridge.micPaused = true
        set(S.LISTENING)
        try { rec?.destroy() } catch (_: Throwable) {}
        rec = null
        main.postDelayed({ if (my == gen) startNow(my, 2) }, 450)
    }

    private fun startNow(my: Int, retries: Int) {
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { Bridge.state("LISTENING") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {
                rms = rmsdB
                Bridge.level((rmsdB / 12f).coerceIn(0f, 1f))
                for (l in levelListeners) l()
            }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) for (l in partialListeners) l(t)
            }
            override fun onResults(results: Bundle?) {
                if (my != gen) return
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                try { r.destroy() } catch (_: Throwable) {}
                if (rec === r) rec = null
                if (t.isNullOrBlank()) { afterError(my, SpeechRecognizer.ERROR_NO_MATCH, retries); return }
                errStreak = 0
                deliver(t)
                if (continuous) waitForJarvis(my) else { set(S.IDLE); Bridge.micPaused = false; finishOnce() }
            }
            override fun onError(error: Int) {
                if (my != gen) return
                try { r.destroy() } catch (_: Throwable) {}
                if (rec === r) rec = null
                afterError(my, error, retries)
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        try {
            r.startListening(i)
        } catch (e: Throwable) {
            say("startListening: ${e.javaClass.simpleName}: ${e.message}")
            afterError(my, SpeechRecognizer.ERROR_CLIENT, 0)
        }
    }

    private fun afterError(my: Int, error: Int, retries: Int) {
        if (my != gen) return
        val transient = error == SpeechRecognizer.ERROR_NETWORK || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ||
            error == SpeechRecognizer.ERROR_AUDIO || error == SpeechRecognizer.ERROR_SERVER ||
            error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error == SpeechRecognizer.ERROR_CLIENT
        val silent = error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
        if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
            say("Нет разрешения на микрофон")
            continuous = false
            stopAll()
            return
        }
        if (!silent && transient && retries > 0) {
            val my2 = ++gen
            main.postDelayed({ if (my2 == gen) startNow(my2, retries - 1) }, 900)
            return
        }
        if (continuous) {
            if (!silent) errStreak++
            if (errStreak >= 8) {
                say("Слишком много ошибок подряд (код $error) — постоянный микрофон выключен")
                toast("Постоянный микрофон выключен: ошибки распознавания (код $error)")
                continuous = false
                stopAll()
                return
            }
            val my2 = ++gen
            main.postDelayed({ if (my2 == gen) startNow(my2, 2) }, if (silent) 250L else 1500L)
            return
        }
        val why = when (error) {
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "не расслышал, нажмите ещё раз"
            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER ->
                "голосовой сервис ТВ не ответил (код $error)"
            else -> "ошибка распознавания (код $error)"
        }
        toast(why)
        stopAll()
    }

    private fun stopAll() {
        gen++
        try { rec?.destroy() } catch (_: Throwable) {}
        rec = null
        if (!continuous) Bridge.micPaused = false
        set(S.IDLE)
        Bridge.state("IDLE")
        finishOnce()
    }

    /** The recognised phrase goes to JARVIS like typed text. Retries while the core is still booting. */
    private fun deliver(text: String, attempt: Int = 0) {
        if (attempt == 0) Bridge.log("You: $text")
        Py.ask("text_command", text) { ok ->
            if (ok != "True" && attempt < 20) main.postDelayed({ deliver(text, attempt + 1) }, 1500)
        }
    }

    /** "Always on": do not listen while JARVIS thinks or speaks — it would hear itself. */
    private fun waitForJarvis(my: Int) {
        set(S.WAITING)
        val t0 = System.currentTimeMillis()
        var quiet = 0
        val poll = object : Runnable {
            override fun run() {
                if (my != gen || !continuous) return
                val busy = Bridge.curState == "THINKING" || Bridge.curState == "SPEAKING"
                quiet = if (busy) 0 else quiet + 1
                val waited = System.currentTimeMillis() - t0
                if ((waited > 2500 && quiet >= 3) || waited > 120_000) {
                    set(S.IDLE)
                    begin()
                } else {
                    main.postDelayed(this, 500)
                }
            }
        }
        main.postDelayed(poll, 1500)
    }
}
