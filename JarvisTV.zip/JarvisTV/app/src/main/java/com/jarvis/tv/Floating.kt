package com.jarvis.tv

import android.content.Context
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import org.json.JSONObject

/** Look of the microphone, result numbers and results-window buttons, from the plugin ("widgets"); empty = theme. */
object Widgets {
    fun mic(ctx: Context, fg: Int, accent: Int): Pair<MicIcon, Int> {
        val w = Skin.widgets()
        val d = ctx.resources.displayMetrics.density
        val icon = Skin.color(w.optString("micIcon"), fg)
        val active = Skin.color(w.optString("micActive"), accent)
        val plate = Skin.color(w.optString("micPlate"), Hud.withAlpha(accent, 0x30))
        val size = (w.optDouble("micSize", 44.0).coerceIn(24.0, 120.0) * d).toInt()
        return MicIcon(ctx, icon, active, plate) to size
    }

    /** Style for the results-window buttons in the format Skin.styleButton reads. */
    fun buttonStyle(): JSONObject {
        val w = Skin.widgets()
        val e = JSONObject()
        fun copy(src: String, dst: String) { val v = w.optString(src); if (v.isNotEmpty()) e.put(dst, v) }
        copy("btnFill", "fill"); copy("btnStroke", "stroke"); copy("btnText", "textColor"); copy("btnFocus", "focusColor")
        if (w.has("btnRadius")) e.put("radius", w.optInt("btnRadius"))
        if (w.has("btnStrokeWidth")) e.put("strokeWidth", w.optDouble("btnStrokeWidth"))
        return e
    }

    /** Applies the style and the optional text size to a results-window button. */
    fun styleButton(tv: TextView, th: Skin.Theme) {
        Skin.styleButton(tv, th, buttonStyle())
        val ts = Skin.widgets().optDouble("btnTextSize", 0.0)
        if (ts > 0.0) tv.textSize = ts.toFloat()
    }

    /** Button height in px, or WRAP_CONTENT when "btnH" is 0. */
    fun buttonHeight(ctx: Context): Int {
        val h = Skin.widgets().optDouble("btnH", 0.0)
        return if (h > 0.0) (h * ctx.resources.displayMetrics.density).toInt() else ViewGroup.LayoutParams.WRAP_CONTENT
    }
}

/** Number in the corner of a poster: the same plate in the overlay and in the JARVIS results window. */
object Badge {
    private fun h(ctx: Context): Float = Skin.widgets().optDouble("badgeSize", 22.0).coerceIn(12.0, 60.0).toFloat() * ctx.resources.displayMetrics.density

    fun make(ctx: Context, n: Int, fill: Int, ink: Int): TextView {
        val d = ctx.resources.displayMetrics.density
        val w = Skin.widgets()
        val height = h(ctx)
        return TextView(ctx).apply {
            text = n.toString()
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, height * 0.55f)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(Skin.color(w.optString("badgeInk"), ink))
            gravity = Gravity.CENTER
            minWidth = height.toInt()
            setPadding((6 * d).toInt(), 0, (6 * d).toInt(), 0)
            background = Skin.roundRect(ctx, Skin.color(w.optString("badgeFill"), fill), 0, 0f, (height / d / 2f).toInt())
        }
    }

    fun params(ctx: Context): FrameLayout.LayoutParams {
        val d = ctx.resources.displayMetrics.density
        return FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, h(ctx).toInt(), Gravity.TOP or Gravity.START)
            .apply { setMargins((6 * d).toInt(), (6 * d).toInt(), 0, 0) }
    }
}

/**
 * Buttons that float over a panel and can be dragged anywhere with the mouse.
 * The position is kept as a fraction (0..1) of the free room inside the panel, so it follows the panel when it
 * grows (results appear) and is saved per [prefix] (one set of positions per screen) in the layout file.
 * A click still works: only a move longer than a few dp drags.
 */
class Floating(private val host: FrameLayout, private val prefix: String) {
    private class Item(val v: View, val defX: (Int, Int) -> Int, val defY: (Int, Int) -> Int)

    private val items = LinkedHashMap<String, Item>()
    private val saved = HashMap<String, FloatArray?>()     // read the file once, not on every layout pass
    private var dragging = false
    private var slot = ""

    private fun keyOf(id: String) = if (slot.isEmpty()) "$prefix.$id" else "$prefix.$id.$slot"

    /** Separate saved positions for different states of the same panel (e.g. "" = no results yet, "results"). */
    fun setSlot(s: String) {
        if (s == slot) return
        slot = s
        place()
    }
    private val d = host.resources.displayMetrics.density

    init {
        host.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob ->
            if (r - l != orr - ol || b - t != ob - ot) place()
        }
    }

    /** [defX]/[defY]: where the button sits until it is moved, in pixels from (panel size, button size). */
    fun add(id: String, v: View, w: Int, h: Int, defX: (Int, Int) -> Int, defY: (Int, Int) -> Int) {
        items[id] = Item(v, defX, defY)
        v.elevation = 20 * d            // only for z-order: no shadow (shadows clipped by the panel gave dark corners)
        v.outlineProvider = null
        host.addView(v, FrameLayout.LayoutParams(w, h, Gravity.TOP or Gravity.START))
        v.setOnTouchListener(dragger(id))
        v.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob ->
            if (r - l != orr - ol || b - t != ob - ot) place()      // a layout pass alone (text changing) must not move the button
        }
    }

    fun place() {
        if (host.width == 0 || dragging) return
        for ((id, item) in items) {
            val v = item.v
            if (v.width == 0) continue
            val rx = (host.width - v.width).coerceAtLeast(0).toFloat()
            val ry = (host.height - v.height).coerceAtLeast(0).toFloat()
            val key = keyOf(id)
            if (!saved.containsKey(key)) saved[key] = Skin.floatPos(key)
            val p = saved[key]
            v.translationX = if (p != null) (p[0] * rx).coerceIn(0f, rx) else item.defX(host.width, v.width).toFloat().coerceIn(0f, rx)
            v.translationY = if (p != null) (p[1] * ry).coerceIn(0f, ry) else item.defY(host.height, v.height).toFloat().coerceIn(0f, ry)
        }
    }

    private fun dragger(id: String): View.OnTouchListener {
        var x0 = 0f
        var y0 = 0f
        var tx0 = 0f
        var ty0 = 0f
        var moved = false
        val slop = 8 * d
        return View.OnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    x0 = e.rawX; y0 = e.rawY
                    tx0 = v.translationX; ty0 = v.translationY
                    moved = false
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - x0
                    val dy = e.rawY - y0
                    if (!moved && Math.hypot(dx.toDouble(), dy.toDouble()) > slop) {
                        moved = true
                        dragging = true
                        v.parent?.requestDisallowInterceptTouchEvent(true)
                        val c = MotionEvent.obtain(e)
                        c.action = MotionEvent.ACTION_CANCEL      // the button must not "click" after a drag
                        v.onTouchEvent(c)
                        c.recycle()
                    }
                    if (moved) {
                        v.translationX = (tx0 + dx).coerceIn(0f, (host.width - v.width).coerceAtLeast(0).toFloat())
                        v.translationY = (ty0 + dy).coerceIn(0f, (host.height - v.height).coerceAtLeast(0).toFloat())
                        true
                    } else false
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        moved = false
                        dragging = false
                        val rx = (host.width - v.width).coerceAtLeast(1).toFloat()
                        val ry = (host.height - v.height).coerceAtLeast(1).toFloat()
                        val fx = v.translationX / rx
                        val fy = v.translationY / ry
                        saved[keyOf(id)] = floatArrayOf(fx, fy)
                        Skin.saveFloatPos(keyOf(id), fx, fy)
                        true
                    } else false
                }
                MotionEvent.ACTION_CANCEL -> { moved = false; dragging = false; false }
                else -> false
            }
        }
    }
}

/**
 * Remote navigation between the floating controls (microphone, buttons — they can be dragged anywhere) and the
 * results (tiles / list). Directions are decided by where the views really are on the screen, so it keeps working
 * wherever the controls were moved. Returns true when the key was handled.
 */
object PadNav {
    private fun cx(v: View): Int { val l = IntArray(2); v.getLocationOnScreen(l); return l[0] + v.width / 2 }
    private fun cy(v: View): Int { val l = IntArray(2); v.getLocationOnScreen(l); return l[1] + v.height / 2 }

    private fun inside(root: View, v: View?): Boolean {
        var p: View? = v
        while (p != null) { if (p === root) return true; p = p.parent as? View }
        return false
    }

    private fun cells(root: View, out: MutableList<View>) {
        if (root.visibility != View.VISIBLE) return
        if (root is ViewGroup) {
            for (i in 0 until root.childCount) {
                val c = root.getChildAt(i)
                if (c.isFocusable && c.visibility == View.VISIBLE && c.width > 0 && c.getGlobalVisibleRect(android.graphics.Rect())) out.add(c)
                else if (c is ViewGroup) cells(c, out)
            }
        }
    }

    /** Best view from [cands] in the direction of [key] as seen from [from] (nearest along the axis, close to its line). */
    private fun pick(from: View, key: Int, cands: List<View>): View? {
        val fx = cx(from)
        val fy = cy(from)
        var best: View? = null
        var bestScore = Long.MAX_VALUE
        for (c in cands) {
            if (c === from) continue
            val dx = cx(c) - fx
            val dy = cy(c) - fy
            val along = when (key) {
                KeyEvent.KEYCODE_DPAD_LEFT -> -dx
                KeyEvent.KEYCODE_DPAD_RIGHT -> dx
                KeyEvent.KEYCODE_DPAD_UP -> -dy
                else -> dy
            }
            if (along <= 0) continue
            val cross = if (key == KeyEvent.KEYCODE_DPAD_LEFT || key == KeyEvent.KEYCODE_DPAD_RIGHT) Math.abs(dy) else Math.abs(dx)
            val score = along.toLong() + 2L * cross
            if (score < bestScore) { bestScore = score; best = c }
        }
        return best
    }

    fun handle(key: Int, focus: View?, controls: List<View>, gridRoots: List<View?>): Boolean {
        if (key != KeyEvent.KEYCODE_DPAD_UP && key != KeyEvent.KEYCODE_DPAD_DOWN &&
            key != KeyEvent.KEYCODE_DPAD_LEFT && key != KeyEvent.KEYCODE_DPAD_RIGHT) return false
        val ctl = controls.filter { it.visibility == View.VISIBLE && it.width > 0 }
        if (ctl.isEmpty() || focus == null) return false
        val roots = gridRoots.filterNotNull()
        if (ctl.any { it === focus }) {
            val cand = ArrayList<View>(ctl)
            for (r in roots) cells(r, cand)
            val t = pick(focus, key, cand)
            if (t != null) { t.requestFocus(); }
            return true          // from a control the focus never leaves by the system search
        }
        val gr = roots.firstOrNull { inside(it, focus) } ?: return false
        val sys = focus.focusSearch(
            when (key) {
                KeyEvent.KEYCODE_DPAD_UP -> View.FOCUS_UP
                KeyEvent.KEYCODE_DPAD_DOWN -> View.FOCUS_DOWN
                KeyEvent.KEYCODE_DPAD_LEFT -> View.FOCUS_LEFT
                else -> View.FOCUS_RIGHT
            }
        )
        if (sys != null && inside(gr, sys)) return false          // inside the results the usual navigation works
        val t = pick(focus, key, ctl) ?: return false
        t.requestFocus()
        return true
    }
}
