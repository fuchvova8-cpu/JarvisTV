package com.jarvis.tv

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.ui.PlayerView
import com.chaquo.python.Python
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

/** Calls into tvshim.entry off the UI thread. */
object Py {
    private val ui = Handler(Looper.getMainLooper())

    fun call(fn: String, vararg a: Any?) {
        thread(name = "py-$fn") {
            try {
                Python.getInstance().getModule("tvshim.entry").callAttr(fn, *a)
            } catch (t: Throwable) {
                Bridge.log("ERR: $fn: ${t.message}")
            }
        }
    }

    fun ask(fn: String, vararg a: Any?, done: (String) -> Unit) {
        thread(name = "py-$fn") {
            val out = try {
                Python.getInstance().getModule("tvshim.entry").callAttr(fn, *a).toString()
            } catch (t: Throwable) {
                ""
            }
            ui.post { done(out) }
        }
    }
}

class MainActivity : Activity(), UiListener {
    private val main = Handler(Looper.getMainLooper())

    private lateinit var hud: HudView
    private lateinit var nameView: TextView
    private lateinit var stateView: TextView
    private lateinit var clockView: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var logText: TextView
    private val logBuf = SpannableStringBuilder()
    private lateinit var contentTitle: TextView
    private lateinit var contentText: TextView
    private lateinit var contentPanel: LinearLayout
    private lateinit var input: EditText
    private lateinit var muteBtn: Button

    private lateinit var confirmPanel: LinearLayout
    private lateinit var confirmTitle: TextView
    private lateinit var confirmDetail: TextView

    private lateinit var quizPanel: LinearLayout
    private lateinit var quizHead: TextView
    private lateinit var quizQ: TextView
    private lateinit var quizOptions: LinearLayout
    private lateinit var quizInput: EditText
    private lateinit var quizSend: Button
    private lateinit var quizNote: TextView
    private lateinit var quizNext: Button
    private var quizLast = false

    private lateinit var videoLayer: FrameLayout
    private lateinit var playerView: PlayerView
    private lateinit var imageView: ImageView
    private lateinit var videoTitle: TextView
    private var player: ExoPlayer? = null
    private var showingImage = false

    private var keyDialog: AlertDialog? = null
    private var started = false

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ═══════════════ construction ═══════════════
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(buildUi())
        ensurePermissionsThenStart()
    }

    private fun box(fill: Int, stroke: Int, radius: Int = 10): GradientDrawable = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(2), stroke)
    }

    private fun btn(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.textSize = 14f
        b.minWidth = 0
        b.minimumWidth = 0
        b.setPadding(dp(14), dp(6), dp(14), dp(6))
        val st = StateListDrawable()
        st.addState(intArrayOf(android.R.attr.state_focused), box(Color.rgb(0, 110, 150), Color.rgb(0, 230, 255)))
        st.addState(intArrayOf(android.R.attr.state_pressed), box(Color.rgb(0, 140, 190), Color.WHITE))
        st.addState(intArrayOf(), box(Color.argb(210, 8, 28, 42), Color.rgb(0, 95, 125)))
        b.background = st
        b.setOnClickListener { onClick() }
        return b
    }

    private fun label(sizeSp: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView = TextView(this).apply {
        textSize = sizeSp
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun panelBg(): GradientDrawable = box(Color.argb(190, 4, 16, 26), Color.rgb(0, 80, 105))

    private fun buildUi(): View {
        val sw = resources.displayMetrics.widthPixels
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        hud = HudView(this)
        root.addView(hud, FrameLayout.LayoutParams(-1, -1))

        // top bar
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(24), dp(14), dp(24), 0) }
        nameView = label(20f, Color.rgb(0, 214, 255), true).apply { text = "JARVIS" }
        stateView = label(14f, Color.rgb(160, 200, 215)).apply { text = "SLEEPING"; setPadding(dp(16), dp(6), dp(16), 0) }
        clockView = label(16f, Color.rgb(160, 200, 215))
        top.addView(nameView)
        top.addView(stateView, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(clockView)
        root.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        // log (left)
        logText = label(13f, Color.rgb(190, 225, 235))
        logText.setPadding(dp(12), dp(8), dp(12), dp(8))
        logScroll = ScrollView(this).apply {
            background = panelBg()
            isFocusable = true
            addView(logText)
        }
        root.addView(logScroll, FrameLayout.LayoutParams((sw * 0.36f).toInt(), -1, Gravity.START).apply {
            topMargin = dp(56); bottomMargin = dp(76); leftMargin = dp(16)
        })

        // content (right)
        contentTitle = label(15f, Color.rgb(255, 176, 40), true)
        contentText = label(13f, Color.rgb(210, 235, 245))
        contentPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            addView(contentTitle)
            addView(contentText)
        }
        val cScroll = ScrollView(this).apply {
            background = panelBg()
            isFocusable = true
            addView(contentPanel)
        }
        cScroll.visibility = View.GONE
        contentScrollRef = cScroll
        root.addView(cScroll, FrameLayout.LayoutParams((sw * 0.30f).toInt(), -1, Gravity.END).apply {
            topMargin = dp(56); bottomMargin = dp(76); rightMargin = dp(16)
        })

        // bottom bar
        input = EditText(this).apply {
            hint = "Написать JARVIS…"
            setHintTextColor(Color.rgb(90, 130, 145))
            setTextColor(Color.WHITE)
            textSize = 15f
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEND
            background = box(Color.argb(210, 6, 22, 34), Color.rgb(0, 95, 125))
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setSingleLine(true)
            setOnEditorActionListener { _, _, _ -> sendTyped(); true }
        }
        muteBtn = btn("Микрофон: вкл") { Py.call("toggle_mute") }
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(12))
            addView(input, LinearLayout.LayoutParams(0, dp(44), 1f))
            addView(btn("Отправить") { sendTyped() })
            addView(btn("Голос") { startVoice() })
            addView(muteBtn)
            addView(btn("Стоп") { Py.call("interrupt") })
            addView(btn("Плагины") { showPlugins() })
            addView(btn("Меню") { showSettings() })
        }
        root.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        // confirm
        confirmTitle = label(20f, Color.rgb(255, 176, 40), true)
        confirmDetail = label(15f)
        confirmPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(Color.argb(240, 20, 12, 4), Color.rgb(255, 176, 40))
            setPadding(dp(24), dp(18), dp(24), dp(18))
            addView(confirmTitle)
            addView(confirmDetail)
            val row = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(14), 0, 0) }
            row.addView(btn("Да, выполнить") { Py.call("confirm_answer", true); onConfirmHide() })
            row.addView(btn("Отмена") { Py.call("confirm_answer", false); onConfirmHide() })
            addView(row)
            visibility = View.GONE
        }
        root.addView(confirmPanel, FrameLayout.LayoutParams((sw * 0.55f).toInt(), -2, Gravity.CENTER))

        // quiz
        quizHead = label(13f, Color.rgb(0, 214, 255), true)
        quizQ = label(20f)
        quizOptions = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        quizInput = EditText(this).apply {
            setTextColor(Color.WHITE); textSize = 16f; inputType = InputType.TYPE_CLASS_TEXT; setSingleLine(true)
            background = box(Color.argb(210, 6, 22, 34), Color.rgb(0, 95, 125)); setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        quizSend = btn("Ответить") { submitQuiz(quizInput.text.toString()) }
        quizNote = label(15f, Color.rgb(255, 176, 40))
        quizNext = btn("Далее") { Py.call("quiz_next") }
        quizPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(Color.argb(245, 4, 16, 26), Color.rgb(0, 214, 255))
            setPadding(dp(24), dp(18), dp(24), dp(18))
            addView(quizHead); addView(quizQ); addView(quizOptions); addView(quizInput); addView(quizSend)
            addView(quizNote); addView(quizNext)
            visibility = View.GONE
        }
        root.addView(quizPanel, FrameLayout.LayoutParams((sw * 0.62f).toInt(), -2, Gravity.CENTER))

        // video / image
        playerView = PlayerView(this).apply { useController = false }
        imageView = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; visibility = View.GONE }
        videoTitle = label(14f, Color.WHITE)
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(8), dp(16), dp(14))
            addView(btn("-10 c") { seekBy(-10) })
            addView(btn("Пауза/Играть") { togglePause() })
            addView(btn("+10 c") { seekBy(10) })
            addView(btn("Звук") { player?.let { it.volume = if (it.volume > 0f) 0f else 1f } })
            addView(btn("Закрыть") { onVideoClose() })
        }
        videoLayer = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(playerView, FrameLayout.LayoutParams(-1, -1))
            addView(imageView, FrameLayout.LayoutParams(-1, -1))
            addView(videoTitle, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { setMargins(dp(20), dp(12), 0, 0) })
            addView(controls, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
            visibility = View.GONE
        }
        root.addView(videoLayer, FrameLayout.LayoutParams(-1, -1))
        return root
    }

    private lateinit var contentScrollRef: ScrollView

    // ═══════════════ lifecycle ═══════════════
    private val clockTick = object : Runnable {
        override fun run() {
            clockView.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            main.postDelayed(this, 20_000)
        }
    }

    override fun onStart() {
        super.onStart()
        Bridge.appVisible = true
        Bridge.listener = this
        // catch up with what happened while the screen was away
        logBuf.clear()
        logText.text = ""
        for (l in Bridge.snapshotLog()) appendLog(l)
        onState(Bridge.curState)
        onMuted(Bridge.curMuted)
        if (Bridge.assistantName.isNotEmpty()) nameView.text = Bridge.assistantName.uppercase()
        if (Bridge.curText.isNotEmpty()) onContent(Bridge.curTitle, Bridge.curText)
        Bridge.curConfirm?.let { onConfirm(it.first, it.second) }
        if (Bridge.curQuiz.isNotEmpty()) onQuiz(Bridge.curQuiz)
        if (Bridge.promptingKey) onPromptKey()
        clockTick.run()
    }

    override fun onStop() {
        Bridge.appVisible = false
        Bridge.listener = null
        main.removeCallbacks(clockTick)
        super.onStop()
    }

    override fun onDestroy() {
        player?.release(); player = null
        super.onDestroy()
    }

    private fun ensurePermissionsThenStart() {
        val need = ArrayList<String>()
        for (p in arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p)
        }
        if (need.isEmpty()) startCore() else requestPermissions(need.toTypedArray(), 7)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Bridge.log("SYS: Нет доступа к микрофону — работает только текст и кнопка «Голос».")
        }
        startCore()
        if (code == 8 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            VoiceLoop.setContinuous(true)
        }
    }

    private fun startCore() {
        if (started) return
        started = true
        JarvisService.start(this)
    }

    // ═══════════════ UiListener ═══════════════
    private fun appendLog(line: String) {
        val color = when {
            line.startsWith("You:") || line.startsWith("YOU:") -> Color.rgb(0, 214, 255)
            line.startsWith("SYS:") -> Color.rgb(130, 160, 175)
            line.startsWith("ERR:") -> Color.rgb(255, 100, 100)
            else -> Color.rgb(255, 196, 90)
        }
        val start = logBuf.length
        logBuf.append(line).append('\n')
        logBuf.setSpan(ForegroundColorSpan(color), start, logBuf.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (logBuf.length > 14000) logBuf.delete(0, logBuf.length - 10000)
        logText.text = logBuf
        logScroll.post { logScroll.scrollTo(0, logText.height) }
    }

    override fun onLog(line: String) = appendLog(line)

    override fun onState(state: String) {
        stateView.text = state
        hud.state = state
    }

    override fun onContent(title: String, text: String) {
        contentTitle.text = title
        contentText.text = text
        contentScrollRef.visibility = View.VISIBLE
        contentScrollRef.scrollTo(0, 0)
    }

    override fun onMuted(muted: Boolean) {
        muteBtn.text = if (muted) "Микрофон: ВЫКЛ" else "Микрофон: вкл"
    }

    override fun onConfirm(title: String, detail: String) {
        confirmTitle.text = title
        confirmDetail.text = detail
        confirmPanel.visibility = View.VISIBLE
        confirmPanel.getChildAt(2)?.let { (it as ViewGroup).getChildAt(0)?.requestFocus() }
    }

    override fun onConfirmHide() { confirmPanel.visibility = View.GONE }

    override fun onReady(ready: Boolean, name: String) {
        nameView.text = name.uppercase()
        if (ready) {
            Bridge.promptingKey = false
            keyDialog?.dismiss()
        }
    }

    override fun onPromptKey() { showKeyDialog() }

    // ── quiz ──
    override fun onQuiz(json: String) {
        val o = JSONObject(json)
        quizHead.text = "${o.optString("topic").uppercase()}  ·  ${o.optInt("n")}/${o.optInt("total")}"
        quizQ.text = o.optString("question")
        quizNote.text = ""
        quizNext.visibility = View.GONE
        quizOptions.removeAllViews()
        val opts: JSONArray = o.optJSONArray("options") ?: JSONArray()
        if (opts.length() > 0) {
            quizInput.visibility = View.GONE
            quizSend.visibility = View.GONE
            for (i in 0 until opts.length()) {
                val text = opts.optString(i)
                quizOptions.addView(btn(text) { submitQuiz(text) })
            }
            quizOptions.getChildAt(0)?.requestFocus()
        } else {
            quizInput.setText("")
            quizInput.visibility = View.VISIBLE
            quizSend.visibility = View.VISIBLE
            quizInput.requestFocus()
        }
        quizPanel.visibility = View.VISIBLE
    }

    private fun submitQuiz(given: String) {
        quizSend.isEnabled = false
        for (i in 0 until quizOptions.childCount) quizOptions.getChildAt(i).isEnabled = false
        Py.ask("quiz_submit", given) { res ->
            try {
                val o = JSONObject(res)
                quizNote.text = o.optString("mark")
                quizLast = o.optBoolean("last")
                quizNext.text = if (quizLast) "Завершить" else "Далее"
                quizNext.visibility = View.VISIBLE
                quizNext.requestFocus()
            } catch (_: Throwable) {}
            quizSend.isEnabled = true
        }
    }

    override fun onQuizHide() { quizPanel.visibility = View.GONE }

    // ── video / image ──
    override fun onVideoOpen(src: String, title: String, muted: Boolean, audio: String) {
        onVideoClose()
        val factory = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Linux; Android 9; TV) AppleWebKit/537.36 Chrome/120 Safari/537.36")
            .setAllowCrossProtocolRedirects(true)
        val msf = DefaultMediaSourceFactory(factory)
        fun item(s: String) = MediaItem.fromUri(if (s.contains("://")) Uri.parse(s) else Uri.fromFile(File(s)))
        val video = msf.createMediaSource(item(src))
        val source = if (audio.isNotEmpty()) MergingMediaSource(video, msf.createMediaSource(item(audio))) else video
        val p = ExoPlayer.Builder(this).build()
        p.setMediaSource(source)
        p.volume = if (muted) 0f else 1f
        p.prepare()
        p.playWhenReady = true
        player = p
        playerView.player = p
        showingImage = false
        imageView.visibility = View.GONE
        playerView.visibility = View.VISIBLE
        videoTitle.text = title
        videoLayer.visibility = View.VISIBLE
    }

    override fun onImageOpen(path: String, title: String) {
        onVideoClose()
        imageView.setImageURI(Uri.fromFile(File(path)))
        showingImage = true
        playerView.visibility = View.GONE
        imageView.visibility = View.VISIBLE
        videoTitle.text = title
        videoLayer.visibility = View.VISIBLE
    }

    override fun onVideoClose() {
        player?.release(); player = null
        playerView.player = null
        showingImage = false
        videoLayer.visibility = View.GONE
    }

    override fun onVideoMute(muted: Boolean) { player?.volume = if (muted) 0f else 1f }
    override fun onVideoPause(paused: Boolean) { player?.playWhenReady = !paused }

    override fun onVideoSeek(seconds: Double, relative: Boolean) {
        val p = player ?: return
        val ms = (seconds * 1000).toLong()
        p.seekTo(if (relative) (p.currentPosition + ms).coerceAtLeast(0) else ms.coerceAtLeast(0))
    }

    override fun videoState(): String {
        val o = JSONObject()
        val p = player
        when {
            p != null -> {
                o.put("kind", "video")
                o.put("position", p.currentPosition / 1000.0)
                o.put("duration", if (p.duration > 0) p.duration / 1000.0 else 0.0)
                o.put("paused", !p.playWhenReady)
            }
            showingImage -> { o.put("kind", "image"); o.put("position", 0.0); o.put("duration", 0.0); o.put("paused", false) }
            else -> { o.put("kind", ""); o.put("position", 0.0); o.put("duration", 0.0); o.put("paused", false) }
        }
        return o.toString()
    }

    private fun seekBy(sec: Int) = onVideoSeek(sec.toDouble(), true)
    private fun togglePause() { player?.let { it.playWhenReady = !it.playWhenReady } }

    // ═══════════════ input ═══════════════
    private fun sendTyped() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        Bridge.log("You: $t")
        Py.call("text_command", t)
    }

    /** The system recognizer (also what the remote's microphone feeds) — see VoiceLoop. */
    private fun startVoice() = VoiceLoop.listenOnce()

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_SEARCH, KeyEvent.KEYCODE_ASSIST, KeyEvent.KEYCODE_VOICE_ASSIST -> { startVoice(); return true }
            KeyEvent.KEYCODE_MENU -> { showSettings(); return true }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE ->
                if (videoLayer.visibility == View.VISIBLE) { togglePause(); return true }
        }
        return super.onKeyDown(keyCode, event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            videoLayer.visibility == View.VISIBLE -> onVideoClose()
            quizPanel.visibility == View.VISIBLE -> Py.call("quiz_hide")
            confirmPanel.visibility == View.VISIBLE -> { Py.call("confirm_answer", false); onConfirmHide() }
            contentScrollRef.visibility == View.VISIBLE -> contentScrollRef.visibility = View.GONE
            else -> super.onBackPressed()     // leave the screen; JARVIS keeps running in the service
        }
    }

    // ═══════════════ dialogs ═══════════════
    private fun showKeyDialog() {
        if (keyDialog?.isShowing == true) return
        val et = EditText(this).apply {
            hint = "AIza…  (пусто = локальный режим)"
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
        }
        keyDialog = AlertDialog.Builder(this)
            .setTitle("Ключ Gemini API")
            .setMessage("Получить: aistudio.google.com/apikey. Набрать на пульте трудно — скопируйте ключ на ТВ " +
                "(например, из приложения-пульта) и нажмите «Из буфера».")
            .setView(et)
            .setCancelable(false)
            .setPositiveButton("Сохранить") { _, _ ->
                Bridge.promptingKey = false
                Py.call("save_key", et.text.toString().trim())
            }
            .setNeutralButton("Из буфера") { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                val v = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()?.trim().orEmpty()
                Bridge.promptingKey = false
                Py.call("save_key", v)
            }
            .create()
        keyDialog?.show()
    }

    private fun showSettings() {
        val items = arrayOf(
            "Ключ Gemini API", "Имена (ассистент / вы)", "Голос Gemini", "Плагины (вкл/выкл)",
            "Настройки плагинов", "Папка плагинов",
            if (VoiceLoop.continuous) "Микрофон постоянно: ВЫКЛЮЧИТЬ" else "Микрофон постоянно: ВКЛЮЧИТЬ",
            "Проверить ADB (ввод и экран)", "Автозапуск при включении ТВ", "Где лежит папка Jarvis", "Выйти полностью"
        )
        AlertDialog.Builder(this).setTitle("JARVIS — меню").setItems(items) { _, i ->
            when (i) {
                0 -> showKeyDialog()
                1 -> showNames()
                2 -> showVoices()
                3 -> showPlugins()
                4 -> showPluginSettings()
                5 -> showPluginDir()
                6 -> {
                    if (!VoiceLoop.hasPermission()) requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 8)
                    else VoiceLoop.setContinuous(!VoiceLoop.continuous)
                }
                7 -> checkAdb()
                8 -> toggleAutostart()
                9 -> AlertDialog.Builder(this).setTitle("Папка Jarvis")
                    .setMessage("${AssetInstaller.targetDir(this).absolutePath}\n\nСюда кладутся свои плагины (plugins/*.py), " +
                        "агенты, и здесь лежат config/ и memory/.").setPositiveButton("OK", null).show()
                10 -> {
                    VoiceLoop.abort()
                    stopService(Intent(this, JarvisService::class.java))
                    finishAffinity()
                    android.os.Process.killProcess(android.os.Process.myPid())
                }
            }
        }.show()
    }

    private fun showPluginSettings() {
        Py.ask("plugin_settings_list") { json ->
            val arr = try { JSONArray(json) } catch (_: Throwable) { JSONArray() }
            if (arr.length() == 0) {
                AlertDialog.Builder(this).setTitle("Настройки плагинов")
                    .setMessage("Пока ни у одного плагина нет страницы настроек (плагин может добавить её сам: SETTINGS, settings_items, settings_event).")
                    .setPositiveButton("OK", null).show()
                return@ask
            }
            val titles = Array(arr.length()) { arr.getJSONObject(it).optString("title") }
            AlertDialog.Builder(this).setTitle("Настройки плагинов").setItems(titles) { _, i ->
                val o = arr.getJSONObject(i)
                startActivity(Intent(this, PluginSettingsActivity::class.java)
                    .putExtra(PluginSettingsActivity.EXTRA_PLUGIN, o.optString("name"))
                    .putExtra(PluginSettingsActivity.EXTRA_TITLE, o.optString("title")))
            }.setNegativeButton("Закрыть", null).show()
        }
    }

    private fun showPluginDir() {
        Py.ask("plugin_dir_info") { json ->
            val o = try { JSONObject(json) } catch (_: Throwable) { JSONObject() }
            val custom = o.optString("custom")
            val et = EditText(this).apply { setText(custom); hint = o.optString("default"); setSingleLine(true) }
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(20), dp(8), dp(20), 0)
                addView(TextView(this@MainActivity).apply { text = "Сейчас: ${o.optString("current")}" })
                addView(et)
            }
            AlertDialog.Builder(this).setTitle("Папка плагинов").setView(col)
                .setPositiveButton("Применить") { _, _ -> applyPluginDir(et.text.toString()) }
                .setNeutralButton("Выбрать папку…") { _, _ ->
                    val start = java.io.File(custom).takeIf { it.isDirectory } ?: android.os.Environment.getExternalStorageDirectory()
                    pickFolder(start) { applyPluginDir(it) }
                }
                .setNegativeButton("Стандартная") { _, _ -> applyPluginDir("") }.show()
        }
    }

    private fun applyPluginDir(path: String) {
        Py.ask("plugin_dir_set", path) { msg ->
            AlertDialog.Builder(this).setTitle("Папка плагинов").setMessage(msg).setPositiveButton("OK", null).show()
        }
    }

    /** Small folder browser: OK on a row opens it, the first row goes up. */
    private fun pickFolder(start: java.io.File, onPick: (String) -> Unit) {
        var dir = start
        val entries = ArrayList<String>()
        val list = android.widget.ListView(this)
        val adapter = android.widget.ArrayAdapter(this, android.R.layout.simple_list_item_1, entries)
        list.adapter = adapter
        val dlg = AlertDialog.Builder(this)
            .setView(list)
            .setPositiveButton("Выбрать эту папку") { _, _ -> onPick(dir.absolutePath) }
            .setNegativeButton("Отмена", null)
            .create()
        var subs: List<java.io.File> = emptyList()
        fun fill() {
            subs = (dir.listFiles { f -> f.isDirectory && !f.name.startsWith(".") } ?: emptyArray())
                .sortedBy { it.name.lowercase() }
            entries.clear()
            entries.add("⬆  .. (вверх)")
            subs.forEach { entries.add("📁  " + it.name) }
            adapter.notifyDataSetChanged()
            dlg.setTitle(dir.absolutePath)
        }
        list.setOnItemClickListener { _, _, pos, _ ->
            if (pos == 0) dir.parentFile?.let { dir = it } else dir = subs[pos - 1]
            fill()
        }
        fill()
        dlg.show()
    }

    private fun showNames() {
        Py.ask("config_get") { json ->
            val o = try { JSONObject(json) } catch (_: Throwable) { JSONObject() }
            val a = EditText(this).apply { setText(o.optString("assistant_name")); hint = "Имя ассистента"; setSingleLine(true) }
            val u = EditText(this).apply { setText(o.optString("user_name")); hint = "Ваше имя"; setSingleLine(true) }
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0); addView(a); addView(u) }
            AlertDialog.Builder(this).setTitle("Имена").setView(col)
                .setPositiveButton("Сохранить") { _, _ -> Py.call("save_names", a.text.toString().trim(), u.text.toString().trim()) }
                .setNegativeButton("Отмена", null).show()
        }
    }

    private fun showVoices() {
        Py.ask("config_get") { json ->
            val o = try { JSONObject(json) } catch (_: Throwable) { return@ask }
            val arr = o.optJSONArray("voices") ?: return@ask
            val names = Array(arr.length()) { arr.optString(it) }
            val cur = names.indexOf(o.optString("voice")).coerceAtLeast(0)
            AlertDialog.Builder(this).setTitle("Голос").setSingleChoiceItems(names, cur) { d, which ->
                Py.call("set_voice", names[which]); d.dismiss()
            }.show()
        }
    }

    private fun showPlugins() {
        Py.ask("plugins_json") { json ->
            val arr = try { JSONArray(json) } catch (_: Throwable) { JSONArray() }
            if (arr.length() == 0) {
                AlertDialog.Builder(this).setTitle("Плагины")
                    .setMessage("Плагинов пока нет.\nПоложите файл .py в папку plugins внутри папки Jarvis и перезапустите JARVIS.")
                    .setPositiveButton("OK", null).show()
                return@ask
            }
            val names = Array(arr.length()) {
                val p = arr.getJSONObject(it)
                p.optString("name") + if (p.optBoolean("valid", true)) "" else "  (ошибка)"
            }
            val on = BooleanArray(arr.length()) { arr.getJSONObject(it).optBoolean("enabled") }
            AlertDialog.Builder(this).setTitle("Плагины (применяются сразу)")
                .setMultiChoiceItems(names, on) { _, which, checked ->
                    Py.call("plugin_enable", arr.getJSONObject(which).optString("name"), checked)
                }
                .setPositiveButton("Готово", null).show()
        }
    }

    private fun checkAdb() {
        Toast.makeText(this, "Проверяю ADB…", Toast.LENGTH_SHORT).show()
        thread(name = "adb-check") {
            val ok = Adb.available()
            runOnUiThread {
                AlertDialog.Builder(this).setTitle(if (ok) "ADB подключён" else "ADB не подключён")
                    .setMessage(
                        if (ok) "Ввод (клавиши, касания, текст) и зрение (снимок экрана) работают."
                        else "Включите на ТВ: Настройки → Параметры устройства → О продукте → 7 раз «Сборка» → " +
                            "Для разработчиков → «Отладка по USB» и «Отладка по сети». Если сеть не включается — " +
                            "один раз с ПК: adb connect <IP ТВ> и adb tcpip 5555. Затем нажмите «Разрешить» в окне ТВ."
                    ).setPositiveButton("OK", null).show()
            }
        }
    }

    private fun toggleAutostart() {
        val p = getSharedPreferences("jarvis", Context.MODE_PRIVATE)
        val now = !p.getBoolean("autostart", true)
        p.edit().putBoolean("autostart", now).apply()
        Toast.makeText(this, if (now) "Автозапуск включён" else "Автозапуск выключен", Toast.LENGTH_SHORT).show()
    }
}
