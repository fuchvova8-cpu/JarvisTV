package com.jarvis.tv

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.ui.PlayerView
import com.chaquo.python.Python
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

/** Calls into tvshim.entry off the UI thread. */
object Py {
    private val ui = Handler(Looper.getMainLooper())

    fun call(fn: String, vararg a: Any?) {
        thread(name = "py-$fn") {
            try {
                Python.getInstance().getModule("tvshim.entry").callAttr(fn, *a)
            } catch (t: Throwable) {
                Bridge.log("ERR: $fn: ${t.message}")
            }
        }
    }

    fun ask(fn: String, vararg a: Any?, done: (String) -> Unit) {
        thread(name = "py-$fn") {
            val out = try {
                Python.getInstance().getModule("tvshim.entry").callAttr(fn, *a).toString()
            } catch (t: Throwable) {
                ""
            }
            ui.post { done(out) }
        }
    }
}

class MainActivity : Activity(), UiListener {
    private val main = Handler(Looper.getMainLooper())

    private lateinit var hud: HudView
    private lateinit var nameView: TextView
    private lateinit var stateView: TextView
    private lateinit var clockView: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var logText: TextView
    private val logBuf = SpannableStringBuilder()
    private lateinit var contentTitle: TextView
    private lateinit var contentText: TextView
    private lateinit var contentPanel: LinearLayout
    private lateinit var input: EditText
    private lateinit var muteBtn: Button

    private lateinit var confirmPanel: LinearLayout
    private lateinit var confirmTitle: TextView
    private lateinit var confirmDetail: TextView

    private lateinit var quizPanel: LinearLayout
    private lateinit var quizHead: TextView
    private lateinit var quizQ: TextView
    private lateinit var quizOptions: LinearLayout
    private lateinit var quizInput: EditText
    private lateinit var quizSend: Button
    private lateinit var quizNote: TextView
    private lateinit var quizNext: Button
    private var quizLast = false

    private lateinit var videoLayer: FrameLayout
    private lateinit var playerView: PlayerView
    private lateinit var imageView: ImageView
    private lateinit var videoTitle: TextView
    private var player: ExoPlayer? = null
    private var showingImage = false

    private var keyDialog: AlertDialog? = null
    private var skinSig = 0L
    private var pendingSkinRebuild = false
    private var settingsMenuDialog: AlertDialog? = null
    private var started = false
    private var viewMapRef: Map<String, View> = emptyMap()
    private var editLayerRef: View? = null
    private var bottomRef: View? = null

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ═══════════════ construction ═══════════════
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(buildUi())
        ensurePermissionsThenStart()
    }

    private fun box(fill: Int, stroke: Int, radius: Int = 10): GradientDrawable = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(2), stroke)
    }

    private fun btn(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.textSize = 14f
        b.minWidth = 0
        b.minimumWidth = 0
        b.setPadding(dp(14), dp(6), dp(14), dp(6))
        val st = StateListDrawable()
        st.addState(intArrayOf(android.R.attr.state_focused), box(Color.rgb(0, 110, 150), Color.rgb(0, 230, 255)))
        st.addState(intArrayOf(android.R.attr.state_pressed), box(Color.rgb(0, 140, 190), Color.WHITE))
        st.addState(intArrayOf(), box(Color.argb(210, 8, 28, 42), Color.rgb(0, 95, 125)))
        b.background = st
        b.setOnClickListener { onClick() }
        return b
    }

    private fun menuRow(text: String, onClick: () -> Unit): TextView = Hud.menuButton(this, text, onClick)

    private fun menuRowWithPin(
        text: String,
        initiallyPinned: Boolean,
        onPin: (Boolean) -> Unit,
        onClick: () -> Unit
    ): View {
        var pinned = initiallyPinned
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(menuRow(text, onClick), LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(10) })
        val pin = Hud.button(this, if (pinned) "✓ Убрать" else "＋ На экран") { }
        pin.apply {
            textSize = 11f
            isAllCaps = false
            letterSpacing = 0f
            minWidth = 0
            minimumWidth = 0
            minHeight = dp(34)
            gravity = Gravity.CENTER
            setPadding(dp(9), dp(3), dp(9), dp(3))
            maxWidth = dp(132)
            contentDescription = if (pinned) "Убрать с главного экрана" else "Добавить на главный экран"
            setOnClickListener {
                pinned = !pinned
                this.text = if (pinned) "✓ Убрать" else "＋ На экран"
                contentDescription = if (pinned) "Убрать с главного экрана" else "Добавить на главный экран"
                onPin(pinned)
            }
        }
        row.addView(pin, LinearLayout.LayoutParams(-2, dp(34)))
        return row
    }

    private fun setMenuShortcut(key: String, added: Boolean) {
        val op = if (added) "pin_add:" else "pin_remove:"
        Py.ask("plugin_settings_event", "screen_style", op + "mb_" + key, "{}") { result ->
            val saved = try { JSONObject(result).optBoolean("refresh") } catch (_: Throwable) { false }
            if (!saved) {
                android.widget.Toast.makeText(this, "Закрепление требует включённого плагина «Экран (стиль Google)»", android.widget.Toast.LENGTH_SHORT).show()
                return@ask
            }
            Skin.invalidate()
            skinSig = Skin.signature()
            pendingSkinRebuild = true
        }
    }

    private fun shortcutGroup(key: String): String? = when (key) {
        "section_profile" -> "Профиль и голос"
        "section_plugins" -> "Плагины"
        "section_mic" -> "Микрофон"
        "section_system" -> "Экран и система"
        "section_exit" -> "Завершение работы"
        else -> null
    }

    private fun label(sizeSp: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView = TextView(this).apply {
        textSize = sizeSp
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun panelBg(): GradientDrawable = box(Color.argb(190, 4, 16, 26), Color.rgb(0, 80, 105))

    private fun buildUi(): View {
        val sw = resources.displayMetrics.widthPixels
        skinSig = Skin.signature()
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        val bgFrame = BgFrameView(this)
        root.addView(bgFrame, FrameLayout.LayoutParams(-1, -1))
        hud = HudView(this)
        root.addView(hud, FrameLayout.LayoutParams(-1, -1))

        // top bar
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(24), dp(14), dp(24), 0) }
        nameView = label(20f, Color.rgb(0, 214, 255), true).apply { text = "JARVIS" }
        stateView = label(14f, Color.rgb(160, 200, 215)).apply { text = "SLEEPING"; setPadding(dp(16), dp(6), dp(16), 0) }
        clockView = label(16f, Color.rgb(160, 200, 215))
        top.addView(nameView)
        top.addView(stateView, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(clockView)
        root.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        // log (left)
        logText = label(13f, Color.rgb(190, 225, 235))
        logText.setPadding(dp(12), dp(8), dp(12), dp(8))
        logScroll = ScrollView(this).apply {
            background = panelBg()
            isFocusable = true
            addView(logText)
        }
        root.addView(logScroll, FrameLayout.LayoutParams((sw * 0.36f).toInt(), -1, Gravity.START).apply {
            topMargin = dp(56); bottomMargin = dp(76); leftMargin = dp(16)
        })

        // content (right)
        contentTitle = label(15f, Color.rgb(255, 176, 40), true)
        contentText = label(13f, Color.rgb(210, 235, 245))
        contentPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            addView(contentTitle)
            addView(contentText)
        }
        val cScroll = ScrollView(this).apply {
            background = panelBg()
            isFocusable = true
            addView(contentPanel)
        }
        cScroll.visibility = View.GONE
        contentScrollRef = cScroll
        root.addView(cScroll, FrameLayout.LayoutParams((sw * 0.30f).toInt(), -1, Gravity.END).apply {
            topMargin = dp(56); bottomMargin = dp(76); rightMargin = dp(16)
        })

        // bottom bar
        input = EditText(this).apply {
            hint = "Написать JARVIS…"
            setHintTextColor(Color.rgb(90, 130, 145))
            setTextColor(Color.WHITE)
            textSize = 15f
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEND
            background = box(Color.argb(210, 6, 22, 34), Color.rgb(0, 95, 125))
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setSingleLine(true)
            setOnEditorActionListener { _, _, _ -> sendTyped(); true }
        }
        muteBtn = btn("Микрофон: вкл") { Py.call("toggle_mute") }
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(12))
            addView(input, LinearLayout.LayoutParams(0, dp(44), 1f))
            addView(btn("Отправить") { sendTyped() })
            addView(btn("Голос") { startVoice() })
            addView(muteBtn)
            addView(btn("Стоп") { Py.call("interrupt") })
            addView(btn("Результаты") {
                if (TvHost.resultsVisible()) TvHost.hideResults()
                else if (!TvHost.reopenResults())
                    android.widget.Toast.makeText(this@MainActivity, "Пока нет результатов поиска", android.widget.Toast.LENGTH_SHORT).show()
            })
            addView(btn("Плагины") { showPlugins() })
            addView(btn("Меню") { showSettings() })
        }
        root.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        // confirm
        confirmTitle = label(20f, Color.rgb(255, 176, 40), true)
        confirmDetail = label(15f)
        confirmPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(Color.argb(240, 20, 12, 4), Color.rgb(255, 176, 40))
            setPadding(dp(24), dp(18), dp(24), dp(18))
            addView(confirmTitle)
            addView(confirmDetail)
            val row = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(14), 0, 0) }
            row.addView(btn("Да, выполнить") { Py.call("confirm_answer", true); onConfirmHide() })
            row.addView(btn("Отмена") { Py.call("confirm_answer", false); onConfirmHide() })
            addView(row)
            visibility = View.GONE
        }
        root.addView(confirmPanel, FrameLayout.LayoutParams((sw * 0.55f).toInt(), -2, Gravity.CENTER))

        // quiz
        quizHead = label(13f, Color.rgb(0, 214, 255), true)
        quizQ = label(20f)
        quizOptions = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        quizInput = EditText(this).apply {
            setTextColor(Color.WHITE); textSize = 16f; inputType = InputType.TYPE_CLASS_TEXT; setSingleLine(true)
            background = box(Color.argb(210, 6, 22, 34), Color.rgb(0, 95, 125)); setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        quizSend = btn("Ответить") { submitQuiz(quizInput.text.toString()) }
        quizNote = label(15f, Color.rgb(255, 176, 40))
        quizNext = btn("Далее") { Py.call("quiz_next") }
        quizPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(Color.argb(245, 4, 16, 26), Color.rgb(0, 214, 255))
            setPadding(dp(24), dp(18), dp(24), dp(18))
            addView(quizHead); addView(quizQ); addView(quizOptions); addView(quizInput); addView(quizSend)
            addView(quizNote); addView(quizNext)
            visibility = View.GONE
        }
        root.addView(quizPanel, FrameLayout.LayoutParams((sw * 0.62f).toInt(), -2, Gravity.CENTER))

        // video / image
        playerView = PlayerView(this).apply { useController = false }
        imageView = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; visibility = View.GONE }
        videoTitle = label(14f, Color.WHITE)
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(8), dp(16), dp(14))
            addView(btn("-10 c") { seekBy(-10) })
            addView(btn("Пауза/Играть") { togglePause() })
            addView(btn("+10 c") { seekBy(10) })
            addView(btn("Звук") { player?.let { it.volume = if (it.volume > 0f) 0f else 1f } })
            addView(btn("Закрыть") { onVideoClose() })
        }
        videoLayer = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            isClickable = true          // eats touches: nothing underneath reacts while the video is up
            addView(playerView, FrameLayout.LayoutParams(-1, -1))
            addView(imageView, FrameLayout.LayoutParams(-1, -1))
            addView(videoTitle, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { setMargins(dp(20), dp(12), 0, 0) })
            addView(controls, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
            visibility = View.GONE
        }
        root.addView(videoLayer, FrameLayout.LayoutParams(-1, -1))

        // Screen skin (plugin screen_style): every element below can be moved/resized/restyled.
        // No skin file, or mode "off" → nothing changes.
        bottomRef = bottom
        val bottomBtns = (0 until bottom.childCount).map { bottom.getChildAt(it) }
        val viewMap = linkedMapOf<String, View>(
                "hud" to hud, "name" to nameView, "state" to stateView, "clock" to clockView,
                "log" to logScroll, "content" to cScroll, "input" to input,
                "btn_send" to bottomBtns[1], "btn_voice" to bottomBtns[2], "btn_mute" to muteBtn,
                "btn_stop" to bottomBtns[4], "btn_results" to bottomBtns[5],
                "btn_plugins" to bottomBtns[6], "btn_menu" to bottomBtns[7],
                "confirm" to confirmPanel, "quiz" to quizPanel
        )
        viewMapRef = viewMap
        // menu entries the plugin put on the main screen: element ids "mb_<key>"
        Skin.load(true)?.main?.keys()?.forEach { k ->
            if (k.startsWith("mb_")) menuButton(k.substring(3))?.let { viewMap[k] = it }
        }
        Skin.applyMain(
            this, root, viewMap,
            listOf(top, bottom),
            listOf(contentTitle, confirmTitle, quizHead),
            listOf(contentText, confirmDetail, quizQ),
            bgFrame
        )
        videoLayer.bringToFront()      // video and its controls stay above any re-placed element
        val editCfg = Skin.load(true)
        if (editCfg?.edit == true) {
            val layer = EditLayer(this, root, viewMap, { sig -> skinSig = sig }, { Skin.setEdit(false); recreate() })
            editLayerRef = layer
            root.addView(layer, FrameLayout.LayoutParams(-1, -1))
            layer.bringToFront()
            android.widget.Toast.makeText(this, "Редактор экрана: тащите элементы мышью. «Готово» — выйти", android.widget.Toast.LENGTH_LONG).show()
        }
        return root
    }

    private lateinit var contentScrollRef: ScrollView

    // ═══════════════ lifecycle ═══════════════
    // A voice command (or the settings page) can rewrite the skin while this screen is up: rebuild then.
    private val skinWatch = object : Runnable {
        override fun run() {
            val currentSig = Skin.signature()
            if (skinSig != currentSig) {
                if (settingsMenuDialog?.isShowing == true) {
                    pendingSkinRebuild = true
                    skinSig = currentSig
                } else { recreate(); return }
            }
            main.postDelayed(this, 2000)
        }
    }

    private val clockTick = object : Runnable {
        override fun run() {
            clockView.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            main.postDelayed(this, 20_000)
        }
    }

    override fun onStart() {
        super.onStart()
        if (skinSig != Skin.signature()) {      // a menu shortcut or screen_style setting changed the layout
            if (settingsMenuDialog?.isShowing == true) {
                pendingSkinRebuild = true
                skinSig = Skin.signature()
            } else {
                recreate()
                return
            }
        }
        Bridge.appVisible = true
        Bridge.listener = this
        MicIndicator.sync()          // e.g. after coming back from the "draw over other apps" screen
        // catch up with what happened while the screen was away
        logBuf.clear()
        logText.text = ""
        for (l in Bridge.snapshotLog()) appendLog(l)
        onState(Bridge.curState)
        onMuted(Bridge.curMuted)
        if (Bridge.assistantName.isNotEmpty()) nameView.text = Bridge.assistantName.uppercase()
        if (Bridge.curText.isNotEmpty()) onContent(Bridge.curTitle, Bridge.curText)
        Bridge.curConfirm?.let { onConfirm(it.first, it.second) }
        if (Bridge.curQuiz.isNotEmpty()) onQuiz(Bridge.curQuiz)
        if (Bridge.promptingKey) onPromptKey()
        clockTick.run()
        main.postDelayed(skinWatch, 2000)
    }

    override fun onStop() {
        Bridge.appVisible = false
        Bridge.listener = null
        main.removeCallbacks(clockTick)
        main.removeCallbacks(skinWatch)
        super.onStop()
    }

    override fun onDestroy() {
        player?.release(); player = null
        super.onDestroy()
    }

    private fun ensurePermissionsThenStart() {
        val need = ArrayList<String>()
        for (p in arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p)
        }
        if (need.isEmpty()) startCore() else requestPermissions(need.toTypedArray(), 7)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Bridge.log("SYS: Нет доступа к микрофону — работает только текст и кнопка «Голос».")
        }
        startCore()
        if (code == 8 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            MicMode.setMode(MicMode.Mode.LIVE)
        }
    }

    private fun startCore() {
        if (started) return
        started = true
        JarvisService.start(this)
    }

    // ═══════════════ UiListener ═══════════════
    private fun appendLog(line: String) {
        val color = when {
            line.startsWith("You:") || line.startsWith("YOU:") -> Color.rgb(0, 214, 255)
            line.startsWith("SYS:") -> Color.rgb(130, 160, 175)
            line.startsWith("ERR:") -> Color.rgb(255, 100, 100)
            else -> Color.rgb(255, 196, 90)
        }
        val start = logBuf.length
        logBuf.append(line).append('\n')
        logBuf.setSpan(ForegroundColorSpan(color), start, logBuf.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (logBuf.length > 14000) logBuf.delete(0, logBuf.length - 10000)
        logText.text = logBuf
        logScroll.post { logScroll.scrollTo(0, logText.height) }
    }

    override fun onLog(line: String) = appendLog(line)

    override fun onState(state: String) {
        stateView.text = state
        hud.state = state
    }

    override fun onContent(title: String, text: String) {
        contentTitle.text = title
        contentText.text = text
        contentScrollRef.visibility = View.VISIBLE
        contentScrollRef.scrollTo(0, 0)
    }

    override fun onMuted(muted: Boolean) {
        muteBtn.text = if (muted) "Микрофон: ВЫКЛ" else "Микрофон: вкл"
    }

    override fun onConfirm(title: String, detail: String) {
        confirmTitle.text = title
        confirmDetail.text = detail
        confirmPanel.visibility = View.VISIBLE
        confirmPanel.getChildAt(2)?.let { (it as ViewGroup).getChildAt(0)?.requestFocus() }
    }

    override fun onConfirmHide() { confirmPanel.visibility = View.GONE }

    override fun onReady(ready: Boolean, name: String) {
        nameView.text = name.uppercase()
        if (ready) {
            Bridge.promptingKey = false
            keyDialog?.dismiss()
        }
    }

    override fun onPromptKey() { showKeyDialog() }

    // ── quiz ──
    override fun onQuiz(json: String) {
        val o = JSONObject(json)
        quizHead.text = "${o.optString("topic").uppercase()}  ·  ${o.optInt("n")}/${o.optInt("total")}"
        quizQ.text = o.optString("question")
        quizNote.text = ""
        quizNext.visibility = View.GONE
        quizOptions.removeAllViews()
        val opts: JSONArray = o.optJSONArray("options") ?: JSONArray()
        if (opts.length() > 0) {
            quizInput.visibility = View.GONE
            quizSend.visibility = View.GONE
            for (i in 0 until opts.length()) {
                val text = opts.optString(i)
                quizOptions.addView(btn(text) { submitQuiz(text) })
            }
            quizOptions.getChildAt(0)?.requestFocus()
        } else {
            quizInput.setText("")
            quizInput.visibility = View.VISIBLE
            quizSend.visibility = View.VISIBLE
            quizInput.requestFocus()
        }
        quizPanel.visibility = View.VISIBLE
    }

    private fun submitQuiz(given: String) {
        quizSend.isEnabled = false
        for (i in 0 until quizOptions.childCount) quizOptions.getChildAt(i).isEnabled = false
        Py.ask("quiz_submit", given) { res ->
            try {
                val o = JSONObject(res)
                quizNote.text = o.optString("mark")
                quizLast = o.optBoolean("last")
                quizNext.text = if (quizLast) "Завершить" else "Далее"
                quizNext.visibility = View.VISIBLE
                quizNext.requestFocus()
            } catch (_: Throwable) {}
            quizSend.isEnabled = true
        }
    }

    override fun onQuizHide() { quizPanel.visibility = View.GONE }

    // ── video / image ──
    override fun onVideoOpen(src: String, title: String, muted: Boolean, audio: String) {
        onVideoClose()
        val factory = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Linux; Android 9; TV) AppleWebKit/537.36 Chrome/120 Safari/537.36")
            .setAllowCrossProtocolRedirects(true)
        val msf = DefaultMediaSourceFactory(factory)
        fun item(s: String) = MediaItem.fromUri(if (s.contains("://")) Uri.parse(s) else Uri.fromFile(File(s)))
        val video = msf.createMediaSource(item(src))
        val source = if (audio.isNotEmpty()) MergingMediaSource(video, msf.createMediaSource(item(audio))) else video
        val p = ExoPlayer.Builder(this).build()
        p.setMediaSource(source)
        p.volume = if (muted) 0f else 1f
        p.prepare()
        p.playWhenReady = true
        player = p
        playerView.player = p
        showingImage = false
        imageView.visibility = View.GONE
        playerView.visibility = View.VISIBLE
        videoTitle.text = title
        videoLayer.visibility = View.VISIBLE
        videoLayer.bringToFront()
    }

    override fun onImageOpen(path: String, title: String) {
        onVideoClose()
        imageView.setImageURI(Uri.fromFile(File(path)))
        showingImage = true
        playerView.visibility = View.GONE
        imageView.visibility = View.VISIBLE
        videoTitle.text = title
        videoLayer.visibility = View.VISIBLE
        videoLayer.bringToFront()
    }

    override fun onVideoClose() {
        player?.release(); player = null
        playerView.player = null
        showingImage = false
        videoLayer.visibility = View.GONE
    }

    override fun onVideoMute(muted: Boolean) { player?.volume = if (muted) 0f else 1f }
    override fun onVideoPause(paused: Boolean) { player?.playWhenReady = !paused }

    override fun onVideoSeek(seconds: Double, relative: Boolean) {
        val p = player ?: return
        val ms = (seconds * 1000).toLong()
        p.seekTo(if (relative) (p.currentPosition + ms).coerceAtLeast(0) else ms.coerceAtLeast(0))
    }

    override fun videoState(): String {
        val o = JSONObject()
        val p = player
        when {
            p != null -> {
                o.put("kind", "video")
                o.put("position", p.currentPosition / 1000.0)
                o.put("duration", if (p.duration > 0) p.duration / 1000.0 else 0.0)
                o.put("paused", !p.playWhenReady)
            }
            showingImage -> { o.put("kind", "image"); o.put("position", 0.0); o.put("duration", 0.0); o.put("paused", false) }
            else -> { o.put("kind", ""); o.put("position", 0.0); o.put("duration", 0.0); o.put("paused", false) }
        }
        return o.toString()
    }

    private fun seekBy(sec: Int) = onVideoSeek(sec.toDouble(), true)
    private fun togglePause() { player?.let { it.playWhenReady = !it.playWhenReady } }

    // ═══════════════ input ═══════════════
    private fun sendTyped() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        Bridge.log("You: $t")
        Py.call("text_command", t)
    }

    /** The system recognizer (also what the remote's microphone feeds) — see VoiceLoop. */
    private fun startVoice() = VoiceLoop.listenOnce()

    // In the layout editor every touch / mouse press goes to the editor first, whatever lies underneath.
    override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
        val layer = editLayerRef
        if (layer != null && layer.parent != null) return layer.dispatchTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_SEARCH, KeyEvent.KEYCODE_ASSIST, KeyEvent.KEYCODE_VOICE_ASSIST -> { startVoice(); return true }
            KeyEvent.KEYCODE_MENU -> { showSettings(); return true }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                if (VideoWindow.active) { VideoWindow.toggle(); return true }
                if (videoLayer.visibility == View.VISIBLE) { togglePause(); return true }
            }
            KeyEvent.KEYCODE_MEDIA_REWIND -> if (VideoWindow.active) { VideoWindow.seek(-10.0, true); return true }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> if (VideoWindow.active) { VideoWindow.seek(10.0, true); return true }
        }
        return super.onKeyDown(keyCode, event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            VideoWindow.active -> VideoWindow.close()
            videoLayer.visibility == View.VISIBLE -> onVideoClose()
            quizPanel.visibility == View.VISIBLE -> Py.call("quiz_hide")
            confirmPanel.visibility == View.VISIBLE -> { Py.call("confirm_answer", false); onConfirmHide() }
            contentScrollRef.visibility == View.VISIBLE -> contentScrollRef.visibility = View.GONE
            else -> super.onBackPressed()     // leave the screen; JARVIS keeps running in the service
        }
    }

    // ═══════════════ dialogs ═══════════════
    private fun showKeyDialog() {
        if (keyDialog?.isShowing == true) return
        val et = EditText(this).apply {
            hint = "AIza…  (пусто = локальный режим)"
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
        }
        keyDialog = AlertDialog.Builder(this)
            .setTitle("Ключ Gemini API")
            .setMessage("Получить: aistudio.google.com/apikey. Набрать на пульте трудно — скопируйте ключ на ТВ " +
                "(например, из приложения-пульта) и нажмите «Из буфера».")
            .setView(et)
            .setCancelable(false)
            .setPositiveButton("Сохранить") { _, _ ->
                Bridge.promptingKey = false
                Py.call("save_key", et.text.toString().trim())
            }
            .setNeutralButton("Из буфера") { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                val v = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()?.trim().orEmpty()
                Bridge.promptingKey = false
                Py.call("save_key", v)
            }
            .create()
        keyDialog?.let { Skin.showStyled(it) }
    }

    private class MenuEntry(val label: () -> String, val short: () -> String, val action: () -> Unit)

    /**
     * Every entry of the Service menu, by key. The same table drives the menu dialog and the buttons the
     * screen_style plugin can put on the main screen (element ids "mb_<key>").
     */
    private fun menuEntries(): LinkedHashMap<String, MenuEntry> {
        val m = LinkedHashMap<String, MenuEntry>()
        fun add(key: String, label: () -> String, short: () -> String, action: () -> Unit) { m[key] = MenuEntry(label, short, action) }
        add("gemini_key", { "Ключ Gemini API" }, { "Ключ API" }) { showKeyDialog() }
        add("names", { "Имена (ассистент / вы)" }, { "Имена" }) { showNames() }
        add("voice", { "Голос Gemini" }, { "Голос Gemini" }) { showVoices() }
        add("plugins", { "Плагины (вкл/выкл)" }, { "Плагины" }) { showPlugins() }
        add("plugin_settings", { "Настройки плагинов" }, { "Настр. плагинов" }) { showPluginSettings() }
        add("plugin_dir", { "Папка плагинов" }, { "Папка плагинов" }) { showPluginDir() }
        add("mic_mode",
            { if (MicMode.mode == MicMode.Mode.PTT) "Режим микрофона: ПО КНОПКЕ  → сделать постоянным" else "Режим микрофона: ПОСТОЯННО  → сделать по кнопке" },
            { if (MicMode.mode == MicMode.Mode.PTT) "Мик: по кнопке" else "Мик: постоянно" }) {
            if (MicMode.mode == MicMode.Mode.PTT && !VoiceLoop.hasPermission())
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 8)
            else MicMode.toggleMode()
        }
        add("mic_live",
            { if (MicMode.mode == MicMode.Mode.PTT) "Постоянное прослушивание: включить"
                else if (MicMode.liveOn) "Постоянное прослушивание: ВЫКЛЮЧИТЬ" else "Постоянное прослушивание: ВКЛЮЧИТЬ" },
            { if (MicMode.liveOn) "Прослуш.: вкл" else "Прослуш.: выкл" }) {
            if (MicMode.mode == MicMode.Mode.PTT && !VoiceLoop.hasPermission())
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 8)
            else MicMode.toggleLiveOn()
        }
        add("mic_bg",
            { if (MicMode.background) "Микрофон в фоне: ВКЛ  → выключить" else "Микрофон в фоне: ВЫКЛ  → включить" },
            { if (MicMode.background) "Мик в фоне: вкл" else "Мик в фоне: выкл" }) { MicMode.setBackground(!MicMode.background) }
        add("mic_indicator",
            { if (MicIndicator.enabled) "Индикатор микрофона: ВКЛ  → выключить" else "Индикатор микрофона: ВЫКЛ  → включить" },
            { if (MicIndicator.enabled) "Индикатор: вкл" else "Индикатор: выкл" }) { toggleIndicator() }
        add("adb", { "Проверить ADB (ввод и экран)" }, { "Проверить ADB" }) { checkAdb() }
        add("autostart", { "Автозапуск при включении ТВ" }, { "Автозапуск" }) { toggleAutostart() }
        add("autostart_ui",
            { if (getSharedPreferences("jarvis", Context.MODE_PRIVATE).getBoolean("autostart_ui", true)) "Открывать экран при запуске ТВ: ВКЛ  → выключить" else "Открывать экран при запуске ТВ: ВЫКЛ  → включить" },
            { if (getSharedPreferences("jarvis", Context.MODE_PRIVATE).getBoolean("autostart_ui", true)) "Экран при старте: вкл" else "Экран при старте: выкл" }) {
            val sp = getSharedPreferences("jarvis", Context.MODE_PRIVATE)
            val now = !sp.getBoolean("autostart_ui", true)
            sp.edit().putBoolean("autostart_ui", now).apply()
            Toast.makeText(this, if (now) "Экран будет открываться при запуске ТВ" else "При запуске ТВ JARVIS работает в фоне, экран не открывается", Toast.LENGTH_LONG).show()
        }
        add("folder_info", { "Где лежит папка Jarvis" }, { "Папка Jarvis" }) {
            AlertDialog.Builder(this).setTitle("Папка Jarvis")
                .setMessage("${AssetInstaller.targetDir(this).absolutePath}\n\nСюда кладутся свои плагины (plugins/*.py), " +
                    "агенты, и здесь лежат config/ и memory/.").setPositiveButton("OK", null).let { Skin.showStyled(it.create()) }
        }
        add("edit_screen", { "Редактор экрана (перетаскивание мышью)" }, { "Редактор экрана" }) { startScreenEditor() }
        add("exit", { "Выйти полностью" }, { "Выйти" }) {
            VoiceLoop.abort()
            stopService(Intent(this, JarvisService::class.java))
            finishAffinity()
            android.os.Process.killProcess(android.os.Process.myPid())
        }
        return m
    }

    /** Turns the drag-and-drop editor on (needs the screen_style plugin's layout file). */
    private fun startScreenEditor() {
        if (Skin.setEdit(true)) recreate()
        else android.widget.Toast.makeText(this, "Редактор недоступен: включите плагин «Экран (стиль Google)» в настройках плагинов (сам стиль можно оставить классическим)", android.widget.Toast.LENGTH_LONG).show()
    }

    /** A main-screen button for one menu entry; its caption follows the state (mic mode etc.). */
    private fun menuButton(key: String): View? {
        shortcutGroup(key)?.let { group -> return btn(group) { showSettings(group) } }
        // These ordinary service-menu actions also start with "plugin_". Resolve
        // them before interpreting the prefix as a plugin-settings shortcut.
        val e = menuEntries()[key]
        if (e != null) {
            var self: Button? = null
            val b = btn(e.short()) {
                e.action()
                self?.postDelayed({ self?.text = e.short() }, 500)
            }
            self = b
            return b
        }
        if (key.startsWith("plugin_")) {
            val shortcuts = PluginSettingsActivity.shortcutItems(this)
            val item = (0 until shortcuts.length()).mapNotNull { shortcuts.optJSONObject(it) }.firstOrNull { it.optString("key") == key }
                ?: return null
            val b = btn(item.optString("label")) {
                startActivity(Intent(this, PluginSettingsActivity::class.java)
                    .putExtra(PluginSettingsActivity.EXTRA_PLUGIN, item.optString("plugin"))
                    .putExtra(PluginSettingsActivity.EXTRA_TITLE, item.optString("title"))
                    .putExtra(PluginSettingsActivity.EXTRA_SECTION, item.optString("section"))
                    .putExtra(PluginSettingsActivity.EXTRA_EVENT, item.optString("event")))
            }
            return b
        }
        return null
    }

    private fun showSettings(initialGroup: String? = null) {
        val entries = menuEntries()
        val groups = linkedMapOf(
            "Профиль и голос" to listOf("gemini_key", "names", "voice"),
            "Плагины" to listOf("plugins", "plugin_settings", "plugin_dir"),
            "Микрофон" to listOf("mic_mode", "mic_live", "mic_bg", "mic_indicator"),
            "Экран и система" to listOf("adb", "autostart", "autostart_ui", "folder_info", "edit_screen"),
            "Завершение работы" to listOf("exit")
        )
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(8), dp(18), dp(12))
        }
        val heading = label(15f, Color.LTGRAY, true)
        root.addView(heading, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(list) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, dp(390)))

        var selectedGroup: String? = initialGroup
        lateinit var dialog: AlertDialog
        fun renderSettings() {
            list.removeAllViews()
            val groupTitle = selectedGroup
            heading.text = groupTitle ?: "Выберите раздел настроек"
            if (groupTitle == null) {
                for (title in groups.keys) {
                    val pinKey = when (title) {
                        "Профиль и голос" -> "section_profile"
                        "Плагины" -> "section_plugins"
                        "Микрофон" -> "section_mic"
                        "Экран и система" -> "section_system"
                        else -> "section_exit"
                    }
                    list.addView(menuRowWithPin(title, Skin.menuItemPinned(pinKey), { setMenuShortcut(pinKey, it) }) {
                        selectedGroup = title; renderSettings()
                    }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) })
                }
            } else {
                for (key in groups[groupTitle].orEmpty()) {
                    val entry = entries[key] ?: continue
                    list.addView(menuRowWithPin(entry.label(), Skin.menuItemPinned(key), { setMenuShortcut(key, it) }) {
                        entry.action()
                        // The settings page remains beneath any prompt or activity opened by the action.
                        list.postDelayed({ if (dialog.isShowing && selectedGroup == groupTitle) renderSettings() }, 350)
                    }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) })
                }
            }
            val backLabel = if (groupTitle == null) "Закрыть" else "← Назад"
            list.addView(menuRow(backLabel) {
                if (selectedGroup == null) dialog.dismiss()
                else { selectedGroup = null; renderSettings() }
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
            if (dialog.isShowing) Skin.styleDialog(dialog)
            list.getChildAt(0)?.requestFocus()
        }

        dialog = AlertDialog.Builder(this)
            .setTitle("JARVIS — настройки")
            .setView(root)
            .create()
        dialog.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_BACK) {
                if (event.action == KeyEvent.ACTION_UP && event.repeatCount == 0) {
                    if (selectedGroup != null) { selectedGroup = null; renderSettings() }
                    else dialog.dismiss()
                }
                true
            } else false
        }
        settingsMenuDialog = dialog
        dialog.setOnDismissListener {
            if (settingsMenuDialog === dialog) settingsMenuDialog = null
            if (pendingSkinRebuild) {
                pendingSkinRebuild = false
                main.post { recreate() }
            }
        }
        renderSettings()
        Skin.showStyled(dialog)
        renderSettings()
    }

    private fun showPluginSettings() {
        Py.ask("plugin_settings_list") { json ->
            val arr = try { JSONArray(json) } catch (_: Throwable) { JSONArray() }
            if (arr.length() == 0) {
                AlertDialog.Builder(this).setTitle("Настройки плагинов")
                    .setMessage("Пока ни у одного плагина нет страницы настроек (плагин может добавить её сам: SETTINGS, settings_items, settings_event).")
                    .setPositiveButton("OK", null).let { Skin.showStyled(it.create()) }
                return@ask
            }
            val root = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(18), dp(8), dp(18), dp(12))
            }
            val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val scroll = ScrollView(this).apply { isFillViewport = true; addView(list) }
            root.addView(scroll, LinearLayout.LayoutParams(-1, dp(390)))
            lateinit var dialog: AlertDialog
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val name = item.optString("name")
                val title = item.optString("title", name)
                val shortcutId = PluginSettingsActivity.shortcutId(name, "", "")
                list.addView(menuRowWithPin(title,
                    PluginSettingsActivity.hasShortcut(this, shortcutId), { add ->
                        PluginSettingsActivity.toggleShortcut(this, name, title, "", "", title)
                        setMenuShortcut(shortcutId, add)
                    }) {
                        // Keep this chooser visible underneath PluginSettingsActivity. Back from the
                        // plugin then reveals this exact screen instead of skipping to the menu group.
                        startActivity(Intent(this, PluginSettingsActivity::class.java)
                            .putExtra(PluginSettingsActivity.EXTRA_PLUGIN, name)
                            .putExtra(PluginSettingsActivity.EXTRA_TITLE, title))
                    }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) })
            }
            list.addView(menuRow("Закрыть") { dialog.dismiss() },
                LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
            dialog = AlertDialog.Builder(this)
                .setTitle("Настройки плагинов")
                .setView(root)
                .create()
            settingsMenuDialog = dialog
            dialog.setOnKeyListener { _, keyCode, event ->
                if (keyCode == KeyEvent.KEYCODE_BACK) {
                    if (event.action == KeyEvent.ACTION_UP && event.repeatCount == 0) dialog.dismiss()
                    true
                } else false
            }
            dialog.setOnDismissListener {
                if (settingsMenuDialog === dialog) settingsMenuDialog = null
                if (pendingSkinRebuild) {
                    pendingSkinRebuild = false
                    main.post { recreate() }
                }
            }
            Skin.showStyled(dialog)
            list.getChildAt(0)?.requestFocus()
        }
    }

    private fun showPluginDir() {
        Py.ask("plugin_dir_info") { json ->
            val o = try { JSONObject(json) } catch (_: Throwable) { JSONObject() }
            val custom = o.optString("custom")
            val et = EditText(this).apply { setText(custom); hint = o.optString("default"); setSingleLine(true) }
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(20), dp(8), dp(20), 0)
                addView(TextView(this@MainActivity).apply { text = "Сейчас: ${o.optString("current")}" })
                addView(et)
            }
            AlertDialog.Builder(this).setTitle("Папка плагинов").setView(col)
                .setPositiveButton("Применить") { _, _ -> applyPluginDir(et.text.toString()) }
                .setNeutralButton("Выбрать папку…") { _, _ ->
                    val start = java.io.File(custom).takeIf { it.isDirectory } ?: android.os.Environment.getExternalStorageDirectory()
                    pickFolder(start) { applyPluginDir(it) }
                }
                .setNegativeButton("Стандартная") { _, _ -> applyPluginDir("") }.let { Skin.showStyled(it.create()) }
        }
    }

    private fun applyPluginDir(path: String) {
        Py.ask("plugin_dir_set", path) { msg ->
            AlertDialog.Builder(this).setTitle("Папка плагинов").setMessage(msg).setPositiveButton("OK", null).let { Skin.showStyled(it.create()) }
        }
    }

    /** Small folder browser: OK on a row opens it, the first row goes up. */
    private fun pickFolder(start: java.io.File, onPick: (String) -> Unit) {
        var dir = start
        val entries = ArrayList<String>()
        val list = android.widget.ListView(this)
        val adapter = android.widget.ArrayAdapter(this, android.R.layout.simple_list_item_1, entries)
        list.adapter = adapter
        val dlg = AlertDialog.Builder(this)
            .setView(list)
            .setPositiveButton("Выбрать эту папку") { _, _ -> onPick(dir.absolutePath) }
            .setNegativeButton("Отмена", null)
            .create()
        var subs: List<java.io.File> = emptyList()
        fun fill() {
            subs = (dir.listFiles { f -> f.isDirectory && !f.name.startsWith(".") } ?: emptyArray())
                .sortedBy { it.name.lowercase() }
            entries.clear()
            entries.add("⬆  .. (вверх)")
            subs.forEach { entries.add("📁  " + it.name) }
            adapter.notifyDataSetChanged()
            dlg.setTitle(dir.absolutePath)
        }
        list.setOnItemClickListener { _, _, pos, _ ->
            if (pos == 0) dir.parentFile?.let { dir = it } else dir = subs[pos - 1]
            fill()
        }
        fill()
        Skin.showStyled(dlg)
    }

    private fun showNames() {
        Py.ask("config_get") { json ->
            val o = try { JSONObject(json) } catch (_: Throwable) { JSONObject() }
            val a = EditText(this).apply { setText(o.optString("assistant_name")); hint = "Имя ассистента"; setSingleLine(true) }
            val u = EditText(this).apply { setText(o.optString("user_name")); hint = "Ваше имя"; setSingleLine(true) }
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0); addView(a); addView(u) }
            AlertDialog.Builder(this).setTitle("Имена").setView(col)
                .setPositiveButton("Сохранить") { _, _ -> Py.call("save_names", a.text.toString().trim(), u.text.toString().trim()) }
                .setNegativeButton("Отмена", null).let { Skin.showStyled(it.create()) }
        }
    }

    private fun showVoices() {
        Py.ask("config_get") { json ->
            val o = try { JSONObject(json) } catch (_: Throwable) { return@ask }
            val arr = o.optJSONArray("voices") ?: return@ask
            val names = Array(arr.length()) { arr.optString(it) }
            val cur = names.indexOf(o.optString("voice")).coerceAtLeast(0)
            AlertDialog.Builder(this).setTitle("Голос").setSingleChoiceItems(names, cur) { d, which ->
                Py.call("set_voice", names[which]); d.dismiss()
            }.let { Skin.showStyled(it.create()) }
        }
    }

    private fun showPlugins() {
        Py.ask("plugins_json") { json ->
            val arr = try { JSONArray(json) } catch (_: Throwable) { JSONArray() }
            if (arr.length() == 0) {
                AlertDialog.Builder(this).setTitle("Плагины")
                    .setMessage("Плагинов пока нет.\nПоложите файл .py в папку plugins внутри папки Jarvis и перезапустите JARVIS.")
                    .setPositiveButton("OK", null).let { Skin.showStyled(it.create()) }
                return@ask
            }
            val names = Array(arr.length()) {
                val p = arr.getJSONObject(it)
                p.optString("name") + if (p.optBoolean("valid", true)) "" else "  (ошибка)"
            }
            val on = BooleanArray(arr.length()) { arr.getJSONObject(it).optBoolean("enabled") }
            AlertDialog.Builder(this).setTitle("Плагины (применяются сразу)")
                .setMultiChoiceItems(names, on) { _, which, checked ->
                    Py.call("plugin_enable", arr.getJSONObject(which).optString("name"), checked)
                }
                .setPositiveButton("Готово", null).let { Skin.showStyled(it.create()) }
        }
    }

    private fun checkAdb() {
        Toast.makeText(this, "Проверяю ADB…", Toast.LENGTH_SHORT).show()
        thread(name = "adb-check") {
            val ok = Adb.available()
            runOnUiThread {
                AlertDialog.Builder(this).setTitle(if (ok) "ADB подключён" else "ADB не подключён")
                    .setMessage(
                        if (ok) "Ввод (клавиши, касания, текст) и зрение (снимок экрана) работают."
                        else "Включите на ТВ: Настройки → Параметры устройства → О продукте → 7 раз «Сборка» → " +
                            "Для разработчиков → «Отладка по USB» и «Отладка по сети». Если сеть не включается — " +
                            "один раз с ПК: adb connect <IP ТВ> и adb tcpip 5555. Затем нажмите «Разрешить» в окне ТВ."
                    ).setPositiveButton("OK", null).let { Skin.showStyled(it.create()) }
            }
        }
    }

    private fun toggleIndicator() {
        if (MicIndicator.enabled) {
            MicIndicator.switchTo(false)
            Toast.makeText(this, "Индикатор микрофона выключен", Toast.LENGTH_SHORT).show()
        } else {
            MicIndicator.switchTo(true)     // shown at once if allowed
            MicIndicator.ensurePermission(this) { ok ->
                if (ok) {
                    MicIndicator.sync()
                    Toast.makeText(this, "Индикатор включён. Переместить — перетащить мышью", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun toggleAutostart() {
        val p = getSharedPreferences("jarvis", Context.MODE_PRIVATE)
        val now = !p.getBoolean("autostart", true)
        p.edit().putBoolean("autostart", now).apply()
        Toast.makeText(this, if (now) "Автозапуск включён" else "Автозапуск выключен", Toast.LENGTH_SHORT).show()
    }
}
