package com.jarvis.tv

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

/**
 * Generic settings page of a plugin (opened from the Service menu or from a pinned button).
 * The plugin describes the page itself (see "plugin settings pages" in plugins_ext.py): labels, section
 * headings, buttons, tick boxes, colour mixers and text fields; every button press sends all field
 * values back to the plugin.
 *
 * Navigation: a plugin may have pages inside the page (screen_style does). "Back" — the remote's key or
 * the "← Назад" pill — first asks the plugin to step one level up ("__back__"); only when the plugin is
 * already on its first page (or does not know sub-pages) does the window close and the menu show again.
 *
 * Item types: label, section, title (sets the header, e.g. "Экран › Видео"), button, check, text, color.
 * A button may carry  "sub": caption,  and  "pin": "page" | "act"  (+ "pin_event", "pin_title") — then a
 * "＋ На главный" chip appears next to it that puts that page / action on the main screen.
 */
class PluginSettingsActivity : Activity() {

    private lateinit var plugin: String
    private lateinit var titleView: TextView
    private lateinit var status: TextView
    private lateinit var box: LinearLayout
    private lateinit var scroll: ScrollView
    private val fields = LinkedHashMap<String, EditText>()
    private val checks = LinkedHashMap<String, CheckBox>()
    private var loaded = false
    private var busy = false
    private var shownTitle = ""

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        plugin = intent.getStringExtra(EXTRA_PLUGIN) ?: ""
        val title = intent.getStringExtra(EXTRA_TITLE) ?: plugin

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Skin.theme()?.bg ?: 0xFF101418.toInt())
            setPadding(dp(24), dp(18), dp(24), dp(14))
        }
        val colW = minOf((resources.displayMetrics.widthPixels * 0.84f).toInt(), dp(1000))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(col, LinearLayout.LayoutParams(colW, ViewGroup.LayoutParams.MATCH_PARENT))

        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(MenuKit.button(this, "←  Назад", false) { goBack() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)))
        titleView = TextView(this).apply {
            text = title
            textSize = 22f
            setTextColor(MenuKit.accent)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            maxLines = 2
            setPadding(dp(18), 0, dp(8), 0)
        }
        head.addView(titleView, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        col.addView(head)

        status = TextView(this).apply {
            textSize = 14f
            setTextColor(Hud.AMBER)
            text = "Загрузка…"
        }
        col.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(6)
            bottomMargin = dp(6)
        })
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply {
            isFocusable = false
            isVerticalScrollBarEnabled = false
            addView(box)
        }
        col.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        // A fresh visit always starts on the plugin's first page; a pinned sub-page then jumps straight to it.
        val ev = intent.getStringExtra(EXTRA_EVENT)
        kotlin.concurrent.thread(name = "plugin-settings-nav") {
            try { TvHost.py("plugin_settings_event", plugin, "__open__", "{}") } catch (_: Throwable) {}
            if (!ev.isNullOrEmpty()) {
                try { TvHost.py("plugin_settings_event", plugin, ev, "{}") } catch (_: Throwable) {}
            }
            runOnUiThread { reload() }
        }
    }

    // ── back: one level up inside the plugin, then close ────────────────────
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        goBack()
    }

    private fun goBack() {
        if (busy) return
        busy = true
        val values = collect()                      // typed values of the page being left are saved by the plugin
        kotlin.concurrent.thread(name = "plugin-settings-back") {
            var handled = false
            try {
                handled = JSONObject(TvHost.py("plugin_settings_event", plugin, "__back__", values)).optBoolean("handled")
            } catch (_: Throwable) {
            }
            runOnUiThread {
                busy = false
                if (handled) reload() else finish()
            }
        }
    }

    private fun reload() {
        kotlin.concurrent.thread(name = "plugin-settings") {
            val json = try {
                TvHost.py("plugin_settings_items", plugin)
            } catch (e: Throwable) {
                "[{\"type\":\"label\",\"text\":\"Ошибка: ${e.message?.replace("\"", "'")}\"}]"
            }
            runOnUiThread { render(json) }
        }
    }

    private fun render(json: String) {
        val keepY = scroll.scrollY
        box.removeAllViews()
        fields.clear()
        checks.clear()
        var first: View? = null
        var newTitle: String? = null
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.optString("type") == "title") {
                    newTitle = o.optString("text")
                    continue
                }
                val v = makeItem(o) ?: continue
                if (first == null && v.isFocusable) first = v
            }
        } catch (e: Throwable) {
            status.text = "Не удалось показать настройки: ${e.message}"
        }
        loaded = true
        if (status.text.toString() == "Загрузка…") status.text = ""
        // A different page (the plugin changed the header) opens at the top; the same page keeps its scroll.
        val samePage = newTitle == null || newTitle == shownTitle
        if (newTitle != null) {
            titleView.text = newTitle
            shownTitle = newTitle
        }
        scroll.post {
            if (samePage && keepY > 0) scroll.scrollTo(0, keepY) else { scroll.scrollTo(0, 0); first?.requestFocus() }
        }
    }

    private fun fieldBg(): StateListDrawable {
        fun shape(stroke: Int, w: Int) = GradientDrawable().apply {
            setColor(Skin.theme()?.surface ?: 0xFF0A0D10.toInt())
            setStroke(w, stroke)
            cornerRadius = dp(if (Skin.theme() != null) 12 else 8).toFloat()
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), shape(Hud.CYAN, dp(2)))
            addState(intArrayOf(), shape(Skin.theme()?.focus ?: 0xFF2A3A48.toInt(), dp(1)))
        }
    }

    private fun makeItem(o: JSONObject): View? {
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        when (o.optString("type")) {
            "label" -> {
                val t = TextView(this).apply {
                    text = o.optString("text")
                    textSize = 14f
                    setTextColor(MenuKit.muted)
                }
                box.addView(t, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(2); bottomMargin = dp(8) })
                return t
            }
            "section" -> {
                val t = MenuKit.heading(this, o.optString("text"))
                box.addView(t, LinearLayout.LayoutParams(match, wrap))
                return t
            }
            "button" -> {
                val id = o.optString("id")
                val label = o.optString("label")
                val sub = o.optString("sub")
                val b = MenuKit.button(this, if (sub.isEmpty()) label else MenuKit.lines(label, sub), true) { onButton(id) }
                b.minHeight = dp(54)
                val pinKind = o.optString("pin")
                if (pinKind == "page" || pinKind == "act") {
                    val key = Pins.pluginKey(plugin, o.optString("pin_title").ifEmpty { label }, o.optString("pin_event").ifEmpty { id }, pinKind)
                    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                    row.addView(b, LinearLayout.LayoutParams(0, wrap, 1f))
                    addPinChip(row, key)
                    box.addView(row, LinearLayout.LayoutParams(match, wrap).apply { bottomMargin = dp(8) })
                } else {
                    box.addView(b, LinearLayout.LayoutParams(match, wrap).apply { bottomMargin = dp(8) })
                }
                return b
            }
            "color" -> return makeColor(o)
            "check" -> {
                // Tick box: the value goes back to the plugin as "1" / "0" under its id (like a text field).
                val id = o.optString("id")
                val c = CheckBox(this).apply {
                    text = o.optString("label")
                    isChecked = o.optBoolean("checked", false)
                    textSize = 15f
                    setTextColor(Hud.TEXT)
                    buttonTintList = android.content.res.ColorStateList.valueOf(Hud.CYAN)
                    background = fieldBg()
                    setPadding(dp(10), dp(6), dp(10), dp(6))
                    isFocusable = true
                }
                checks[id] = c
                box.addView(c, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(4) })
                return c
            }
            "text" -> {
                val id = o.optString("id")
                val multi = o.optBoolean("multiline", false)
                box.addView(TextView(this).apply {
                    text = o.optString("label")
                    textSize = 15f
                    setTextColor(Hud.TEXT)
                }, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(8) })
                val e = EditText(this).apply {
                    setText(o.optString("value"))
                    hint = o.optString("hint")
                    setTextColor(Hud.TEXT)
                    setHintTextColor(Hud.MUTED)
                    textSize = 16f
                    background = fieldBg()
                    setPadding(dp(10), dp(8), dp(10), dp(8))
                    if (multi) {
                        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                        setSingleLine(false)
                        minLines = 2
                        maxLines = Int.MAX_VALUE
                        gravity = Gravity.TOP or Gravity.START
                    } else {
                        inputType = InputType.TYPE_CLASS_TEXT
                        setSingleLine(true)
                    }
                }
                fields[id] = e
                box.addView(e, LinearLayout.LayoutParams(match, wrap))
                return e
            }
        }
        return null
    }

    /** "＋ На главный" next to a button; flips to "✔ На главном" in place (nothing is reloaded). */
    private fun addPinChip(row: LinearLayout, key: String) {
        val chip = MenuKit.pinChip(this, Pins.has(this, key)) {
            val now = Pins.toggle(this, key)
            Toast.makeText(this,
                if (now) "Кнопка добавлена на главный экран" else "Кнопка убрана с главного экрана",
                Toast.LENGTH_SHORT).show()
            row.removeViewAt(1)
            addPinChip(row, key)
            row.getChildAt(1)?.requestFocus()
        }
        chip.minHeight = dp(54)
        row.addView(chip, 1, LinearLayout.LayoutParams(dp(150), ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(8) })
    }


    /** Colour mixer: swatch, four equalizer bars (R G B A), hex field. Empty hex = "use the default". */
    private fun makeColor(o: JSONObject): View {
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val id = o.optString("id")
        val value = o.optString("value")
        val def = Skin.color(o.optString("default"), Color.WHITE)
        box.addView(TextView(this).apply {
            text = o.optString("label")
            textSize = 15f
            setTextColor(Hud.TEXT)
        }, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(10) })

        var argb = Skin.color(value, def)
        val hex = EditText(this).apply {
            setText(value)
            hint = o.optString("default").ifEmpty { "#RRGGBB" }
            setTextColor(Hud.TEXT)
            setHintTextColor(Hud.MUTED)
            textSize = 16f
            background = fieldBg()
            setPadding(dp(10), dp(8), dp(10), dp(8))
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
        }
        fields[id] = hex
        val swatch = View(this)
        fun paintSwatch() {
            swatch.background = Skin.roundRect(this, argb, 0xFFFFFFFF.toInt(), 1f, 10)
        }
        paintSwatch()

        var syncing = false
        val bars = ArrayList<EqBar>()
        fun writeHex() {
            syncing = true
            val a = Color.alpha(argb)
            hex.setText(if (a == 255) String.format("#%02X%02X%02X", Color.red(argb), Color.green(argb), Color.blue(argb))
                        else String.format("#%02X%02X%02X%02X", a, Color.red(argb), Color.green(argb), Color.blue(argb)))
            syncing = false
        }
        fun setBars() { bars[0].value = Color.red(argb); bars[1].value = Color.green(argb); bars[2].value = Color.blue(argb); bars[3].value = Color.alpha(argb) }
        val tints = intArrayOf(0xFFFF5252.toInt(), 0xFF4CAF50.toInt(), 0xFF448AFF.toInt(), 0xFFE0E0E0.toInt())
        val init = intArrayOf(Color.red(argb), Color.green(argb), Color.blue(argb), Color.alpha(argb))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(swatch, LinearLayout.LayoutParams(dp(56), dp(120)).apply { marginEnd = dp(14) })
        for (i in 0 until 4) {
            val bar = EqBar(this, tints[i], init[i]) { v ->
                argb = when (i) {
                    0 -> Color.argb(Color.alpha(argb), v, Color.green(argb), Color.blue(argb))
                    1 -> Color.argb(Color.alpha(argb), Color.red(argb), v, Color.blue(argb))
                    2 -> Color.argb(Color.alpha(argb), Color.red(argb), Color.green(argb), v)
                    else -> Color.argb(v, Color.red(argb), Color.green(argb), Color.blue(argb))
                }
                paintSwatch()
                writeHex()
            }
            bars.add(bar)
            row.addView(bar, LinearLayout.LayoutParams(wrap, wrap).apply { marginEnd = dp(6) })
        }
        val side = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        side.addView(hex, LinearLayout.LayoutParams(dp(190), wrap))
        side.addView(Hud.button(this, "Сброс") {
            hex.setText("")
            argb = def
            paintSwatch()
            setBars()
        }, LinearLayout.LayoutParams(wrap, wrap).apply { topMargin = dp(8) })
        row.addView(side, LinearLayout.LayoutParams(wrap, wrap).apply { marginStart = dp(12) })
        hex.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                if (syncing) return
                val t = s?.toString()?.trim().orEmpty()
                val parsed = try { if (t.length >= 7) Color.parseColor(if (t.startsWith("#")) t else "#$t") else null } catch (_: Throwable) { null }
                if (parsed != null) { argb = parsed; paintSwatch(); setBars() }
            }
        })
        box.addView(row, LinearLayout.LayoutParams(wrap, wrap).apply { topMargin = dp(4) })
        return bars[0]
    }

    private fun collect(): String {
        val o = JSONObject()
        for ((k, v) in fields) o.put(k, v.text.toString())
        for ((k, c) in checks) o.put(k, if (c.isChecked) "1" else "0")
        return o.toString()
    }

    private fun onButton(id: String) {
        if (busy) return
        busy = true
        val values = collect()
        status.setTextColor(Hud.AMBER)
        status.text = "Выполняю…"
        kotlin.concurrent.thread(name = "plugin-settings") {
            val res = try {
                JSONObject(TvHost.py("plugin_settings_event", plugin, id, values))
            } catch (e: Throwable) {
                JSONObject().put("message", "Ошибка: ${e.message}").put("refresh", false)
            }
            runOnUiThread {
                busy = false
                val msg = res.optString("message")
                status.setTextColor(Hud.CYAN)
                status.text = msg
                if (msg.isNotEmpty()) Bridge.log("SYS: $plugin: $msg")
                if (res.optBoolean("refresh")) reload()
            }
        }
    }

    /** Leaving the page saves the typed values (plugin gets the "__leave__" event). */
    override fun onStop() {
        if (loaded && (fields.isNotEmpty() || checks.isNotEmpty()) && !isChangingConfigurations) {
            val values = collect()
            val name = plugin
            kotlin.concurrent.thread(name = "plugin-settings") {
                try {
                    TvHost.py("plugin_settings_event", name, "__leave__", values)
                } catch (e: Throwable) {
                    Bridge.log("SYS: $name: сохранение при выходе: ${e.message}")
                }
            }
        }
        super.onStop()
    }

    companion object {
        const val EXTRA_PLUGIN = "plugin"
        const val EXTRA_TITLE = "title"
        const val EXTRA_EVENT = "event"
    }
}
