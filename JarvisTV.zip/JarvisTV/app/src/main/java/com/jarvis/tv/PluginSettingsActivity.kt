package com.jarvis.tv

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

/**
 * Generic settings page of a plugin (opened from the Service menu).
 * The plugin describes the page itself (see "plugin settings pages" in brain.py):
 * labels, buttons and text fields; every button press sends all field values back to the plugin.
 */
class PluginSettingsActivity : Activity() {

    private lateinit var plugin: String
    private lateinit var status: TextView
    private lateinit var box: LinearLayout
    private lateinit var scroll: ScrollView
    private val fields = LinkedHashMap<String, EditText>()
    private var loaded = false

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        plugin = intent.getStringExtra(EXTRA_PLUGIN) ?: ""
        val title = intent.getStringExtra(EXTRA_TITLE) ?: plugin

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF101418.toInt())
            setPadding(dp(24), dp(16), dp(24), dp(16))
        }
        root.addView(TextView(this).apply {
            text = title.uppercase()
            textSize = 22f
            setTextColor(Hud.CYAN)
            letterSpacing = 0.1f
        })
        status = TextView(this).apply {
            textSize = 14f
            setTextColor(Hud.AMBER)
            text = "Загрузка…"
        }
        root.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(4)
            bottomMargin = dp(8)
        })
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply {
            isFocusable = false
            addView(box)
        }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        reload()
    }

    private fun reload() {
        kotlin.concurrent.thread(name = "plugin-settings") {
            val json = try {
                TvHost.py("plugin_settings_items", plugin)
            } catch (e: Throwable) {
                "[{\"type\":\"label\",\"text\":\"Ошибка: ${e.message?.replace("\"", "'")}\"}]"
            }
            runOnUiThread { render(json) }
        }
    }

    private fun render(json: String) {
        val keepY = scroll.scrollY
        box.removeAllViews()
        fields.clear()
        var first: View? = null
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val v = makeItem(arr.getJSONObject(i)) ?: continue
                if (first == null && v.isFocusable) first = v
            }
        } catch (e: Throwable) {
            status.text = "Не удалось показать настройки: ${e.message}"
        }
        loaded = true
        if (status.text.toString() == "Загрузка…") status.text = ""
        scroll.post {
            if (keepY > 0) scroll.scrollTo(0, keepY) else first?.requestFocus()
        }
    }

    private fun fieldBg(): StateListDrawable {
        fun shape(stroke: Int, w: Int) = GradientDrawable().apply {
            setColor(0xFF0A0D10.toInt())
            setStroke(w, stroke)
            cornerRadius = dp(4).toFloat()
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), shape(Hud.CYAN, dp(2)))
            addState(intArrayOf(), shape(0xFF2A3A48.toInt(), dp(1)))
        }
    }

    private fun makeItem(o: JSONObject): View? {
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        when (o.optString("type")) {
            "label" -> {
                val t = TextView(this).apply {
                    text = o.optString("text")
                    textSize = 14f
                    setTextColor(Hud.MUTED)
                }
                box.addView(t, LinearLayout.LayoutParams(match, wrap).apply { bottomMargin = dp(8) })
                return t
            }
            "button" -> {
                val id = o.optString("id")
                val b = Hud.button(this, o.optString("label")) { onButton(id) }
                box.addView(b, LinearLayout.LayoutParams(wrap, wrap).apply { bottomMargin = dp(8) })
                return b
            }
            "text" -> {
                val id = o.optString("id")
                val multi = o.optBoolean("multiline", false)
                box.addView(TextView(this).apply {
                    text = o.optString("label")
                    textSize = 15f
                    setTextColor(Hud.TEXT)
                }, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(8) })
                val e = EditText(this).apply {
                    setText(o.optString("value"))
                    hint = o.optString("hint")
                    setTextColor(Color.WHITE)
                    setHintTextColor(0xFF667788.toInt())
                    textSize = 16f
                    background = fieldBg()
                    setPadding(dp(10), dp(8), dp(10), dp(8))
                    if (multi) {
                        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                        setSingleLine(false)
                        minLines = 2
                        maxLines = Int.MAX_VALUE
                        gravity = Gravity.TOP or Gravity.START
                    } else {
                        inputType = InputType.TYPE_CLASS_TEXT
                        setSingleLine(true)
                    }
                }
                fields[id] = e
                box.addView(e, LinearLayout.LayoutParams(match, wrap))
                return e
            }
        }
        return null
    }

    private fun collect(): String {
        val o = JSONObject()
        for ((k, v) in fields) o.put(k, v.text.toString())
        return o.toString()
    }

    private fun onButton(id: String) {
        val values = collect()
        status.setTextColor(Hud.AMBER)
        status.text = "Выполняю…"
        kotlin.concurrent.thread(name = "plugin-settings") {
            val res = try {
                JSONObject(TvHost.py("plugin_settings_event", plugin, id, values))
            } catch (e: Throwable) {
                JSONObject().put("message", "Ошибка: ${e.message}").put("refresh", false)
            }
            runOnUiThread {
                val msg = res.optString("message")
                status.setTextColor(Hud.CYAN)
                status.text = msg
                if (msg.isNotEmpty()) Bridge.log("SYS: $plugin: $msg")
                if (res.optBoolean("refresh")) reload()
            }
        }
    }

    /** Leaving the page saves the typed values (plugin gets the "__leave__" event). */
    override fun onStop() {
        if (loaded && fields.isNotEmpty() && !isChangingConfigurations) {
            val values = collect()
            val name = plugin
            kotlin.concurrent.thread(name = "plugin-settings") {
                try {
                    TvHost.py("plugin_settings_event", name, "__leave__", values)
                } catch (e: Throwable) {
                    Bridge.log("SYS: $name: сохранение при выходе: ${e.message}")
                }
            }
        }
        super.onStop()
    }

    companion object {
        const val EXTRA_PLUGIN = "plugin"
        const val EXTRA_TITLE = "title"
    }
}
