package com.jarvis.tv

import android.app.Application
import android.os.StrictMode

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Bridge.app = this
        // The original hands plain file paths to players/browsers (file:// URIs).
        StrictMode.setVmPolicy(StrictMode.VmPolicy.Builder().build())
    }
}
