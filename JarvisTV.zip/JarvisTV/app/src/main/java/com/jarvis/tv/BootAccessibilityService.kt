package com.jarvis.tv

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.os.SystemClock
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent

/**
 * Empty accessibility service. The system binds enabled accessibility services early in boot, well before
 * BOOT_COMPLETED reaches ordinary apps on a slow TV, so this starts JARVIS sooner.
 * It reads nothing and clicks nothing.
 */
class BootAccessibilityService : AccessibilityService() {
    companion object {
        /** Is the service switched on in Settings → Accessibility. */
        fun isEnabled(ctx: Context): Boolean = try {
            val me = ComponentName(ctx, BootAccessibilityService::class.java).flattenToString()
            (Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "")
                .split(':').any { it.equals(me, true) }
        } catch (_: Throwable) { false }

        /** Only a bind this soon after power-on counts as "the TV just started". */
        private const val BOOT_WINDOW_S = 300
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        val sinceBoot = SystemClock.elapsedRealtime() / 1000
        BootReceiver.note(this, "спец. возможности: служба подключена")
        // late re-binds (user toggled it, process restarted) must not pop the screen up
        BootReceiver.kickOff(this, openScreen = sinceBoot < BOOT_WINDOW_S)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
