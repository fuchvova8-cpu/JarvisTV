package com.jarvis.tv

import android.app.Application
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.DisplayMetrics
import android.view.KeyEvent
import android.view.WindowManager
import android.webkit.MimeTypeMap
import android.widget.Toast
import java.io.File
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.FutureTask
import java.util.concurrent.TimeUnit

/** What the screen shows; implemented by MainActivity while it is on screen. */
interface UiListener {
    fun onLog(line: String)
    fun onState(state: String)
    fun onContent(title: String, text: String)
    fun onMuted(muted: Boolean)
    fun onConfirm(title: String, detail: String)
    fun onConfirmHide()
    fun onQuiz(json: String)
    fun onQuizHide()
    fun onVideoOpen(src: String, title: String, muted: Boolean, audio: String)
    fun onImageOpen(path: String, title: String)
    fun onVideoClose()
    fun onVideoMute(muted: Boolean)
    fun onVideoPause(paused: Boolean)
    fun onVideoSeek(seconds: Double, relative: Boolean)
    fun videoState(): String
    fun onPromptKey()
    fun onReady(ready: Boolean, name: String)
}

/**
 * The single object Python talks to (tvshim/bridge.py -> com.jarvis.tv.Bridge.INSTANCE).
 *
 * Two jobs: (1) draw — forward what Python says to whichever activity is on
 * screen, and remember it so a re-opened activity can catch up; (2) act — the
 * Android side of the PC commands (volume, links, apps, clipboard, speech,
 * notifications, ADB).
 *
 * Every method may be called from any Python thread.
 */
object Bridge {
    lateinit var app: Application

    private val main = Handler(Looper.getMainLooper())

    @Volatile var listener: UiListener? = null

    // ── state replayed to a freshly attached activity ───────────────────────
    private val logLines = ArrayList<String>()
    @Volatile var curState: String = "SLEEPING"
    @Volatile var curMuted: Boolean = false
    @Volatile var curTitle: String = ""
    @Volatile var curText: String = ""
    @Volatile var curQuiz: String = ""
    @Volatile var curConfirm: Pair<String, String>? = null
    @Volatile var ready: Boolean = false
    @Volatile var assistantName: String = "JARVIS"
    @Volatile var promptingKey: Boolean = false

    // 0..1 loudness of whatever is audible right now (mic while listening, voice
    // while speaking). The HUD reads it on every frame; no posting needed.
    @Volatile var level: Float = 0f
    @Volatile var levelAt: Long = 0L

    // While the system speech recognizer owns the microphone our own capture steps aside.
    @Volatile var micPaused: Boolean = false
        set(v) { if (field != v) { field = v; Diag.log("MIC", "micPaused=$v") } }
    // Android 9 gives the microphone to one capturer; while Jarvis is off-screen the
    // TV's own voice search needs it, so capture is released until we are visible again.
    @Volatile var appVisible: Boolean = true
        set(v) { if (field != v) { field = v; Diag.log("MIC", "appVisible=$v") } }
    val micFree: Boolean get() = micPaused || !appVisible || MicMode.captureOff

    fun snapshotLog(): List<String> = synchronized(logLines) { ArrayList(logLines) }

    private fun ui(block: (UiListener) -> Unit) {
        val l = listener ?: return
        main.post { try { block(l) } catch (_: Throwable) {} }
    }

    private fun <T> onMain(default: T, block: () -> T): T {
        if (Looper.myLooper() == Looper.getMainLooper()) return block()
        val task = FutureTask<T> { block() }
        main.post(task)
        return try { task.get(3, TimeUnit.SECONDS) } catch (_: Throwable) { default }
    }

    // ════════════ Python -> screen ════════════
    val logTaps = java.util.concurrent.CopyOnWriteArrayList<(String) -> Unit>()

    fun log(text: String) {
        Diag.log("CHAT", text)
        for (t in logTaps) main.post { try { t(text) } catch (_: Throwable) {} }
        synchronized(logLines) {
            logLines.add(text)
            while (logLines.size > 400) logLines.removeAt(0)
        }
        ui { it.onLog(text) }
    }

    fun state(s: String) { if (s != curState) Diag.log("STATE", "$curState -> $s"); curState = s; ui { it.onState(s) } }

    fun level(f: Float) { level = f; levelAt = System.nanoTime() }

    fun content(title: String, text: String) {
        curTitle = title; curText = text
        ui { it.onContent(title, text) }
    }

    fun muted(m: Boolean) { curMuted = m; ui { it.onMuted(m) } }

    fun uiReady(r: Boolean, name: String) {
        ready = r; assistantName = name
        ui { it.onReady(r, name) }
        if (!r) promptKey()
    }

    fun promptKey() { promptingKey = true; ui { it.onPromptKey() } }

    fun confirmShow(title: String, detail: String) {
        curConfirm = Pair(title, detail)
        ui { it.onConfirm(title, detail) }
    }

    fun confirmHide() { curConfirm = null; ui { it.onConfirmHide() } }

    fun quizShow(json: String) { curQuiz = json; ui { it.onQuiz(json) } }
    fun quizHide() { curQuiz = ""; ui { it.onQuizHide() } }

    fun videoOpen(src: String, title: String, muted: Boolean, audio: String) =
        ui { it.onVideoOpen(src, title, muted, audio) }

    fun imageOpen(path: String, title: String) = ui { it.onImageOpen(path, title) }
    fun videoClose() = ui { it.onVideoClose() }
    fun videoMute(m: Boolean) = ui { it.onVideoMute(m) }
    fun videoPause(p: Boolean) = ui { it.onVideoPause(p) }
    fun videoSeek(seconds: Double, relative: Boolean) = ui { it.onVideoSeek(seconds, relative) }
    fun videoState(): String = onMain("{}") { listener?.videoState() ?: "{}" }

    // A TV has no camera for Python's webcam calls; accepted and ignored.
    fun cameraFrame(bytes: ByteArray) {}
    fun cameraStream(on: Boolean) {}

    // ════════════ Python -> Android system ════════════
    private val audio: AudioManager
        get() = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun volumeGet(): Int {
        val am = audio
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        return Math.round(am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100f / max)
    }

    fun volumeSet(pct: Int) {
        val am = audio
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val v = Math.round(pct.coerceIn(0, 100) * max / 100f)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, v, AudioManager.FLAG_SHOW_UI)
    }

    fun muteGet(): Boolean = audio.isStreamMute(AudioManager.STREAM_MUSIC)

    fun muteSet(m: Boolean) {
        audio.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (m) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE,
            AudioManager.FLAG_SHOW_UI
        )
    }

    fun mediaKey(code: Int) {
        val am = audio
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    fun screenSize(): IntArray {
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        return intArrayOf(dm.widthPixels, dm.heightPixels)
    }

    fun toast(text: String) { main.post { Toast.makeText(app, text, Toast.LENGTH_LONG).show() } }

    private fun ensureChannel(id: String, name: String, importance: Int) {
        val nm = app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(id) == null) nm.createNotificationChannel(NotificationChannel(id, name, importance))
    }

    fun notify(title: String, text: String) {
        toast("$title: $text")
        try {
            ensureChannel("jarvis_alerts", "JARVIS", NotificationManager.IMPORTANCE_DEFAULT)
            val n = Notification.Builder(app, "jarvis_alerts")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true)
                .build()
            val nm = app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify((System.currentTimeMillis() % 100000).toInt(), n)
        } catch (_: Throwable) {}
    }

    fun clipSet(text: String) {
        onMain(Unit) {
            val cm = app.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("jarvis", text))
        }
    }

    fun clipGet(): String = onMain("") {
        val cm = app.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(app)?.toString() ?: ""
    }

    /** URL, scheme (spotify:, steam://) or a file path -> whatever app opens it. */
    fun openUrl(target: String): Boolean {
        return try {
            val intent: Intent
            if (target.contains("://") || (target.contains(":") && !target.startsWith("/") && target.indexOf(':') > 1)) {
                intent = Intent(Intent.ACTION_VIEW, Uri.parse(target))
            } else {
                val f = File(target)
                if (!f.exists()) return false
                val ext = MimeTypeMap.getFileExtensionFromUrl(f.name)
                val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.lowercase()) ?: "*/*"
                intent = Intent(Intent.ACTION_VIEW).setDataAndType(Uri.fromFile(f), mime)
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            app.startActivity(intent)
            true
        } catch (_: Throwable) { false }
    }

    /** Open an installed app by (part of) its name or package. */
    fun launchApp(name: String): Boolean {
        val q = name.trim().lowercase()
        if (q.isEmpty()) return false
        val pm = app.packageManager
        var best: Intent? = null
        var bestScore = 0
        val seen = HashSet<String>()
        for (cat in arrayOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val probe = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(probe, 0)) {
                val pkg = ri.activityInfo.packageName
                if (!seen.add(pkg)) continue
                val label = ri.loadLabel(pm).toString().lowercase()
                val score = when {
                    label == q || pkg.lowercase() == q -> 3
                    label.startsWith(q) -> 2
                    label.contains(q) || (label.length > 2 && q.contains(label)) || pkg.lowercase().contains(q) -> 1
                    else -> 0
                }
                if (score > bestScore) {
                    val li = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg)
                    if (li != null) { best = li; bestScore = score }
                }
            }
        }
        val intent = best ?: return false
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            app.startActivity(intent)
            true
        } catch (_: Throwable) { false }
    }

    // ════════════ speech: the Android engine behind `espeak-ng` ════════════
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    private val ttsLock = Any()

    private fun ensureTts(): TextToSpeech? {
        if (tts == null) {
            val latch = CountDownLatch(1)
            main.post {
                tts = TextToSpeech(app) { status ->
                    ttsReady = (status == TextToSpeech.SUCCESS)
                    latch.countDown()
                }
            }
            latch.await(6, TimeUnit.SECONDS)
        }
        return if (ttsReady) tts else null
    }

    private fun applyVoice(t: TextToSpeech, voice: String, wpm: Int) {
        val tag = voice.trim().replace('_', '-')
        val loc = if (tag.isEmpty() || tag == "default") Locale.getDefault() else Locale.forLanguageTag(tag)
        val r = t.isLanguageAvailable(loc)
        t.language = if (r >= TextToSpeech.LANG_AVAILABLE) loc else Locale.getDefault()
        t.setSpeechRate(if (wpm > 0) (wpm / 175f).coerceIn(0.4f, 2.5f) else 1f)
    }

    private fun waitFor(t: TextToSpeech, id: String, timeoutSec: Long): Boolean {
        val done = CountDownLatch(1)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { if (utteranceId == id) done.countDown() }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { if (utteranceId == id) done.countDown() }
        })
        return done.await(timeoutSec, TimeUnit.SECONDS)
    }

    fun tts(text: String, voice: String): Boolean = synchronized(ttsLock) {
        val t = ensureTts() ?: return false
        applyVoice(t, voice, 0)
        val id = "u" + System.nanoTime()
        val done = CountDownLatch(1)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { if (utteranceId == id) done.countDown() }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { if (utteranceId == id) done.countDown() }
        })
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
        done.await(90, TimeUnit.SECONDS)
        true
    }

    fun ttsToFile(text: String, voice: String, wpm: Int, path: String): Boolean = synchronized(ttsLock) {
        val t = ensureTts() ?: return false
        applyVoice(t, voice, wpm)
        val id = "f" + System.nanoTime()
        val f = File(path)
        f.parentFile?.mkdirs()
        val started = t.synthesizeToFile(text, Bundle(), f, id)
        if (started != TextToSpeech.SUCCESS) return false
        waitFor(t, id, 90)
        f.exists() && f.length() > 44
    }

    fun ttsLanguages(): String {
        val t = ensureTts() ?: return ""
        return try {
            t.availableLanguages.joinToString(",") { it.toLanguageTag() }
        } catch (_: Throwable) { "" }
    }

    // ════════════ ADB ════════════
    fun adbAvailable(): Boolean = Adb.available()
    fun adbShell(cmd: String): String = Adb.shell(cmd)
    fun adbScreencap(): ByteArray = Adb.screencap()
}
