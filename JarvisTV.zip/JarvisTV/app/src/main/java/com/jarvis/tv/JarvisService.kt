package com.jarvis.tv

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.os.PowerManager
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import kotlin.concurrent.thread

/** Keeps Mark LVII (the Python side) alive whether or not the screen is open. */
class JarvisService : Service() {
    companion object {
        @Volatile var started = false

        fun start(ctx: Context) {
            val i = Intent(ctx, JarvisService::class.java)
            ctx.startForegroundService(i)
        }
    }

    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, notification())
        if (!started) {
            started = true
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jarvis:core").apply { acquire() }
            thread(name = "jarvis-boot") { boot() }
        }
        return START_STICKY
    }

    private fun notification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel("jarvis_service") == null) {
            nm.createNotificationChannel(
                NotificationChannel("jarvis_service", "JARVIS", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Builder(this, "jarvis_service")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("JARVIS")
            .setContentText("Mark LVII работает")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    private fun boot() {
        try {
            Bridge.log("SYS: Распаковка Mark LVII…")
            val dir = AssetInstaller.install(this)
            if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                Bridge.log("SYS: Прогрев микрофона…")
                try { MicBridge.warmUp() } catch (_: Throwable) {}
            }
            if (!Python.isStarted()) Python.start(AndroidPlatform(this))
            Bridge.log("SYS: Запуск Python-ядра…")
            val err = Python.getInstance().getModule("tvshim.entry")
                .callAttr("start", dir.absolutePath).toString()
            if (err.isNotEmpty()) {
                Bridge.log("ERR: запуск не удался: $err")
                started = false
            } else {
                Bridge.log("SYS: Папка Jarvis: ${dir.absolutePath}")
            }
        } catch (t: Throwable) {
            Bridge.log("ERR: ${t.javaClass.simpleName}: ${t.message}")
            started = false
        }
    }

    override fun onDestroy() {
        try { wake?.release() } catch (_: Throwable) {}
        super.onDestroy()
    }
}
