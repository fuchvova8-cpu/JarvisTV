package com.jarvis.tv

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Auto-start with the TV (switch it off in the service menu inside the app).
 * Starts the JARVIS service and, unless "autostart_ui" is off, opens the main screen a few seconds later.
 */
class BootReceiver : BroadcastReceiver() {
    companion object {
        /** Appends a line to Jarvis/boot.log (Python and the log screen are not up yet at boot). */
        fun note(ctx: Context, text: String) {
            try {
                val f = java.io.File(AssetInstaller.targetDir(ctx), "boot.log")
                f.parentFile?.mkdirs()
                val line = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date()) + "  " + text + "\n"
                f.appendText(line)
                if (f.length() > 20_000) f.writeText(f.readLines().takeLast(100).joinToString("\n", postfix = "\n"))
            } catch (_: Throwable) {}
        }

        /** Last lines of boot.log, for the log screen. */
        fun tail(ctx: Context, n: Int = 6): List<String> = try {
            java.io.File(AssetInstaller.targetDir(ctx), "boot.log").readLines().takeLast(n)
        } catch (_: Throwable) { emptyList() }
    }

    override fun onReceive(context: Context, intent: Intent) {
        val a = intent.action
        note(context, "получен сигнал: $a")
        if (a != Intent.ACTION_BOOT_COMPLETED && a != "android.intent.action.QUICKBOOT_POWERON" &&
            a != "com.htc.intent.action.QUICKBOOT_POWERON") return
        val p = context.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
        if (!p.getBoolean("autostart", true)) { note(context, "автозапуск выключен в меню — выход"); return }
        try {
            JarvisService.start(context)
            note(context, "служба запущена")
        } catch (t: Throwable) {
            note(context, "служба НЕ запущена: ${t.javaClass.simpleName}: ${t.message}")
        }
        if (!p.getBoolean("autostart_ui", true)) { note(context, "экран при старте выключен в меню"); return }
        val app = context.applicationContext
        val pending = goAsync()
        Thread {
            try {
                Thread.sleep(6000)       // let the TV launcher come up first, otherwise it covers our screen
                app.startActivity(Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                note(app, "экран открыт")
            } catch (t: Throwable) {
                note(app, "экран НЕ открыт: ${t.javaClass.simpleName}: ${t.message}")
            } finally {
                pending.finish()
            }
        }.start()
    }
}
