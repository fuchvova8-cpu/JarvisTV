package com.jarvis.tv

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Auto-start with the TV (switch it off in the service menu inside the app).
 * Starts the JARVIS service and, unless "autostart_ui" is off, opens the main screen a few seconds later.
 */
class BootReceiver : BroadcastReceiver() {
    companion object {
        /** Set by MainActivity.onStart/onStop: is our screen on top right now. */
        @Volatile var screenUp = false
        private val uiScheduled = AtomicBoolean(false)

        private val BOOT_ACTIONS = setOf(
            Intent.ACTION_BOOT_COMPLETED,
            "android.intent.action.LOCKED_BOOT_COMPLETED",
            "android.intent.action.QUICKBOOT_POWERON",
            "com.htc.intent.action.QUICKBOOT_POWERON")

        /** Appends a line to Jarvis/boot.log (Python and the log screen are not up yet at boot). */
        fun note(ctx: Context, text: String) {
            try {
                val f = java.io.File(AssetInstaller.targetDir(ctx), "boot.log")
                f.parentFile?.mkdirs()
                val line = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date()) +
                    " [+" + (SystemClock.elapsedRealtime() / 1000) + "с с включения]  " + text + "\n"
                f.appendText(line)
                if (f.length() > 20_000) f.writeText(f.readLines().takeLast(100).joinToString("\n", postfix = "\n"))
            } catch (_: Throwable) {}
        }

        /** Last lines of boot.log, for the log screen. */
        fun tail(ctx: Context, n: Int = 6): List<String> = try {
            java.io.File(AssetInstaller.targetDir(ctx), "boot.log").readLines().takeLast(n)
        } catch (_: Throwable) { emptyList() }
    }

    override fun onReceive(context: Context, intent: Intent) {
        val a = intent.action
        note(context, "получен сигнал: $a")
        if (a !in BOOT_ACTIONS) return
        val p = context.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
        if (!p.getBoolean("autostart", true)) { note(context, "автозапуск выключен в меню — выход"); return }
        try {
            JarvisService.start(context)      // no-op if an earlier boot signal already started it
            note(context, "служба запущена")
        } catch (t: Throwable) {
            note(context, "служба НЕ запущена: ${t.javaClass.simpleName}: ${t.message}")
        }
        if (!p.getBoolean("autostart_ui", true)) { note(context, "экран при старте выключен в меню"); return }
        if (!uiScheduled.compareAndSet(false, true)) { note(context, "экран уже запланирован — пропуск"); return }
        // No goAsync(): holding an ordered boot broadcast would delay every app after us. The foreground
        // service keeps the process alive. Open the screen at once and, if the TV launcher comes up and
        // covers it, bring it back — until it stays on top for 1.5 s (max 12 s).
        val app = context.applicationContext
        Thread {
            try {
                val t0 = SystemClock.elapsedRealtime()
                var upSince = 0L
                var launches = 0
                while (SystemClock.elapsedRealtime() - t0 < 12_000) {
                    val now = SystemClock.elapsedRealtime()
                    if (screenUp) {
                        if (upSince == 0L) upSince = now
                        else if (now - upSince >= 1500) break
                    } else {
                        upSince = 0L
                        if (launches < 8) {
                            app.startActivity(Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            launches++
                            note(app, "экран: запуск №$launches")
                        }
                    }
                    Thread.sleep(500)
                }
                note(app, "экран открыт (запусков: $launches)")
            } catch (t: Throwable) {
                note(app, "экран НЕ открыт: ${t.javaClass.simpleName}: ${t.message}")
            }
        }.start()
    }
}
