package com.jarvis.tv

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

/**
 * Results panel: long answers as text, or search results as a grid of poster cards.
 * Poster cards come as JSON: [{"title","sub","image","cmd","app"}]. D-pad moves between cards,
 * OK opens the title in its app, Back closes the panel, it closes itself after a period of inactivity.
 */
class ResultsActivity : Activity() {

    companion object {
        /** The open panel, if any (for the quick-action "свернуть/развернуть"). */
        @Volatile var current: ResultsActivity? = null
    }

    private val mainH = android.os.Handler(android.os.Looper.getMainLooper())

    // Skin (plugin screen_style): null = classic look.
    private val sk = Skin.load()
    private val th = sk?.let { Skin.theme(it) }
    private val rc: JSONObject? = sk?.results
    private fun rD(k: String, d: Double): Double = rc?.optDouble(k, d) ?: d
    private fun rInt(k: String, d: Int): Int = rc?.optInt(k, d) ?: d
    private fun rB(k: String, d: Boolean): Boolean {
        val v = rc?.opt(k)
        return when (v) { is Boolean -> v; is Number -> v.toInt() != 0; else -> d }
    }
    private fun panelW(): Int = (resources.displayMetrics.widthPixels * (if (rc != null) rD("w", 86.0) else 86.0) / 100.0).toInt()
    private val cAccent = th?.accent ?: Hud.CYAN
    private val cText = th?.text ?: Hud.TEXT
    private val cMuted = th?.muted ?: Hud.MUTED
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }
    private lateinit var titleView: TextView
    private lateinit var body: TextView
    private lateinit var scroll: ScrollView
    private lateinit var postersScroll: ScrollView
    private lateinit var grid: LinearLayout
    private lateinit var modeBtn: TextView
    private var cards: JSONArray? = null
    private var listMode: Boolean
        get() = prefs.getBoolean("results_list", rInt("listDefault", 0) == 1)
        set(v) { prefs.edit().putBoolean("results_list", v).apply() }
    private val closeRunnable = Runnable { finish() }
    private var micRef: MicIcon? = null
    private var headerCtl: List<View> = emptyList()
    private val micState: () -> Unit = { micRef?.active = VoiceLoop.state == VoiceLoop.S.LISTENING }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val dm = resources.displayMetrics
        val root = FrameLayout(this)
        val card = HudPanel(this)
        th?.let {
            card.background = Skin.roundRect(
                this, Skin.color(rc?.optString("panelFill"), it.surface),
                Skin.color(rc?.optString("panelStroke"), 0), rD("panelStrokeWidth", 0.0).toFloat(),
                rInt("panelRadius", it.radius)
            )
        }
        titleView = TextView(this).apply {
            textSize = rD("titleBarSize", 22.0).toFloat()
            setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL), Typeface.NORMAL)
            setTextColor(cAccent)
            letterSpacing = 0.12f
        }
        body = TextView(this).apply {
            textSize = 20f
            setTextColor(cText)
            setLineSpacing(0f, 1.12f)
        }
        scroll = ScrollView(this).apply {
            isFocusable = true
            isFocusableInTouchMode = true
            addView(body)
        }
        grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        postersScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(grid)
        }
        val areaH = if (rD("h", 0.0) > 0) (dm.heightPixels * rD("h", 0.0) / 100.0 - dp(90)).toInt().coerceAtLeast(dp(120)) else (dm.heightPixels * 0.74f).toInt()
        modeBtn = Hud.button(this, "") {
            listMode = !listMode
            cards?.let { buildView(it) }
            modeBtn.requestFocus()
        }
        th?.let { Widgets.styleButton(modeBtn, it) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(titleView, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.minimumHeight = dp(56)
        header.setPadding(0, 0, dp(420), 0)          // room for the three buttons where they sit by default
        val minBtn = Hud.button(this, "Свернуть") { minimize() }.also { b -> th?.let { Widgets.styleButton(b, it) } }
        val (micBtn, micSize) = Widgets.mic(this, cText, cAccent)
        micBtn.setOnClickListener { VoiceLoop.listenOnce() }
        micRef = micBtn
        card.addView(header, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        card.addView(
            scroll,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, areaH).apply { topMargin = dp(12) }
        )
        card.addView(
            postersScroll,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, areaH).apply { topMargin = dp(12) }
        )
        val wrap = FrameLayout(this)
        wrap.addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        // microphone and the two header buttons float over the panel: drag them anywhere with the mouse (own position here)
        val fl = Floating(wrap, "ResultsActivity")
        val wp = ViewGroup.LayoutParams.WRAP_CONTENT
        val bh = Widgets.buttonHeight(this)
        val edge = dp(18)
        val top = dp(12)
        fl.add("min", minBtn, wp, bh, { w, v -> w - v - edge }, { _, _ -> top })
        fl.add("mode", modeBtn, wp, bh, { w, v -> w - edge - minBtn.width - dp(8) - v }, { _, _ -> top })
        headerCtl = listOf(minBtn, modeBtn, micBtn)
        micBtn.isFocusable = true
        fl.add("mic", micBtn, micSize, micSize, { w, v -> w - edge - minBtn.width - dp(8) - modeBtn.width - dp(8) - v }, { _, _ -> top })
        root.addView(
            wrap,
            FrameLayout.LayoutParams(
                panelW(), ViewGroup.LayoutParams.WRAP_CONTENT,
                if (rc != null) Gravity.TOP or Gravity.START else Gravity.END or Gravity.CENTER_VERTICAL
            ).apply {
                if (rc != null) {
                    leftMargin = (dm.widthPixels * rD("x", 12.0) / 100.0).toInt()
                    topMargin = (dm.heightPixels * rD("y", 8.0) / 100.0).toInt()
                } else marginEnd = dp(16)
            }
        )
        if (rc != null) root.setBackgroundColor(Color.argb((rD("dim", 0.0) * 2.55).toInt().coerceIn(0, 255), 0, 0, 0))
        setContentView(root)
        current = this
        VoiceLoop.stateListeners.add(micState)
        render()
    }

    /** Hide the panel but keep the results: "Результаты" on the main screen (or the quick action) brings it back. */
    private fun minimize() {
        android.widget.Toast.makeText(this, "Результаты свёрнуты — вернуть: кнопка «Результаты»", android.widget.Toast.LENGTH_SHORT).show()
        finish()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        render()
    }

    private fun render() {
        titleView.text = TvHost.lastTitle.uppercase()
        val json = TvHost.lastResults
        if (json.isNotEmpty()) {
            scroll.visibility = View.GONE
            postersScroll.visibility = View.VISIBLE
            try {
                val arr = JSONArray(json)
                cards = arr
                modeBtn.visibility = View.VISIBLE
                buildView(arr)
            } catch (e: Throwable) {
                Bridge.log("SYS: Постеры: не разобрать данные: ${e.message}")
            }
        } else {
            postersScroll.visibility = View.GONE
            modeBtn.visibility = View.GONE
            scroll.visibility = View.VISIBLE
            body.text = "Нет результатов"
        }
        restartTimer()
    }

    private fun buildView(arr: JSONArray) {
        modeBtn.text = if (listMode) "Вид: список  ▸ плитки" else "Вид: плитки  ▸ список"
        if (listMode) buildList(arr) else buildGrid(arr)
    }

    private fun activate(item: JSONObject) {
        val cmds = item.optJSONArray("cmds")
        val list = ArrayList<String>()
        if (cmds != null) for (i in 0 until cmds.length()) list.add(cmds.getString(i))
        if (list.isEmpty() && item.optString("cmd").isNotEmpty()) list.add(item.optString("cmd"))
        if (list.isEmpty() && (item.optJSONArray("intents")?.length() ?: 0) == 0) {
            android.widget.Toast.makeText(this, "Нет команды для открытия", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        TvHost.openCard(item.optString("title"), item.optJSONArray("intents")?.toString() ?: "[]", list)
        restartTimer()
    }

    private fun focusEffect(v: View) {
        val focusBg = GradientDrawable().apply {
            cornerRadius = dp(rInt("cardRadius", 6)).toFloat()
            setColor(Hud.withAlpha(cAccent, 40))
            setStroke(dp(2), cAccent)
        }
        v.setOnFocusChangeListener { view, has ->
            view.background = if (has) focusBg else null
            if (has) restartTimer()
        }
    }

    /** Poster image with a number badge and a letter placeholder until the image arrives. */
    private fun makePoster(index: Int, item: JSONObject, w: Int, h: Int): View {
        val title = item.optString("title")
        val posterBox = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(rInt("posterRadius", 4)).toFloat()
                setColor(Hud.withAlpha(cAccent, 28))
            }
        }
        val letter = TextView(this).apply {
            text = title.trim().take(1).uppercase()
            textSize = 40f
            setTextColor(Hud.withAlpha(cAccent, 140))
            gravity = Gravity.CENTER
        }
        val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        val fill = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        posterBox.addView(letter, fill)
        posterBox.addView(img, FrameLayout.LayoutParams(fill))
        if (rB("showBadge", true)) posterBox.addView(
            Badge.make(this, index + 1, cAccent, th?.bg ?: 0xFF001018.toInt()), Badge.params(this)
        )
        val image = item.optString("image")
        if (image.isNotEmpty()) {
            Posters.load(this, image, w, h) { bmp ->
                if (bmp != null) {
                    img.setImageBitmap(bmp)
                    letter.visibility = View.GONE
                }
            }
        }
        return posterBox
    }

    private fun buildGrid(arr: JSONArray) {
        grid.removeAllViews()
        val dm = resources.displayMetrics
        val cols = rInt("columns", 0).takeIf { it > 0 } ?: if (dm.widthPixels >= 1800) 6 else 5
        val avail = panelW() - dp(36) - dp(4)
        val cellW = avail / cols
        val posterW = cellW - dp(14)
        val posterH = (posterW * rD("posterRatio", 1.5).toFloat()).toInt()
        var row: LinearLayout? = null
        var first: View? = null
        for (i in 0 until arr.length()) {
            if (i % cols == 0) {
                row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                grid.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
            val item = arr.getJSONObject(i)
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(7), dp(7), dp(7), dp(7))
                isFocusable = true
                isClickable = true
                setOnClickListener { activate(item) }
            }
            focusEffect(cell)
            cell.addView(makePoster(i, item, posterW, posterH), LinearLayout.LayoutParams(posterW, posterH))
            cell.addView(TextView(this).apply {
                text = item.optString("title")
                textSize = rD("titleSize", 14.0).toFloat()
                setTextColor(cText)
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(posterW, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(5) })
            if (rB("showSub", true)) cell.addView(TextView(this).apply {
                text = item.optString("sub")
                textSize = rD("subSize", 12.0).toFloat()
                setTextColor(cMuted)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(posterW, ViewGroup.LayoutParams.WRAP_CONTENT))
            val appName = item.optString("app")
            if (appName.isNotEmpty() && rB("showApp", true)) {
                cell.addView(TextView(this).apply {
                    text = appName
                    textSize = rD("appSize", 11.0).toFloat()
                    setTextColor(cAccent)
                    maxLines = 1
                }, LinearLayout.LayoutParams(posterW, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
            row!!.addView(cell, LinearLayout.LayoutParams(cellW, ViewGroup.LayoutParams.WRAP_CONTENT))
            if (first == null) first = cell
        }
        postersScroll.scrollTo(0, 0)
        first?.requestFocus()
    }

    /** One title per row: poster on the left, title / meta / description on the right. */
    private fun buildList(arr: JSONArray) {
        grid.removeAllViews()
        val dm = resources.displayMetrics
        val posterW = (dm.widthPixels * rD("listPosterW", 8.5).toFloat() / 100f).toInt()
        val posterH = (posterW * rD("posterRatio", 1.5).toFloat()).toInt()
        var first: View? = null
        for (i in 0 until arr.length()) {
            val item = arr.getJSONObject(i)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(8), dp(8), dp(8), dp(8))
                isFocusable = true
                isClickable = true
                setOnClickListener { activate(item) }
            }
            focusEffect(row)
            row.addView(makePoster(i, item, posterW, posterH), LinearLayout.LayoutParams(posterW, posterH))
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(TextView(this).apply {
                text = item.optString("title")
                textSize = rD("listTitleSize", 20.0).toFloat()
                setTextColor(cText)
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            })
            val meta = listOf(item.optString("year"), item.optString("rating"), item.optString("app"))
                .filter { it.isNotEmpty() }.joinToString("  •  ")
            if (meta.isNotEmpty()) {
                col.addView(TextView(this).apply {
                    text = meta
                    textSize = rD("listMetaSize", 14.0).toFloat()
                    setTextColor(cAccent)
                }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(3) })
            }
            val desc = item.optString("desc")
            if (desc.isNotEmpty()) {
                col.addView(TextView(this).apply {
                    text = desc
                    textSize = rD("listDescSize", 15.0).toFloat()
                    setTextColor(cMuted)
                    maxLines = rInt("descLines", 4)
                    ellipsize = TextUtils.TruncateAt.END
                    setLineSpacing(0f, 1.1f)
                }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
            }
            row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = dp(14)
                gravity = Gravity.CENTER_VERTICAL
            })
            grid.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            if (first == null) first = row
        }
        postersScroll.scrollTo(0, 0)
        first?.requestFocus()
    }

    private fun restartTimer() {
        mainH.removeCallbacks(closeRunnable)
        val custom = rInt("autoClose", 0) * 1000L
        mainH.postDelayed(closeRunnable, if (custom > 0) custom else if (TvHost.lastResults.isNotEmpty()) 120_000L else 40_000L)
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN) {
            if (e.keyCode == KeyEvent.KEYCODE_BACK) {
                finish()
                return true
            }
            restartTimer()
            if (PadNav.handle(e.keyCode, currentFocus, headerCtl, listOf(grid, scroll))) return true
        }
        return super.dispatchKeyEvent(e)
    }

    override fun onDestroy() {
        mainH.removeCallbacks(closeRunnable)
        if (current === this) current = null
        VoiceLoop.stateListeners.remove(micState)
        super.onDestroy()
    }
}
