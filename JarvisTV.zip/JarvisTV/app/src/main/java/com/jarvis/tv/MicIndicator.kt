package com.jarvis.tv

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Point
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import kotlin.concurrent.thread

/**
 * Small dot (12 px) drawn over every app: green = microphone is listening, red = it is off.
 * Lives exactly as long as [JarvisService] (shown only while the app is running).
 * Drag it with the mouse; the place is remembered across restarts. On/off switch: menu in the app.
 * Main thread only (except [ensurePermission], which works on its own thread).
 */
object MicIndicator {
    private const val DOT_PX = 12          // the visible dot
    private const val HIT_PX = 28          // touch area around it, so a mouse can grab it
    private const val MARGIN_PX = 16
    private const val GREEN = 0xFF00E676.toInt()
    private const val RED = 0xFFFF1744.toInt()

    private val main = Handler(Looper.getMainLooper())
    private var view: DotView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var attached = false           // the service is running

    private fun prefs() = Bridge.app.getSharedPreferences("mic_indicator", Context.MODE_PRIVATE)
    private fun wm() = Bridge.app.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    var enabled: Boolean
        get() = try { prefs().getBoolean("enabled", true) } catch (_: Throwable) { true }
        private set(v) { try { prefs().edit().putBoolean("enabled", v).apply() } catch (_: Throwable) {} }

    fun canDraw(): Boolean = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(Bridge.app)

    // ── lifecycle (JarvisService) ──
    fun attach() { attached = true; sync() }
    fun detach() { attached = false; sync() }

    fun switchTo(on: Boolean) { enabled = on; sync() }

    /** Shows or removes the dot according to: service running + switch on + permission given. */
    fun sync() {
        if (attached && enabled && canDraw()) show() else hide()
    }

    // ── state ──
    private fun micOn(): Boolean {
        if (!VoiceLoop.hasPermission()) return false
        if (VoiceLoop.state == VoiceLoop.S.LISTENING || VoiceLoop.continuous) return true
        if (Bridge.curMuted) return false
        return !Bridge.micFree && MicHub.running
    }

    private val tick = object : Runnable {
        override fun run() {
            val v = view ?: return
            v.on = micOn()
            main.postDelayed(this, 400)
        }
    }

    // ── window ──
    private fun screen(): Point = Point().also { try { wm().defaultDisplay.getRealSize(it) } catch (_: Throwable) { it.set(1920, 1080) } }

    private fun show() {
        if (view != null) return
        try {
            val s = screen()
            val p = prefs()
            val x = if (p.contains("x")) p.getInt("x", MARGIN_PX) else MARGIN_PX
            val y = if (p.contains("y")) p.getInt("y", 0) else s.y - HIT_PX - MARGIN_PX   // default: bottom left
            val params = WindowManager.LayoutParams(
                HIT_PX, HIT_PX,
                if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                this.x = x.coerceIn(0, (s.x - HIT_PX).coerceAtLeast(0))
                this.y = y.coerceIn(0, (s.y - HIT_PX).coerceAtLeast(0))
            }
            val v = DotView(Bridge.app)
            v.on = micOn()
            wm().addView(v, params)
            view = v; lp = params
            main.removeCallbacks(tick)
            main.post(tick)
        } catch (t: Throwable) {
            view = null; lp = null
            Diag.log("SYS", "indicator: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    private fun hide() {
        main.removeCallbacks(tick)
        val v = view ?: return
        try { wm().removeView(v) } catch (_: Throwable) {}
        view = null; lp = null
    }

    private fun savePos() {
        val l = lp ?: return
        try { prefs().edit().putInt("x", l.x).putInt("y", l.y).apply() } catch (_: Throwable) {}
    }

    private class DotView(ctx: Context) : View(ctx) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var downX = 0f; private var downY = 0f
        private var startX = 0; private var startY = 0

        var on = false
            set(v) { if (field != v) { field = v; invalidate() } }

        override fun onDraw(c: Canvas) {
            val cx = width / 2f; val cy = height / 2f
            paint.style = Paint.Style.FILL
            paint.color = if (on) GREEN else RED
            c.drawCircle(cx, cy, DOT_PX / 2f, paint)
            paint.style = Paint.Style.STROKE        // thin dark rim: visible on light and dark pictures
            paint.strokeWidth = 1f
            paint.color = 0xAA000000.toInt()
            c.drawCircle(cx, cy, DOT_PX / 2f, paint)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            val l = lp ?: return false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startX = l.x; startY = l.y }
                MotionEvent.ACTION_MOVE -> {
                    val s = screen()
                    l.x = (startX + (e.rawX - downX)).toInt().coerceIn(0, (s.x - HIT_PX).coerceAtLeast(0))
                    l.y = (startY + (e.rawY - downY)).toInt().coerceIn(0, (s.y - HIT_PX).coerceAtLeast(0))
                    try { wm().updateViewLayout(this, l) } catch (_: Throwable) {}
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> savePos()
            }
            return true
        }
    }

    // ── permission "draw over other apps" ──
    /**
     * Makes sure the dot may be drawn. First silently through the TV's own ADB (the app already uses it),
     * otherwise opens the system screen. [done] runs on the main thread when the answer is known
     * (false also when the system screen had to be opened — the dot appears when the user comes back).
     */
    fun ensurePermission(a: Activity, done: (Boolean) -> Unit) {
        if (canDraw()) { done(true); return }
        thread(name = "overlay-grant") {
            var ok = false
            try {
                Adb.shell("appops set ${Bridge.app.packageName} SYSTEM_ALERT_WINDOW allow")
                ok = canDraw()
            } catch (_: Throwable) {}
            main.post {
                if (ok) { done(true); return@post }
                try {
                    a.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${a.packageName}")))
                    Toast.makeText(a, "Разрешите «Поверх других окон» для JARVIS", Toast.LENGTH_LONG).show()
                } catch (_: Throwable) {
                    Toast.makeText(a, "Нужно разрешение «Поверх других окон». На ТВ без этого экрана: включите отладку по сети (меню → Проверить ADB) и повторите", Toast.LENGTH_LONG).show()
                }
                done(false)
            }
        }
    }
}
