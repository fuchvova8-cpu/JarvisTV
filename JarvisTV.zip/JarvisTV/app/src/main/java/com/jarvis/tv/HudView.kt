package com.jarvis.tv

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** The arc-reactor centrepiece. Colour follows the state; size follows the voice. */
class HudView(ctx: Context) : View(ctx) {
    var state: String = "SLEEPING"

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val oval = RectF()
    private val src = Rect()
    private val dst = Rect()
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val t0 = System.nanoTime()
    private var smooth = 0f

    private fun accent(): Int = when (state.uppercase()) {
        "LISTENING" -> Color.rgb(0, 214, 255)
        "SPEAKING" -> Color.rgb(255, 176, 40)
        "THINKING", "PROCESSING" -> Color.rgb(170, 110, 255)
        "MUTED" -> Color.rgb(255, 70, 70)
        else -> Color.rgb(60, 110, 130)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(Color.rgb(3, 9, 16))

        // A plugin (sphere_hud) supplies its own centrepiece: show it, skip the built-in rings.
        val custom: Bitmap? = Bridge.hudBitmap
        if (custom != null) {
            val side = min(w, h * 0.92f).toInt()
            val left = ((w - side) / 2f).toInt()
            val top = (h * 0.5f - side * 0.5f).toInt().coerceAtLeast(0)
            src.set(0, 0, custom.width, custom.height)
            dst.set(left, top, left + side, top + side)
            c.drawBitmap(custom, src, dst, bmpPaint)
            postInvalidateDelayed(33)
            return
        }
        val t = (System.nanoTime() - t0) / 1e9f

        val fresh = (System.nanoTime() - Bridge.levelAt) < 300_000_000L
        val target = if (fresh) Bridge.level.coerceIn(0f, 1f) else 0f
        smooth += (target - smooth) * 0.3f

        val col = accent()
        val cx = w / 2f
        val cy = h * 0.45f
        val r = min(w, h) * 0.24f
        val pulse = 1f + smooth * 0.18f

        p.style = Paint.Style.FILL
        p.color = col
        p.alpha = (30 + 90 * smooth).toInt()
        c.drawCircle(cx, cy, r * 0.55f * pulse, p)
        p.alpha = (80 + 140 * smooth).toInt()
        c.drawCircle(cx, cy, r * 0.22f * pulse, p)

        p.style = Paint.Style.STROKE
        p.color = col
        val rings = floatArrayOf(0.62f, 0.8f, 1.0f, 1.18f)
        for ((i, k) in rings.withIndex()) {
            p.strokeWidth = if (i == 2) r * 0.045f else r * 0.025f
            p.alpha = 150 - i * 20
            val rr = r * k * (if (i % 2 == 0) pulse else 1f)
            oval.set(cx - rr, cy - rr, cx + rr, cy + rr)
            val speed = (if (i % 2 == 0) 28f else -40f) * (1f + smooth * 2f)
            val start = t * speed + i * 55f
            c.drawArc(oval, start, 70f + i * 18f, false, p)
            c.drawArc(oval, start + 180f, 70f + i * 18f, false, p)
        }

        // Voice bars on a ring.
        p.strokeWidth = r * 0.03f
        p.alpha = 190
        val bars = 56
        for (i in 0 until bars) {
            val a = (i.toFloat() / bars) * 2f * PI.toFloat()
            val wob = 0.5f + 0.5f * sin(t * 6f + i * 0.7f)
            val len = r * (0.05f + 0.22f * smooth * wob + 0.015f)
            val r0 = r * 1.3f
            c.drawLine(cx + cos(a) * r0, cy + sin(a) * r0, cx + cos(a) * (r0 + len), cy + sin(a) * (r0 + len), p)
        }

        postInvalidateDelayed(33)
    }
}
