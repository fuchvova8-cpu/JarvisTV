package com.jarvis.tv

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Layout editor drawn on top of the main screen (screen_style plugin → edit mode).
 * Drag an element with the mouse (or a finger) to move it; drag its bottom-right corner to resize it.
 * The new position is written to the layout file when the button is released.
 * While it is on, the buttons underneath do not react to clicks.
 */
class EditLayer(
    ctx: Context,
    private val root: FrameLayout,
    private val views: Map<String, View>,
    private val onSaved: (Long) -> Unit,
    private val onDone: () -> Unit
) : FrameLayout(ctx) {

    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val tri = android.graphics.Path()
    private val grids = doubleArrayOf(0.0, 0.5, 1.0, 2.0, 5.0)
    private var gridIdx = 2
    private var activeId: String? = null
    private var resizing = false
    private var downX = 0f
    private var downY = 0f
    private var l0 = 0
    private var t0 = 0
    private var w0 = 0
    private var h0 = 0
    private var resized = false
    private var longFired = false
    private val longRun = Runnable {
        val id = activeId
        if (id != null && !resized && !movedFar) {
            longFired = true
            context.startActivity(android.content.Intent(context, PluginSettingsActivity::class.java)
                .putExtra(PluginSettingsActivity.EXTRA_PLUGIN, "screen_style")
                .putExtra(PluginSettingsActivity.EXTRA_TITLE, "Экран (стиль Google)")
                .putExtra(PluginSettingsActivity.EXTRA_EVENT, "goto:el:$id"))
        }
    }
    private var movedFar = false
    private lateinit var gridBtn: TextView

    private val surface = object : View(ctx) {
        override fun onDraw(c: Canvas) { drawOutlines(c) }
        override fun onTouchEvent(e: MotionEvent): Boolean = handleTouch(e)
    }

    init {
        // Buttons have their own elevation (shadow) and would be drawn and hit-tested ABOVE this layer: raise it over everything.
        elevation = 2000f
        translationZ = 2000f
        isClickable = true
        addView(surface, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val th = Skin.theme()
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = Skin.roundRect(ctx, Hud.withAlpha(th?.surface ?: 0xFF202124.toInt(), 0xE6), Hud.CYAN, 1f, 28)
            setPadding((18 * d).toInt(), (6 * d).toInt(), (10 * d).toInt(), (6 * d).toInt())
        }
        bar.addView(TextView(ctx).apply {
            text = "Редактор: тащите — перемещение, угол — размер, долгое нажатие — настройки/цвета"
            textSize = 13f
            setTextColor(Hud.TEXT)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = (14 * d).toInt() })
        gridBtn = Hud.button(ctx, gridText()) {
            gridIdx = (gridIdx + 1) % grids.size
            gridBtn.text = gridText()
        }
        bar.addView(gridBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = (8 * d).toInt() })
        bar.addView(Hud.button(ctx, "Готово") { onDone() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = (8 * d).toInt() })
    }

    private fun gridText(): String {
        val g = grids[gridIdx]
        return if (g == 0.0) "Сетка: нет" else "Сетка: " + (if (g == g.toInt().toDouble()) g.toInt().toString() else g.toString()) + "%"
    }

    // ── geometry ──
    private fun lpOf(v: View): FrameLayout.LayoutParams = v.layoutParams as FrameLayout.LayoutParams

    private fun widthOf(v: View): Int = lpOf(v).width.let { if (it > 0) it else v.width }
    private fun heightOf(v: View): Int = lpOf(v).height.let { if (it > 0) it else v.height }

    /** Elements that sit directly on the screen, bottom to top. */
    private fun placed(): List<Pair<String, View>> {
        val out = ArrayList<Pair<String, View>>()
        for (i in 0 until root.childCount) {
            val child = root.getChildAt(i)
            if (child === this || child.visibility != View.VISIBLE) continue
            val id = views.entries.firstOrNull { it.value === child }?.key ?: continue
            out.add(id to child)
        }
        return out
    }

    private fun snapX(px: Float): Int {
        val g = grids[gridIdx]
        if (g <= 0.0) return px.toInt()
        val step = root.width * g / 100.0
        return (Math.round(px / step) * step).toInt()
    }

    private fun snapY(px: Float): Int {
        val g = grids[gridIdx]
        if (g <= 0.0) return px.toInt()
        val step = root.height * g / 100.0
        return (Math.round(px / step) * step).toInt()
    }

    // ── drawing ──
    private fun drawOutlines(c: Canvas) {
        paint.textSize = 11f * d
        for ((id, v) in placed()) {
            val lp = lpOf(v)
            val w = widthOf(v)
            val h = heightOf(v)
            rect.set(lp.leftMargin.toFloat(), lp.topMargin.toFloat(), (lp.leftMargin + w).toFloat(), (lp.topMargin + h).toFloat())
            val active = id == activeId
            paint.style = Paint.Style.FILL
            paint.color = Hud.withAlpha(Hud.CYAN, if (active) 0x30 else 0x14)
            c.drawRect(rect, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = (if (active) 3f else 1.5f) * d
            paint.color = if (active) Color.WHITE else Hud.CYAN
            c.drawRect(rect, paint)
            // name tag
            paint.style = Paint.Style.FILL
            val tw = paint.measureText(id) + 12 * d
            paint.color = Hud.withAlpha(0xFF000000.toInt(), 0xB0)
            c.drawRect(rect.left, rect.top, rect.left + tw, rect.top + 16 * d, paint)
            paint.color = Color.WHITE
            c.drawText(id, rect.left + 6 * d, rect.top + 12 * d, paint)
            // resize handle
            paint.color = Hud.CYAN
            tri.reset()
            tri.moveTo(rect.right, rect.bottom - 20 * d)
            tri.lineTo(rect.right, rect.bottom)
            tri.lineTo(rect.right - 20 * d, rect.bottom)
            tri.close()
            c.drawPath(tri, paint)
        }
    }

    // ── touch ──
    private fun handleTouch(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                activeId = null
                val list = placed()
                for (i in list.indices.reversed()) {
                    val (id, v) = list[i]
                    val lp = lpOf(v)
                    val w = widthOf(v)
                    val h = heightOf(v)
                    if (e.x >= lp.leftMargin && e.x <= lp.leftMargin + w && e.y >= lp.topMargin && e.y <= lp.topMargin + h) {
                        activeId = id
                        resizing = e.x >= lp.leftMargin + w - 40 * d && e.y >= lp.topMargin + h - 40 * d
                        downX = e.x
                        downY = e.y
                        l0 = lp.leftMargin
                        t0 = lp.topMargin
                        w0 = w
                        h0 = h
                        resized = false
                        movedFar = false
                        longFired = false
                        surface.postDelayed(longRun, 650)
                        break
                    }
                }
                surface.invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                val id = activeId ?: return true
                val v = views[id] ?: return true
                val lp = lpOf(v)
                val dx = e.x - downX
                val dy = e.y - downY
                if (longFired) return true
                if (Math.abs(dx) > 12 * d || Math.abs(dy) > 12 * d) { movedFar = true; surface.removeCallbacks(longRun) }
                if (resizing) {
                    lp.width = maxOf((24 * d).toInt(), snapX(w0 + dx))
                    lp.height = maxOf((16 * d).toInt(), snapY(h0 + dy))
                    resized = true
                } else {
                    lp.leftMargin = snapX(l0 + dx).coerceIn(0, maxOf(0, root.width - (20 * d).toInt()))
                    lp.topMargin = snapY(t0 + dy).coerceIn(0, maxOf(0, root.height - (20 * d).toInt()))
                }
                v.layoutParams = lp
                surface.invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                surface.removeCallbacks(longRun)
                val id = if (longFired) null else activeId
                val v = if (id != null) views[id] else null
                if (id != null && v != null && e.actionMasked == MotionEvent.ACTION_UP) {
                    val lp = lpOf(v)
                    val W = maxOf(1, root.width).toDouble()
                    val H = maxOf(1, root.height).toDouble()
                    val moved = lp.leftMargin != l0 || lp.topMargin != t0 || resized
                    if (moved) {
                        val sig = Skin.saveRect(
                            id, lp.leftMargin / W * 100.0, lp.topMargin / H * 100.0,
                            if (resized) widthOf(v) / W * 100.0 else null,
                            if (resized) heightOf(v) / H * 100.0 else null
                        )
                        onSaved(sig)
                    }
                }
                resizing = false
                surface.invalidate()
            }
        }
        return true
    }
}
