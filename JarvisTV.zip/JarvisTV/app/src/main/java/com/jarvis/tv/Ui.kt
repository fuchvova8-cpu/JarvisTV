package com.jarvis.tv

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max

/** Palette and small widgets shared by the extra screens (results, plugin settings, overlay). */
object Hud {
    // With a skin active (plugin screen_style) every screen that uses Hud takes the skin's colours.
    val CYAN: Int get() = Skin.theme()?.accent ?: 0xFF00D4FF.toInt()
    val TEXT: Int get() = Skin.theme()?.text ?: 0xFFD8F8FF.toInt()
    val MUTED: Int get() = Skin.theme()?.muted ?: 0xFF5AB8CC.toInt()
    val AMBER: Int get() = if (Skin.theme() != null) 0xFFFBBC04.toInt() else 0xFFFFB300.toInt()
    val CYAN_DIM: Int get() = withAlpha(CYAN, 0x66)

    fun withAlpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    fun button(ctx: Context, text: String, onClick: () -> Unit): TextView {
        val d = ctx.resources.displayMetrics.density
        fun shape(fill: Int, stroke: Int) = GradientDrawable().apply {
            setColor(fill)
            setStroke(max(1, (1.5f * d).toInt()), stroke)
            cornerRadius = 4f * d
        }
        val states = StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), shape(withAlpha(CYAN, 70), CYAN))
            addState(intArrayOf(android.R.attr.state_pressed), shape(withAlpha(CYAN, 110), CYAN))
            addState(intArrayOf(), shape(withAlpha(CYAN, 12), CYAN_DIM))
        }
        return TextView(ctx).apply {
            this.text = text
            textSize = 14f
            setTextColor(TEXT)
            letterSpacing = 0.12f
            isAllCaps = true
            gravity = Gravity.CENTER
            background = states
            isFocusable = true
            isClickable = true
            setPadding((18 * d).toInt(), (10 * d).toInt(), (18 * d).toInt(), (10 * d).toInt())
            setOnClickListener { onClick() }
            Skin.theme()?.let { Skin.styleButton(this, it, null); setPadding((20 * d).toInt(), (10 * d).toInt(), (20 * d).toInt(), (10 * d).toInt()) }
        }
    }

    /** Shared row geometry for menus and submenus; matches the platform's classic ~48dp list rows. */
    fun menuButton(ctx: Context, text: String, onClick: () -> Unit): TextView {
        val d = ctx.resources.displayMetrics.density
        return button(ctx, text, onClick).apply {
            textSize = 16f
            isAllCaps = false
            letterSpacing = 0f
            gravity = Gravity.CENTER_VERTICAL or Gravity.START
            minHeight = (48 * d).toInt()
            setPadding((18 * d).toInt(), (10 * d).toInt(), (18 * d).toInt(), (10 * d).toInt())
        }
    }
}

/** Dark glass panel with a thin cyan border. */
class HudPanel(ctx: Context) : LinearLayout(ctx) {
    init {
        val d = resources.displayMetrics.density
        orientation = VERTICAL
        val th = Skin.theme()
        background = if (th != null) {
            when (th.design) {
                "glass" -> GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
                    Hud.withAlpha(th.surface, 0xD8), Hud.withAlpha(th.surface, 0xA8), Hud.withAlpha(th.accent, 0x18)
                )).apply {
                    cornerRadius = (th.radius * d)
                    setStroke(max(1, (1.2f * d).toInt()), Hud.withAlpha(th.text, 0x55))
                }
                "appleglass" -> LiquidGlass(d, maxOf(28, th.radius) * d, th.surface)
                "futuristic" -> GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(
                    Hud.withAlpha(th.surface, 0xF4), Hud.withAlpha(th.bg, 0xF8)
                )).apply {
                    cornerRadius = (max(3, th.radius) * d)
                    setStroke(max(1, (1.5f * d).toInt()), Hud.withAlpha(th.accent, 0xCC))
                }
                else -> Skin.roundRect(ctx, th.surface, 0, 0f, th.radius)
            }
        } else GradientDrawable().apply {
            setColor(0xEB010D14.toInt())
            setStroke(max(1, (2 * d).toInt()), Hud.CYAN_DIM)
            cornerRadius = 8f * d
        }
        val pad = ((if (th?.design == "futuristic") 14 else 18) * d).toInt()
        setPadding(pad, pad, pad, pad)
    }
}
