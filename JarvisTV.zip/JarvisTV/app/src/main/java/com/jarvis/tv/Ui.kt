package com.jarvis.tv

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max

/** Palette and small widgets shared by the extra screens (results, plugin settings, overlay). */
object Hud {
    val CYAN = 0xFF00D4FF.toInt()
    val TEXT = 0xFFD8F8FF.toInt()
    val MUTED = 0xFF5AB8CC.toInt()
    val AMBER = 0xFFFFB300.toInt()
    val CYAN_DIM: Int get() = withAlpha(CYAN, 0x66)

    fun withAlpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    fun button(ctx: Context, text: String, onClick: () -> Unit): TextView {
        val d = ctx.resources.displayMetrics.density
        fun shape(fill: Int, stroke: Int) = GradientDrawable().apply {
            setColor(fill)
            setStroke(max(1, (1.5f * d).toInt()), stroke)
            cornerRadius = 4f * d
        }
        val states = StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), shape(withAlpha(CYAN, 70), CYAN))
            addState(intArrayOf(android.R.attr.state_pressed), shape(withAlpha(CYAN, 110), CYAN))
            addState(intArrayOf(), shape(withAlpha(CYAN, 12), CYAN_DIM))
        }
        return TextView(ctx).apply {
            this.text = text
            textSize = 14f
            setTextColor(TEXT)
            letterSpacing = 0.12f
            isAllCaps = true
            gravity = Gravity.CENTER
            background = states
            isFocusable = true
            isClickable = true
            setPadding((18 * d).toInt(), (10 * d).toInt(), (18 * d).toInt(), (10 * d).toInt())
            setOnClickListener { onClick() }
        }
    }
}

/** Dark glass panel with a thin cyan border. */
class HudPanel(ctx: Context) : LinearLayout(ctx) {
    init {
        val d = resources.displayMetrics.density
        orientation = VERTICAL
        background = GradientDrawable().apply {
            setColor(0xEB010D14.toInt())
            setStroke(max(1, (2 * d).toInt()), Hud.CYAN_DIM)
            cornerRadius = 8f * d
        }
        val pad = (18 * d).toInt()
        setPadding(pad, pad, pad, pad)
    }
}
