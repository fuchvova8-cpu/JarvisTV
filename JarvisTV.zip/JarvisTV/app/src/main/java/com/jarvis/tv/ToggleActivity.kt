package com.jarvis.tv

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

/** Invisible: flips "microphone always on" and closes at once. */
class ToggleActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!VoiceLoop.hasPermission()) {
            Toast.makeText(this, "JARVIS: нет разрешения на микрофон", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, MainActivity::class.java))
        } else {
            JarvisService.start(this)
            VoiceLoop.setContinuous(!VoiceLoop.continuous)
        }
        finish()
    }
}
