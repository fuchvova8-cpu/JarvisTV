package com.jarvis.tv

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray

/**
 * Buttons the user pinned to the main screen. Keys: "m:<menu key>" (an entry of the Service menu) or
 * "p:<plugin>|<title>" (the settings page of a plugin). Stored in the app's preferences, in order.
 */
object Pins {
    private const val K = "pins"

    fun list(ctx: Context): MutableList<String> {
        val s = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE).getString(K, "[]") ?: "[]"
        val out = ArrayList<String>()
        try {
            val a = JSONArray(s)
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (_: Throwable) {
        }
        return out
    }

    fun save(ctx: Context, l: List<String>) {
        val a = JSONArray()
        for (x in l) a.put(x)
        ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE).edit().putString(K, a.toString()).apply()
    }

    /** Pins or unpins; returns true when the key is pinned afterwards. */
    fun toggle(ctx: Context, key: String): Boolean {
        val l = list(ctx)
        val now = if (l.contains(key)) { l.remove(key); false } else { l.add(key); true }
        save(ctx, l)
        return now
    }
}

/**
 * The Service menu as a full-screen layer inside MainActivity: sections → items, a real page stack
 * (Back goes one level up, only the root closes the menu) and a "＋ На главный" button next to every item.
 */
class MenuPanel(
    private val act: Activity,
    private val entries: () -> LinkedHashMap<String, MainActivity.MenuEntry>,
    private val openPlugin: (String, String) -> Unit,
    private val onPinsChanged: () -> Unit
) : FrameLayout(act) {

    private class Cat(val id: String, val title: String, val hint: String, val keys: List<String>)

    private val cats = listOf(
        Cat("assistant", "Ассистент", "Ключ, имена, голос", listOf("gemini_key", "names", "voice")),
        Cat("mic", "Микрофон", "Режим, прослушивание, индикатор", listOf("mic_mode", "mic_live", "mic_bg", "mic_indicator")),
        Cat("plugins", "Плагины", "Включение, настройки, папка", listOf("plugins", "plugin_dir")),
        Cat("screen", "Экран", "Редактор экрана, кнопки на главном", listOf("edit_screen")),
        Cat("system", "Система", "ADB, автозапуск, выход", listOf("adb", "autostart", "folder_info", "exit"))
    )

    private val stack = ArrayList<String>()
    private var pluginPages: JSONArray? = null
    private var firstFocus: View? = null

    private val titleView: TextView
    private val backBtn: Button
    private val body: LinearLayout
    private val scroll: ScrollView

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private val accent: Int get() = Skin.theme()?.accent ?: Color.rgb(0, 214, 255)
    private val muted: Int get() = Skin.theme()?.muted ?: Color.rgb(140, 175, 190)
    private val cardFill: Int get() = Skin.theme()?.surface ?: Color.rgb(6, 20, 32)

    init {
        setBackgroundColor(Color.argb(215, 0, 0, 0))
        isClickable = true
        visibility = View.GONE

        val card = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            background = box(cardFill, Color.argb(255, Color.red(accent) / 2, Color.green(accent) / 2, Color.blue(accent) / 2), 16)
            setPadding(dp(18), dp(14), dp(18), dp(14))
        }
        val head = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        backBtn = mkBtn("← Назад") { back() }
        titleView = TextView(act).apply {
            textSize = 20f
            setTextColor(accent)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        head.addView(backBtn, LinearLayout.LayoutParams(-2, dp(44)))
        head.addView(titleView, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(mkBtn("На главный экран") { close() }, LinearLayout.LayoutParams(-2, dp(44)))
        card.addView(head)

        body = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, dp(4)) }
        scroll = ScrollView(act).apply { addView(body) }
        card.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val sw = resources.displayMetrics.widthPixels
        val sh = resources.displayMetrics.heightPixels
        addView(card, FrameLayout.LayoutParams((sw * 0.74f).toInt(), (sh * 0.88f).toInt(), Gravity.CENTER))
    }

    // ── public ──────────────────────────────────────────────────────────────
    fun isOpen(): Boolean = visibility == View.VISIBLE

    fun open() {
        stack.clear()
        stack.add("root")
        visibility = View.VISIBLE
        bringToFront()
        render()
        Py.ask("plugin_settings_list") { json ->
            pluginPages = try { JSONArray(json) } catch (_: Throwable) { JSONArray() }
            if (isOpen() && stack.lastOrNull() == "cat:plugins") render()
        }
    }

    fun close() {
        visibility = View.GONE
        stack.clear()
    }

    /** One level up; the root closes the menu. Always consumes the key while the menu is shown. */
    fun back(): Boolean {
        if (!isOpen()) return false
        if (stack.size > 1) {
            stack.removeAt(stack.size - 1)
            render()
        } else close()
        return true
    }

    /** Redraw the current page (states changed, or we came back from another screen). */
    fun refresh() {
        if (isOpen()) render()
    }

    // ── drawing ─────────────────────────────────────────────────────────────
    private fun box(fill: Int, stroke: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(2), stroke)
    }

    private fun mkBtn(text: CharSequence, onClick: () -> Unit): Button {
        val b = Button(act)
        b.text = text
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.textSize = 15f
        b.minWidth = 0
        b.minimumWidth = 0
        b.minHeight = 0
        b.minimumHeight = 0
        b.setPadding(dp(16), dp(8), dp(16), dp(8))
        val ac = accent
        val st = StateListDrawable()
        st.addState(intArrayOf(android.R.attr.state_focused), box(Color.argb(255, Color.red(ac) / 3, Color.green(ac) / 3, Color.blue(ac) / 3), ac, 12))
        st.addState(intArrayOf(android.R.attr.state_pressed), box(Color.argb(255, Color.red(ac) / 2, Color.green(ac) / 2, Color.blue(ac) / 2), Color.WHITE, 12))
        st.addState(intArrayOf(), box(Color.argb(230, 10, 32, 48), Color.argb(255, Color.red(ac) / 4, Color.green(ac) / 4, Color.blue(ac) / 4), 12))
        b.background = st
        b.setOnClickListener { onClick() }
        return b
    }

    private fun two(title: String, sub: String): CharSequence {
        val s = SpannableStringBuilder(title)
        s.setSpan(StyleSpan(Typeface.BOLD), 0, title.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        s.setSpan(RelativeSizeSpan(1.1f), 0, title.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (sub.isNotEmpty()) {
            val from = s.length + 1
            s.append("\n").append(sub)
            s.setSpan(RelativeSizeSpan(0.8f), from, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            s.setSpan(ForegroundColorSpan(muted), from, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return s
    }

    private fun note(text: String): TextView = TextView(act).apply {
        this.text = text
        textSize = 13f
        setTextColor(muted)
        setPadding(dp(4), dp(4), dp(4), dp(8))
    }

    private fun section(text: String): TextView = TextView(act).apply {
        this.text = text
        textSize = 14f
        setTextColor(accent)
        setTypeface(typeface, Typeface.BOLD)
        setPadding(dp(4), dp(14), dp(4), dp(6))
    }

    private fun focusable(v: View) {
        if (firstFocus == null) firstFocus = v
    }

    private fun render() {
        body.removeAllViews()
        firstFocus = null
        val page = stack.lastOrNull() ?: "root"
        backBtn.text = if (stack.size > 1) "← Назад" else "← Закрыть"
        when {
            page == "root" -> renderRoot()
            page == "pins" -> renderPins()
            page.startsWith("cat:") -> cats.firstOrNull { it.id == page.substring(4) }?.let { renderCat(it) }
        }
        body.post { firstFocus?.requestFocus() }
    }

    private fun renderRoot() {
        titleView.text = "JARVIS — меню"
        body.addView(note("Выберите раздел. Рядом с каждым пунктом есть кнопка «＋ На главный» — она выводит пункт " +
            "отдельной кнопкой на главный экран."))
        val tiles = ArrayList<Pair<CharSequence, () -> Unit>>()
        for (c in cats) tiles.add(Pair<CharSequence, () -> Unit>(two(c.title, c.hint), { go("cat:" + c.id) }))
        val n = Pins.list(act).size
        tiles.add(Pair<CharSequence, () -> Unit>(two("Кнопки на главном экране", if (n == 0) "Пока нет закреплённых" else "Закреплено: $n"), { go("pins") }))
        var i = 0
        while (i < tiles.size) {
            val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
            for (j in 0..1) {
                if (i + j < tiles.size) {
                    val t = tiles[i + j]
                    val b = mkBtn(t.first, t.second)
                    b.gravity = Gravity.START or Gravity.CENTER_VERTICAL
                    focusable(b)
                    row.addView(b, LinearLayout.LayoutParams(0, dp(84), 1f).apply { setMargins(dp(5), dp(5), dp(5), dp(5)) })
                } else {
                    row.addView(View(act), LinearLayout.LayoutParams(0, dp(84), 1f))
                }
            }
            body.addView(row)
            i += 2
        }
    }

    private fun go(page: String) {
        stack.add(page)
        render()
    }

    private fun renderCat(c: Cat) {
        titleView.text = c.title
        val map = entries()
        for (k in c.keys) if (map.containsKey(k)) addEntryRow(map, k)
        if (c.id == "plugins") {
            body.addView(section("Страницы настроек плагинов"))
            val arr = pluginPages
            when {
                arr == null -> body.addView(note("Загрузка…"))
                arr.length() == 0 -> body.addView(note("Пока ни у одного плагина нет страницы настроек."))
                else -> for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val name = o.optString("name")
                    val title = o.optString("title")
                    addRow(two(title, "Страница настроек плагина"), "p:$name|$title") { openPlugin(name, title) }
                }
            }
        }
        if (c.id == "screen") {
            body.addView(note("Кнопки, закреплённые на главном экране, видны в нижней строке над панелью управления."))
            addRow(two("Кнопки на главном экране", "Порядок и удаление"), null) { go("pins") }
        }
    }

    private fun entryInfo(map: Map<String, MainActivity.MenuEntry>, key: String): Pair<String, String> {
        val prefs = act.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
        val ptt = MicMode.mode == MicMode.Mode.PTT
        fun st(on: Boolean) = if (on) "Сейчас: включено" else "Сейчас: выключено"
        return when (key) {
            "gemini_key" -> Pair("Ключ Gemini API", "Без ключа работает локальный режим")
            "names" -> Pair("Имена", "Как зовут ассистента и как обращаться к вам")
            "voice" -> Pair("Голос Gemini", "Выбор голоса ответов")
            "plugins" -> Pair("Плагины: вкл / выкл", "Применяется сразу")
            "plugin_dir" -> Pair("Папка плагинов", "Где лежат ваши плагины")
            "mic_mode" -> Pair("Режим микрофона",
                if (ptt) "Сейчас: по кнопке  ·  нажмите — сделать постоянным" else "Сейчас: постоянно  ·  нажмите — сделать по кнопке")
            "mic_live" -> Pair("Постоянное прослушивание",
                if (ptt) "Доступно в постоянном режиме" else st(MicMode.liveOn))
            "mic_bg" -> Pair("Микрофон в фоне", st(MicMode.background))
            "mic_indicator" -> Pair("Индикатор микрофона", st(MicIndicator.enabled))
            "adb" -> Pair("Проверить ADB", "Нужен для ввода и снимка экрана")
            "autostart" -> Pair("Автозапуск при включении ТВ", st(prefs.getBoolean("autostart", true)))
            "folder_info" -> Pair("Папка Jarvis", "Где лежат plugins, config и memory")
            "edit_screen" -> Pair("Редактор экрана", "Перетаскивать элементы мышью")
            "exit" -> Pair("Выйти полностью", "Остановить JARVIS")
            else -> Pair(map[key]?.label?.invoke() ?: key, "")
        }
    }

    private fun addEntryRow(map: LinkedHashMap<String, MainActivity.MenuEntry>, key: String) {
        val info = entryInfo(map, key)
        val pinKey = "m:$key"
        addRow(two(info.first, info.second), pinKey) {
            map[key]?.action?.invoke()
            postDelayed({ refresh() }, 600)
        }
    }

    /** One line: the item (big button) + a pin toggle on the right. */
    private fun addRow(text: CharSequence, pinKey: String?, onClick: () -> Unit) {
        val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val main = mkBtn(text, onClick)
        main.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        focusable(main)
        row.addView(main, LinearLayout.LayoutParams(0, dp(64), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        if (pinKey != null) {
            val pinned = Pins.list(act).contains(pinKey)
            val pin = mkBtn(if (pinned) "✔ На главном" else "＋ На главный") {
                val now = Pins.toggle(act, pinKey)
                android.widget.Toast.makeText(act,
                    if (now) "Кнопка добавлена на главный экран" else "Кнопка убрана с главного экрана",
                    android.widget.Toast.LENGTH_SHORT).show()
                onPinsChanged()
                render()
            }
            pin.textSize = 13f
            row.addView(pin, LinearLayout.LayoutParams(dp(150), dp(64)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        }
        body.addView(row)
    }

    // ── pinned buttons page ─────────────────────────────────────────────────
    private fun pinTitle(key: String): String {
        if (key.startsWith("m:")) return entryInfo(entries(), key.substring(2)).first
        if (key.startsWith("p:")) return key.substringAfter('|', key.substring(2))
        return key
    }

    private fun renderPins() {
        titleView.text = "Кнопки на главном экране"
        val list = Pins.list(act)
        if (list.isEmpty()) {
            body.addView(note("Пока ничего не закреплено. Откройте любой раздел и нажмите «＋ На главный» рядом с нужным пунктом."))
            val b = mkBtn("К разделам") { stack.clear(); stack.add("root"); render() }
            focusable(b)
            body.addView(b, LinearLayout.LayoutParams(-2, dp(48)).apply { setMargins(dp(4), dp(8), dp(4), dp(4)) })
            return
        }
        body.addView(note("Порядок слева направо в нижней строке главного экрана."))
        for ((idx, key) in list.withIndex()) {
            val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val t = TextView(act).apply {
                text = "${idx + 1}.  ${pinTitle(key)}"
                textSize = 16f
                setTextColor(Color.WHITE)
                setPadding(dp(8), 0, dp(8), 0)
            }
            row.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
            if (idx > 0) {
                val l = mkBtn("◀ Левее") {
                    val cur = Pins.list(act)
                    val i = cur.indexOf(key)
                    if (i > 0) { cur.removeAt(i); cur.add(i - 1, key); Pins.save(act, cur) }
                    onPinsChanged(); render()
                }
                focusable(l)
                row.addView(l, LinearLayout.LayoutParams(-2, dp(48)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
            }
            val rm = mkBtn("Убрать") {
                Pins.toggle(act, key)
                onPinsChanged(); render()
            }
            focusable(rm)
            row.addView(rm, LinearLayout.LayoutParams(-2, dp(48)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
            body.addView(row)
        }
    }
}
