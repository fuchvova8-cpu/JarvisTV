package com.jarvis.tv

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

/**
 * Buttons the user pinned to the main screen, in order (stored in the app's preferences). Key kinds:
 *   "m:<menu key>"                         an entry of the Service menu
 *   "p:<plugin>|<title>"                   the settings page of a plugin (its first page)
 *   "s:<plugin>|<title>|<event>|page"      any sub-page of a plugin's settings (opened straight on that page)
 *   "s:<plugin>|<title>|<event>|act"       an action of a plugin's settings page, run in one press
 * Keys written by earlier versions ("m:" and "p:") keep working unchanged.
 */
object Pins {
    private const val K = "pins"

    fun list(ctx: Context): MutableList<String> {
        val s = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE).getString(K, "[]") ?: "[]"
        val out = ArrayList<String>()
        try {
            val a = JSONArray(s)
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (_: Throwable) {
        }
        return out
    }

    fun save(ctx: Context, l: List<String>) {
        val a = JSONArray()
        for (x in l) a.put(x)
        ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE).edit().putString(K, a.toString()).apply()
    }

    fun has(ctx: Context, key: String): Boolean = list(ctx).contains(key)

    /** Pins or unpins; returns true when the key is pinned afterwards. */
    fun toggle(ctx: Context, key: String): Boolean {
        val l = list(ctx)
        val now = if (l.contains(key)) { l.remove(key); false } else { l.add(key); true }
        save(ctx, l)
        return now
    }

    fun pluginKey(plugin: String, title: String, event: String, kind: String): String =
        "s:" + plugin + "|" + title.replace('|', '/') + "|" + event + "|" + kind

    /** Caption of a pinned plugin button ("s:" and "p:" keys). */
    fun pluginTitle(key: String): String {
        if (key.startsWith("p:")) return key.substringAfter('|', key.substring(2))
        val p = key.substring(2).split('|')
        return if (p.size > 1 && p[1].isNotEmpty()) p[1] else p[0]
    }

    /** Runs a pinned plugin button: opens the page it points at, or performs the action. */
    fun runPlugin(act: Activity, key: String) {
        if (key.startsWith("p:")) {
            val name = key.substring(2).substringBefore('|')
            act.startActivity(Intent(act, PluginSettingsActivity::class.java)
                .putExtra(PluginSettingsActivity.EXTRA_PLUGIN, name)
                .putExtra(PluginSettingsActivity.EXTRA_TITLE, pluginTitle(key)))
            return
        }
        if (!key.startsWith("s:")) return
        val p = key.substring(2).split('|')
        val name = p.getOrElse(0) { "" }
        val title = pluginTitle(key)
        val event = p.getOrElse(2) { "" }
        if (p.getOrElse(3) { "page" } == "act") {
            kotlin.concurrent.thread(name = "pin-act") {
                val res = try { JSONObject(TvHost.py("plugin_settings_event", name, event, "{}")) } catch (_: Throwable) { JSONObject() }
                val msg = res.optString("message")
                act.runOnUiThread {
                    Toast.makeText(act, if (msg.isEmpty()) title else msg, Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            act.startActivity(Intent(act, PluginSettingsActivity::class.java)
                .putExtra(PluginSettingsActivity.EXTRA_PLUGIN, name)
                .putExtra(PluginSettingsActivity.EXTRA_TITLE, title)
                .putExtra(PluginSettingsActivity.EXTRA_EVENT, event))
        }
    }
}

/**
 * The Service menu as a full-screen layer inside MainActivity: sections → items, a real page stack
 * (Back goes one level up, only the first page closes the menu) and a "＋ На главный" chip next to every
 * item. The open page is remembered, so after the screen rebuilds itself (a skin was changed in a
 * plugin's settings) the menu comes back on the same page instead of dropping you on the main screen.
 */
class MenuPanel(
    private val act: Activity,
    private val entries: () -> LinkedHashMap<String, MainActivity.MenuEntry>,
    private val openPlugin: (String, String) -> Unit,
    private val onPinsChanged: () -> Unit
) : FrameLayout(act) {

    private class Cat(val id: String, val title: String, val hint: String)

    private val cats = listOf(
        Cat("assistant", "Ассистент", "Ключ API, имена, голос"),
        Cat("mic", "Микрофон", "Режим, прослушивание, индикатор"),
        Cat("plugins", "Плагины", "Включение, папка, страницы настроек"),
        Cat("screen", "Экран", "Стиль Google, редактор, кнопки на главном"),
        Cat("system", "Система", "ADB, автозапуск, папка, выход")
    )

    private val stack = ArrayList<String>()
    private var pluginPages: JSONArray? = null
    private var firstFocus: View? = null
    private var shownPage = ""

    private val crumbView: TextView
    private val titleView: TextView
    private val backBtn: TextView
    private val body: LinearLayout
    private val scroll: ScrollView

    private fun dp(v: Int): Int = MenuKit.dp(act, v)

    init {
        setBackgroundColor(Color.argb(215, 0, 0, 0))
        isClickable = true
        visibility = View.GONE

        val card = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            background = MenuKit.shape(act, MenuKit.card, MenuKit.alpha(MenuKit.accent, 0x90), 2f, 24)
            setPadding(dp(26), dp(18), dp(26), dp(14))
        }
        val head = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        backBtn = MenuKit.button(act, "←  Назад", false) { back() }
        val titles = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), 0, dp(18), 0) }
        crumbView = TextView(act).apply { textSize = 13f; setTextColor(MenuKit.muted); maxLines = 1 }
        titleView = TextView(act).apply {
            textSize = 26f
            setTextColor(MenuKit.accent)
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 1
        }
        titles.addView(crumbView)
        titles.addView(titleView)
        head.addView(backBtn, LinearLayout.LayoutParams(-2, dp(48)))
        head.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(MenuKit.button(act, "На главный экран", false) { close() }, LinearLayout.LayoutParams(-2, dp(48)))
        card.addView(head)

        body = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(4)) }
        scroll = ScrollView(act).apply { addView(body); isVerticalScrollBarEnabled = false }
        card.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val sw = resources.displayMetrics.widthPixels
        val sh = resources.displayMetrics.heightPixels
        addView(card, FrameLayout.LayoutParams((sw * 0.76f).toInt(), (sh * 0.90f).toInt(), Gravity.CENTER))
    }

    companion object {
        /** The open page stack, kept across a rebuild of the main screen; null = the menu was closed. */
        @Volatile private var saved: List<String>? = null
    }

    private fun persist() { saved = ArrayList(stack) }

    // ── public ──────────────────────────────────────────────────────────────
    fun isOpen(): Boolean = visibility == View.VISIBLE

    fun open() {
        stack.clear()
        stack.add("root")
        show()
    }

    /** After the main screen was rebuilt: bring the menu back on the page it was on. */
    fun restoreIfAny() {
        val s = saved ?: return
        stack.clear()
        stack.addAll(s)
        if (stack.isEmpty()) stack.add("root")
        show()
    }

    private fun show() {
        visibility = View.VISIBLE
        bringToFront()
        persist()
        shownPage = ""
        render()
        Py.ask("plugin_settings_list") { json ->
            pluginPages = try { JSONArray(json) } catch (_: Throwable) { JSONArray() }
            val p = stack.lastOrNull()
            if (isOpen() && (p == "cat:plugins" || p == "cat:screen")) render()
        }
    }

    fun close() {
        visibility = View.GONE
        stack.clear()
        saved = null
    }

    /** One level up; the first page closes the menu. Always consumes the key while the menu is shown. */
    fun back(): Boolean {
        if (!isOpen()) return false
        if (stack.size > 1) {
            stack.removeAt(stack.size - 1)
            persist()
            render()
        } else close()
        return true
    }

    /** Redraw the current page (states changed, or we came back from another screen). */
    fun refresh() {
        if (isOpen()) render()
    }

    // ── drawing ─────────────────────────────────────────────────────────────
    private fun pageTitle(page: String): String = when {
        page == "root" -> "Меню JARVIS"
        page == "pins" -> "Кнопки на главном экране"
        page.startsWith("cat:") -> cats.firstOrNull { it.id == page.substring(4) }?.title ?: page
        else -> page
    }

    private fun focusable(v: View) {
        if (firstFocus == null) firstFocus = v
    }

    /** Where the focus is: row index in the list and (inside a row) the index of the focused button. */
    private fun focusSlot(): IntArray? {
        val row = body.focusedChild ?: return null
        val i = body.indexOfChild(row)
        if (i < 0) return null
        val j = if (row is ViewGroup) row.indexOfChild(row.focusedChild) else -1
        return intArrayOf(i, j)
    }

    private fun render() {
        val page = stack.lastOrNull() ?: "root"
        val slot = if (page == shownPage) focusSlot() else null
        val keepY = if (page == shownPage) scroll.scrollY else 0
        body.removeAllViews()
        firstFocus = null
        backBtn.visibility = if (stack.size > 1) View.VISIBLE else View.GONE
        val trail = stack.dropLast(1).map { pageTitle(it) }
        crumbView.text = if (trail.isEmpty()) "JARVIS" else "JARVIS  ›  " + trail.joinToString("  ›  ")
        titleView.text = pageTitle(page)
        when {
            page == "root" -> renderRoot()
            page == "pins" -> renderPins()
            page.startsWith("cat:") -> cats.firstOrNull { it.id == page.substring(4) }?.let { renderCat(it) }
        }
        shownPage = page
        body.post {
            var target: View? = null
            if (slot != null && slot[0] < body.childCount) {
                val row = body.getChildAt(slot[0])
                target = if (row is ViewGroup && slot[1] >= 0 && slot[1] < row.childCount) row.getChildAt(slot[1]) else row
                if (target != null && !target.isFocusable) target = null
            }
            (target ?: firstFocus)?.requestFocus()
            if (keepY > 0) scroll.scrollTo(0, keepY)
        }
    }

    private fun go(page: String) {
        stack.add(page)
        persist()
        render()
    }

    private fun micStatus(): String {
        val ptt = MicMode.mode == MicMode.Mode.PTT
        return if (ptt) "По кнопке" else if (MicMode.liveOn) "Постоянно · слушает" else "Постоянно · на паузе"
    }

    private fun renderRoot() {
        body.addView(MenuKit.note(act, "Выберите раздел. Рядом с любым пунктом есть кнопка «＋ На главный»: она выводит " +
            "пункт отдельной кнопкой на главный экран. «Назад» на пульте — на шаг назад."))
        val tiles = ArrayList<Pair<CharSequence, () -> Unit>>()
        for (c in cats) {
            val status = when (c.id) {
                "mic" -> micStatus()
                "screen" -> if (Skin.theme() != null) "Сейчас: стиль Google" else "Сейчас: классический экран"
                else -> ""
            }
            tiles.add(Pair<CharSequence, () -> Unit>(MenuKit.lines(c.title, c.hint, status), { go("cat:" + c.id) }))
        }
        val n = Pins.list(act).size
        tiles.add(Pair<CharSequence, () -> Unit>(
            MenuKit.lines("Кнопки на главном экране", "Порядок и удаление", if (n == 0) "Пока ничего не закреплено" else "Закреплено: $n"),
            { go("pins") }))
        var i = 0
        while (i < tiles.size) {
            val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
            for (j in 0..1) {
                if (i + j < tiles.size) {
                    val t = tiles[i + j]
                    val b = MenuKit.button(act, t.first, true, t.second)
                    focusable(b)
                    row.addView(b, LinearLayout.LayoutParams(0, dp(104), 1f).apply { setMargins(dp(5), dp(5), dp(5), dp(5)) })
                } else {
                    row.addView(View(act), LinearLayout.LayoutParams(0, dp(104), 1f))
                }
            }
            body.addView(row)
            i += 2
        }
    }

    private fun pagesOf(name: String): JSONObject? {
        val arr = pluginPages ?: return null
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("name") == name) return o
        }
        return null
    }

    private fun renderCat(c: Cat) {
        val map = entries()
        fun rows(vararg keys: String) { for (k in keys) if (map.containsKey(k)) addEntryRow(map, k) }
        when (c.id) {
            "assistant" -> {
                body.addView(MenuKit.heading(act, "Подключение"))
                rows("gemini_key")
                body.addView(MenuKit.heading(act, "Обращение и голос"))
                rows("names", "voice")
            }
            "mic" -> {
                body.addView(MenuKit.heading(act, "Как слушать"))
                rows("mic_mode", "mic_live")
                body.addView(MenuKit.heading(act, "Дополнительно"))
                rows("mic_bg", "mic_indicator")
            }
            "plugins" -> {
                body.addView(MenuKit.heading(act, "Управление"))
                rows("plugins", "plugin_dir")
                body.addView(MenuKit.heading(act, "Страницы настроек плагинов"))
                val arr = pluginPages
                var shown = 0
                if (arr == null) body.addView(MenuKit.note(act, "Загрузка…"))
                else {
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val name = o.optString("name")
                        if (name == "screen_style") continue            // lives under «Экран»
                        val title = o.optString("title")
                        addRow(MenuKit.lines(title, "Страница настроек плагина"), "p:$name|$title") { openPlugin(name, title) }
                        shown++
                    }
                    if (shown == 0) body.addView(MenuKit.note(act, "Других страниц настроек пока нет."))
                    if (pagesOf("screen_style") != null) body.addView(MenuKit.note(act, "Настройки экрана (стиль Google) — в разделе «Экран»."))
                }
            }
            "screen" -> {
                body.addView(MenuKit.heading(act, "Оформление"))
                val o = pagesOf("screen_style")
                if (o != null) {
                    val name = o.optString("name")
                    val title = o.optString("title")
                    addRow(MenuKit.lines(title, "Тема, элементы, окно результатов, оверлей микрофона, видео"), "p:$name|$title") { openPlugin(name, title) }
                } else if (pluginPages == null) body.addView(MenuKit.note(act, "Загрузка…"))
                else body.addView(MenuKit.note(act, "Плагин «Экран (стиль Google)» выключен — включите его в разделе «Плагины»."))
                rows("edit_screen")
                body.addView(MenuKit.heading(act, "Главный экран"))
                addRow(MenuKit.lines("Кнопки на главном экране", "Порядок и удаление закреплённых пунктов"), null) { go("pins") }
            }
            "system" -> {
                body.addView(MenuKit.heading(act, "Проверка и запуск"))
                rows("adb", "autostart")
                body.addView(MenuKit.heading(act, "О приложении"))
                rows("folder_info")
                body.addView(MenuKit.heading(act, "Завершение"))
                rows("exit")
            }
        }
    }

    private fun entryInfo(map: Map<String, MainActivity.MenuEntry>, key: String): Pair<String, String> {
        val prefs = act.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
        val ptt = MicMode.mode == MicMode.Mode.PTT
        fun st(on: Boolean) = if (on) "Сейчас: включено" else "Сейчас: выключено"
        return when (key) {
            "gemini_key" -> Pair("Ключ Gemini API", "Без ключа работает локальный режим")
            "names" -> Pair("Имена", "Как зовут ассистента и как обращаться к вам")
            "voice" -> Pair("Голос Gemini", "Выбор голоса ответов")
            "plugins" -> Pair("Плагины: вкл / выкл", "Применяется сразу")
            "plugin_dir" -> Pair("Папка плагинов", "Где лежат ваши плагины")
            "plugin_settings" -> Pair("Настройки плагинов", "Список страниц настроек")
            "mic_mode" -> Pair("Режим микрофона",
                if (ptt) "Сейчас: по кнопке  ·  нажмите — сделать постоянным" else "Сейчас: постоянно  ·  нажмите — сделать по кнопке")
            "mic_live" -> Pair("Постоянное прослушивание",
                if (ptt) "Доступно в постоянном режиме" else st(MicMode.liveOn))
            "mic_bg" -> Pair("Микрофон в фоне", st(MicMode.background))
            "mic_indicator" -> Pair("Индикатор микрофона", st(MicIndicator.enabled))
            "adb" -> Pair("Проверить ADB", "Нужен для ввода и снимка экрана")
            "autostart" -> Pair("Автозапуск при включении ТВ", st(prefs.getBoolean("autostart", true)))
            "folder_info" -> Pair("Папка Jarvis", "Где лежат plugins, config и memory")
            "edit_screen" -> Pair("Редактор экрана", "Перетаскивать элементы мышью")
            "exit" -> Pair("Выйти полностью", "Остановить JARVIS")
            else -> Pair(map[key]?.label?.invoke() ?: key, "")
        }
    }

    private fun addEntryRow(map: LinkedHashMap<String, MainActivity.MenuEntry>, key: String) {
        val info = entryInfo(map, key)
        val pinKey = if (key == "exit") null else "m:$key"
        addRow(MenuKit.lines(info.first, info.second), pinKey) {
            map[key]?.action?.invoke()
            postDelayed({ refresh() }, 600)
        }
    }

    /** One line: the item (wide button) + a pin chip on the right. */
    private fun addRow(text: CharSequence, pinKey: String?, onClick: () -> Unit) {
        val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val main = MenuKit.button(act, text, true, onClick)
        focusable(main)
        row.addView(main, LinearLayout.LayoutParams(0, dp(68), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        if (pinKey != null) {
            val pinned = Pins.has(act, pinKey)
            val pin = MenuKit.pinChip(act, pinned) {
                val now = Pins.toggle(act, pinKey)
                Toast.makeText(act,
                    if (now) "Кнопка добавлена на главный экран" else "Кнопка убрана с главного экрана",
                    Toast.LENGTH_SHORT).show()
                onPinsChanged()
                render()
            }
            row.addView(pin, LinearLayout.LayoutParams(dp(150), dp(68)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        }
        body.addView(row)
    }

    // ── pinned buttons page ─────────────────────────────────────────────────
    private fun pinTitle(key: String): String {
        if (key.startsWith("m:")) return entryInfo(entries(), key.substring(2)).first
        if (key.startsWith("p:") || key.startsWith("s:")) return Pins.pluginTitle(key)
        return key
    }

    private fun pinWhere(key: String): String {
        if (key.startsWith("m:")) return "Пункт меню"
        if (key.startsWith("p:")) return "Страница настроек плагина «" + key.substring(2).substringBefore('|') + "»"
        if (key.startsWith("s:")) {
            val p = key.substring(2).split('|')
            val who = p.getOrElse(0) { "" }
            return if (p.getOrElse(3) { "page" } == "act") "Действие плагина «$who»" else "Страница плагина «$who»"
        }
        return ""
    }

    private fun movePin(key: String, delta: Int) {
        val cur = Pins.list(act)
        val i = cur.indexOf(key)
        val j = i + delta
        if (i < 0 || j < 0 || j >= cur.size) return
        cur.removeAt(i)
        cur.add(j, key)
        Pins.save(act, cur)
        onPinsChanged()
        render()
    }

    private fun renderPins() {
        val list = Pins.list(act)
        if (list.isEmpty()) {
            body.addView(MenuKit.note(act, "Пока ничего не закреплено. Откройте любой раздел меню (или любую страницу настроек " +
                "плагина) и нажмите «＋ На главный» рядом с нужным пунктом."))
            val b = MenuKit.button(act, "К разделам меню", false) { stack.clear(); stack.add("root"); persist(); render() }
            focusable(b)
            body.addView(b, LinearLayout.LayoutParams(-2, dp(52)).apply { setMargins(dp(4), dp(8), dp(4), dp(4)) })
            return
        }
        body.addView(MenuKit.note(act, "Порядок слева направо в строке кнопок над нижней панелью главного экрана."))
        for ((idx, key) in list.withIndex()) {
            val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val t = TextView(act).apply {
                text = MenuKit.lines("${idx + 1}.  ${pinTitle(key)}", pinWhere(key))
                textSize = 15f
                setTextColor(MenuKit.ink)
                setPadding(dp(10), dp(4), dp(10), dp(4))
            }
            row.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
            val left = MenuKit.button(act, "◀ Левее", false) { movePin(key, -1) }
            val right = MenuKit.button(act, "Правее ▶", false) { movePin(key, 1) }
            val rm = MenuKit.button(act, "Убрать", false) {
                Pins.toggle(act, key)
                onPinsChanged(); render()
            }
            for (b in listOf(left, right, rm)) {
                b.textSize = 14f
                focusable(b)
            }
            if (idx > 0) row.addView(left, LinearLayout.LayoutParams(-2, dp(52)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
            if (idx < list.size - 1) row.addView(right, LinearLayout.LayoutParams(-2, dp(52)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
            row.addView(rm, LinearLayout.LayoutParams(-2, dp(52)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
            body.addView(row)
        }
    }
}
