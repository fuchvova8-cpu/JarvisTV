package com.jarvis.tv

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder

/**
 * Microphone for Python's `sounddevice.InputStream` (tvshim: sounddevice.py).
 * `read()` blocks for one block of `frames` 16-bit mono samples.
 */
class MicBridge(private val rate: Int, private val frames: Int) {
    private var rec: AudioRecord? = null
    @Volatile private var running = false
    private val bytes = frames * 2

    fun start() {
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) throw IllegalStateException("no audio input on this device (code $min)")
        val size = maxOf(min * 2, bytes * 4)
        var made: AudioRecord? = null
        // VOICE_RECOGNITION first (flat response, no ducking); then the others.
        val sources = intArrayOf(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            MediaRecorder.AudioSource.MIC,
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            MediaRecorder.AudioSource.DEFAULT
        )
        for (src in sources) {
            try {
                val r = AudioRecord(src, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size)
                if (r.state == AudioRecord.STATE_INITIALIZED) { made = r; break } else r.release()
            } catch (_: Throwable) {}
        }
        val r = made ?: throw IllegalStateException("microphone not available (permission or hardware)")
        r.startRecording()
        if (r.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
            r.release()
            throw IllegalStateException("microphone is busy")
        }
        rec = r
        running = true
    }

    /** One block, or null once stopped. While the system recognizer owns the mic, silence. */
    fun read(): ByteArray? {
        val r = rec ?: return null
        if (Bridge.micPaused) {
            try { if (r.recordingState == AudioRecord.RECORDSTATE_RECORDING) r.stop() } catch (_: Throwable) {}
            try { Thread.sleep((frames * 1000L / rate).coerceAtLeast(10)) } catch (_: InterruptedException) {}
            return if (running) ByteArray(bytes) else null
        }
        if (r.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
            try { r.startRecording() } catch (_: Throwable) {}
        }
        val buf = ByteArray(bytes)
        var off = 0
        while (running && off < bytes) {
            val n = r.read(buf, off, bytes - off)
            if (n < 0) return null
            off += n
        }
        return if (running) buf else null
    }

    fun stop() {
        running = false
        try { rec?.stop() } catch (_: Throwable) {}
    }

    fun release() {
        stop()
        try { rec?.release() } catch (_: Throwable) {}
        rec = null
    }
}

/**
 * Speaker for Python's `sounddevice.RawOutputStream`. `write()` blocks until the
 * hardware buffer accepts the samples, which is what paces JARVIS's voice.
 */
class SpeakerBridge(private val rate: Int, private val channels: Int, private val frames: Int) {
    private var track: AudioTrack? = null
    private var bufFrames = 0

    fun start() {
        val mask = if (channels >= 2) AudioFormat.CHANNEL_OUT_STEREO else AudioFormat.CHANNEL_OUT_MONO
        val min = AudioTrack.getMinBufferSize(rate, mask, AudioFormat.ENCODING_PCM_16BIT)
        val want = rate * 2 * channels / 6                 // ~160 ms
        val size = maxOf(min, want)
        val t = AudioTrack(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build(),
            AudioFormat.Builder()
                .setSampleRate(rate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(mask)
                .build(),
            size,
            AudioTrack.MODE_STREAM,
            AudioManager.AUDIO_SESSION_ID_GENERATE
        )
        if (t.state != AudioTrack.STATE_INITIALIZED) { t.release(); throw IllegalStateException("audio output not available") }
        bufFrames = size / (2 * channels)
        t.play()
        track = t
    }

    fun write(data: ByteArray): Int {
        val t = track ?: return -1
        var off = 0
        while (off < data.size) {
            val n = t.write(data, off, data.size - off)
            if (n < 0) return n
            off += n
        }
        return off
    }

    fun latencySeconds(): Double = if (bufFrames > 0) bufFrames.toDouble() / rate else 0.0

    /** Let what is queued finish, then stop. */
    fun stop() {
        try { track?.stop() } catch (_: Throwable) {}
    }

    /** Drop what is queued at once (barge-in). */
    fun abort() {
        try { track?.pause(); track?.flush() } catch (_: Throwable) {}
    }

    fun release() {
        try { track?.release() } catch (_: Throwable) {}
        track = null
    }
}
