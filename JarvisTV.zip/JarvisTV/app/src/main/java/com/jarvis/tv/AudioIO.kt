package com.jarvis.tv

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder

/**
 * One long-lived capture shared by everything in the process. The TV's audio HAL wakes up slowly
 * on every open (first samples arrive late, sometimes seconds), so the capture is opened once —
 * before the Python core even starts — and stays open; [MicBridge] consumers only attach to it.
 * It is released only while the system recognizer / TV voice search needs the mic ([Bridge.micFree]).
 */
object MicHub {
    private const val RATE = 16000
    private const val CHUNK = 640                       // 20 ms of 16-bit mono
    private val consumers = java.util.concurrent.CopyOnWriteArrayList<java.util.concurrent.LinkedBlockingQueue<ByteArray>>()
    @Volatile private var thread: Thread? = null
    @Volatile private var rec: AudioRecord? = null
    @Volatile private var lastData = 0L

    @Synchronized fun ensure() {
        if (thread?.isAlive == true) return
        thread = Thread({ loop() }, "mic-hub").apply { isDaemon = true; start() }
    }

    fun attach(): java.util.concurrent.LinkedBlockingQueue<ByteArray> {
        val q = java.util.concurrent.LinkedBlockingQueue<ByteArray>()
        consumers.add(q)
        ensure()
        return q
    }

    fun detach(q: java.util.concurrent.LinkedBlockingQueue<ByteArray>) { consumers.remove(q) }

    private fun closeRec() {
        val r = rec ?: return
        rec = null
        try { r.stop() } catch (_: Throwable) {}
        try { r.release() } catch (_: Throwable) {}
    }

    private fun openRec(): AudioRecord? {
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return null
        val size = maxOf(min * 2, CHUNK * 16)
        val sources = intArrayOf(
            MediaRecorder.AudioSource.VOICE_RECOGNITION, MediaRecorder.AudioSource.MIC,
            MediaRecorder.AudioSource.VOICE_COMMUNICATION, MediaRecorder.AudioSource.DEFAULT)
        for (src in sources) {
            val r = try {
                AudioRecord(src, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size)
            } catch (_: Throwable) { continue }
            if (r.state != AudioRecord.STATE_INITIALIZED) { try { r.release() } catch (_: Throwable) {}; continue }
            try { r.startRecording() } catch (_: Throwable) {}
            if (r.recordingState == AudioRecord.RECORDSTATE_RECORDING) return r
            try { r.stop() } catch (_: Throwable) {}
            try { r.release() } catch (_: Throwable) {}
        }
        return null
    }

    private fun loop() {
        val buf = ByteArray(CHUNK)
        // A capture that is "recording" but delivers nothing is dropped and reopened (read() then
        // fails and the loop reopens); consumers get silence meanwhile so Gemini never sees a gap.
        Thread({
            while (true) {
                try { Thread.sleep(500) } catch (_: InterruptedException) { return@Thread }
                val now = android.os.SystemClock.elapsedRealtime()
                if (rec != null && now - lastData > 2500 && !Bridge.micFree) {
                    Bridge.log("SYS: Микрофон не отдавал звук — открываю заново")
                    closeRec()
                    lastData = now
                }
            }
        }, "mic-hub-watch").apply { isDaemon = true; start() }

        while (true) {
            try {
                if (Bridge.micFree) {
                    closeRec()
                    lastData = android.os.SystemClock.elapsedRealtime()
                    Thread.sleep(100)
                    continue
                }
                var r = rec
                if (r == null) {
                    r = openRec()
                    if (r == null) { Thread.sleep(200); continue }
                    rec = r
                    lastData = android.os.SystemClock.elapsedRealtime()
                }
                var off = 0
                while (off < CHUNK) {
                    val n = r.read(buf, off, CHUNK - off)
                    if (n < 0) { closeRec(); off = -1; break }
                    if (n == 0) { Thread.sleep(5); continue }
                    off += n
                    lastData = android.os.SystemClock.elapsedRealtime()
                }
                if (off == CHUNK) {
                    val chunk = buf.copyOf()
                    for (q in consumers) {
                        q.offer(chunk)
                        while (q.size > 100) q.poll()       // slow consumer: drop the oldest
                    }
                }
            } catch (_: InterruptedException) {
                return
            } catch (_: Throwable) {
                closeRec()
                try { Thread.sleep(200) } catch (_: InterruptedException) { return }
            }
        }
    }
}

/**
 * Microphone for Python's `sounddevice.InputStream` (tvshim: sounddevice.py).
 * `read()` returns one block of `frames` 16-bit mono samples from [MicHub]; when the hub has
 * nothing (capture released for the system recognizer, or still waking up) it returns silence
 * after a short wait, so the stream never stalls.
 */
class MicBridge(private val rate: Int, private val frames: Int) {
    @Volatile private var running = false
    private var q: java.util.concurrent.LinkedBlockingQueue<ByteArray>? = null
    private val bytes = frames * 2
    private var rest: ByteArray? = null                  // tail of a hub chunk that did not fit the last block

    fun start() {
        rest = null
        q = MicHub.attach()
        running = true
    }

    fun read(): ByteArray? {
        val queue = q ?: return null
        val buf = ByteArray(bytes)                       // zero = silence for anything not filled
        val blockMs = (frames * 1000L / rate).coerceAtLeast(10)
        val deadline = android.os.SystemClock.elapsedRealtime() + blockMs + 150
        var off = 0
        rest?.let { r -> val n = minOf(r.size, bytes); System.arraycopy(r, 0, buf, 0, n); off = n; rest = if (n < r.size) r.copyOfRange(n, r.size) else null }
        while (running && off < bytes) {
            val wait = deadline - android.os.SystemClock.elapsedRealtime()
            val c = if (Bridge.micFree) null else try { queue.poll(maxOf(wait, 1L), java.util.concurrent.TimeUnit.MILLISECONDS) } catch (_: InterruptedException) { null }
            if (c == null) {
                if (Bridge.micFree) { queue.clear(); try { Thread.sleep(blockMs) } catch (_: InterruptedException) {} }
                break                                    // pad with silence
            }
            val n = minOf(c.size, bytes - off)
            System.arraycopy(c, 0, buf, off, n)
            off += n
            if (n < c.size) rest = c.copyOfRange(n, c.size)
        }
        return if (running) buf else null
    }

    fun stop() {
        running = false
        q?.let { MicHub.detach(it) }
        q = null
    }

    fun release() = stop()
}

/**
 * Speaker for Python's `sounddevice.RawOutputStream`. `write()` blocks until the
 * hardware buffer accepts the samples, which is what paces JARVIS's voice.
 */
class SpeakerBridge(private val rate: Int, private val channels: Int, private val frames: Int) {
    private var track: AudioTrack? = null
    private var bufFrames = 0

    fun start() {
        val mask = if (channels >= 2) AudioFormat.CHANNEL_OUT_STEREO else AudioFormat.CHANNEL_OUT_MONO
        val min = AudioTrack.getMinBufferSize(rate, mask, AudioFormat.ENCODING_PCM_16BIT)
        val want = rate * 2 * channels / 6                 // ~160 ms
        val size = maxOf(min, want)
        val t = AudioTrack(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build(),
            AudioFormat.Builder()
                .setSampleRate(rate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(mask)
                .build(),
            size,
            AudioTrack.MODE_STREAM,
            AudioManager.AUDIO_SESSION_ID_GENERATE
        )
        if (t.state != AudioTrack.STATE_INITIALIZED) { t.release(); throw IllegalStateException("audio output not available") }
        bufFrames = size / (2 * channels)
        t.play()
        track = t
    }

    fun write(data: ByteArray): Int {
        val t = track ?: return -1
        var off = 0
        while (off < data.size) {
            val n = t.write(data, off, data.size - off)
            if (n < 0) return n
            off += n
        }
        return off
    }

    fun latencySeconds(): Double = if (bufFrames > 0) bufFrames.toDouble() / rate else 0.0

    /** Let what is queued finish, then stop. */
    fun stop() {
        try { track?.stop() } catch (_: Throwable) {}
    }

    /** Drop what is queued at once (barge-in). */
    fun abort() {
        try { track?.pause(); track?.flush() } catch (_: Throwable) {}
    }

    fun release() {
        try { track?.release() } catch (_: Throwable) {}
        track = null
    }
}
