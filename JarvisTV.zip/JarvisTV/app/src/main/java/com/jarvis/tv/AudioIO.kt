package com.jarvis.tv

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder

/**
 * One long-lived capture shared by everything in the process. The TV's audio HAL wakes up slowly
 * on every open (first samples arrive late, sometimes seconds), so the capture is opened once —
 * before the Python core even starts — and stays open; [MicBridge] consumers only attach to it.
 * It is released only while the system recognizer / TV voice search needs the mic ([Bridge.micFree]).
 */
object MicHub {
    private const val RATE = 16000
    private const val CHUNK = 640                       // 20 ms of 16-bit mono
    private val consumers = java.util.concurrent.CopyOnWriteArrayList<java.util.concurrent.LinkedBlockingQueue<ByteArray>>()
    @Volatile private var thread: Thread? = null
    @Volatile private var rec: AudioRecord? = null
    @Volatile private var lastData = 0L
    @Volatile private var openedAt = 0L
    @Volatile private var firstLogged = true

    // ── per-heartbeat counters (loop thread writes, watch thread reads) ──
    @Volatile private var nChunks = 0L
    @Volatile private var nZero = 0L
    @Volatile private var peakMax = 0
    @Volatile private var sumAbs = 0L
    @Volatile var padCount = 0L          // blocks MicBridge had to pad with silence (hub had nothing)
    @Volatile var readCount = 0L
    private fun hlog(msg: String) = Diag.log("MIC", msg)
    private fun ctx(): String = Diag.snapshot()

    private fun heartbeat(sec: Int, full: Boolean) {
        val n = nChunks; val z = nZero; val pk = peakMax
        val avg = if (n > 0) sumAbs / (n * (CHUNK / 2)) else 0
        nChunks = 0; nZero = 0; peakMax = 0; sumAbs = 0
        val r = rec
        hlog("hb ${sec}s: chunks=$n(exp ${sec * 50}) silent=$z peak=$pk avg=$avg consumers=${consumers.size} " +
            "queued=${consumers.joinToString("/") { it.size.toString() }} reads=$readCount padded=$padCount " +
            "rec=${if (r == null) "closed" else srcName(r.audioSource) + "/state" + r.recordingState} sinceData=${android.os.SystemClock.elapsedRealtime() - lastData}ms" +
            if (full) "; " + ctx() else "")
        readCount = 0; padCount = 0
    }

    @Synchronized fun ensure() {
        if (thread?.isAlive == true) return
        loadLearned()
        hlog("hub start; configured source=" + configuredSource().let { if (it < 0) "auto" else srcName(it) } + "; " + ctx())
        thread = Thread({ loop() }, "mic-hub").apply { isDaemon = true; start() }
    }

    fun attach(): java.util.concurrent.LinkedBlockingQueue<ByteArray> {
        val q = java.util.concurrent.LinkedBlockingQueue<ByteArray>()
        consumers.add(q)
        ensure()
        return q
    }

    fun detach(q: java.util.concurrent.LinkedBlockingQueue<ByteArray>) { consumers.remove(q) }

    private fun closeRec() {
        val r = rec ?: return
        rec = null
        try { r.stop() } catch (_: Throwable) {}
        try { r.release() } catch (_: Throwable) {}
    }

    // ── which audio source to capture from ──────────────────────────────────────────────────────
    // The logcat of the TV showed `input source = 6` (VOICE_RECOGNITION) on every open, and with it the
    // capture stops delivering after ~31 s. Sources are therefore tried in auto mode, one after another:
    // after a stall the next one is used; a source that lives 2 minutes is remembered.
    // Fixed choice (no rebuild): Jarvis/config/mic_source.txt — auto | mic | camcorder | communication |
    // unprocessed | recognition.
    private val CANDIDATES = intArrayOf(1, 5, 7, 9, 6)   // MIC, CAMCORDER, VOICE_COMMUNICATION, UNPROCESSED, VOICE_RECOGNITION
    @Volatile private var autoIdx = 0
    @Volatile private var learnedSaved = -1

    private fun srcName(s: Int): String = when (s) {
        1 -> "MIC"; 5 -> "CAMCORDER"; 7 -> "VOICE_COMMUNICATION"; 9 -> "UNPROCESSED"; 6 -> "VOICE_RECOGNITION"; 0 -> "DEFAULT"
        else -> "src$s"
    }

    private fun cfgFile(name: String) = java.io.File(java.io.File(AssetInstaller.targetDir(Bridge.app), "config"), name)

    /** The source fixed in mic_source.txt, or -1 for auto. */
    private fun configuredSource(): Int = try {
        val f = cfgFile("mic_source.txt")
        if (!f.exists()) {
            f.parentFile?.mkdirs()
            f.writeText("auto\n# auto - Jarvis picks a working source itself (MIC, CAMCORDER, VOICE_COMMUNICATION, UNPROCESSED, VOICE_RECOGNITION)\n" +
                "# or one word: mic | camcorder | communication | unprocessed | recognition\n")
        }
        val w = f.readLines().firstOrNull { it.isNotBlank() && !it.trim().startsWith("#") }?.trim()?.lowercase() ?: "auto"
        when (w) {
            "mic" -> 1; "camcorder" -> 5; "communication", "voice_communication" -> 7
            "unprocessed" -> 9; "recognition", "voice_recognition" -> 6; "default" -> 0
            else -> w.toIntOrNull() ?: -1
        }
    } catch (_: Throwable) { -1 }

    private fun loadLearned() {
        try {
            val v = cfgFile("mic_source_learned.txt").readText().trim().toInt()
            val i = CANDIDATES.indexOf(v)
            if (i >= 0) { autoIdx = i; learnedSaved = v; hlog("remembered working source: ${srcName(v)}") }
        } catch (_: Throwable) {}
    }

    private fun openRec(): AudioRecord? {
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return null
        val size = maxOf(min * 2, CHUNK * 16)
        val fixed = configuredSource()
        val sources: List<Int> = if (fixed >= 0) listOf(fixed) + CANDIDATES.filter { it != fixed } + 0
            else (0 until CANDIDATES.size).map { CANDIDATES[(autoIdx + it) % CANDIDATES.size] } + 0
        for (src in sources) {
            val r = try {
                AudioRecord(src, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size)
            } catch (_: Throwable) { continue }
            if (r.state != AudioRecord.STATE_INITIALIZED) { try { r.release() } catch (_: Throwable) {}; continue }
            try { r.startRecording() } catch (_: Throwable) {}
            if (r.recordingState == AudioRecord.RECORDSTATE_RECORDING) return r
            try { r.stop() } catch (_: Throwable) {}
            try { r.release() } catch (_: Throwable) {}
        }
        return null
    }

    private fun loop() {
        val buf = ByteArray(CHUNK)
        // A capture that is "recording" but delivers nothing is dropped and reopened (read() then
        // fails and the loop reopens); consumers get silence meanwhile so Gemini never sees a gap.
        Thread({
            var tick = 0
            while (true) {
                try { Thread.sleep(500) } catch (_: InterruptedException) { return@Thread }
                val now = android.os.SystemClock.elapsedRealtime()
                tick++
                if (tick % 10 == 0) heartbeat(5, tick % 60 == 0)
                val rr = rec
                if (rr != null && !Bridge.micFree && now - openedAt > 120_000 && learnedSaved != rr.audioSource && configuredSource() < 0) {
                    learnedSaved = rr.audioSource
                    try { cfgFile("mic_source_learned.txt").writeText(rr.audioSource.toString()) } catch (_: Throwable) {}
                    hlog("source " + srcName(rr.audioSource) + " works for over 2 min without a stall - remembered")
                }
                if (rec != null && now - lastData > 2500 && !Bridge.micFree) {
                    val src = rec?.audioSource ?: -1
                    val lived = (lastData - openedAt).coerceAtLeast(0)
                    hlog("STALL: no samples for " + (now - lastData) + " ms; source " + srcName(src) + " delivered sound for " +
                        (lived / 1000) + " s; " + ctx())
                    if (configuredSource() < 0 && src >= 0) {
                        val i = CANDIDATES.indexOf(src)
                        if (i >= 0) {
                            autoIdx = (i + 1) % CANDIDATES.size
                            hlog("auto: " + srcName(src) + " stalled after " + (lived / 1000) + " s -> next source " + srcName(CANDIDATES[autoIdx]))
                        }
                        if (learnedSaved == src) { learnedSaved = -1; try { cfgFile("mic_source_learned.txt").delete() } catch (_: Throwable) {} }
                    }
                    Bridge.log("SYS: Микрофон не отдавал звук — открываю заново")
                    closeRec()
                    lastData = now
                }
            }
        }, "mic-hub-watch").apply { isDaemon = true; start() }

        while (true) {
            try {
                if (Bridge.micFree) {
                    if (rec != null) hlog("released (micFree); " + ctx())
                    closeRec()
                    lastData = android.os.SystemClock.elapsedRealtime()
                    Thread.sleep(100)
                    continue
                }
                var r = rec
                if (r == null) {
                    r = openRec()
                    if (r == null) { hlog("open failed (all sources); retry"); Thread.sleep(200); continue }
                    rec = r
                    lastData = android.os.SystemClock.elapsedRealtime()
                    openedAt = lastData; firstLogged = false
                    hlog("opened src=" + r.audioSource + " (" + srcName(r.audioSource) + "); " + ctx())
                }
                var off = 0
                while (off < CHUNK) {
                    val n = r.read(buf, off, CHUNK - off)
                    if (n < 0) { hlog("read error $n; " + ctx()); closeRec(); off = -1; break }
                    if (n == 0) { Thread.sleep(5); continue }
                    off += n
                    lastData = android.os.SystemClock.elapsedRealtime()
                    if (!firstLogged) { firstLogged = true; hlog("first samples after " + (lastData - openedAt) + " ms") }
                }
                if (off == CHUNK) {
                    var pk = 0; var sa = 0L
                    var i = 0
                    while (i < CHUNK) {
                        val v = (buf[i].toInt() and 0xFF) or (buf[i + 1].toInt() shl 8)
                        val a = if (v < 0) -v else v
                        if (a > pk) pk = a
                        sa += a
                        i += 2
                    }
                    nChunks++; sumAbs += sa
                    if (pk == 0) nZero++
                    if (pk > peakMax) peakMax = pk
                    val chunk = buf.copyOf()
                    for (q in consumers) {
                        q.offer(chunk)
                        while (q.size > 100) q.poll()       // slow consumer: drop the oldest
                    }
                }
            } catch (_: InterruptedException) {
                return
            } catch (t: Throwable) {
                hlog("hub loop error: " + android.util.Log.getStackTraceString(t))
                closeRec()
                try { Thread.sleep(200) } catch (_: InterruptedException) { return }
            }
        }
    }
}

/**
 * Microphone for Python's `sounddevice.InputStream` (tvshim: sounddevice.py).
 * `read()` returns one block of `frames` 16-bit mono samples from [MicHub]; when the hub has
 * nothing (capture released for the system recognizer, or still waking up) it returns silence
 * after a short wait, so the stream never stalls.
 */
class MicBridge(private val rate: Int, private val frames: Int) {
    @Volatile private var running = false
    private var q: java.util.concurrent.LinkedBlockingQueue<ByteArray>? = null
    private val bytes = frames * 2
    private var rest: ByteArray? = null                  // tail of a hub chunk that did not fit the last block

    fun start() {
        rest = null
        q = MicHub.attach()
        running = true
        Diag.log("MIC", "consumer start rate=$rate frames=$frames")
    }

    fun read(): ByteArray? {
        val queue = q ?: return null
        MicHub.readCount++
        val buf = ByteArray(bytes)                       // zero = silence for anything not filled
        val blockMs = (frames * 1000L / rate).coerceAtLeast(10)
        val deadline = android.os.SystemClock.elapsedRealtime() + blockMs + 150
        var off = 0
        rest?.let { r -> val n = minOf(r.size, bytes); System.arraycopy(r, 0, buf, 0, n); off = n; rest = if (n < r.size) r.copyOfRange(n, r.size) else null }
        while (running && off < bytes) {
            val wait = deadline - android.os.SystemClock.elapsedRealtime()
            val c = if (Bridge.micFree) null else try { queue.poll(maxOf(wait, 1L), java.util.concurrent.TimeUnit.MILLISECONDS) } catch (_: InterruptedException) { null }
            if (c == null) {
                if (Bridge.micFree) { queue.clear(); try { Thread.sleep(blockMs) } catch (_: InterruptedException) {} }
                if (!Bridge.micFree) MicHub.padCount++
                break                                    // pad with silence
            }
            val n = minOf(c.size, bytes - off)
            System.arraycopy(c, 0, buf, off, n)
            off += n
            if (n < c.size) rest = c.copyOfRange(n, c.size)
        }
        return if (running) buf else null
    }

    fun stop() {
        if (running) Diag.log("MIC", "consumer stop")
        running = false
        q?.let { MicHub.detach(it) }
        q = null
    }

    fun release() = stop()
}

/**
 * Speaker for Python's `sounddevice.RawOutputStream`. `write()` blocks until the
 * hardware buffer accepts the samples, which is what paces JARVIS's voice.
 */
class SpeakerBridge(private val rate: Int, private val channels: Int, private val frames: Int) {
    private var track: AudioTrack? = null
    private var bufFrames = 0

    fun start() {
        val mask = if (channels >= 2) AudioFormat.CHANNEL_OUT_STEREO else AudioFormat.CHANNEL_OUT_MONO
        val min = AudioTrack.getMinBufferSize(rate, mask, AudioFormat.ENCODING_PCM_16BIT)
        val want = rate * 2 * channels / 6                 // ~160 ms
        val size = maxOf(min, want)
        val t = AudioTrack(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build(),
            AudioFormat.Builder()
                .setSampleRate(rate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(mask)
                .build(),
            size,
            AudioTrack.MODE_STREAM,
            AudioManager.AUDIO_SESSION_ID_GENERATE
        )
        if (t.state != AudioTrack.STATE_INITIALIZED) { t.release(); throw IllegalStateException("audio output not available") }
        bufFrames = size / (2 * channels)
        t.play()
        track = t
        Diag.log("SPK", "start rate=$rate ch=$channels buf=${size}B (~${bufFrames * 1000 / rate} ms)")
    }

    fun write(data: ByteArray): Int {
        val t = track ?: return -1
        var off = 0
        while (off < data.size) {
            val n = t.write(data, off, data.size - off)
            if (n < 0) { Diag.log("SPK", "write error $n"); return n }
            off += n
        }
        return off
    }

    fun latencySeconds(): Double = if (bufFrames > 0) bufFrames.toDouble() / rate else 0.0

    /** Let what is queued finish, then stop. */
    fun stop() {
        Diag.log("SPK", "stop (drain)")
        try { track?.stop() } catch (_: Throwable) {}
    }

    /** Drop what is queued at once (barge-in). */
    fun abort() {
        Diag.log("SPK", "abort (barge-in/flush)")
        try { track?.pause(); track?.flush() } catch (_: Throwable) {}
    }

    fun release() {
        Diag.log("SPK", "release")
        try { track?.release() } catch (_: Throwable) {}
        track = null
    }
}
