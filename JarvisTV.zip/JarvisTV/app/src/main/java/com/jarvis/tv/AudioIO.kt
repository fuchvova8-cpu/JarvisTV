package com.jarvis.tv

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder

/**
 * Microphone for Python's `sounddevice.InputStream` (tvshim: sounddevice.py).
 * `read()` blocks for one block of `frames` 16-bit mono samples.
 */
class MicBridge(private val rate: Int, private val frames: Int) {
    private var rec: AudioRecord? = null
    @Volatile private var running = false
    @Volatile private var lastData = 0L
    private val bytes = frames * 2

    companion object {
        // Every AudioRecord this process has open. The TV's audio HAL takes one capture at a time, so a
        // record left over from a torn-down session makes every later start fail with "busy" until the
        // process is restarted. A new capture first clears the leftovers.
        private val live = java.util.Collections.synchronizedSet(HashSet<AudioRecord>())

        private fun drop(r: AudioRecord) {
            live.remove(r)
            try { r.stop() } catch (_: Throwable) {}
            try { r.release() } catch (_: Throwable) {}
        }

        private fun dropAll() {
            val old = synchronized(live) { live.toList() }
            for (r in old) drop(r)
        }
    }

    private fun openOnce(): AudioRecord? {
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) throw IllegalStateException("no audio input on this device (code $min)")
        val size = maxOf(min * 2, bytes * 4)
        // VOICE_RECOGNITION first (flat response, no ducking); then the others.
        val sources = intArrayOf(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            MediaRecorder.AudioSource.MIC,
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            MediaRecorder.AudioSource.DEFAULT
        )
        var initialised = false
        for (src in sources) {
            val r = try {
                AudioRecord(src, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size)
            } catch (_: Throwable) { continue }
            if (r.state != AudioRecord.STATE_INITIALIZED) { try { r.release() } catch (_: Throwable) {}; continue }
            initialised = true
            live.add(r)
            try { r.startRecording() } catch (_: Throwable) {}
            if (r.recordingState == AudioRecord.RECORDSTATE_RECORDING) return r
            drop(r)
        }
        if (!initialised) throw IllegalStateException("microphone not available (permission or hardware)")
        return null
    }

    /** Opens the capture, clearing leftovers and retrying for ~1.5 s: a just-closed one is released
     *  by the HAL a little later. */
    private fun open(): AudioRecord {
        dropAll()
        for (attempt in 0 until 14) {
            openOnce()?.let { return it }
            try { Thread.sleep(120) } catch (_: InterruptedException) {}
            dropAll()
        }
        throw IllegalStateException("microphone is busy")
    }

    @Synchronized private fun closeRec() {
        rec?.let { drop(it) }
        rec = null
    }

    fun start() {
        val r = open()
        synchronized(this) { rec = r }
        lastData = android.os.SystemClock.elapsedRealtime()
        running = true
        startWatchdog()
    }

    /** A capture that is "recording" but delivers nothing (seen right after the app starts: the HAL is
     *  still letting go of the previous one) would leave Gemini without audio until it closes the
     *  session for inactivity. If no sound arrives for 1.5 s the capture is dropped and reopened. */
    private fun startWatchdog() {
        Thread({
            while (running) {
                try { Thread.sleep(500) } catch (_: InterruptedException) { return@Thread }
                if (!running) break
                val now = android.os.SystemClock.elapsedRealtime()
                if (Bridge.micFree) { lastData = now; continue }
                if (rec != null && now - lastData > 1500) {
                    Bridge.log("SYS: Микрофон не отдавал звук — открываю заново")
                    closeRec()
                    lastData = now
                }
            }
        }, "mic-watchdog").apply { isDaemon = true; start() }
    }

    private fun silence(): ByteArray? {
        try { Thread.sleep((frames * 1000L / rate).coerceAtLeast(10)) } catch (_: InterruptedException) {}
        return if (running) ByteArray(bytes) else null
    }

    /** One block, or null once stopped. While the system recognizer (or the TV's own voice
     *  search, with Jarvis off-screen) needs the mic, it is fully released and we send silence. */
    fun read(): ByteArray? {
        if (!running) return null
        if (Bridge.micFree) {
            closeRec()
            return silence()
        }
        var cur: AudioRecord? = rec
        if (cur == null) {
            val opened: AudioRecord = try { open() } catch (_: Throwable) { return silence() }  // retry on the next block
            val keep = synchronized(this) { if (running) { rec = opened; true } else false }
            if (!keep) { drop(opened); return null }
            cur = opened
        }
        val r: AudioRecord = cur
        val buf = ByteArray(bytes)
        var off = 0
        while (running && off < bytes) {
            val n = try { r.read(buf, off, bytes - off) } catch (_: Throwable) { -1 }
            if (n < 0) { closeRec(); return silence() }
            if (n == 0) { try { Thread.sleep(5) } catch (_: InterruptedException) {} ; continue }
            lastData = android.os.SystemClock.elapsedRealtime()
            off += n
        }
        return if (running) buf else null
    }

    fun stop() {
        running = false
        closeRec()
    }

    fun release() = stop()
}

/**
 * Speaker for Python's `sounddevice.RawOutputStream`. `write()` blocks until the
 * hardware buffer accepts the samples, which is what paces JARVIS's voice.
 */
class SpeakerBridge(private val rate: Int, private val channels: Int, private val frames: Int) {
    private var track: AudioTrack? = null
    private var bufFrames = 0

    fun start() {
        val mask = if (channels >= 2) AudioFormat.CHANNEL_OUT_STEREO else AudioFormat.CHANNEL_OUT_MONO
        val min = AudioTrack.getMinBufferSize(rate, mask, AudioFormat.ENCODING_PCM_16BIT)
        val want = rate * 2 * channels / 6                 // ~160 ms
        val size = maxOf(min, want)
        val t = AudioTrack(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build(),
            AudioFormat.Builder()
                .setSampleRate(rate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(mask)
                .build(),
            size,
            AudioTrack.MODE_STREAM,
            AudioManager.AUDIO_SESSION_ID_GENERATE
        )
        if (t.state != AudioTrack.STATE_INITIALIZED) { t.release(); throw IllegalStateException("audio output not available") }
        bufFrames = size / (2 * channels)
        t.play()
        track = t
    }

    fun write(data: ByteArray): Int {
        val t = track ?: return -1
        var off = 0
        while (off < data.size) {
            val n = t.write(data, off, data.size - off)
            if (n < 0) return n
            off += n
        }
        return off
    }

    fun latencySeconds(): Double = if (bufFrames > 0) bufFrames.toDouble() / rate else 0.0

    /** Let what is queued finish, then stop. */
    fun stop() {
        try { track?.stop() } catch (_: Throwable) {}
    }

    /** Drop what is queued at once (barge-in). */
    fun abort() {
        try { track?.pause(); track?.flush() } catch (_: Throwable) {}
    }

    fun release() {
        try { track?.release() } catch (_: Throwable) {}
        track = null
    }
}
