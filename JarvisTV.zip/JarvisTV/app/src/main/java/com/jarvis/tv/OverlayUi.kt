package com.jarvis.tv

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

/**
 * The four coloured dots of the Google assistant. Waiting: dots. Listening: bars that follow the voice level.
 * Thinking: dots bounce one after another. Speaking: a calm wave.
 */
class GoogleDots(ctx: Context) : View(ctx) {
    var state: String = "LISTENING"
        set(v) { field = v; invalidate() }

    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val colors = intArrayOf(0xFF4285F4.toInt(), 0xFFEA4335.toInt(), 0xFFFBBC04.toInt(), 0xFF34A853.toInt())
    private var smooth = 0f

    override fun onDraw(c: Canvas) {
        val t = System.nanoTime() / 1_000_000_000.0
        val w = width.toFloat()
        val h = height.toFloat()
        val dot = 11 * d
        val gap = 8 * d
        val total = 4 * dot + 3 * gap
        val x0 = (w - total) / 2f
        val fresh = (System.nanoTime() - Bridge.levelAt) < 300_000_000L
        val lv = if (fresh) Bridge.level.coerceIn(0f, 1f) else 0f
        smooth += (lv - smooth) * 0.4f
        for (i in 0 until 4) {
            val k: Float = when (state) {
                "LISTENING" -> (smooth * (0.55f + 0.45f * Math.sin(t * 9.0 + i * 1.7).toFloat()) * 1.8f).coerceIn(0f, 1f)
                "SPEAKING" -> (0.25f + 0.25f * Math.sin(t * 4.0 + i * 0.9).toFloat() + smooth * 0.5f).coerceIn(0f, 1f)
                "THINKING", "PROCESSING" -> (0.5f + 0.5f * Math.sin(t * 6.0 - i * 0.9).toFloat()).coerceIn(0f, 1f)
                else -> 0f
            }
            val bh = dot + k * (h - dot - 6 * d)
            val x = x0 + i * (dot + gap)
            val cy = if (state == "THINKING" || state == "PROCESSING") h / 2f - k * 8 * d + 4 * d else h / 2f
            r.set(x, cy - bh / 2f, x + dot, cy + bh / 2f)
            paint.color = colors[i]
            c.drawRoundRect(r, dot / 2f, dot / 2f, paint)
        }
        postInvalidateOnAnimation()
    }
}
