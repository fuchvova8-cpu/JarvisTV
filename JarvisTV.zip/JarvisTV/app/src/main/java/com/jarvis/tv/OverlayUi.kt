package com.jarvis.tv

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

/**
 * The four coloured dots of the Google assistant. Waiting: dots. Listening: bars that follow the voice level.
 * Thinking: dots bounce one after another. Speaking: a calm wave.
 */
class GoogleDots(ctx: Context) : View(ctx) {
    var state: String = "LISTENING"
        set(v) { field = v; invalidate() }

    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val colors = intArrayOf(0xFF4285F4.toInt(), 0xFFEA4335.toInt(), 0xFFFBBC04.toInt(), 0xFF34A853.toInt())
    private var smooth = 0f

    override fun onDraw(c: Canvas) {
        val t = System.nanoTime() / 1_000_000_000.0
        val w = width.toFloat()
        val h = height.toFloat()
        val dot = 11 * d
        val gap = 8 * d
        val total = 4 * dot + 3 * gap
        val x0 = (w - total) / 2f
        val fresh = (System.nanoTime() - Bridge.levelAt) < 300_000_000L
        val lv = if (fresh) Bridge.level.coerceIn(0f, 1f) else 0f
        smooth += (lv - smooth) * 0.4f
        for (i in 0 until 4) {
            val k: Float = when (state) {
                "LISTENING" -> (smooth * (0.55f + 0.45f * Math.sin(t * 9.0 + i * 1.7).toFloat()) * 1.8f).coerceIn(0f, 1f)
                "SPEAKING" -> (0.25f + 0.25f * Math.sin(t * 4.0 + i * 0.9).toFloat() + smooth * 0.5f).coerceIn(0f, 1f)
                "THINKING", "PROCESSING" -> (0.5f + 0.5f * Math.sin(t * 6.0 - i * 0.9).toFloat()).coerceIn(0f, 1f)
                else -> 0f
            }
            val bh = dot + k * (h - dot - 6 * d)
            val x = x0 + i * (dot + gap)
            val cy = if (state == "THINKING" || state == "PROCESSING") h / 2f - k * 8 * d + 4 * d else h / 2f
            r.set(x, cy - bh / 2f, x + dot, cy + bh / 2f)
            paint.color = colors[i]
            c.drawRoundRect(r, dot / 2f, dot / 2f, paint)
        }
        postInvalidateOnAnimation()
    }
}


/** Round microphone button (symbol drawn in code). Lit with the accent colour while the phone is listening. */
class MicIcon(ctx: Context, private val fg: Int, private val accent: Int, private val plate: Int) : View(ctx) {
    var active: Boolean = false
        set(v) { if (field != v) { field = v; invalidate() } }

    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()

    init {
        isFocusable = true
        isClickable = true
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val s = Math.min(w, h)
        val cx = w / 2f
        val cy = h / 2f
        paint.style = Paint.Style.FILL
        paint.color = if (active) accent else plate
        c.drawCircle(cx, cy, s / 2f - 1f * d, paint)
        if (isFocused) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2.5f * d
            paint.color = fg
            c.drawCircle(cx, cy, s / 2f - 2f * d, paint)
        }
        val ink = if (active) 0xFF000000.toInt() else fg
        paint.color = ink
        paint.style = Paint.Style.FILL
        r.set(cx - s * 0.11f, cy - s * 0.30f, cx + s * 0.11f, cy + s * 0.06f)
        c.drawRoundRect(r, s * 0.11f, s * 0.11f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = Math.max(2f, s * 0.05f)
        paint.strokeCap = Paint.Cap.ROUND
        r.set(cx - s * 0.20f, cy - s * 0.14f, cx + s * 0.20f, cy + s * 0.20f)
        c.drawArc(r, 0f, 180f, false, paint)
        c.drawLine(cx, cy + s * 0.20f, cx, cy + s * 0.31f, paint)
        c.drawLine(cx - s * 0.10f, cy + s * 0.31f, cx + s * 0.10f, cy + s * 0.31f, paint)
    }
}
