package com.jarvis.tv

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.ViewGroup
import android.graphics.Color
import android.graphics.Outline
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.HorizontalScrollView
import android.widget.ImageView
import org.json.JSONArray
import org.json.JSONObject
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Translucent strip at the bottom of the screen, for use on top of the TV player or any app.
 * Bind it to a remote button with TV Quick Actions. One phrase, then it closes (Back = cancel).
 */
open class OverlayActivity : Activity() {

    /** true: toggles "microphone always on" and stays while it is on. */
    protected open val continuousMode: Boolean = false

    /** true: the strip never closes by itself (no timers, no silence hide): for the microphone that runs in the background. */
    protected open val persistent: Boolean = false

    private var core: HudView? = null

    // ── Google style (skin active): bottom sheet with the four dots, the phrase and a results strip ──
    private val skin: Skin.Cfg? = Skin.fresh()
    private val oc: JSONObject? = skin?.overlay
    private fun oD(k: String, d: Double): Double = oc?.optDouble(k, d) ?: d
    private fun oI(k: String, d: Int): Int = oc?.optInt(k, d) ?: d
    private fun oB(k: String, d: Boolean): Boolean {      // the plugin writes 1/0; org.json would ignore numbers
        val v = oc?.opt(k)
        return when (v) { is Boolean -> v; is Number -> v.toInt() != 0; else -> d }
    }
    private fun oS(k: String, d: String): String = oc?.optString(k, d) ?: d
    /** "search" = only the query bar; "results" = results replace the bar; "both" = bar and results. */
    private val overlayMode: String get() = if (skin == null) "search" else oS("mode", "search")
    private val resultsMode: Boolean get() = skin != null && overlayMode != "search"
    private var dots: GoogleDots? = null
    private var header: View? = null
    private var stripScroll: HorizontalScrollView? = null
    private var strip: LinearLayout? = null
    private var gotResults = false
    private var toolbar: View? = null
    private var countView: TextView? = null
    private var tilesBtn: TextView? = null
    private var listBtn: TextView? = null
    private var micBtn: MicIcon? = null
    private var listScroll: ScrollView? = null
    private var listCol: LinearLayout? = null
    private var listMode = false
    private var lastItems = JSONArray()
    private val hardStop = Runnable { if (!isFinishing) finish() }

    /** (Re)start the close timer; the persistent strip only closes after a long idle time. */
    private fun armStop(ms: Long) {
        mainH.removeCallbacks(hardStop)
        if (!persistent) mainH.postDelayed(hardStop, ms)
    }
    private var floating: Floating? = null

    // Like Google's microphone: nobody speaks → the window goes away (or just stops listening if results are shown).
    private var speechSeen = false
    private val silenceStop = Runnable {
        if (!isFinishing && !speechSeen && VoiceLoop.state == VoiceLoop.S.LISTENING) {
            VoiceLoop.abort()
            if (!gotResults) finish()
        }
    }

    private fun armSilence() {
        mainH.removeCallbacks(silenceStop)
        if (persistent) return
        speechSeen = false
        val s = oI("silenceHide", 6)
        if (s > 0 && VoiceLoop.state == VoiceLoop.S.LISTENING) mainH.postDelayed(silenceStop, s * 1000L)
    }
    private val consumer: (String, String) -> Boolean = { title, json ->
        runOnUiThread { showResultsInSheet(title, json) }
        true
    }

    private fun setViz(state: String) {
        core?.state = state
        dots?.state = state
    }
    private lateinit var text: TextView

    /** Shows / hides the header: the spacer in the sheet and the floating dots and phrase. */
    private fun headerVis(v: Int) {
        header?.visibility = v
        dots?.visibility = v
        if (header != null) text.visibility = v
    }
    private var ready = false
    private val mainH = android.os.Handler(android.os.Looper.getMainLooper())

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private val stateListener: () -> Unit = {
        if (ready) {
            micBtn?.active = VoiceLoop.state == VoiceLoop.S.LISTENING
            if (VoiceLoop.state == VoiceLoop.S.LISTENING) headerVis(View.VISIBLE)
            when {
                VoiceLoop.state == VoiceLoop.S.LISTENING -> {
                    setViz("LISTENING")
                    text.setTextColor(Hud.TEXT)
                    text.text = "Слушаю…"
                }
                continuousMode && !VoiceLoop.continuous -> finish()
                VoiceLoop.state == VoiceLoop.S.WAITING -> {
                    speechSeen = true
                    setViz("THINKING")
                    text.setTextColor(Hud.AMBER)
                    text.text = "Анализ…"
                }
            }
        }
    }
    private val partialListener: (String) -> Unit = {
        if (ready) {
            if (it.isNotBlank()) speechSeen = true
            text.text = it
        }
    }
    private val logTap: (String) -> Unit = { line ->
        if (ready) {
            val name = Bridge.assistantName.ifEmpty { "JARVIS" } + ": "
            if (line.startsWith(name) || line.startsWith("JARVIS: ")) {
                setViz("SPEAKING")
                text.setTextColor(Hud.CYAN)
                text.text = line.substring(line.indexOf(": ") + 2)
            } else if (line.contains("Нет разрешения") || line.contains("ошибк")) {
                text.setTextColor(Hud.AMBER)
                text.text = line.removePrefix("SYS: ")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!VoiceLoop.hasPermission()) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }
        // make sure the core runs even if the main screen was never opened
        JarvisService.start(this)

        if (continuousMode) {
            if (VoiceLoop.continuous) {
                VoiceLoop.setContinuous(false)
                finish()
                return
            }
            VoiceLoop.setContinuous(true)
        }

        setContentView(if (skin != null) buildGoogle() else buildClassic())
        ready = true

        Bridge.logTaps.add(logTap)
        VoiceLoop.stateListeners.add(stateListener)
        VoiceLoop.partialListeners.add(partialListener)

        if (resultsMode) TvHost.resultsConsumer = consumer
        if (!continuousMode) {
            VoiceLoop.listenOnce { onHeard() }
            armStop(60_000)   // never hang on screen
            mainH.post { armSilence() }
        }
        micBtn?.post { if (!gotResults) micBtn?.requestFocus() }
    }

    private fun buildClassic(): FrameLayout {
        val root = FrameLayout(this)
        val panel = HudPanel(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(24), dp(10))
        }
        val hv = HudView(this)
        core = hv
        panel.addView(hv, LinearLayout.LayoutParams(dp(110), dp(110)))
        text = TextView(this).apply {
            textSize = 22f
            setTextColor(Hud.TEXT)
            this.text = "Слушаю…"
            maxLines = 4
        }
        panel.addView(text, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = dp(14)
        })
        val wrap = FrameLayout(this)
        wrap.addView(panel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        if (oB("mic", true)) {
            panel.setPadding(dp(14), dp(10), Widgets.mic(this, 0, 0).second + dp(26), dp(10))
            addMic(wrap, Hud.TEXT, Hud.CYAN)
        }
        root.addView(
            wrap,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM
            ).apply {
                marginStart = dp(40)
                marginEnd = dp(40)
                bottomMargin = dp(28)
            }
        )
        return root
    }

    // ═══════════════ Google-style sheet ═══════════════
    private fun buildGoogle(): FrameLayout {
        val th = Skin.theme() ?: return buildClassic()
        val dm = resources.displayMetrics
        listMode = getSharedPreferences("overlay_view", MODE_PRIVATE).getBoolean("list", oI("listDefault", 0) == 1)
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.argb((oD("dim", 0.0) * 2.55).toInt().coerceIn(0, 255), 0, 0, 0))
        root.setOnClickListener { VoiceLoop.abort(); finish() }

        val sheet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Skin.roundRect(
                this@OverlayActivity, Skin.color(oS("fill", ""), th.surface), Skin.color(oS("stroke", ""), 0),
                oD("strokeWidth", 0.0).toFloat(), oI("radius", 28)
            )
            setPadding(dp(22), dp(16), dp(22), dp(16))
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header = head
        head.minimumHeight = dp(52)          // keeps the room for the dots and the phrase, which float over it
        val wantDots = oB("dots", true)
        if (wantDots) dots = GoogleDots(this).apply { isClickable = true }
        text = TextView(this).apply {
            isClickable = true
            textSize = oD("textSize", 22.0).toFloat()
            setTextColor(Skin.color(oS("textColor", ""), th.text))
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
            this.text = "Слушаю…"
            maxLines = 4
        }
        sheet.addView(head, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        if (resultsMode) {
            // toolbar: microphone, result counter, tiles / list switch
            val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val cnt = TextView(this).apply {
                textSize = 14f
                setTextColor(th.muted)
                setPadding(dp(12), 0, dp(12), 0)
            }
            countView = cnt
            bar.addView(cnt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val tb = pill("Плитки") { setListMode(false) }
            val lb = pill("Список") { setListMode(true) }
            tilesBtn = tb
            listBtn = lb
            tb.visibility = View.GONE
            lb.visibility = View.GONE
            bar.addView(tb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)).apply { marginEnd = dp(8) })
            bar.addView(lb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)))
            toolbar = bar
            sheet.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) })

            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            strip = row
            val sc = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                visibility = View.GONE
                addView(row)
            }
            stripScroll = sc
            sheet.addView(sc, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) })

            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            listCol = col
            val ls = ScrollView(this).apply {
                isVerticalScrollBarEnabled = false
                visibility = View.GONE
                addView(col)
            }
            listScroll = ls
            sheet.addView(ls, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (dm.heightPixels * 0.5).toInt()).apply { topMargin = dp(10) })
            updateViewButtons()
        }
        val panel = FrameLayout(this)
        panel.addView(sheet, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val fl = Floating(panel, javaClass.simpleName)      // each activity keeps its own positions
        floating = fl
        val panelW = (dm.widthPixels * oD("w", 92.0) / 100.0).toInt()
        val micW = if (oB("mic", true)) Widgets.mic(this, 0, 0).second + dp(8) else 0
        dots?.let { g -> fl.add("dots", g, dp(72), dp(52), { _, _ -> dp(22) }, { _, _ -> dp(16) }) }
        val textX = dp(22) + (if (wantDots) dp(72) + dp(14) else 0)
        fl.add("text", text, (panelW - textX - dp(22) - micW).coerceAtLeast(dp(120)), ViewGroup.LayoutParams.WRAP_CONTENT,
            { _, _ -> textX }, { _, h -> dp(16) + ((dp(52) - h) / 2).coerceAtLeast(0) })
        if (oB("mic", true)) addMic(panel, th.text, th.accent)
        root.addView(
            panel,
            FrameLayout.LayoutParams(
                (dm.widthPixels * oD("w", 92.0) / 100.0).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply { bottomMargin = (dm.heightPixels * oD("bottom", 4.0) / 100.0).toInt() }
        )
        return root
    }

    /** The phrase is over. Search mode closes at once; results modes wait for the answer. */
    private fun onHeard() {
        if (persistent) return
        if (!resultsMode) { finish(); return }
        armStop(25_000)     // no answer at all → close
    }

    /** Microphone button in the results: ask again (a second press stops listening). */
    private fun micClick() {
        mainH.removeCallbacks(hardStop)
        VoiceLoop.listenOnce { onHeard() }
        armSilence()
    }

    /** Microphone button that floats over the panel; drag it anywhere with the mouse, OK on the remote presses it. */
    private fun addMic(panel: FrameLayout, fg: Int, accent: Int) {
        val (mic, s) = Widgets.mic(this, fg, accent)
        micBtn = mic
        mic.setOnClickListener { micClick() }
        val fl = floating ?: Floating(panel, javaClass.simpleName).also { floating = it }
        fl.add("mic", mic, s, s, { w, v -> w - v - dp(14) }, { _, _ -> dp(10) })
    }

    private fun pill(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 14f
        gravity = Gravity.CENTER
        isFocusable = true
        isClickable = true
        setPadding(dp(18), 0, dp(18), 0)
        setOnClickListener { onClick() }
        setOnFocusChangeListener { _, _ -> updateViewButtons() }
    }

    private fun updateViewButtons() {
        val th = Skin.theme() ?: return
        val pairs = listOf(tilesBtn to !listMode, listBtn to listMode)
        for ((b, on) in pairs) {
            if (b == null) continue
            val fill = if (on) th.accent else Hud.withAlpha(th.accent, 0x20)
            b.background = Skin.roundRect(this, fill, if (b.isFocused) th.text else 0, if (b.isFocused) 2f else 0f, 20)
            b.setTextColor(if (on) th.bg else th.text)
        }
    }

    private fun setListMode(list: Boolean) {
        if (listMode == list) return
        listMode = list
        getSharedPreferences("overlay_view", MODE_PRIVATE).edit().putBoolean("list", list).apply()
        renderResults(true)
    }

    private fun showResultsInSheet(title: String, json: String) {
        val sc = stripScroll ?: return
        mainH.removeCallbacks(hardStop)
        gotResults = true
        val arr = try { JSONArray(json) } catch (_: Throwable) { JSONArray() }
        lastItems = arr
        floating?.setSlot(if (arr.length() == 0) "" else "results")      // own mic position once results are in the panel
        if (arr.length() == 0) {
            sc.visibility = View.GONE
            listScroll?.visibility = View.GONE
            tilesBtn?.visibility = View.GONE
            listBtn?.visibility = View.GONE
            countView?.text = ""
            headerVis(View.VISIBLE)
            text.text = if (title.isNotEmpty()) title else "Ничего не найдено"
            armStop(8_000)
            return
        }
        text.text = title
        headerVis(if (overlayMode == "results") View.GONE else View.VISIBLE)
        countView?.text = if (overlayMode == "results" && title.isNotEmpty()) "$title  •  ${arr.length()}" else "Результатов: ${arr.length()}"
        tilesBtn?.visibility = View.VISIBLE
        listBtn?.visibility = View.VISIBLE
        renderResults(true)
        setViz("IDLE")
        armStop(120_000)
    }

    private fun renderResults(focusFirst: Boolean) {
        val sc = stripScroll ?: return
        val row = strip ?: return
        val ls = listScroll ?: return
        val col = listCol ?: return
        row.removeAllViews()
        col.removeAllViews()
        for (i in 0 until lastItems.length()) {
            val item = lastItems.getJSONObject(i)
            if (listMode) {
                col.addView(listRow(i + 1, item), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            } else {
                row.addView(card(i + 1, item), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
        }
        sc.visibility = if (listMode) View.GONE else View.VISIBLE
        ls.visibility = if (listMode) View.VISIBLE else View.GONE
        updateViewButtons()
        if (focusFirst) {
            val host: ViewGroup = if (listMode) col else row
            host.post { host.getChildAt(0)?.requestFocus() }
        }
    }

    private fun skinTheme(): Skin.Theme = Skin.theme() ?: Skin.theme(Skin.Cfg("layout", JSONObject(), JSONObject(), JSONObject()))

    /** Poster with the first letter as a placeholder, the real picture loaded in; number badge in the corner. */
    private fun posterBox(n: Int, item: JSONObject, pw: Int, ph: Int): FrameLayout {
        val th = skinTheme()
        val box = FrameLayout(this)
        box.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(12).toFloat())
            }
        }
        box.clipToOutline = true
        box.setBackgroundColor(Hud.withAlpha(th.accent, 0x30))
        val letter = TextView(this).apply {
            text = item.optString("title").take(1).uppercase()
            textSize = 32f
            setTextColor(th.accent)
            gravity = Gravity.CENTER
        }
        val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        box.addView(letter, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        box.addView(img, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val image = item.optString("image")
        if (image.isNotEmpty()) {
            Posters.load(this, image, pw, ph) { bmp ->
                if (bmp != null) {
                    img.setImageBitmap(bmp)
                    letter.visibility = View.GONE
                }
            }
        }
        if (oB("numbers", true)) box.addView(Badge.make(this, n, th.accent, th.bg), Badge.params(this))
        return box
    }

    private fun card(n: Int, item: JSONObject): View {
        val th = skinTheme()
        val ph = dp(oD("posterH", 150.0).toInt())
        val pw = (ph / oD("posterRatio", 1.5)).toInt()
        val cell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            isFocusable = true
            isClickable = true
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        val focusBg = Skin.roundRect(this, Hud.withAlpha(th.accent, 0x40), th.accent, 2f, 14)
        cell.setOnFocusChangeListener { v, has -> v.background = if (has) focusBg else null }
        cell.setOnClickListener { activate(item) }
        cell.addView(posterBox(n, item, pw, ph), LinearLayout.LayoutParams(pw, ph))
        cell.addView(TextView(this).apply {
            text = item.optString("title")
            textSize = oD("cardTextSize", 13.0).toFloat()
            setTextColor(th.text)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(0, dp(6), 0, 0)
        }, LinearLayout.LayoutParams(pw, ViewGroup.LayoutParams.WRAP_CONTENT))
        val svc = item.optString("app")
        if (svc.isNotEmpty() && oB("showApp", true)) {          // which video service the film is from
            cell.addView(TextView(this).apply {
                text = svc
                textSize = oD("cardTextSize", 13.0).toFloat() - 1f
                setTextColor(th.accent)
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(pw, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        return cell
    }

    private fun listRow(n: Int, item: JSONObject): View {
        val th = skinTheme()
        val ph = dp(oD("listPosterH", 96.0).toInt())
        val pw = (ph / oD("posterRatio", 1.5)).toInt()
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            isFocusable = true
            isClickable = true
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        val focusBg = Skin.roundRect(this, Hud.withAlpha(th.accent, 0x40), th.accent, 2f, 14)
        row.setOnFocusChangeListener { v, has -> v.background = if (has) focusBg else null }
        row.setOnClickListener { activate(item) }
        row.addView(posterBox(n, item, pw, ph), LinearLayout.LayoutParams(pw, ph))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(this).apply {
            text = item.optString("title")
            textSize = oD("cardTextSize", 13.0).toFloat() + 5f
            setTextColor(th.text)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        })
        val meta = listOf(item.optString("year"), item.optString("rating"), if (oB("showApp", true)) item.optString("app") else "")
            .filter { it.isNotEmpty() }.joinToString("  •  ")
        if (meta.isNotEmpty()) {
            col.addView(TextView(this).apply {
                text = meta
                textSize = oD("cardTextSize", 13.0).toFloat() + 1f
                setTextColor(th.accent)
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(3) })
        }
        val sub = item.optString("sub")
        val desc = item.optString("desc").ifEmpty { sub }
        if (desc.isNotEmpty()) {
            col.addView(TextView(this).apply {
                text = desc
                textSize = oD("cardTextSize", 13.0).toFloat() + 1f
                setTextColor(th.muted)
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
        }
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(14) })
        return row
    }

    private fun activate(item: JSONObject) {
        val cmds = item.optJSONArray("cmds")
        val list = ArrayList<String>()
        if (cmds != null) for (i in 0 until cmds.length()) list.add(cmds.getString(i))
        if (list.isEmpty() && item.optString("cmd").isNotEmpty()) list.add(item.optString("cmd"))
        if (list.isEmpty() && (item.optJSONArray("intents")?.length() ?: 0) == 0) {
            android.widget.Toast.makeText(this, "Нет команды для открытия", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        TvHost.openCard(item.optString("title"), item.optJSONArray("intents")?.toString() ?: "[]", list)
        mainH.removeCallbacks(hardStop)
        armStop(120_000)
    }

    override fun onUserInteraction() {
        super.onUserInteraction()
        if (gotResults) {
            mainH.removeCallbacks(hardStop)
            armStop(120_000)
        }
    }

    /** singleTask: a second press of the launcher entry arrives here, not in onCreate. */
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (!ready) return
        if (continuousMode) VoiceLoop.setContinuous(false) else VoiceLoop.abort()
        finish()
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN && e.keyCode == KeyEvent.KEYCODE_BACK) {
            VoiceLoop.abort()
            finish()
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    override fun onDestroy() {
        if (TvHost.resultsConsumer === consumer) TvHost.resultsConsumer = null
        if (ready) {
            Bridge.logTaps.remove(logTap)
            VoiceLoop.stateListeners.remove(stateListener)
            VoiceLoop.partialListeners.remove(partialListener)
            VoiceLoop.cancelOneShot()
        }
        mainH.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
