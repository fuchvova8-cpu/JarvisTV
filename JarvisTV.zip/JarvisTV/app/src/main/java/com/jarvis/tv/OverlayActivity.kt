package com.jarvis.tv

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.ViewGroup
import android.graphics.Color
import android.graphics.Outline
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.HorizontalScrollView
import android.widget.ImageView
import org.json.JSONArray
import org.json.JSONObject
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Translucent strip at the bottom of the screen, for use on top of the TV player or any app.
 * Bind it to a remote button with TV Quick Actions. One phrase, then it closes (Back = cancel).
 */
open class OverlayActivity : Activity() {

    /** true: toggles "microphone always on" and stays while it is on. */
    protected open val continuousMode: Boolean = false

    private var core: HudView? = null

    // ── Google style (skin active): bottom sheet with the four dots, the phrase and a results strip ──
    private val skin: Skin.Cfg? = Skin.fresh()
    private val oc: JSONObject? = skin?.overlay
    private fun oD(k: String, d: Double): Double = oc?.optDouble(k, d) ?: d
    private fun oI(k: String, d: Int): Int = oc?.optInt(k, d) ?: d
    private fun oB(k: String, d: Boolean): Boolean = oc?.optBoolean(k, d) ?: d
    private fun oS(k: String, d: String): String = oc?.optString(k, d) ?: d
    /** "search" = only the query bar; "results" = results replace the bar; "both" = bar and results. */
    private val overlayMode: String get() = if (skin == null) "search" else oS("mode", "search")
    private val resultsMode: Boolean get() = skin != null && overlayMode != "search"
    private var dots: GoogleDots? = null
    private var header: View? = null
    private var stripScroll: HorizontalScrollView? = null
    private var strip: LinearLayout? = null
    private var gotResults = false
    private val hardStop = Runnable { if (!isFinishing) finish() }
    private val consumer: (String, String) -> Boolean = { title, json ->
        runOnUiThread { showResultsInSheet(title, json) }
        true
    }

    private fun setViz(state: String) {
        core?.state = state
        dots?.state = state
    }
    private lateinit var text: TextView
    private var ready = false
    private val mainH = android.os.Handler(android.os.Looper.getMainLooper())

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private val stateListener: () -> Unit = {
        if (ready) {
            when {
                VoiceLoop.state == VoiceLoop.S.LISTENING -> {
                    setViz("LISTENING")
                    text.setTextColor(Hud.TEXT)
                    text.text = "Слушаю…"
                }
                continuousMode && !VoiceLoop.continuous -> finish()
                VoiceLoop.state == VoiceLoop.S.WAITING -> {
                    setViz("THINKING")
                    text.setTextColor(Hud.AMBER)
                    text.text = "Анализ…"
                }
            }
        }
    }
    private val partialListener: (String) -> Unit = { if (ready) text.text = it }
    private val logTap: (String) -> Unit = { line ->
        if (ready) {
            val name = Bridge.assistantName.ifEmpty { "JARVIS" } + ": "
            if (line.startsWith(name) || line.startsWith("JARVIS: ")) {
                setViz("SPEAKING")
                text.setTextColor(Hud.CYAN)
                text.text = line.substring(line.indexOf(": ") + 2)
            } else if (line.contains("Нет разрешения") || line.contains("ошибк")) {
                text.setTextColor(Hud.AMBER)
                text.text = line.removePrefix("SYS: ")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!VoiceLoop.hasPermission()) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }
        // make sure the core runs even if the main screen was never opened
        JarvisService.start(this)

        if (continuousMode) {
            if (VoiceLoop.continuous) {
                VoiceLoop.setContinuous(false)
                finish()
                return
            }
            VoiceLoop.setContinuous(true)
        }

        setContentView(if (skin != null) buildGoogle() else buildClassic())
        ready = true

        Bridge.logTaps.add(logTap)
        VoiceLoop.stateListeners.add(stateListener)
        VoiceLoop.partialListeners.add(partialListener)

        if (resultsMode) TvHost.resultsConsumer = consumer
        if (!continuousMode) {
            VoiceLoop.listenOnce { onHeard() }
            mainH.postDelayed(hardStop, 60_000)   // never hang on screen
        }
    }

    private fun buildClassic(): FrameLayout {
        val root = FrameLayout(this)
        val panel = HudPanel(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(24), dp(10))
        }
        val hv = HudView(this)
        core = hv
        panel.addView(hv, LinearLayout.LayoutParams(dp(110), dp(110)))
        text = TextView(this).apply {
            textSize = 22f
            setTextColor(Hud.TEXT)
            this.text = "Слушаю…"
            maxLines = 4
        }
        panel.addView(text, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = dp(14)
        })
        root.addView(
            panel,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM
            ).apply {
                marginStart = dp(40)
                marginEnd = dp(40)
                bottomMargin = dp(28)
            }
        )
        return root
    }

    // ═══════════════ Google-style sheet ═══════════════
    private fun buildGoogle(): FrameLayout {
        val th = Skin.theme() ?: return buildClassic()
        val dm = resources.displayMetrics
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.argb((oD("dim", 0.0) * 2.55).toInt().coerceIn(0, 255), 0, 0, 0))
        root.setOnClickListener { VoiceLoop.abort(); finish() }

        val sheet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Skin.roundRect(
                this@OverlayActivity, Skin.color(oS("fill", ""), th.surface), Skin.color(oS("stroke", ""), 0),
                oD("strokeWidth", 0.0).toFloat(), oI("radius", 28)
            )
            setPadding(dp(22), dp(16), dp(22), dp(16))
            elevation = dp(12).toFloat()
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header = head
        if (oB("dots", true)) {
            val g = GoogleDots(this)
            dots = g
            head.addView(g, LinearLayout.LayoutParams(dp(72), dp(52)))
        }
        text = TextView(this).apply {
            textSize = oD("textSize", 22.0).toFloat()
            setTextColor(Skin.color(oS("textColor", ""), th.text))
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
            this.text = "Слушаю…"
            maxLines = 4
        }
        head.addView(text, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(14) })
        sheet.addView(head, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        if (resultsMode) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            strip = row
            val sc = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                visibility = View.GONE
                addView(row)
            }
            stripScroll = sc
            sheet.addView(sc, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(14) })
        }
        root.addView(
            sheet,
            FrameLayout.LayoutParams(
                (dm.widthPixels * oD("w", 92.0) / 100.0).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply { bottomMargin = (dm.heightPixels * oD("bottom", 4.0) / 100.0).toInt() }
        )
        return root
    }

    /** The phrase is over. Search mode closes at once; results modes wait for the answer. */
    private fun onHeard() {
        if (!resultsMode) { finish(); return }
        mainH.postDelayed(hardStop, 25_000)     // no answer at all → close
    }

    private fun showResultsInSheet(title: String, json: String) {
        val sc = stripScroll ?: return
        val row = strip ?: return
        mainH.removeCallbacks(hardStop)
        gotResults = true
        row.removeAllViews()
        val arr = try { JSONArray(json) } catch (_: Throwable) { JSONArray() }
        if (arr.length() == 0) {
            sc.visibility = View.GONE
            header?.visibility = View.VISIBLE
            text.text = if (title.isNotEmpty()) title else "Ничего не найдено"
            mainH.postDelayed(hardStop, 8_000)
            return
        }
        text.text = title
        header?.visibility = if (overlayMode == "results") View.GONE else View.VISIBLE
        for (i in 0 until arr.length()) {
            val c = card(arr.getJSONObject(i))
            row.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        sc.visibility = View.VISIBLE
        setViz("IDLE")
        sc.post { row.getChildAt(0)?.requestFocus() }
        mainH.postDelayed(hardStop, 120_000)
    }

    private fun card(item: JSONObject): View {
        val th = Skin.theme() ?: Skin.theme(Skin.Cfg("layout", JSONObject(), JSONObject(), JSONObject()))
        val ph = dp(oD("posterH", 150.0).toInt())
        val pw = (ph / oD("posterRatio", 1.5)).toInt()
        val cell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            isFocusable = true
            isClickable = true
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        val focusBg = Skin.roundRect(this, Hud.withAlpha(th.accent, 0x40), th.accent, 2f, 14)
        cell.setOnFocusChangeListener { v, has -> v.background = if (has) focusBg else null }
        cell.setOnClickListener { activate(item) }
        val box = FrameLayout(this)
        box.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(12).toFloat())
            }
        }
        box.clipToOutline = true
        box.setBackgroundColor(Hud.withAlpha(th.accent, 0x30))
        val letter = TextView(this).apply {
            text = item.optString("title").take(1).uppercase()
            textSize = 32f
            setTextColor(th.accent)
            gravity = Gravity.CENTER
        }
        val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        box.addView(letter, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        box.addView(img, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val image = item.optString("image")
        if (image.isNotEmpty()) {
            Posters.load(this, image, pw, ph) { bmp ->
                if (bmp != null) {
                    img.setImageBitmap(bmp)
                    letter.visibility = View.GONE
                }
            }
        }
        cell.addView(box, LinearLayout.LayoutParams(pw, ph))
        cell.addView(TextView(this).apply {
            text = item.optString("title")
            textSize = oD("cardTextSize", 13.0).toFloat()
            setTextColor(th.text)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(0, dp(6), 0, 0)
        }, LinearLayout.LayoutParams(pw, ViewGroup.LayoutParams.WRAP_CONTENT))
        return cell
    }

    private fun activate(item: JSONObject) {
        val cmds = item.optJSONArray("cmds")
        val list = ArrayList<String>()
        if (cmds != null) for (i in 0 until cmds.length()) list.add(cmds.getString(i))
        if (list.isEmpty() && item.optString("cmd").isNotEmpty()) list.add(item.optString("cmd"))
        if (list.isEmpty() && (item.optJSONArray("intents")?.length() ?: 0) == 0) {
            android.widget.Toast.makeText(this, "Нет команды для открытия", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        TvHost.openCard(item.optString("title"), item.optJSONArray("intents")?.toString() ?: "[]", list)
        mainH.removeCallbacks(hardStop)
        mainH.postDelayed(hardStop, 120_000)
    }

    override fun onUserInteraction() {
        super.onUserInteraction()
        if (gotResults) {
            mainH.removeCallbacks(hardStop)
            mainH.postDelayed(hardStop, 120_000)
        }
    }

    /** singleTask: a second press of the launcher entry arrives here, not in onCreate. */
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (!ready) return
        if (continuousMode) VoiceLoop.setContinuous(false) else VoiceLoop.abort()
        finish()
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN && e.keyCode == KeyEvent.KEYCODE_BACK) {
            VoiceLoop.abort()
            finish()
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    override fun onDestroy() {
        if (TvHost.resultsConsumer === consumer) TvHost.resultsConsumer = null
        if (ready) {
            Bridge.logTaps.remove(logTap)
            VoiceLoop.stateListeners.remove(stateListener)
            VoiceLoop.partialListeners.remove(partialListener)
            VoiceLoop.cancelOneShot()
        }
        mainH.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
