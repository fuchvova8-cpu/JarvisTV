package com.jarvis.tv

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Translucent strip at the bottom of the screen, for use on top of the TV player or any app.
 * Bind it to a remote button with TV Quick Actions. One phrase, then it closes (Back = cancel).
 */
open class OverlayActivity : Activity() {

    /** true: toggles "microphone always on" and stays while it is on. */
    protected open val continuousMode: Boolean = false

    private lateinit var core: HudView
    private lateinit var text: TextView
    private var ready = false
    private val mainH = android.os.Handler(android.os.Looper.getMainLooper())

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private val stateListener: () -> Unit = {
        if (ready) {
            when {
                VoiceLoop.state == VoiceLoop.S.LISTENING -> {
                    core.state = "LISTENING"
                    text.setTextColor(Hud.TEXT)
                    text.text = "Слушаю…"
                }
                continuousMode && !VoiceLoop.continuous -> finish()
                VoiceLoop.state == VoiceLoop.S.WAITING -> {
                    core.state = "THINKING"
                    text.setTextColor(Hud.AMBER)
                    text.text = "Анализ…"
                }
            }
        }
    }
    private val partialListener: (String) -> Unit = { if (ready) text.text = it }
    private val logTap: (String) -> Unit = { line ->
        if (ready) {
            val name = Bridge.assistantName.ifEmpty { "JARVIS" } + ": "
            if (line.startsWith(name) || line.startsWith("JARVIS: ")) {
                core.state = "SPEAKING"
                text.setTextColor(Hud.CYAN)
                text.text = line.substring(line.indexOf(": ") + 2)
            } else if (line.contains("Нет разрешения") || line.contains("ошибк")) {
                text.setTextColor(Hud.AMBER)
                text.text = line.removePrefix("SYS: ")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!VoiceLoop.hasPermission()) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }
        // make sure the core runs even if the main screen was never opened
        JarvisService.start(this)

        if (continuousMode) {
            if (VoiceLoop.continuous) {
                VoiceLoop.setContinuous(false)
                finish()
                return
            }
            VoiceLoop.setContinuous(true)
        }

        val root = FrameLayout(this)
        val panel = HudPanel(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(24), dp(10))
        }
        core = HudView(this)
        panel.addView(core, LinearLayout.LayoutParams(dp(110), dp(110)))
        text = TextView(this).apply {
            textSize = 22f
            setTextColor(Hud.TEXT)
            this.text = "Слушаю…"
            maxLines = 4
        }
        panel.addView(text, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = dp(14)
        })
        root.addView(
            panel,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM
            ).apply {
                marginStart = dp(40)
                marginEnd = dp(40)
                bottomMargin = dp(28)
            }
        )
        setContentView(root)
        ready = true

        Bridge.logTaps.add(logTap)
        VoiceLoop.stateListeners.add(stateListener)
        VoiceLoop.partialListeners.add(partialListener)

        if (!continuousMode) {
            VoiceLoop.listenOnce { finish() }
            mainH.postDelayed({ if (!isFinishing) finish() }, 60_000)   // never hang on screen
        }
    }

    /** singleTask: a second press of the launcher entry arrives here, not in onCreate. */
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (!ready) return
        if (continuousMode) VoiceLoop.setContinuous(false) else VoiceLoop.abort()
        finish()
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN && e.keyCode == KeyEvent.KEYCODE_BACK) {
            VoiceLoop.abort()
            finish()
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    override fun onDestroy() {
        if (ready) {
            Bridge.logTaps.remove(logTap)
            VoiceLoop.stateListeners.remove(stateListener)
            VoiceLoop.partialListeners.remove(partialListener)
            VoiceLoop.cancelOneShot()
        }
        mainH.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
