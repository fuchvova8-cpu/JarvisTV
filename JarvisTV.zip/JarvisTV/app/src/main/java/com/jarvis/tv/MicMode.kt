package com.jarvis.tv

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import java.util.concurrent.CopyOnWriteArrayList

/**
 * How the microphone is used. Two modes (the choice is remembered):
 *  - PTT  ("по кнопке", default): press the voice button, say one phrase (system recognizer), the mic is
 *    released, JARVIS answers, press again. Our own capture never runs.
 *  - LIVE ("постоянно"): our capture listens all the time (MicHub renews it by itself before the TV cuts it),
 *    and it can be switched on/off without leaving the mode.
 * Everything here runs on the main thread (menu, hidden quick-action activities).
 */
object MicMode {
    enum class Mode { PTT, LIVE }

    @Volatile var mode: Mode = Mode.PTT
        private set
    @Volatile var liveOn: Boolean = true
        private set

    val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val main = Handler(Looper.getMainLooper())

    /** Our own capture stays released (MicHub reads this through Bridge.micFree). */
    val captureOff: Boolean get() = mode == Mode.PTT || !liveOn

    private fun prefs() = Bridge.app.getSharedPreferences("mic_mode", Context.MODE_PRIVATE)

    fun load() {
        try {
            val p = prefs()
            mode = if (p.getString("mode", "ptt") == "live") Mode.LIVE else Mode.PTT
            liveOn = p.getBoolean("live_on", true)
        } catch (_: Throwable) {}
    }

    private fun save() {
        try { prefs().edit().putString("mode", if (mode == Mode.LIVE) "live" else "ptt").putBoolean("live_on", liveOn).apply() }
        catch (_: Throwable) {}
    }

    fun label(): String = when {
        mode == Mode.PTT -> "по кнопке"
        liveOn -> "постоянно, слушает"
        else -> "постоянно, ВЫКЛЮЧЕН"
    }

    private fun announce(text: String) {
        Diag.log("MIC", "mode: $text")
        Bridge.log("SYS: Микрофон: $text")
        main.post { try { Toast.makeText(Bridge.app, "JARVIS: микрофон — $text", Toast.LENGTH_SHORT).show() } catch (_: Throwable) {} }
        for (l in listeners) l()
    }

    private fun stopRecognizer() {
        if (VoiceLoop.state != VoiceLoop.S.IDLE || VoiceLoop.continuous) VoiceLoop.abort()
    }

    fun setMode(m: Mode) {
        mode = m
        if (m == Mode.LIVE) liveOn = true
        save()
        stopRecognizer()
        announce(if (m == Mode.PTT) "по кнопке (нажали — сказали — микрофон отключился)" else "постоянный, слушает")
    }

    fun toggleMode() = setMode(if (mode == Mode.PTT) Mode.LIVE else Mode.PTT)

    /** On: switches to LIVE if needed. Off: keeps the mode, just stops listening. */
    fun setLiveOn(on: Boolean) {
        if (on) { mode = Mode.LIVE; liveOn = true; stopRecognizer() } else liveOn = false
        save()
        announce(if (!on) "постоянное прослушивание ВЫКЛЮЧЕНО" else "постоянное прослушивание ВКЛЮЧЕНО")
    }

    fun toggleLiveOn() = setLiveOn(if (mode == Mode.PTT) true else !liveOn)
}
