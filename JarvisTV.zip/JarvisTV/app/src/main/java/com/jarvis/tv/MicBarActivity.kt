package com.jarvis.tv

/** Same bottom strip, separate launcher entry with its own task (the main window is not brought forward). */
class MicBarActivity : OverlayActivity() {
    /** The strip stays after the answer, so the microphone can be pressed again without calling it up anew. */
    override val stayOpen: Boolean = true
}
