package com.jarvis.tv

/**
 * Same bottom strip, separate launcher entry with its own task (the main window is not brought forward).
 * It stays on the screen all the time (no timers, no hiding on silence) — for the microphone that works in the background.
 */
class MicBarActivity : OverlayActivity() {
    override val persistent: Boolean = true
}
