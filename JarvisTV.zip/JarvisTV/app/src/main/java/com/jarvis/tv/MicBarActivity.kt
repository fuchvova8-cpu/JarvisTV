package com.jarvis.tv

/** Same bottom strip, separate launcher entry with its own task (the main window is not brought forward). */
class MicBarActivity : OverlayActivity()
