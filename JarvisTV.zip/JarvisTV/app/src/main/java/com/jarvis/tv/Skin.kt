package com.jarvis.tv

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import org.json.JSONObject
import java.io.File

/**
 * Screen skin, written by a plugin (screen_style.py) as plugin_data/screen_layout.json and read here.
 *
 *   {"mode": "off" | "layout" | "frame",
 *    "theme":   {"bg","surface","focus","text","muted","accent","radius"},
 *    "main":    {"<element id>": {visible, x, y, w, h, radius, fill, stroke, strokeWidth,
 *                                 textColor, textSize, textScale, bold}},
 *    "results": {x, y, w, h, columns, posterRatio, ... see ResultsActivity}}
 *
 * x, y, w, h are percent of the screen (w/h = 0 → wrap content). "off" (or no file) keeps the classic
 * screen exactly as it was. "frame" additionally shows a full-screen picture the plugin renders
 * (Bridge.bgFrame) behind everything. Nothing here is Jarvis logic: it only moves and paints views.
 */
object Skin {
    class Cfg(val mode: String, val theme: JSONObject, val main: JSONObject, val results: JSONObject)

    class Theme(
        val bg: Int, val surface: Int, val focus: Int, val text: Int,
        val muted: Int, val accent: Int, val radius: Int
    )

    private fun file(): File =
        File(File(AssetInstaller.targetDir(Bridge.app), "plugin_data"), "screen_layout.json")

    /** Changes whenever the plugin saves; MainActivity rebuilds itself when it differs. */
    fun signature(): Long = try { file().lastModified() } catch (_: Throwable) { 0L }

    fun load(): Cfg? {
        return try {
            val f = file()
            if (!f.exists()) return null
            val o = JSONObject(f.readText())
            val mode = o.optString("mode", "off")
            if (mode == "off") return null
            Cfg(
                mode,
                o.optJSONObject("theme") ?: JSONObject(),
                o.optJSONObject("main") ?: JSONObject(),
                o.optJSONObject("results") ?: JSONObject()
            )
        } catch (t: Throwable) {
            Bridge.log("SYS: screen_layout.json: ${t.message}")
            null
        }
    }

    fun color(s: String?, def: Int): Int {
        if (s.isNullOrBlank()) return def
        return try { Color.parseColor(s.trim()) } catch (_: Throwable) { def }
    }

    fun theme(c: Cfg): Theme {
        val t = c.theme
        return Theme(
            bg = color(t.optString("bg"), 0xFF202124.toInt()),
            surface = color(t.optString("surface"), 0xFF2D2E31.toInt()),
            focus = color(t.optString("focus"), 0xFF3C4043.toInt()),
            text = color(t.optString("text"), 0xFFE8EAED.toInt()),
            muted = color(t.optString("muted"), 0xFF9AA0A6.toInt()),
            accent = color(t.optString("accent"), 0xFF8AB4F8.toInt()),
            radius = t.optInt("radius", 20)
        )
    }

    private fun dp(ctx: Context, v: Float): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun roundRect(ctx: Context, fill: Int, stroke: Int, strokeDp: Float, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = if (radiusDp < 0) dp(ctx, 999f).toFloat() else dp(ctx, radiusDp.toFloat()).toFloat()
            if (strokeDp > 0f && Color.alpha(stroke) > 0) setStroke(maxOf(1, dp(ctx, strokeDp)), stroke)
        }

    /** Pill button: tonal surface, accent ring when focused (Google TV look). */
    fun styleButton(tv: TextView, th: Theme, e: JSONObject?) {
        val ctx = tv.context
        val radius = e?.optInt("radius", -1) ?: -1
        val fill = color(e?.optString("fill"), th.surface)
        val stroke = color(e?.optString("stroke"), 0)
        val sw = (e?.optDouble("strokeWidth", 0.0) ?: 0.0).toFloat()
        val focusFill = Color.argb(0x40, Color.red(th.accent), Color.green(th.accent), Color.blue(th.accent))
        val st = StateListDrawable()
        st.addState(intArrayOf(android.R.attr.state_focused), roundRect(ctx, focusFill, th.accent, 3f, radius))
        st.addState(intArrayOf(android.R.attr.state_pressed), roundRect(ctx, th.focus, th.accent, 2f, radius))
        st.addState(intArrayOf(), roundRect(ctx, fill, stroke, sw, radius))
        tv.background = st
        tv.setTextColor(color(e?.optString("textColor"), th.text))
        tv.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        tv.gravity = Gravity.CENTER
        tv.setPadding(dp(ctx, 12f), dp(ctx, 4f), dp(ctx, 12f), dp(ctx, 4f))
        tv.isAllCaps = false
        tv.letterSpacing = 0f
    }

    private fun scaleText(v: View, k: Float) {
        if (k == 1f || k <= 0f) return
        if (v is TextView) v.setTextSize(TypedValue.COMPLEX_UNIT_PX, v.textSize * k)
        if (v is ViewGroup) for (i in 0 until v.childCount) scaleText(v.getChildAt(i), k)
    }

    private fun recolor(v: View, c: Int) {
        if (v is TextView) v.setTextColor(c)
        if (v is ViewGroup) for (i in 0 until v.childCount) recolor(v.getChildAt(i), c)
    }

    /**
     * Rearranges the freshly built main screen. [views] are the movable elements by id, [panels] the
     * LinearLayout rows they were first placed in (hidden once empty), [accents]/[bodies] the texts
     * that take the theme's accent / body colour.
     */
    fun applyMain(
        act: Activity, root: FrameLayout, views: Map<String, View>, panels: List<View>,
        accents: List<TextView>, bodies: List<TextView>, bg: View?
    ) {
        val cfg = load() ?: return
        val th = theme(cfg)
        val dm = act.resources.displayMetrics
        val sw = dm.widthPixels
        val sh = dm.heightPixels
        root.setBackgroundColor(th.bg)
        for (t in accents) t.setTextColor(th.accent)
        for (t in bodies) t.setTextColor(th.text)
        (views["hud"] as? HudView)?.transparent = true

        for ((id, v) in views) {
            val e = cfg.main.optJSONObject(id) ?: continue
            (v.parent as? ViewGroup)?.removeView(v)
            if (!e.optBoolean("visible", true)) continue

            val w = e.optDouble("w", 0.0)
            val h = e.optDouble("h", 0.0)
            val lp = FrameLayout.LayoutParams(
                if (w > 0) (sw * w / 100.0).toInt() else ViewGroup.LayoutParams.WRAP_CONTENT,
                if (h > 0) (sh * h / 100.0).toInt() else ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.START
            )
            lp.leftMargin = (sw * e.optDouble("x", 0.0) / 100.0).toInt()
            lp.topMargin = (sh * e.optDouble("y", 0.0) / 100.0).toInt()
            root.addView(v, lp)

            val tsize = e.optDouble("textSize", 0.0).toFloat()
            val scale = e.optDouble("textScale", 1.0).toFloat()
            val bold = e.optBoolean("bold", false)
            when {
                v is Button -> {
                    styleButton(v, th, e)
                    if (tsize > 0f) v.textSize = tsize
                }
                v is EditText -> {
                    val r = e.optInt("radius", -1)
                    v.background = roundRect(act, color(e.optString("fill"), th.surface),
                        color(e.optString("stroke"), 0), e.optDouble("strokeWidth", 0.0).toFloat(), r)
                    v.setTextColor(color(e.optString("textColor"), th.text))
                    v.setHintTextColor(th.muted)
                    if (tsize > 0f) v.textSize = tsize
                    v.setPadding(dp(act, 22f), dp(act, 6f), dp(act, 22f), dp(act, 6f))
                }
                v is HudView -> Unit
                v is TextView -> {
                    v.setTextColor(color(e.optString("textColor"), if (id == "name") th.accent else th.muted))
                    if (tsize > 0f) v.textSize = tsize
                    v.typeface = Typeface.create(if (bold) "sans-serif-medium" else "sans-serif", Typeface.NORMAL)
                }
                v is ViewGroup -> {          // log, content, confirm, quiz
                    val r = e.optInt("radius", th.radius)
                    v.background = roundRect(act, color(e.optString("fill"), th.surface),
                        color(e.optString("stroke"), 0), e.optDouble("strokeWidth", 0.0).toFloat(), r)
                    val tc = e.optString("textColor")
                    if (tc.isNotBlank()) recolor(v, color(tc, th.text))
                    scaleText(v, scale)
                }
            }
        }
        for (p in panels) if (p is ViewGroup && p.childCount == 0) p.visibility = View.GONE
        bg?.visibility = if (cfg.mode == "frame") View.VISIBLE else View.GONE
    }
}

/** Full-screen picture drawn by a plugin (Bridge.bgBitmap), behind every other element. */
class BgFrameView(ctx: Context) : View(ctx) {
    private val src = Rect()
    private val dst = Rect()
    private val paint = android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG)

    override fun onDraw(c: android.graphics.Canvas) {
        val b: Bitmap? = Bridge.bgBitmap
        if (b != null) {
            src.set(0, 0, b.width, b.height)
            dst.set(0, 0, width, height)
            c.drawBitmap(b, src, dst, paint)
            postInvalidateDelayed(50)
        } else {
            postInvalidateDelayed(300)
        }
    }
}
