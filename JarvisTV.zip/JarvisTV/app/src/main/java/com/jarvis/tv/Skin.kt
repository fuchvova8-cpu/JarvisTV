package com.jarvis.tv

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import org.json.JSONObject
import java.io.File

/**
 * Screen skin, written by a plugin (screen_style.py) as plugin_data/screen_layout.json and read here.
 *
 *   {"mode": "off" | "layout" | "frame",
 *    "theme":   {"bg","surface","focus","text","muted","accent","radius"},
 *    "main":    {"<element id>": {visible, x, y, w, h, radius, fill, stroke, strokeWidth,
 *                                 textColor, textSize, textScale, bold}},
 *    "results": {x, y, w, h, columns, posterRatio, ... see ResultsActivity}}
 *
 * x, y, w, h are percent of the screen (w/h = 0 → wrap content). "off" (or no file) keeps the classic
 * screen exactly as it was. "frame" additionally shows a full-screen picture the plugin renders
 * (Bridge.bgFrame) behind everything. Nothing here is Jarvis logic: it only moves and paints views.
 */
object Skin {
    class Cfg(
        val mode: String, val theme: JSONObject, val main: JSONObject, val results: JSONObject,
        val overlay: JSONObject = JSONObject(), val edit: Boolean = false
    )

    class Theme(
        val bg: Int, val surface: Int, val focus: Int, val text: Int,
        val muted: Int, val accent: Int, val radius: Int
    )

    private fun file(): File =
        File(File(AssetInstaller.targetDir(Bridge.app), "plugin_data"), "screen_layout.json")

    private var cSig = -1L
    private var cAt = 0L
    private var cCfg: Cfg? = null
    private var cTheme: Theme? = null

    /** Parsed skin, re-read (at most every 300 ms) when the file changed; null = classic look. */
    @Synchronized
    fun current(): Cfg? {
        val now = System.currentTimeMillis()
        if (now - cAt > 300) {
            cAt = now
            val sig = signature()
            if (sig != cSig) {
                cSig = sig
                cCfg = load()
                cTheme = cCfg?.let { theme(it) }
            }
        }
        return cCfg
    }

    /** Forget the cached skin (call right after this app itself rewrote the file). */
    @Synchronized fun invalidate() { cAt = 0L; cSig = -1L }

    /** Freshly read skin (used when a screen is being built). */
    fun fresh(): Cfg? { invalidate(); return current() }

    /** Turns the layout editor on/off in the file. False when the plugin has not written a usable layout yet. */
    fun setEdit(on: Boolean): Boolean {
        return try {
            val f = file()
            if (!f.exists()) return false
            val o = JSONObject(f.readText())
            val m = o.optJSONObject("main")
            if (m == null || m.length() == 0) return false
                        o.put("edit", on)
            f.writeText(o.toString(1))
            invalidate()
            true
        } catch (t: Throwable) {
            Bridge.log("SYS: редактор экрана: ${t.message}")
            false
        }
    }

    /** Approximate geometry (percent of the screen) of the classic main screen, so the editor can start from it. */
    fun classicDefault(id: String): JSONObject? {
        val r = when (id) {
            "hud" -> doubleArrayOf(0.0, 0.0, 100.0, 100.0)
            "name" -> doubleArrayOf(3.5, 3.5, 0.0, 0.0)
            "state" -> doubleArrayOf(45.0, 4.0, 0.0, 0.0)
            "clock" -> doubleArrayOf(91.0, 3.5, 0.0, 0.0)
            "log" -> doubleArrayOf(2.3, 14.6, 36.0, 65.6)
            "content" -> doubleArrayOf(67.7, 14.6, 30.0, 65.6)
            "input" -> doubleArrayOf(2.3, 86.0, 34.0, 11.0)
            "btn_send" -> doubleArrayOf(37.5, 86.0, 8.0, 11.0)
            "btn_voice" -> doubleArrayOf(46.0, 86.0, 6.5, 11.0)
            "btn_mute" -> doubleArrayOf(53.0, 86.0, 11.0, 11.0)
            "btn_stop" -> doubleArrayOf(65.0, 86.0, 6.0, 11.0)
            "btn_results" -> doubleArrayOf(71.5, 86.0, 9.0, 11.0)
            "btn_plugins" -> doubleArrayOf(81.0, 86.0, 8.0, 11.0)
            "btn_menu" -> doubleArrayOf(89.5, 86.0, 8.0, 11.0)
            "confirm" -> doubleArrayOf(22.5, 36.0, 55.0, 0.0)
            "quiz" -> doubleArrayOf(19.0, 18.0, 62.0, 0.0)
            else -> return null
        }
        return JSONObject().put("visible", true).put("x", r[0]).put("y", r[1]).put("w", r[2]).put("h", r[3])
    }

    /** Stores a rectangle the editor produced (percent of the screen). w/h only when the element was resized. */
    fun saveRect(id: String, x: Double, y: Double, w: Double?, h: Double?): Long {
        return try {
            val f = file()
            val o = JSONObject(f.readText())
            val m = o.optJSONObject("main") ?: JSONObject().also { o.put("main", it) }
            val e = m.optJSONObject(id) ?: JSONObject().also { m.put(id, it) }
            if (o.optString("mode", "off") == "off" && !e.optBoolean("custom") && !id.startsWith("mb_")) {
                // classic look: the element becomes "custom" and keeps its classic size unless it was resized
                classicDefault(id)?.let { d -> for (k in listOf("visible", "w", "h")) if (!e.has(k) || k == "w" || k == "h") e.put(k, d.get(k)) }
            }
            e.put("custom", true)
            e.put("x", Math.round(x * 10.0) / 10.0)
            e.put("y", Math.round(y * 10.0) / 10.0)
            if (w != null) e.put("w", Math.round(w * 10.0) / 10.0)
            if (h != null) e.put("h", Math.round(h * 10.0) / 10.0)
            f.writeText(o.toString(1))
            invalidate()
            f.lastModified()
        } catch (t: Throwable) {
            Bridge.log("SYS: не удалось сохранить положение: ${t.message}")
            signature()
        }
    }

    /** Colours of the active skin, or null when the classic look is on. */
    fun theme(): Theme? { current(); return cTheme }

    /** Changes whenever the plugin saves; MainActivity rebuilds itself when it differs. */
    fun signature(): Long {
        val m = try { file().lastModified() } catch (_: Throwable) { 0L }
        if (m != 0L && m == selfMt && lastSig != 0L) return lastSig      // only the video window moved: no rebuild needed
        lastSig = m
        return m
    }

    @Volatile private var selfMt = 0L
    @Volatile private var lastSig = 0L

    fun fileMt(): Long = try { file().lastModified() } catch (_: Throwable) { 0L }

    /** Whether a service-menu or plugin-settings shortcut is present on the home screen. */
    fun menuItemPinned(key: String): Boolean = try {
        val main = JSONObject(file().readText()).optJSONObject("main")
        main?.has("mb_$key") == true
    } catch (_: Throwable) { false }

    /** The "video" part of the layout file (read even when the skin mode is off). */
    fun videoCfg(): JSONObject = try {
        val f = file()
        if (!f.exists()) JSONObject() else JSONObject(f.readText()).optJSONObject("video") ?: JSONObject()
    } catch (_: Throwable) { JSONObject() }

    /** The "widgets" part of the layout file: look of the microphone, result numbers and results-window buttons. */
    fun widgets(): JSONObject = try {
        val f = file()
        if (!f.exists()) JSONObject() else JSONObject(f.readText()).optJSONObject("widgets") ?: JSONObject()
    } catch (_: Throwable) { JSONObject() }

    /** Where a floating button was left (fractions of its panel), key like "OverlayActivity.mic". */
    fun floatPos(id: String): FloatArray? = try {
        val f = file()
        if (!f.exists()) null else {
            val a = JSONObject(f.readText()).optJSONObject("pos")?.optJSONArray(id)
            if (a != null && a.length() >= 2) floatArrayOf(a.getDouble(0).toFloat(), a.getDouble(1).toFloat()) else null
        }
    } catch (_: Throwable) { null }

    fun saveFloatPos(id: String, fx: Float, fy: Float) {
        try {
            val f = file()
            val o = if (f.exists()) JSONObject(f.readText()) else JSONObject().put("mode", "off")
            val pos = o.optJSONObject("pos") ?: JSONObject().also { o.put("pos", it) }
            pos.put(id, org.json.JSONArray().put(fx.toDouble()).put(fy.toDouble()))
            f.parentFile?.mkdirs()
            f.writeText(o.toString(1))
            selfMt = f.lastModified()
        } catch (t: Throwable) {
            Bridge.log("SYS: не удалось сохранить положение кнопки: ${t.message}")
        }
    }

    /** Window position and size in % of the screen, written when the user drags / resizes the video window. */
    fun saveVideo(x: Double, y: Double, w: Double, h: Double) {
        try {
            val f = file()
            val o = if (f.exists()) JSONObject(f.readText()) else JSONObject().put("mode", "off")
            val v = o.optJSONObject("video") ?: JSONObject().also { o.put("video", it) }
            if (!v.has("mode")) v.put("mode", "window")
            v.put("x", Math.round(x * 10.0) / 10.0)
            v.put("y", Math.round(y * 10.0) / 10.0)
            v.put("w", Math.round(w * 10.0) / 10.0)
            v.put("h", Math.round(h * 10.0) / 10.0)
            f.parentFile?.mkdirs()
            f.writeText(o.toString(1))
            selfMt = f.lastModified()
        } catch (t: Throwable) {
            Bridge.log("SYS: не удалось сохранить окно видео: ${t.message}")
        }
    }

    /**
     * [allowOff] = true also returns the file for mode "off" (classic look). Only the main screen uses that, to place
     * the menu buttons the user pinned and to run the editor without switching to the Google style.
     */
    fun load(allowOff: Boolean = false): Cfg? {
        return try {
            val f = file()
            if (!f.exists()) return null
            val o = JSONObject(f.readText())
            val mode = o.optString("mode", "off")
            if (mode == "off" && !allowOff) return null
            Cfg(
                mode,
                o.optJSONObject("theme") ?: JSONObject(),
                o.optJSONObject("main") ?: JSONObject(),
                o.optJSONObject("results") ?: JSONObject(),
                o.optJSONObject("overlay") ?: JSONObject(),
                o.optBoolean("edit", false)
            )
        } catch (t: Throwable) {
            Bridge.log("SYS: screen_layout.json: ${t.message}")
            null
        }
    }

    fun color(s: String?, def: Int): Int {
        if (s.isNullOrBlank()) return def
        return try { Color.parseColor(s.trim()) } catch (_: Throwable) { def }
    }

    fun theme(c: Cfg): Theme {
        val t = c.theme
        return Theme(
            bg = color(t.optString("bg"), 0xFF202124.toInt()),
            surface = color(t.optString("surface"), 0xFF2D2E31.toInt()),
            focus = color(t.optString("focus"), 0xFF3C4043.toInt()),
            text = color(t.optString("text"), 0xFFE8EAED.toInt()),
            muted = color(t.optString("muted"), 0xFF9AA0A6.toInt()),
            accent = color(t.optString("accent"), 0xFF8AB4F8.toInt()),
            radius = t.optInt("radius", 20)
        )
    }

    // ── dialogs (the Service menu and everything under it) ──
    fun showStyled(d: android.app.Dialog): android.app.Dialog {
        d.show()
        styleDialog(d)
        return d
    }

    fun styleDialog(d: android.app.Dialog) {
        val th = theme() ?: return
        val win = d.window ?: return
        win.setBackgroundDrawable(roundRect(d.context, th.surface, 0, 0f, th.radius))
        val titleId = d.context.resources.getIdentifier("alertTitle", "id", "android")
        restyle(win.decorView, th, titleId)
    }

    private fun restyle(v: View, th: Theme, titleId: Int) {
        when (v) {
            is Button -> styleButton(v, th, null)
            is EditText -> {
                v.setTextColor(th.text)
                v.setHintTextColor(th.muted)
                v.background = roundRect(v.context, th.bg, th.focus, 1f, 12)
            }
            is TextView -> v.setTextColor(if (titleId != 0 && v.id == titleId) th.accent else th.text)
            is android.widget.ListView -> {
                v.divider = android.graphics.drawable.ColorDrawable(th.focus)
                v.dividerHeight = 1
                v.selector = roundRect(v.context, Color.argb(0x40, Color.red(th.accent), Color.green(th.accent), Color.blue(th.accent)), th.accent, 2f, 12)
                v.setOnHierarchyChangeListener(object : ViewGroup.OnHierarchyChangeListener {
                    override fun onChildViewAdded(parent: View?, child: View?) { if (child != null) styleListRow(child, th) }
                    override fun onChildViewRemoved(parent: View?, child: View?) {}
                })
                for (i in 0 until v.childCount) styleListRow(v.getChildAt(i), th)
            }
        }
        if (v is ViewGroup) for (i in 0 until v.childCount) restyle(v.getChildAt(i), th, titleId)
    }

    private fun styleListRow(v: View, th: Theme) {
        if (v is TextView) {
            v.textSize = 16f
            v.setTextColor(th.text)
            v.minHeight = dp(v.context, 48f)
            v.setPadding(dp(v.context, 18f), dp(v.context, 10f), dp(v.context, 18f), dp(v.context, 10f))
            v.gravity = Gravity.CENTER_VERTICAL or Gravity.START
            v.letterSpacing = 0f
        }
        if (v is ViewGroup) for (i in 0 until v.childCount) styleListRow(v.getChildAt(i), th)
    }

    private fun dp(ctx: Context, v: Float): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun roundRect(ctx: Context, fill: Int, stroke: Int, strokeDp: Float, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = if (radiusDp < 0) dp(ctx, 999f).toFloat() else dp(ctx, radiusDp.toFloat()).toFloat()
            if (strokeDp > 0f && Color.alpha(stroke) > 0) setStroke(maxOf(1, dp(ctx, strokeDp)), stroke)
        }

    /** Pill button: tonal surface, accent ring when focused (Google TV look). */
    fun styleButton(tv: TextView, th: Theme, e: JSONObject?) {
        val ctx = tv.context
        val radius = e?.optInt("radius", -1) ?: -1
        val fill = color(e?.optString("fill"), th.surface)
        val stroke = color(e?.optString("stroke"), 0)
        val sw = (e?.optDouble("strokeWidth", 0.0) ?: 0.0).toFloat()
        val fc = color(e?.optString("focusColor"), th.accent)
        val focusFill = Color.argb(0x40, Color.red(fc), Color.green(fc), Color.blue(fc))
        val st = StateListDrawable()
        st.addState(intArrayOf(android.R.attr.state_focused), roundRect(ctx, focusFill, fc, 3f, radius))
        st.addState(intArrayOf(android.R.attr.state_pressed), roundRect(ctx, th.focus, fc, 2f, radius))
        st.addState(intArrayOf(), roundRect(ctx, fill, stroke, sw, radius))
        tv.background = st
        tv.setTextColor(color(e?.optString("textColor"), th.text))
        tv.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        tv.gravity = Gravity.CENTER
        tv.minWidth = 0; tv.minimumWidth = 0; tv.minHeight = 0; tv.minimumHeight = 0   // Button keeps ~48dp min height otherwise
        tv.stateListAnimator = null
        tv.setPadding(dp(ctx, 12f), dp(ctx, 4f), dp(ctx, 12f), dp(ctx, 4f))
        tv.isAllCaps = false
        tv.letterSpacing = 0f
    }

    private fun scaleText(v: View, k: Float) {
        if (k == 1f || k <= 0f) return
        if (v is TextView) v.setTextSize(TypedValue.COMPLEX_UNIT_PX, v.textSize * k)
        if (v is ViewGroup) for (i in 0 until v.childCount) scaleText(v.getChildAt(i), k)
    }

    private fun recolor(v: View, c: Int) {
        if (v is TextView) v.setTextColor(c)
        if (v is ViewGroup) for (i in 0 until v.childCount) recolor(v.getChildAt(i), c)
    }

    /**
     * Rearranges the freshly built main screen. [views] are the movable elements by id, [panels] the
     * LinearLayout rows they were first placed in (hidden once empty), [accents]/[bodies] the texts
     * that take the theme's accent / body colour.
     */
    fun applyMain(
        act: Activity, root: FrameLayout, views: Map<String, View>, panels: List<View>,
        accents: List<TextView>, bodies: List<TextView>, bg: View?
    ) {
        val cfg = load(true) ?: return
        val classic = cfg.mode == "off"      // classic look: only the pinned menu buttons ("mb_*") are placed, nothing is restyled
        val th = theme(cfg)
        val dm = act.resources.displayMetrics
        val sw = dm.widthPixels
        val sh = dm.heightPixels
        if (!classic) {
            root.setBackgroundColor(th.bg)
            for (t in accents) t.setTextColor(th.accent)
            for (t in bodies) t.setTextColor(th.text)
            (views["hud"] as? HudView)?.transparent = true
        }

        // Classic look: an element is moved only when the user changed it ("custom"), is a pinned button, or the editor is on.
        val cth = Theme(bg = Color.BLACK, surface = Color.argb(210, 8, 28, 42), focus = Color.rgb(0, 140, 190), text = Color.WHITE,
            muted = Color.rgb(160, 200, 215), accent = Color.rgb(0, 230, 255), radius = 4)
        val ath = if (classic) cth else th
        fun styled(e: JSONObject) = !classic || listOf("fill", "stroke", "strokeWidth", "textColor", "focusColor", "radius").any { e.has(it) }
        // Once any element was moved, the rest sit where the editor showed them (not in the native rows, where they would pile up).
        val anyCustom = classic && cfg.main.keys().asSequence().any { k -> !k.startsWith("mb_") && cfg.main.optJSONObject(k)?.optBoolean("custom") == true }
        for ((id, v) in views) {
            val e0 = cfg.main.optJSONObject(id)
            val e = if (!classic || id.startsWith("mb_") || e0?.optBoolean("custom") == true) e0
                    else if (cfg.edit || anyCustom) classicDefault(id) else null
            if (e == null) continue
            (v.parent as? ViewGroup)?.removeView(v)
            if (!e.optBoolean("visible", true)) continue

            val w = e.optDouble("w", 0.0)
            val h = e.optDouble("h", 0.0)
            val lp = FrameLayout.LayoutParams(
                if (w > 0) (sw * w / 100.0).toInt() else ViewGroup.LayoutParams.WRAP_CONTENT,
                if (h > 0) (sh * h / 100.0).toInt() else ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.START
            )
            lp.leftMargin = (sw * e.optDouble("x", 0.0) / 100.0).toInt()
            lp.topMargin = (sh * e.optDouble("y", 0.0) / 100.0).toInt()
            root.addView(v, lp)

            val tsize = e.optDouble("textSize", 0.0).toFloat()
            val scale = e.optDouble("textScale", 1.0).toFloat()
            val bold = e.optBoolean("bold", false)
            when {
                v is Button -> {
                    if (styled(e)) styleButton(v, ath, e)
                    if (tsize > 0f) v.textSize = tsize
                }
                v is EditText -> {
                    if (styled(e)) {
                        val r = e.optInt("radius", -1)
                        v.background = roundRect(act, color(e.optString("fill"), ath.surface),
                            color(e.optString("stroke"), 0), e.optDouble("strokeWidth", 0.0).toFloat(), r)
                        v.setTextColor(color(e.optString("textColor"), ath.text))
                        v.setHintTextColor(ath.muted)
                        if (!classic) v.setPadding(dp(act, 22f), dp(act, 6f), dp(act, 22f), dp(act, 6f))
                    }
                    if (tsize > 0f) v.textSize = tsize
                }
                v is HudView -> Unit
                v is TextView -> {
                    if (!classic || e.has("textColor")) v.setTextColor(color(e.optString("textColor"), if (id == "name") th.accent else th.muted))
                    if (e.has("fill") || e.has("stroke")) {
                        v.background = roundRect(v.context, color(e.optString("fill"), 0),
                            color(e.optString("stroke"), 0), e.optDouble("strokeWidth", 0.0).toFloat(), e.optInt("radius", 12))
                    }
                    if (tsize > 0f) v.textSize = tsize
                    if (!classic) v.typeface = Typeface.create(if (bold) "sans-serif-medium" else "sans-serif", Typeface.NORMAL)
                }
                v is ViewGroup -> {          // log, content, confirm, quiz
                    if (styled(e)) {
                        val r = e.optInt("radius", if (classic) 4 else th.radius)
                        v.background = roundRect(act, color(e.optString("fill"), if (classic) Color.argb(190, 4, 16, 26) else th.surface),
                            color(e.optString("stroke"), if (classic) Color.rgb(0, 80, 105) else 0),
                            e.optDouble("strokeWidth", if (classic) 1.0 else 0.0).toFloat(), r)
                    }
                    val tc = e.optString("textColor")
                    if (tc.isNotBlank()) recolor(v, color(tc, th.text))
                    scaleText(v, scale)
                }
            }
        }
        if (!classic) for (p in panels) if (p is ViewGroup && p.childCount == 0) p.visibility = View.GONE
        bg?.visibility = if (cfg.mode == "frame") View.VISIBLE else View.GONE
    }
}

/** Full-screen picture drawn by a plugin (Bridge.bgBitmap), behind every other element. */
class BgFrameView(ctx: Context) : View(ctx) {
    private val src = Rect()
    private val dst = Rect()
    private val paint = android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG)

    override fun onDraw(c: android.graphics.Canvas) {
        val b: Bitmap? = Bridge.bgBitmap
        if (b != null) {
            src.set(0, 0, b.width, b.height)
            dst.set(0, 0, width, height)
            c.drawBitmap(b, src, dst, paint)
            postInvalidateDelayed(50)
        } else {
            postInvalidateDelayed(300)
        }
    }
}
