package com.jarvis.tv

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import org.json.JSONObject
import java.io.File

/**
 * Screen skin, written by a plugin (screen_style.py) as plugin_data/screen_layout.json and read here.
 *
 *   {"mode": "off" | "layout" | "frame",
 *    "theme":   {"bg","surface","focus","text","muted","accent","radius"},
 *    "main":    {"<element id>": {visible, x, y, w, h, radius, fill, stroke, strokeWidth,
 *                                 textColor, textSize, textScale, bold}},
 *    "results": {x, y, w, h, columns, posterRatio, ... see ResultsActivity}}
 *
 * x, y, w, h are percent of the screen (w/h = 0 → wrap content). "off" (or no file) keeps the classic
 * screen exactly as it was. "frame" additionally shows a full-screen picture the plugin renders
 * (Bridge.bgFrame) behind everything. Nothing here is Jarvis logic: it only moves and paints views.
 */
object Skin {
    class Cfg(
        val mode: String, val theme: JSONObject, val main: JSONObject, val results: JSONObject,
        val overlay: JSONObject = JSONObject(), val edit: Boolean = false
    )

    class Theme(
        val bg: Int, val surface: Int, val focus: Int, val text: Int,
        val muted: Int, val accent: Int, val radius: Int, val design: String = "google", val wall: String = "dark", val wallDim: Int = 35
    )

    private fun file(): File =
        File(File(AssetInstaller.targetDir(Bridge.app), "plugin_data"), "screen_layout.json")

    private var cSig = -1L
    private var cAt = 0L
    private var cCfg: Cfg? = null
    private var cTheme: Theme? = null

    /** Parsed skin, re-read (at most every 300 ms) when the file changed; null = classic look. */
    @Synchronized
    fun current(): Cfg? {
        val now = System.currentTimeMillis()
        if (now - cAt > 300) {
            cAt = now
            val sig = signature()
            if (sig != cSig) {
                cSig = sig
                cCfg = load()
                cTheme = cCfg?.let { theme(it) }
            }
        }
        return cCfg
    }

    /** Forget the cached skin (call right after this app itself rewrote the file). */
    @Synchronized fun invalidate() { cAt = 0L; cSig = -1L }

    /** Freshly read skin (used when a screen is being built). */
    fun fresh(): Cfg? { invalidate(); return current() }

    /** Turns the layout editor on/off in the file. False when the plugin has not written a usable layout yet. */
    fun setEdit(on: Boolean): Boolean {
        return try {
            val f = file()
            if (!f.exists()) return false
            val o = JSONObject(f.readText())
            val m = o.optJSONObject("main")
            if (m == null || m.length() == 0) return false
                        o.put("edit", on)
            f.writeText(o.toString(1))
            invalidate()
            true
        } catch (t: Throwable) {
            Bridge.log("SYS: редактор экрана: ${t.message}")
            false
        }
    }

    /** Approximate geometry (percent of the screen) of the classic main screen, so the editor can start from it. */
    fun classicDefault(id: String): JSONObject? {
        val r = when (id) {
            "hud" -> doubleArrayOf(0.0, 0.0, 100.0, 100.0)
            "name" -> doubleArrayOf(3.5, 3.5, 0.0, 0.0)
            "state" -> doubleArrayOf(45.0, 4.0, 0.0, 0.0)
            "clock" -> doubleArrayOf(91.0, 3.5, 0.0, 0.0)
            "log" -> doubleArrayOf(2.3, 14.6, 36.0, 65.6)
            "content" -> doubleArrayOf(67.7, 14.6, 30.0, 65.6)
            "input" -> doubleArrayOf(2.3, 86.0, 34.0, 11.0)
            "btn_send" -> doubleArrayOf(37.5, 86.0, 8.0, 11.0)
            "btn_voice" -> doubleArrayOf(46.0, 86.0, 6.5, 11.0)
            "btn_mute" -> doubleArrayOf(53.0, 86.0, 11.0, 11.0)
            "btn_stop" -> doubleArrayOf(65.0, 86.0, 6.0, 11.0)
            "btn_results" -> doubleArrayOf(71.5, 86.0, 9.0, 11.0)
            "btn_plugins" -> doubleArrayOf(81.0, 86.0, 8.0, 11.0)
            "btn_menu" -> doubleArrayOf(89.5, 86.0, 8.0, 11.0)
            "confirm" -> doubleArrayOf(22.5, 36.0, 55.0, 0.0)
            "quiz" -> doubleArrayOf(19.0, 18.0, 62.0, 0.0)
            else -> return null
        }
        return JSONObject().put("visible", true).put("x", r[0]).put("y", r[1]).put("w", r[2]).put("h", r[3])
    }

    /** Stores a rectangle the editor produced (percent of the screen). w/h only when the element was resized. */
    fun saveRect(id: String, x: Double, y: Double, w: Double?, h: Double?): Long {
        return try {
            val f = file()
            val o = JSONObject(f.readText())
            val m = o.optJSONObject("main") ?: JSONObject().also { o.put("main", it) }
            val e = m.optJSONObject(id) ?: JSONObject().also { m.put(id, it) }
            if (o.optString("mode", "off") == "off" && !e.optBoolean("custom") && !id.startsWith("mb_")) {
                // classic look: the element becomes "custom" and keeps its classic size unless it was resized
                classicDefault(id)?.let { d -> for (k in listOf("visible", "w", "h")) if (!e.has(k) || k == "w" || k == "h") e.put(k, d.get(k)) }
            }
            e.put("custom", true)
            e.put("x", Math.round(x * 10.0) / 10.0)
            e.put("y", Math.round(y * 10.0) / 10.0)
            if (w != null) e.put("w", Math.round(w * 10.0) / 10.0)
            if (h != null) e.put("h", Math.round(h * 10.0) / 10.0)
            f.writeText(o.toString(1))
            invalidate()
            f.lastModified()
        } catch (t: Throwable) {
            Bridge.log("SYS: не удалось сохранить положение: ${t.message}")
            signature()
        }
    }

    /** Colours of the active skin, or null when the classic look is on. */
    fun theme(): Theme? { current(); return cTheme }

    /** Changes whenever the plugin saves; MainActivity rebuilds itself when it differs. */
    fun signature(): Long {
        val m = try { file().lastModified() } catch (_: Throwable) { 0L }
        if (m != 0L && m == selfMt && lastSig != 0L) return lastSig      // only the video window moved: no rebuild needed
        lastSig = m
        return m
    }

    @Volatile private var selfMt = 0L
    @Volatile private var lastSig = 0L

    fun fileMt(): Long = try { file().lastModified() } catch (_: Throwable) { 0L }

    /** Whether a service-menu or plugin-settings shortcut is present on the home screen. */
    fun menuItemPinned(key: String): Boolean = try {
        val main = JSONObject(file().readText()).optJSONObject("main")
        main?.has("mb_$key") == true
    } catch (_: Throwable) { false }

    /** The "video" part of the layout file (read even when the skin mode is off). */
    fun videoCfg(): JSONObject = try {
        val f = file()
        if (!f.exists()) JSONObject() else JSONObject(f.readText()).optJSONObject("video") ?: JSONObject()
    } catch (_: Throwable) { JSONObject() }

    /** The "widgets" part of the layout file: look of the microphone, result numbers and results-window buttons. */
    fun widgets(): JSONObject = try {
        val f = file()
        if (!f.exists()) JSONObject() else JSONObject(f.readText()).optJSONObject("widgets") ?: JSONObject()
    } catch (_: Throwable) { JSONObject() }

    /** Where a floating button was left (fractions of its panel), key like "OverlayActivity.mic". */
    fun floatPos(id: String): FloatArray? = try {
        val f = file()
        if (!f.exists()) null else {
            val a = JSONObject(f.readText()).optJSONObject("pos")?.optJSONArray(id)
            if (a != null && a.length() >= 2) floatArrayOf(a.getDouble(0).toFloat(), a.getDouble(1).toFloat()) else null
        }
    } catch (_: Throwable) { null }

    fun saveFloatPos(id: String, fx: Float, fy: Float) {
        try {
            val f = file()
            val o = if (f.exists()) JSONObject(f.readText()) else JSONObject().put("mode", "off")
            val pos = o.optJSONObject("pos") ?: JSONObject().also { o.put("pos", it) }
            pos.put(id, org.json.JSONArray().put(fx.toDouble()).put(fy.toDouble()))
            f.parentFile?.mkdirs()
            f.writeText(o.toString(1))
            selfMt = f.lastModified()
        } catch (t: Throwable) {
            Bridge.log("SYS: не удалось сохранить положение кнопки: ${t.message}")
        }
    }

    /** Window position and size in % of the screen, written when the user drags / resizes the video window. */
    fun saveVideo(x: Double, y: Double, w: Double, h: Double) {
        try {
            val f = file()
            val o = if (f.exists()) JSONObject(f.readText()) else JSONObject().put("mode", "off")
            val v = o.optJSONObject("video") ?: JSONObject().also { o.put("video", it) }
            if (!v.has("mode")) v.put("mode", "window")
            v.put("x", Math.round(x * 10.0) / 10.0)
            v.put("y", Math.round(y * 10.0) / 10.0)
            v.put("w", Math.round(w * 10.0) / 10.0)
            v.put("h", Math.round(h * 10.0) / 10.0)
            f.parentFile?.mkdirs()
            f.writeText(o.toString(1))
            selfMt = f.lastModified()
        } catch (t: Throwable) {
            Bridge.log("SYS: не удалось сохранить окно видео: ${t.message}")
        }
    }

    /**
     * [allowOff] = true also returns the file for mode "off" (classic look). Only the main screen uses that, to place
     * the menu buttons the user pinned and to run the editor without switching to the Google style.
     */
    fun load(allowOff: Boolean = false): Cfg? {
        return try {
            val f = file()
            if (!f.exists()) return null
            val o = JSONObject(f.readText())
            val mode = o.optString("mode", "off")
            if (mode == "off" && !allowOff) return null
            Cfg(
                mode,
                o.optJSONObject("theme") ?: JSONObject(),
                o.optJSONObject("main") ?: JSONObject(),
                o.optJSONObject("results") ?: JSONObject(),
                o.optJSONObject("overlay") ?: JSONObject(),
                o.optBoolean("edit", false)
            )
        } catch (t: Throwable) {
            Bridge.log("SYS: screen_layout.json: ${t.message}")
            null
        }
    }

    fun color(s: String?, def: Int): Int {
        if (s.isNullOrBlank()) return def
        return try { Color.parseColor(s.trim()) } catch (_: Throwable) { def }
    }

    fun theme(c: Cfg): Theme {
        val t = c.theme
        return Theme(
            bg = color(t.optString("bg"), 0xFF202124.toInt()),
            surface = color(t.optString("surface"), 0xFF2D2E31.toInt()),
            focus = color(t.optString("focus"), 0xFF3C4043.toInt()),
            text = color(t.optString("text"), 0xFFE8EAED.toInt()),
            muted = color(t.optString("muted"), 0xFF9AA0A6.toInt()),
            accent = color(t.optString("accent"), 0xFF8AB4F8.toInt()),
            radius = t.optInt("radius", 20),
            design = t.optString("design", "google"),
            wall = t.optString("wall", "dark"),
            wallDim = t.optInt("walldim", 35)
        )
    }

    // ── dialogs (the Service menu and everything under it) ──
    fun showStyled(d: android.app.Dialog): android.app.Dialog {
        d.show()
        styleDialog(d)
        return d
    }

    fun styleDialog(d: android.app.Dialog) {
        val th = theme() ?: return
        val win = d.window ?: return
        win.setBackgroundDrawable(surfaceBg(d.context, th, th.surface, 0, 0f, th.radius, 0xD8))
        val titleId = d.context.resources.getIdentifier("alertTitle", "id", "android")
        restyle(win.decorView, th, titleId)
    }

    private fun restyle(v: View, th: Theme, titleId: Int) {
        when (v) {
            is Button -> styleButton(v, th, null)
            is EditText -> {
                v.setTextColor(th.text)
                v.setHintTextColor(th.muted)
                v.background = roundRect(v.context, th.bg, th.focus, 1f, 12)
            }
            is TextView -> v.setTextColor(if (titleId != 0 && v.id == titleId) th.accent else th.text)
            is android.widget.ListView -> {
                v.divider = android.graphics.drawable.ColorDrawable(th.focus)
                v.dividerHeight = 1
                v.selector = roundRect(v.context, Color.argb(0x40, Color.red(th.accent), Color.green(th.accent), Color.blue(th.accent)), th.accent, 2f, 12)
                v.setOnHierarchyChangeListener(object : ViewGroup.OnHierarchyChangeListener {
                    override fun onChildViewAdded(parent: View?, child: View?) { if (child != null) styleListRow(child, th) }
                    override fun onChildViewRemoved(parent: View?, child: View?) {}
                })
                for (i in 0 until v.childCount) styleListRow(v.getChildAt(i), th)
            }
        }
        if (v is ViewGroup) for (i in 0 until v.childCount) restyle(v.getChildAt(i), th, titleId)
    }

    private fun styleListRow(v: View, th: Theme) {
        if (v is TextView) {
            v.textSize = 16f
            v.setTextColor(th.text)
            v.minHeight = dp(v.context, 48f)
            v.setPadding(dp(v.context, 18f), dp(v.context, 10f), dp(v.context, 18f), dp(v.context, 10f))
            v.gravity = Gravity.CENTER_VERTICAL or Gravity.START
            v.letterSpacing = 0f
        }
        if (v is ViewGroup) for (i in 0 until v.childCount) styleListRow(v.getChildAt(i), th)
    }

    private fun dp(ctx: Context, v: Float): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun roundRect(ctx: Context, fill: Int, stroke: Int, strokeDp: Float, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = if (radiusDp < 0) dp(ctx, 999f).toFloat() else dp(ctx, radiusDp.toFloat()).toFloat()
            if (strokeDp > 0f && Color.alpha(stroke) > 0) setStroke(maxOf(1, dp(ctx, strokeDp)), stroke)
        }

    /** Panel background for any screen: real Liquid Glass for "appleglass", a plain rounded rect otherwise. */
    fun surfaceBg(ctx: Context, th: Theme, fill: Int, stroke: Int, strokeDp: Float, radiusDp: Int, minAlpha: Int = 0): Drawable =
        if (th.design == "appleglass") {
            val base = if (Color.alpha(fill) < minAlpha) Hud.withAlpha(fill, minAlpha) else fill
            LiquidGlass(ctx.resources.displayMetrics.density,
                if (radiusDp < 0) -1f else dp(ctx, maxOf(radiusDp, 28).toFloat()).toFloat(), base, light = isLight(th))
        } else roundRect(ctx, fill, stroke, strokeDp, radiusDp)

    /** Full-screen background for a theme: the Apple aurora wallpaper, or null (use the solid colour). */
    fun isLight(th: Theme): Boolean {
        val l = 0.299f * Color.red(th.bg) + 0.587f * Color.green(th.bg) + 0.114f * Color.blue(th.bg)
        return l > 140f
    }

    fun screenBg(th: Theme?): Drawable? {
        if (th == null) return null
        if (th.wall == "image") Wallpaper.bitmap()?.let { return ImageBgDrawable(it, th.wallDim) }
        return if (th.design == "appleglass") AuroraDrawable(th.bg, th.wall == "custom", isLight(th)) else null
    }

    /** Marks the skin file as changed so every screen rebuilds with the new wallpaper. */
    fun touch() { try { file().setLastModified(System.currentTimeMillis()) } catch (_: Throwable) {}; invalidate() }

    /** Distinct panel construction for the two non-Google design systems. */
    private fun panelDrawable(ctx: Context, th: Theme, fill: Int, stroke: Int, strokeDp: Float, radius: Int): Drawable {
        val d = ctx.resources.displayMetrics.density
        return when (th.design) {
            "glass" -> GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
                Hud.withAlpha(fill, 0xE8), Hud.withAlpha(fill, 0xB8), Hud.withAlpha(th.accent, 0x20)
            )).apply {
                cornerRadius = dp(ctx, maxOf(radius, 22).toFloat()).toFloat()
                setStroke(maxOf(1, dp(ctx, maxOf(strokeDp, 1f))), if (stroke != 0) stroke else Hud.withAlpha(th.text, 0x55))
            }
            "appleglass" -> LiquidGlass(d, if (radius < 0) -1f else dp(ctx, maxOf(radius, 28).toFloat()).toFloat(), fill, light = isLight(th))
            "futuristic" -> GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(
                Hud.withAlpha(fill, 0xF8), Hud.withAlpha(th.bg, 0xF4)
            )).apply {
                cornerRadius = dp(ctx, minOf(if (radius < 0) 5 else radius, 6).toFloat()).toFloat()
                setStroke(maxOf(1, dp(ctx, maxOf(strokeDp, 1.4f))), if (stroke != 0) stroke else Hud.withAlpha(th.accent, 0xCC))
            }
            else -> roundRect(ctx, fill, stroke, strokeDp, radius)
        }
    }

    /** Pill button: tonal surface, accent ring when focused (Google TV look). */
    fun styleButton(tv: TextView, th: Theme, e: JSONObject?) {
        val ctx = tv.context
        val radius = e?.optInt("radius", -1) ?: -1
        val fill = color(e?.optString("fill"), th.surface)
        val stroke = color(e?.optString("stroke"), 0)
        val sw = (e?.optDouble("strokeWidth", 0.0) ?: 0.0).toFloat()
        val fc = color(e?.optString("focusColor"), th.accent)
        val focusFill = Color.argb(if (th.design == "glass" || th.design == "appleglass") 0x66 else 0x40, Color.red(fc), Color.green(fc), Color.blue(fc))
        if (th.design == "appleglass") { styleGlassButton(tv, th, e, fill, radius); return }
        val st = StateListDrawable()
        val normalStroke = when (th.design) { "glass" -> if (stroke != 0) stroke else 0x668BEAFF; "appleglass" -> if (stroke != 0) stroke else 0x88FFFFFF.toInt(); "futuristic" -> if (stroke != 0) stroke else th.accent; else -> stroke }
        val normalWidth = when (th.design) { "glass" -> maxOf(sw, 1f); "appleglass" -> maxOf(sw, 1.2f); "futuristic" -> maxOf(sw, 1.4f); else -> sw }
        val normalRadius = when (th.design) { "glass" -> maxOf(radius, 22); "appleglass" -> maxOf(radius, 28); "futuristic" -> minOf(if (radius < 0) 5 else radius, 6); else -> radius }
        st.addState(intArrayOf(android.R.attr.state_focused), roundRect(ctx, focusFill, fc, if (th.design == "futuristic") 3f else 2f, normalRadius))
        st.addState(intArrayOf(android.R.attr.state_pressed), roundRect(ctx, th.focus, fc, 2f, normalRadius))
        st.addState(intArrayOf(), roundRect(ctx, fill, normalStroke, normalWidth, normalRadius))
        tv.background = st
        tv.setTextColor(color(e?.optString("textColor"), th.text))
        tv.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        tv.gravity = Gravity.CENTER
        tv.minWidth = 0; tv.minimumWidth = 0; tv.minHeight = 0; tv.minimumHeight = 0   // Button keeps ~48dp min height otherwise
        tv.stateListAnimator = null
        tv.setPadding(dp(ctx, 12f), dp(ctx, 4f), dp(ctx, 12f), dp(ctx, 4f))
        tv.isAllCaps = false
        tv.letterSpacing = 0f
    }

    /**
     * Apple TV style control: a translucent glass pill at rest; when focused the same pill gets the
     * "floating highlight" — brighter sheen, top specular, crisp rim and a soft glow — drawn INSIDE the
     * view (a small inset leaves room for the glow), so nothing is scaled and nothing leaves the screen.
     */
    private fun styleGlassButton(tv: TextView, th: Theme, e: JSONObject?, fill: Int, radius: Int) {
        val ctx = tv.context
        val d = ctx.resources.displayMetrics.density
        val light = isLight(th)
        val rad = if (radius < 0) -1f else dp(ctx, maxOf(radius, 28).toFloat()).toFloat()
        val st = StateListDrawable()
        st.addState(intArrayOf(android.R.attr.state_pressed), LiquidGlass(d, rad, fill, bright = true, pressed = true, light = light, inset = 5f))
        st.addState(intArrayOf(android.R.attr.state_focused), LiquidGlass(d, rad, fill, bright = true, light = light, inset = 5f))
        st.addState(intArrayOf(), LiquidGlass(d, rad, fill, light = light, inset = 5f))
        tv.background = st
        tv.setTextColor(color(e?.optString("textColor"), th.text))
        tv.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        tv.gravity = Gravity.CENTER
        tv.minWidth = 0; tv.minimumWidth = 0; tv.minHeight = 0; tv.minimumHeight = 0
        tv.stateListAnimator = null
        tv.scaleX = 1f; tv.scaleY = 1f
        tv.setPadding(dp(ctx, 16f), dp(ctx, 6f), dp(ctx, 16f), dp(ctx, 6f))
        tv.isAllCaps = false
        tv.letterSpacing = 0f
    }

    private fun scaleText(v: View, k: Float) {
        if (k == 1f || k <= 0f) return
        if (v is TextView) v.setTextSize(TypedValue.COMPLEX_UNIT_PX, v.textSize * k)
        if (v is ViewGroup) for (i in 0 until v.childCount) scaleText(v.getChildAt(i), k)
    }

    private fun recolor(v: View, c: Int) {
        if (v is TextView) v.setTextColor(c)
        if (v is ViewGroup) for (i in 0 until v.childCount) recolor(v.getChildAt(i), c)
    }

    /**
     * Rearranges the freshly built main screen. [views] are the movable elements by id, [panels] the
     * LinearLayout rows they were first placed in (hidden once empty), [accents]/[bodies] the texts
     * that take the theme's accent / body colour.
     */
    fun applyMain(
        act: Activity, root: FrameLayout, views: Map<String, View>, panels: List<View>,
        accents: List<TextView>, bodies: List<TextView>, bg: View?
    ) {
        val cfg = load(true) ?: return
        val classic = cfg.mode == "off"      // classic look: only the pinned menu buttons ("mb_*") are placed, nothing is restyled
        val th = theme(cfg)
        val dm = act.resources.displayMetrics
        val sw = dm.widthPixels
        val sh = dm.heightPixels
        if (!classic) {
            val aur = screenBg(th)
            if (aur != null && (cfg.mode != "frame" || th.wall == "image")) root.background = aur else root.setBackgroundColor(th.bg)
            for (t in accents) t.setTextColor(th.accent)
            for (t in bodies) t.setTextColor(th.text)
            (views["hud"] as? HudView)?.transparent = true
        }

        // Classic look: an element is moved only when the user changed it ("custom"), is a pinned button, or the editor is on.
        val cth = Theme(bg = Color.BLACK, surface = Color.argb(210, 8, 28, 42), focus = Color.rgb(0, 140, 190), text = Color.WHITE,
            muted = Color.rgb(160, 200, 215), accent = Color.rgb(0, 230, 255), radius = 4)
        val ath = if (classic) cth else th
        fun styled(e: JSONObject) = !classic || listOf("fill", "stroke", "strokeWidth", "textColor", "focusColor", "radius").any { e.has(it) }
        // Once any element was moved, the rest sit where the editor showed them (not in the native rows, where they would pile up).
        val anyCustom = classic && cfg.main.keys().asSequence().any { k -> !k.startsWith("mb_") && cfg.main.optJSONObject(k)?.optBoolean("custom") == true }
        for ((id, v) in views) {
            val e0 = cfg.main.optJSONObject(id)
            val e = if (!classic || id.startsWith("mb_") || e0?.optBoolean("custom") == true) e0
                    else if (cfg.edit || anyCustom) classicDefault(id) else null
            if (e == null) continue
            (v.parent as? ViewGroup)?.removeView(v)
            if (!e.optBoolean("visible", true)) continue

            val w = e.optDouble("w", 0.0)
            val h = e.optDouble("h", 0.0)
            val lp = FrameLayout.LayoutParams(
                if (w > 0) (sw * w / 100.0).toInt() else ViewGroup.LayoutParams.WRAP_CONTENT,
                if (h > 0) (sh * h / 100.0).toInt() else ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.START
            )
            lp.leftMargin = (sw * e.optDouble("x", 0.0) / 100.0).toInt()
            lp.topMargin = (sh * e.optDouble("y", 0.0) / 100.0).toInt()
            root.addView(v, lp)

            val tsize = e.optDouble("textSize", 0.0).toFloat()
            val scale = e.optDouble("textScale", 1.0).toFloat()
            val bold = e.optBoolean("bold", false)
            when {
                v is Button -> {
                    if (styled(e)) styleButton(v, ath, e)
                    if (tsize > 0f) v.textSize = tsize
                }
                v is EditText -> {
                    if (styled(e)) {
                        val r = e.optInt("radius", -1)
                        v.background = panelDrawable(act, ath, color(e.optString("fill"), ath.surface),
                            color(e.optString("stroke"), 0), e.optDouble("strokeWidth", 0.0).toFloat(), r)
                        v.setTextColor(color(e.optString("textColor"), ath.text))
                        v.setHintTextColor(ath.muted)
                        if (!classic) v.setPadding(dp(act, 22f), dp(act, 6f), dp(act, 22f), dp(act, 6f))
                    }
                    if (tsize > 0f) v.textSize = tsize
                }
                v is HudView -> Unit
                v is TextView -> {
                    if (!classic || e.has("textColor")) v.setTextColor(color(e.optString("textColor"), if (id == "name") th.accent else th.muted))
                    if (e.has("fill") || e.has("stroke")) {
                        v.background = roundRect(v.context, color(e.optString("fill"), 0),
                            color(e.optString("stroke"), 0), e.optDouble("strokeWidth", 0.0).toFloat(), e.optInt("radius", 12))
                    }
                    if (tsize > 0f) v.textSize = tsize
                    if (!classic) v.typeface = Typeface.create(if (bold) "sans-serif-medium" else "sans-serif", Typeface.NORMAL)
                }
                v is ViewGroup -> {          // log, content, confirm, quiz
                    if (styled(e)) {
                        val r = e.optInt("radius", if (classic) 4 else th.radius)
                        v.background = if (classic) roundRect(act, color(e.optString("fill"), Color.argb(190, 4, 16, 26)),
                            color(e.optString("stroke"), Color.rgb(0, 80, 105)), e.optDouble("strokeWidth", 1.0).toFloat(), r)
                        else panelDrawable(act, th, color(e.optString("fill"), th.surface), color(e.optString("stroke"), 0),
                            e.optDouble("strokeWidth", 0.0).toFloat(), r)
                    }
                    val tc = e.optString("textColor")
                    if (tc.isNotBlank()) recolor(v, color(tc, th.text))
                    scaleText(v, scale)
                }
            }
        }
        if (!classic) for (p in panels) if (p is ViewGroup && p.childCount == 0) p.visibility = View.GONE
        bg?.visibility = if (cfg.mode == "frame" && th.wall != "image") View.VISIBLE else View.GONE
    }
}

/** Full-screen picture drawn by a plugin (Bridge.bgBitmap), behind every other element. */
class BgFrameView(ctx: Context) : View(ctx) {
    private val src = Rect()
    private val dst = Rect()
    private val paint = android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG)

    override fun onDraw(c: android.graphics.Canvas) {
        val b: Bitmap? = Bridge.bgBitmap
        if (b != null) {
            src.set(0, 0, b.width, b.height)
            dst.set(0, 0, width, height)
            c.drawBitmap(b, src, dst, paint)
            postInvalidateDelayed(50)
        } else {
            postInvalidateDelayed(300)
        }
    }
}


/**
 * Apple "Liquid Glass" surface. Rest: translucent body, soft sheen, bright specular rim. [bright] = focused:
 * the Apple TV "floating highlight" (stronger sheen, top specular, crisp rim, soft outer glow in the [inset]).
 * [light] = for light backgrounds (white glass, dark shadows). radius < 0 = capsule. [inset] in dp.
 */
class LiquidGlass(
    private val d: Float, private val radius: Float, private val base: Int,
    private val bright: Boolean = false, private val pressed: Boolean = false,
    private val light: Boolean = false, private val inset: Float = 0f
) : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private var sheen: Shader? = null
    private var glow: Shader? = null
    private var rim: Shader? = null
    private var edge: Shader? = null
    private var spec: Shader? = null
    private fun w(a: Int) = Color.argb(a, 255, 255, 255)
    private fun k(a: Int) = Color.argb(a, 0, 0, 0)

    override fun onBoundsChange(b: android.graphics.Rect) {
        val inn = inset * d
        val bw = b.width() - 2f * inn; val bh = b.height() - 2f * inn
        if (bw <= 0f || bh <= 0f) return
        val up = if (pressed) 0x18 else 0
        sheen = when {
            bright && light -> LinearGradient(0f, 0f, 0f, bh, w(0xFF), w(0xC8 + up), Shader.TileMode.CLAMP)
            bright -> LinearGradient(0f, 0f, 0f, bh, w(0x5C + up), w(0x24 + up), Shader.TileMode.CLAMP)
            light -> LinearGradient(0f, 0f, 0f, bh, intArrayOf(w(0xB4), w(0x66), w(0x7C)), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
            else -> LinearGradient(0f, 0f, 0f, bh, intArrayOf(w(0x2E), w(0x12), w(0x1C)), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        }
        glow = RadialGradient(bw * 0.12f, 0f, maxOf(bw, bh) * 0.75f, w(if (light) 0x70 else 0x34), w(0x00), Shader.TileMode.CLAMP)
        spec = LinearGradient(0f, 0f, 0f, bh * 0.45f, w(if (light) 0xB0 else 0x70), w(0x00), Shader.TileMode.CLAMP)
        rim = if (light)
            LinearGradient(0f, 0f, bw, bh, intArrayOf(w(0xFF), k(if (bright) 0x40 else 0x22), k(0x12), w(0xE0)),
                floatArrayOf(0f, 0.3f, 0.65f, 1f), Shader.TileMode.CLAMP)
        else
            LinearGradient(0f, 0f, bw, bh, intArrayOf(w(if (bright) 0xFF else 0xF0), w(if (bright) 0x80 else 0x40), w(if (bright) 0x50 else 0x14), w(if (bright) 0xE0 else 0xB8)),
                floatArrayOf(0f, 0.25f, 0.6f, 1f), Shader.TileMode.CLAMP)
        edge = LinearGradient(0f, 0f, 0f, bh * 0.5f, w(0x58), w(0x00), Shader.TileMode.CLAMP)
    }

    override fun draw(c: Canvas) {
        val b = bounds
        val inn = inset * d
        val bw = b.width() - 2f * inn; val bh = b.height() - 2f * inn
        if (bw <= 0f || bh <= 0f) return
        c.save()
        c.translate(b.left + inn, b.top + inn)
        val rad = if (radius < 0f) minOf(bw, bh) / 2f else minOf(radius, minOf(bw, bh) / 2f)
        r.set(0f, 0f, bw, bh)

        // soft outer glow of the focused highlight (inside the view's own bounds)
        if (bright && inn > 1f) {
            val rings = 10
            val step = inn / rings
            p.style = Paint.Style.STROKE; p.shader = null; p.strokeWidth = step + 0.5f
            for (i in 0 until rings) {
                val o = step * (i + 0.5f)
                val t = 1f - i.toFloat() / rings
                p.color = if (light) k((0x30 * t).toInt()) else w((0x44 * t).toInt())
                c.drawRoundRect(-o, -o, bw + o, bh + o, rad + o, rad + o, p)
            }
        }
        p.style = Paint.Style.FILL
        if (Color.alpha(base) > 0) {
            p.shader = null; p.color = base
            c.drawRoundRect(r, rad, rad, p)
        }
        p.shader = sheen; p.color = Color.WHITE
        c.drawRoundRect(r, rad, rad, p)
        if (bright) {
            c.save()
            c.clipRect(0f, 0f, bw, bh * 0.45f)
            p.shader = spec
            c.drawRoundRect(r, rad, rad, p)
            c.restore()
        } else {
            p.shader = glow; c.drawRoundRect(r, rad, rad, p)
            if (!light) {
                p.style = Paint.Style.STROKE
                val ie = maxOf(1f, 1.6f * d) + 0.8f * d
                r.set(ie, ie, bw - ie, bh - ie)
                p.strokeWidth = maxOf(1f, d); p.shader = edge
                c.drawRoundRect(r, maxOf(0f, rad - ie), maxOf(0f, rad - ie), p)
            }
        }
        p.style = Paint.Style.STROKE
        val rw = maxOf(1f, (if (bright) 2f else 1.5f) * d)
        r.set(rw / 2f, rw / 2f, bw - rw / 2f, bh - rw / 2f)
        p.strokeWidth = rw; p.shader = rim
        c.drawRoundRect(r, maxOf(0f, rad - rw / 2f), maxOf(0f, rad - rw / 2f), p)
        p.shader = null
        c.restore()
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/**
 * Wallpaper behind the glass: Apple-style light pools on dark, pastel pools on light, or pools derived
 * from the colour the user picked ([custom]).
 */
class AuroraDrawable(private val bg: Int, private val custom: Boolean, private val light: Boolean) : Drawable() {
    private class Blob(val x: Float, val y: Float, val r: Float, val argb: Int)
    private val base: Int
    private val blobs: List<Blob>
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var shaders: List<Shader> = emptyList()

    init {
        fun c(rgb: Int, a: Int) = (a shl 24) or (rgb and 0xFFFFFF)
        if (custom) {
            base = bg or 0xFF000000.toInt()
            val hsv = FloatArray(3); Color.colorToHSV(base, hsv)
            fun shade(shift: Float, sMul: Float, vMul: Float, vAdd: Float, a: Int): Int {
                val h = floatArrayOf((hsv[0] + shift + 360f) % 360f, (hsv[1] * sMul).coerceIn(0f, 1f), (hsv[2] * vMul + vAdd).coerceIn(0f, 1f))
                return c(Color.HSVToColor(h), a)
            }
            blobs = if (light) listOf(
                Blob(0.10f, 0.08f, 0.62f, shade(0f, 0.7f, 0.92f, 0f, 0xB0)), Blob(0.90f, 0.05f, 0.55f, shade(40f, 0.8f, 1f, 0f, 0x90)),
                Blob(0.88f, 0.98f, 0.60f, shade(-45f, 0.8f, 1f, 0f, 0x90)), Blob(0.06f, 0.98f, 0.55f, shade(80f, 0.7f, 1f, 0f, 0x80)))
            else listOf(
                Blob(0.10f, 0.08f, 0.62f, shade(0f, 1f, 1.5f, 0.12f, 0xC0)), Blob(0.90f, 0.05f, 0.55f, shade(40f, 1f, 1.5f, 0.1f, 0xA0)),
                Blob(0.88f, 0.98f, 0.60f, shade(-45f, 1f, 1.5f, 0.1f, 0x90)), Blob(0.06f, 0.98f, 0.55f, shade(80f, 1f, 1.4f, 0.08f, 0x80)))
        } else if (light) {
            base = 0xFFEEF2FA.toInt()
            blobs = listOf(Blob(0.10f, 0.08f, 0.62f, c(0x7FB8FF, 0xC0)), Blob(0.90f, 0.05f, 0.55f, c(0xD6A8FF, 0xA0)),
                Blob(0.55f, 0.55f, 0.50f, c(0xB8B6FF, 0x60)), Blob(0.88f, 0.98f, 0.60f, c(0xFFB0C8, 0xA0)), Blob(0.06f, 0.98f, 0.55f, c(0x9FEDE4, 0x90)))
        } else {
            base = 0xFF05070F.toInt()
            blobs = listOf(Blob(0.10f, 0.08f, 0.62f, c(0x0A84FF, 0xC0)), Blob(0.90f, 0.04f, 0.55f, c(0xBF5AF2, 0xA0)),
                Blob(0.55f, 0.55f, 0.50f, c(0x5E5CE6, 0x58)), Blob(0.88f, 0.98f, 0.60f, c(0xFF375F, 0x80)), Blob(0.06f, 0.98f, 0.55f, c(0x30D5C8, 0x78)))
        }
    }

    override fun onBoundsChange(b: android.graphics.Rect) {
        val m = maxOf(b.width(), b.height()).toFloat()
        shaders = blobs.map {
            RadialGradient(b.left + b.width() * it.x, b.top + b.height() * it.y, m * it.r, it.argb, it.argb and 0xFFFFFF, Shader.TileMode.CLAMP)
        }
    }

    override fun draw(c: Canvas) {
        c.drawColor(base)
        for (s in shaders) { p.shader = s; c.drawRect(bounds, p) }
        p.shader = null
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}
