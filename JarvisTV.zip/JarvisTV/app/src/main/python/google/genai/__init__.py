"""Minimal, pure-Python replacement for the `google-genai` SDK (v2).

Why it exists: the official SDK depends on pydantic, whose compiled core has no
Android build for Chaquopy. This module offers exactly the surface Mark LVII
calls — `genai.Client(...)`, `client.models.generate_content(...)`,
`client.aio.live.connect(...)` and `google.genai.types` — over the public
Gemini REST and Live (WebSocket) endpoints. Mark LVII's own files are untouched.
"""
from . import errors, types
from .client import Client

__all__ = ["Client", "types", "errors"]
__version__ = "0.0.0+tv"
