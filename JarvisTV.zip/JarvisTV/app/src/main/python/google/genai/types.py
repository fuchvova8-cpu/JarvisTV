"""Pydantic-free stand-in for `google.genai.types`.

Only the names Mark LVII uses are here. Every type is a plain attribute bag:
unknown fields read as None (so `msg.server_content` is simply None when the
server did not send it, like the real SDK), and `to_wire()` produces the camelCase
JSON the Gemini API expects.
"""
from __future__ import annotations

import base64
import enum
import re

# Subtrees whose keys are the caller's own data, never API field names.
_OPAQUE = {"properties", "args", "response"}

_snake_re = re.compile(r"(?<!^)(?=[A-Z])")


def camel(key: str) -> str:
    if "_" not in key:
        return key
    head, *rest = key.split("_")
    return head + "".join(p[:1].upper() + p[1:] for p in rest)


def snake(key: str) -> str:
    return _snake_re.sub("_", key).lower() if key != key.lower() else key


class _Obj:
    def __init__(self, **kw):
        for k, v in kw.items():
            setattr(self, k, v)

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        return None

    def __repr__(self):
        body = ", ".join(f"{k}={v!r}" for k, v in vars(self).items() if v is not None)
        return f"{type(self).__name__}({body})"

    def model_dump(self, **_):
        return to_wire(self)

    def to_json_dict(self):
        return to_wire(self)


def to_wire(obj, opaque: bool = False):
    """Python value -> JSON-ready value (camelCase keys, bytes as base64)."""
    if isinstance(obj, _Obj):
        return {camel(k): to_wire(v, k in _OPAQUE) for k, v in vars(obj).items()
                if v is not None and not k.startswith("_")}
    if isinstance(obj, enum.Enum):
        return obj.value
    if isinstance(obj, (bytes, bytearray)):
        return base64.b64encode(bytes(obj)).decode("ascii")
    if isinstance(obj, dict):
        if opaque:
            return {k: _plain(v) for k, v in obj.items()}
        return {camel(str(k)): to_wire(v, k in _OPAQUE) for k, v in obj.items() if v is not None}
    if isinstance(obj, (list, tuple)):
        return [to_wire(v, opaque) for v in obj]
    return obj


def _plain(v):
    if isinstance(v, _Obj):
        return to_wire(v)
    if isinstance(v, (bytes, bytearray)):
        return base64.b64encode(bytes(v)).decode("ascii")
    if isinstance(v, dict):
        return {k: _plain(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [_plain(x) for x in v]
    if isinstance(v, enum.Enum):
        return v.value
    return v


def from_wire(obj, key: str = ""):
    """Server JSON -> attribute objects with snake_case names."""
    if isinstance(obj, dict):
        if key in _OPAQUE:
            return obj
        out = _Obj()
        for k, v in obj.items():
            sk = snake(k)
            val = from_wire(v, sk)
            if sk == "thought_signature" and isinstance(val, str):
                try:
                    val = base64.b64decode(val)
                except Exception:
                    pass
            if sk == "data" and key == "inline_data" and isinstance(val, str):
                try:
                    val = base64.b64decode(val)
                except Exception:
                    pass
            setattr(out, sk, val)
        return out
    if isinstance(obj, list):
        return [from_wire(v, key) for v in obj]
    return obj


class _Enum(str, enum.Enum):
    def __str__(self):
        return self.value


class StartSensitivity(_Enum):
    START_SENSITIVITY_UNSPECIFIED = "START_SENSITIVITY_UNSPECIFIED"
    START_SENSITIVITY_HIGH = "START_SENSITIVITY_HIGH"
    START_SENSITIVITY_LOW = "START_SENSITIVITY_LOW"


class EndSensitivity(_Enum):
    END_SENSITIVITY_UNSPECIFIED = "END_SENSITIVITY_UNSPECIFIED"
    END_SENSITIVITY_HIGH = "END_SENSITIVITY_HIGH"
    END_SENSITIVITY_LOW = "END_SENSITIVITY_LOW"


class MediaResolution(_Enum):
    MEDIA_RESOLUTION_UNSPECIFIED = "MEDIA_RESOLUTION_UNSPECIFIED"
    MEDIA_RESOLUTION_LOW = "MEDIA_RESOLUTION_LOW"
    MEDIA_RESOLUTION_MEDIUM = "MEDIA_RESOLUTION_MEDIUM"
    MEDIA_RESOLUTION_HIGH = "MEDIA_RESOLUTION_HIGH"


def _mk(name, doc=""):
    return type(name, (_Obj,), {"__doc__": doc or name})


Blob = _mk("Blob")
FunctionCall = _mk("FunctionCall")
FunctionResponse = _mk("FunctionResponse")
Content = _mk("Content")
SessionResumptionConfig = _mk("SessionResumptionConfig")
ContextWindowCompressionConfig = _mk("ContextWindowCompressionConfig")
SlidingWindow = _mk("SlidingWindow")
SpeechConfig = _mk("SpeechConfig")
VoiceConfig = _mk("VoiceConfig")
PrebuiltVoiceConfig = _mk("PrebuiltVoiceConfig")
ProactivityConfig = _mk("ProactivityConfig")
RealtimeInputConfig = _mk("RealtimeInputConfig")
AutomaticActivityDetection = _mk("AutomaticActivityDetection")
ThinkingConfig = _mk("ThinkingConfig")
HttpOptions = _mk("HttpOptions")
GenerateContentConfig = _mk("GenerateContentConfig")
LiveConnectConfig = _mk("LiveConnectConfig")
AutomaticFunctionCallingConfig = _mk("AutomaticFunctionCallingConfig")


class Part(_Obj):
    @classmethod
    def from_bytes(cls, *, data, mime_type):
        return cls(inline_data=Blob(data=data, mime_type=mime_type))

    @classmethod
    def from_text(cls, *, text):
        return cls(text=text)

    @classmethod
    def from_function_response(cls, *, name, response):
        return cls(function_response=FunctionResponse(name=name, response=response))

    @classmethod
    def from_function_call(cls, *, name, args):
        return cls(function_call=FunctionCall(name=name, args=args))


class GenerateContentResponse(_Obj):
    @property
    def text(self):
        cand = (self.candidates or [None])[0]
        parts = getattr(getattr(cand, "content", None), "parts", None) or []
        out = [p.text for p in parts if getattr(p, "text", None) and not getattr(p, "thought", False)]
        return "".join(out) if out else None


class LiveServerMessage(_Obj):
    @property
    def data(self):
        sc = self.server_content
        mt = getattr(sc, "model_turn", None) if sc else None
        chunks = []
        for p in (getattr(mt, "parts", None) or []):
            blob = getattr(p, "inline_data", None)
            if blob is not None and isinstance(getattr(blob, "data", None), (bytes, bytearray)):
                chunks.append(bytes(blob.data))
        return b"".join(chunks) if chunks else None

    @property
    def text(self):
        sc = self.server_content
        mt = getattr(sc, "model_turn", None) if sc else None
        out = [p.text for p in (getattr(mt, "parts", None) or []) if getattr(p, "text", None)]
        return "".join(out) if out else None
