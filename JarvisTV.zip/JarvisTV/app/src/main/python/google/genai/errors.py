class APIError(Exception):
    def __init__(self, code=None, response_json=None, message=None):
        self.code = code
        self.response_json = response_json or {}
        err = self.response_json.get("error", {}) if isinstance(self.response_json, dict) else {}
        self.status = err.get("status")
        self.message = message or err.get("message") or ""
        super().__init__(f"{code} {self.status or ''}. {self.response_json}".strip())


class ClientError(APIError):
    pass


class ServerError(APIError):
    pass
