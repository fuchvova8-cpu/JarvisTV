from __future__ import annotations

import io


def to_png(data: bytes, size, level: int = 6, output=None):
    from PIL import Image
    img = Image.frombytes("RGB", tuple(size), bytes(data))
    buf = io.BytesIO()
    img.save(buf, format="PNG", compress_level=level)
    png = buf.getvalue()
    if output:
        with open(output, "wb") as f:
            f.write(png)
        return None
    return png
