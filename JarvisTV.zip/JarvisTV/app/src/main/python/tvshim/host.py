"""The `host` object behind android_bridge (the Mark TV plugin API).

Keys and shell go over loopback ADB; search providers, the results screen, app
launching and intents are Kotlin (com.jarvis.tv.TvHost).
"""
from __future__ import annotations

import os
import traceback

from tvshim import adbio
from tvshim.bridge import kt, jclass


class _Stub:
    """Off-device stand-in (desktop tests)."""

    def __init__(self):
        self.calls = []

    def __getattr__(self, name):
        def _f(*a):
            self.calls.append((name, a))
            return {"searchProviders": "", "searchQuery": "[]", "queryUri": "[]",
                    "listApps": "[]", "launchApp": "ok", "openIntents": "ok:stub",
                    "showResults": None, "pluginsDir": ""}.get(name)
        return _f


_th = None


def th():
    global _th
    if _th is None:
        try:
            _th = jclass("com.jarvis.tv.TvHost").INSTANCE
        except Exception:
            _th = _Stub()
    return _th


class Host:
    def key(self, code) -> str:
        try:
            adbio.keyevent(int(code))
            return "ok"
        except Exception as e:
            return f"ADB: {e}"

    def shell(self, cmd) -> str:
        try:
            return adbio.shell(str(cmd))
        except Exception as e:
            return f"ADB: {e}"

    def speak(self, text) -> None:
        try:
            kt().tts(str(text), "")
        except Exception:
            traceback.print_exc()

    def log(self, msg) -> None:
        print(f"[plugin] {msg}", flush=True)

    def showContent(self, title, text) -> None:
        kt().content(str(title), str(text))

    def showResults(self, title, json_text) -> None:
        th().showResults(str(title), str(json_text))

    def openIntents(self, title, json_text) -> str:
        return str(th().openIntents(str(title), str(json_text)))

    def searchProviders(self) -> str:
        return str(th().searchProviders())

    def searchQuery(self, authority, query, limit) -> str:
        return str(th().searchQuery(str(authority), str(query), int(limit)))

    def queryUri(self, uri, selection, arg) -> str:
        return str(th().queryUri(str(uri), selection, arg))

    def providerSpec(self, authority) -> str:
        return str(th().providerSpec(str(authority)))

    def listApps(self) -> str:
        return str(th().listApps())

    def launchApp(self, pkg) -> str:
        return str(th().launchApp(str(pkg)))

    def dataDir(self) -> str:
        d = os.path.join(os.environ.get("JARVIS_HOME", "."), "plugin_data")
        try:
            os.makedirs(d, exist_ok=True)
        except OSError:
            pass
        return d

    def pluginsDir(self) -> str:
        from tvshim import plugins_ext
        return str(plugins_ext.active_dir())
