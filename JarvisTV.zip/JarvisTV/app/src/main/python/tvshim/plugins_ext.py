"""Plugin folder choice and plugin settings pages, on top of the unmodified original.

* The original discovers plugins once, in <Jarvis>/plugins. `install_loader_patch()`
  wraps core.plugin_loader.discover_plugins so the folder the user picked is
  scanned instead. The original files stay as shipped.
* A plugin may add a settings page (same contract as in Mark TV):
      SETTINGS = {"title": "..."}
      def settings_items() -> [{"type": "label"|"button"|"text", ...}]
      def settings_event(event, values) -> str | {"message":..., "refresh":bool}
"""
from __future__ import annotations

import json
import os
import pkgutil
import shutil
import sys
import traceback
from pathlib import Path

BUNDLED = ("movie_search.py", "app_launcher.py", "sphere_hud.py", "screen_style.py",
           "barge_in.py", "ott_navigator.py", "quiet_mode.py", "tv_chatter.py", "tv_ddgs.py",
           "tv_micdiag.py", "tv_micfix.py", "tv_news.py", "tv_nosleep.py", "ultron_plugin.py",
           "youtube_control.py")
# Files that changed in this build: an already-installed copy is replaced once (the old one is kept as .bak).
UPDATED = {"movie_search.py": 2}


def _home() -> Path:
    return Path(os.environ.get("JARVIS_HOME", "."))


def _cfg_file() -> Path:
    return _home() / "config" / "tv_plugins_dir.txt"


def default_dir() -> Path:
    return _home() / "plugins"


def custom_dir() -> str:
    try:
        return _cfg_file().read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def active_dir() -> Path:
    c = custom_dir()
    if c:
        p = Path(c)
        try:
            p.mkdir(parents=True, exist_ok=True)
        except OSError:
            pass
        if p.is_dir() and os.access(p, os.R_OK):
            return p
        print(f"[tvshim] plugins folder unavailable: {c} — using the standard one", flush=True)
    return default_dir()


def _py_files(d: Path) -> list[Path]:
    try:
        return [f for f in d.iterdir() if f.is_file() and f.suffix == ".py"]
    except OSError:
        return []


def _seed(d: Path) -> None:
    """Put the bundled plugins into the folder once; a file the user deleted stays deleted."""
    mark = _home() / "config" / "tv_seeded.json"
    try:
        done = json.loads(mark.read_text(encoding="utf-8"))
    except Exception:
        done = {}
    key = str(d)
    seen = set(done.get(key, []))
    changed = False
    for name in BUNDLED:
        if name in seen:
            continue
        seen.add(name)
        changed = True
        target = d / name
        if target.exists():
            continue
        try:
            data = pkgutil.get_data("tvshim", "bundled_plugins/" + name)
            if data:
                d.mkdir(parents=True, exist_ok=True)
                target.write_bytes(data)
        except Exception:
            traceback.print_exc()
    for name, ver in UPDATED.items():
        tag = "%s@v%d" % (name, ver)
        if tag in seen:
            continue
        seen.add(tag)
        changed = True
        target = d / name
        try:
            data = pkgutil.get_data("tvshim", "bundled_plugins/" + name)
            if data and target.exists() and target.read_bytes() != data:
                shutil.copy2(target, d / (name + ".bak"))
                target.write_bytes(data)
        except Exception:
            traceback.print_exc()
    if changed:
        done[key] = sorted(seen)
        try:
            mark.parent.mkdir(parents=True, exist_ok=True)
            mark.write_text(json.dumps(done), encoding="utf-8")
        except OSError:
            pass


def _extend_package(d: Path) -> None:
    """`from plugins._helper import x` must also work for helpers in the chosen folder."""
    try:
        import plugins
        if str(d) not in list(plugins.__path__):
            plugins.__path__.append(str(d))
    except Exception:
        pass


def install_loader_patch() -> None:
    import core.plugin_loader as pl

    orig = pl.discover_plugins

    def patched(plugins_dir, *a, **kw):
        d = active_dir()
        try:
            _seed(d)
            if d.resolve() != Path(plugins_dir).resolve():
                _extend_package(d)
                print(f"[tvshim] plugins folder: {d}", flush=True)
        except Exception:
            traceback.print_exc()
        return orig(d, *a, **kw)

    pl.discover_plugins = patched


# ── folder choice (called from the menu) ────────────────────────────────────
def dir_info() -> str:
    return json.dumps({"current": str(active_dir()), "custom": custom_dir(),
                       "default": str(default_dir())}, ensure_ascii=False)


def dir_set(path: str) -> str:
    """Returns a message for the user."""
    path = (path or "").strip().rstrip("/")
    old = active_dir()
    f = _cfg_file()
    if not path:
        try:
            f.unlink()
        except OSError:
            pass
        return f"Папка плагинов: стандартная ({default_dir()}). Перезапустите JARVIS."
    if not path.startswith("/"):
        return "Нужен полный путь, например /storage/emulated/0/Jarvis/plugins"
    d = Path(path)
    try:
        d.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
    if not d.is_dir() or not os.access(d, os.R_OK):
        return f"Не удалось открыть {path} (нет доступа к файлам?)"
    note = ""
    if not _py_files(d) and old.resolve() != d.resolve():
        n = 0
        for src in _py_files(old):
            try:
                shutil.copy2(src, d / src.name)
                n += 1
            except OSError:
                pass
        if n:
            note = f" Скопировано плагинов из старой папки: {n}."
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text(path, encoding="utf-8")
    return f"Папка плагинов: {path}.{note} Перезапустите JARVIS (Меню → Выйти полностью, затем запустить)."


# ── plugin settings pages ───────────────────────────────────────────────────
def _settings_mods() -> list[tuple[str, str, object]]:
    out = []
    for key, m in list(sys.modules.items()):
        if not key.startswith("plugins.") or m is None:
            continue
        s = getattr(m, "SETTINGS", None)
        if isinstance(s, dict) and callable(getattr(m, "settings_items", None)):
            meta = getattr(m, "PLUGIN", None)
            name = (meta or {}).get("name") if isinstance(meta, dict) else None
            name = str(name or key.split(".", 1)[1])
            out.append((name, str(s.get("title") or name), m))
    out.sort(key=lambda t: t[0])
    return out


def _find(name: str):
    for n, _t, m in _settings_mods():
        if n == name:
            return m
    return None


def settings_list() -> str:
    return json.dumps([{"name": n, "title": t} for n, t, _m in _settings_mods()],
                      ensure_ascii=False)


def settings_items(name: str) -> str:
    m = _find(name)
    if m is None:
        return json.dumps([{"type": "label", "text": "У плагина нет настроек."}], ensure_ascii=False)
    try:
        return json.dumps(list(m.settings_items()), ensure_ascii=False)
    except Exception as e:
        traceback.print_exc()
        return json.dumps([{"type": "label", "text": f"Ошибка: {type(e).__name__}: {e}"}],
                          ensure_ascii=False)


def settings_event(name: str, event: str, values_json: str) -> str:
    out = {"message": "", "refresh": False}
    m = _find(name)
    if m is None or not callable(getattr(m, "settings_event", None)):
        return json.dumps(out, ensure_ascii=False)
    try:
        values = json.loads(values_json) if values_json else {}
        res = m.settings_event(str(event), values)
        if isinstance(res, dict):
            out["message"] = str(res.get("message") or "")
            out["refresh"] = bool(res.get("refresh"))
        elif res:
            out["message"] = str(res)
            out["refresh"] = True
    except Exception as e:
        traceback.print_exc()
        out["message"] = f"Ошибка: {type(e).__name__}: {e}"
    return json.dumps(out, ensure_ascii=False)
