"""Entry points the Kotlin side calls (Python.getModule("tvshim.entry").callAttr).

Every function returns plain str / bool / JSON text so Chaquopy conversions stay
trivial, and never raises into Kotlin.
"""
from __future__ import annotations

import json
import os
import sys
import threading
import traceback

_started = False
_main_mod = None
_holder: dict = {}


def _log(msg: str) -> None:
    print(f"[tvshim] {msg}")


def start(jarvis_dir: str) -> str:
    """Boot Mark LVII from its extracted, writable folder. Returns "" or an error."""
    global _started
    if _started:
        return ""
    _started = True
    try:
        from tvshim import boot
        boot.run(jarvis_dir)
        return ""
    except Exception as e:
        traceback.print_exc()
        _started = False
        return f"{type(e).__name__}: {e}"


def _ui():
    from tvshim import ui_android
    return ui_android.CURRENT


def _safe(fn, default=""):
    try:
        return fn()
    except Exception as e:
        traceback.print_exc()
        return default


# ── conversation ─────────────────────────────────────────────────────────────
def text_command(text: str) -> bool:
    ui = _ui()
    if ui is None or not ui.on_text_command:
        return False
    threading.Thread(target=lambda: _safe(lambda: ui.on_text_command(str(text))),
                     daemon=True).start()
    return True


def interrupt() -> bool:
    ui = _ui()
    if ui and ui.on_interrupt:
        threading.Thread(target=lambda: _safe(ui.on_interrupt), daemon=True).start()
        return True
    return False


def set_muted(flag: bool) -> bool:
    ui = _ui()
    if ui:
        ui.muted = bool(flag)
        return ui.muted
    return False


def toggle_mute() -> bool:
    ui = _ui()
    return set_muted(not ui.muted) if ui else False


def confirm_answer(accepted: bool) -> None:
    from core.confirm import resolve
    threading.Thread(target=lambda: _safe(lambda: resolve(bool(accepted))), daemon=True).start()


def push_to_talk(held: bool) -> None:
    ui = _ui()
    if ui and ui.ptt_hold:
        _safe(lambda: ui.ptt_hold(bool(held)))


# ── wake word ────────────────────────────────────────────────────────────────
def wake_state() -> str:
    ui = _ui()
    if ui and ui.wake_get_state:
        return json.dumps(_safe(ui.wake_get_state, {}) or {})
    return "{}"


def wake_toggle(enable: bool) -> str:
    ui = _ui()
    return str(_safe(lambda: ui.on_wake_toggle(bool(enable)), "")) if ui and ui.on_wake_toggle else ""


def wake_manual() -> None:
    ui = _ui()
    if ui and ui.on_wake_manual:
        _safe(ui.on_wake_manual)


def wake_install() -> str:
    ui = _ui()
    if ui and ui.on_wake_install:
        ok, msg = _safe(ui.on_wake_install, (False, "unavailable"))
        return json.dumps({"ok": bool(ok), "msg": str(msg)})
    return json.dumps({"ok": False, "msg": "unavailable"})


# ── settings ─────────────────────────────────────────────────────────────────
def config_get() -> str:
    from memory import config_manager as cm
    d = cm.load_api_keys()
    key = d.get("gemini_api_key") or ""
    return json.dumps({
        "has_key": bool(key),
        "key_tail": key[-4:] if key else "",
        "assistant_name": cm.get_assistant_name(),
        "user_name": cm.get_user_name(),
        "voice": cm.get_voice(),
        "voices": list(cm.AVAILABLE_VOICES),
        "wake_word": cm.get_wake_word_enabled(),
        "ready": bool(_ui() and _ui()._win._ready),
    }, ensure_ascii=False)


def save_key(key: str) -> bool:
    """First-run / re-entry: the same fields the PC setup overlay writes."""
    from memory.config_manager import update_config
    key = (key or "").strip()
    fields = {"os_system": "linux", "local_only": not key}
    if key:
        fields["gemini_api_key"] = key
    update_config(**fields)
    try:
        from core import gemini
        gemini.api_key(refresh=True)
    except Exception:
        pass
    ui = _ui()
    if ui:
        ui._win._ready = True
        ui.set_state("LISTENING")
        ui.write_log("SYS: Initialised. OS=LINUX (Android TV). "
                     f"{ui.assistant_name} online.")
    return True


def save_names(assistant: str, user: str) -> None:
    from memory.config_manager import save_assistant_config
    save_assistant_config(assistant, user)
    ui = _ui()
    if ui:
        ui._win._assistant_name = assistant or "JARVIS"


def set_voice(voice: str) -> None:
    from memory.config_manager import save_voice
    save_voice(voice)
    ui = _ui()
    if ui and ui.on_voice_change:
        threading.Thread(target=lambda: _safe(ui.on_voice_change), daemon=True).start()


# ── plugins ──────────────────────────────────────────────────────────────────
def plugins_json() -> str:
    ui = _ui()
    if ui and ui.get_plugins:
        return json.dumps(_safe(ui.get_plugins, []) or [], ensure_ascii=False, default=str)
    return "[]"


def plugin_enable(name: str, enabled: bool) -> None:
    from memory.config_manager import save_plugin_enabled
    save_plugin_enabled(name, bool(enabled))


# ── quiz ─────────────────────────────────────────────────────────────────────
def quiz_submit(given: str) -> str:
    ui = _ui()
    return ui.quiz_submit(given) if ui else "{}"


def quiz_next() -> None:
    ui = _ui()
    if ui:
        ui.quiz_next()


def quiz_hide() -> None:
    ui = _ui()
    if ui:
        ui.hide_quiz()


def set_current_file(path: str) -> None:
    ui = _ui()
    if ui:
        ui._current_file = path or None


# ── lifecycle ────────────────────────────────────────────────────────────────
def shutdown() -> None:
    from tvshim import boot
    boot.shutdown()


# ── plugin folder and plugin settings pages ─────────────────────────────────
def plugin_dir_info() -> str:
    from tvshim import plugins_ext
    return _safe(plugins_ext.dir_info, "{}")


def plugin_dir_set(path: str) -> str:
    from tvshim import plugins_ext
    return _safe(lambda: plugins_ext.dir_set(str(path)), "Ошибка")


def plugin_settings_list() -> str:
    from tvshim import plugins_ext
    return _safe(plugins_ext.settings_list, "[]")


def plugin_settings_items(name: str) -> str:
    from tvshim import plugins_ext
    return _safe(lambda: plugins_ext.settings_items(str(name)), "[]")


def plugin_settings_event(name: str, event: str, values_json: str) -> str:
    from tvshim import plugins_ext
    return _safe(lambda: plugins_ext.settings_event(str(name), str(event), str(values_json)), "{}")
