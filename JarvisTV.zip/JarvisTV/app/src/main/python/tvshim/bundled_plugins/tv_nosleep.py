"""
tv_nosleep — Jarvis (the assistant) stops going to sleep after 2 minutes of silence.

In wake-word mode Mark LVII puts itself to sleep when nobody has spoken for
WAKE_SLEEP_TIMEOUT (120 s) and then only answers "Hey Jarvis". This plugin raises that
timeout to "never" (or a number of minutes you choose) and wakes Jarvis up if it is
asleep right now. The choice is saved in config/tv_nosleep.json and re-applied on
every start. It changes nothing in the original files — it sets the same timer
attribute the app itself reads.
"""
from __future__ import annotations

import json
import threading
import time

import os
from pathlib import Path

HOME = Path(os.environ.get("JARVIS_HOME") or Path(__file__).resolve().parent.parent)


def _log(player, msg: str) -> None:
    print(f"[tv_nosleep] {msg}")
    if player:
        try:
            player.write_log(f"JARVIS: {msg}")
        except Exception:
            pass

PLUGIN = {
    "name": "tv_nosleep",
    "description": (
        "Controls Jarvis's own auto-sleep (the assistant going quiet after 2 minutes without speech and "
        "waiting for 'Hey Jarvis'). action: on = never fall asleep (default) | off = back to the normal "
        "2 minutes | minutes = sleep after N minutes of silence (value) | status. "
        "Use for 'don't go to sleep', 'stay awake', 'stop falling asleep', 'sleep after 10 minutes'. "
        "This is about Jarvis, not the TV screen (for the TV screen use tv_awake)."
    ),
    "brief": "Stop Jarvis from auto-sleeping after silence.",
    "tier": "extra",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING", "description": "on | off | minutes | status"},
            "value": {"type": "NUMBER", "description": "Minutes of silence before sleeping, for action=minutes"},
        },
        "required": [],
    },
}

_FILE = HOME / "config" / "tv_nosleep.json"
NEVER = 10 ** 9          # seconds; far longer than any evening
DEFAULT = 120.0          # main.WAKE_SLEEP_TIMEOUT


def _live(player=None):
    """The running JarvisLive: request_say is its bound method plugin_say."""
    ui = player
    if ui is None:
        try:
            from tvshim import ui_android
            ui = ui_android.CURRENT
        except Exception:
            return None
    fn = getattr(ui, "request_say", None)
    return getattr(fn, "__self__", None)


def _load() -> float | None:
    try:
        v = json.loads(_FILE.read_text(encoding="utf-8")).get("timeout")
        return float(v) if v else None
    except Exception:
        return None


def _save(seconds: float | None) -> None:
    try:
        if seconds is None:
            _FILE.unlink(missing_ok=True)
        else:
            _FILE.parent.mkdir(parents=True, exist_ok=True)
            _FILE.write_text(json.dumps({"timeout": seconds}), encoding="utf-8")
    except Exception as e:
        print(f"[tv_nosleep] could not save: {e}")


def _apply(live, seconds: float) -> None:
    live._wake_sleep_timeout = float(seconds)
    try:                                           # restart the silence clock, and wake if asleep
        live._last_user_speech = time.monotonic()
        if not live._awake and getattr(live, "_wake_enabled", False) and seconds >= 60:
            live.wake(reason="auto-sleep disabled")
    except Exception as e:
        print(f"[tv_nosleep] wake failed: {e}")


def _restore_on_start() -> None:
    """Re-apply the saved choice once JarvisLive exists (plugins load before it is built)."""
    saved = _load()
    if not saved:
        return
    for _ in range(180):
        live = _live()
        if live is not None and hasattr(live, "_wake_sleep_timeout"):
            live._wake_sleep_timeout = saved
            print(f"[tv_nosleep] auto-sleep timeout restored to {saved:.0f} s")
            return
        time.sleep(2)


threading.Thread(target=_restore_on_start, name="tv-nosleep-restore", daemon=True).start()


def _describe(sec: float) -> str:
    return "never" if sec >= NEVER else f"after {sec / 60:.0f} min of silence"


def run(parameters: dict, player=None) -> str:
    p = parameters or {}
    action = str(p.get("action") or "on").lower().strip()
    live = _live(player)
    if live is None or not hasattr(live, "_wake_sleep_timeout"):
        return "I could not reach the assistant's sleep timer."
    if action == "status":
        mode = "wake-word mode" if getattr(live, "_wake_enabled", False) else "wake word is off, so it never auto-sleeps anyway"
        return f"Auto-sleep: {_describe(live._wake_sleep_timeout)} ({mode})."
    if action == "on":
        seconds = NEVER
    elif action == "off":
        seconds = DEFAULT
    elif action == "minutes":
        try:
            seconds = max(1.0, float(p.get("value"))) * 60
        except (TypeError, ValueError):
            return "How many minutes?"
    else:
        return f"Unknown action '{action}'. Use on, off, minutes or status."
    _apply(live, seconds)
    _save(None if seconds == DEFAULT else seconds)
    msg = f"Auto-sleep: {_describe(seconds)}."
    _log(player, msg)
    return msg
