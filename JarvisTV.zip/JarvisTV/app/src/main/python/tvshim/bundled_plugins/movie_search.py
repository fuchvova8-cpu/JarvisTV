"""Поиск фильмов и сериалов во всех видеосервисах ТВ — общий плагин (объединяет обе версии) со страницей настроек.

Как «ATV поиск»: у видео-приложений (Lazy Media Deluxe, Zona, HDRezka, KinoPub, Seasonvar…) есть
поисковые провайдеры Android TV (content://<authority>/search_suggest_query/…). Плагин опрашивает их
изнутри приложения (ContentResolver, без root), а если так не вышло — запасными путями через ADB
(`content query`) и, по желанию, root. Результаты — плитками на экране JARVIS (или списком текста).
Открытие — по номеру («открой номер 3»). Режим «apk» (по умолчанию) повторяет «ATV Поиск» из его APK: Lazy Media —
ссылка tvhomechannels://…/article/<закодированные данные>, Zona — https://mobi.zona/… с NEW_TASK|CLEAR_TASK,
остальные — окно поиска приложения (searchable) + данные/действие/extra строки результата, флаг NEW_TASK;
если не открылось — повтор без окна (только пакет), затем запуск самого приложения.

Действия: search | open_result (или open_number) | apps | open | sources | screen.
Настройки: Меню → Настройки плагинов → «Поиск фильмов».
"""
import json
import os
import re
import shlex
import threading
import time
import urllib.parse
import urllib.request
import difflib
import xml.etree.ElementTree as ET

import android_bridge as android

PLUGIN = {
    "name": "movie_search",
    "description": (
        "Поиск фильмов/сериалов/видео по ВСЕМ видеосервисам на ТВ (Lazy Media, Zona, FreeZona, HDRezka и др.) "
        "с плитками на экране. Короткие действия (action): «поиск» + query — найти (сузить: service/app — «зона», "
        "«lazy», «rezka»); «номер» + open_number — открыть результат из последнего поиска; «приложения» — кто умеет "
        "искать; «запуск» + app — запустить приложение; «источники» — сколько результатов дал каждый источник; "
        "service «tunnel» (или action «tunnel») — найти и сразу открыть страницу фильма в Tunnel; «экран» — прочитать текст с экрана; «отладка» + index — как приложение описало результат; «ссылки» + app "
        "(пакет) — какие ссылки принимает приложение; «запись» — начать запись запусков (очистить журнал); "
        "«запуски» (+ app — пакет) — показать записанные запуски других приложений (например ATV Поиска). "
        "(Английские search, open_result, apps, open, sources, screen, debug, links, trace_start, trace_show "
        "тоже работают.) Вызывай на «найди фильм…», «поищи сериал…», «открой номер 3», «включи второй». "
        "После поиска скажи пользователю кратко и предложи открыть по номеру."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING", "description": "поиск | номер | приложения | запуск | источники | экран | отладка | ссылки | запись | запуски (по умолчанию поиск)"},
            "query": {"type": "STRING", "description": "Что искать: название фильма или сериала"},
            "service": {"type": "STRING", "description": "Необязательно: только в этом сервисе («зона», «lazy», «rezka»)"},
            "app": {"type": "STRING", "description": "То же, что service; для action=open — какое приложение запустить"},
            "open_number": {"type": "INTEGER", "description": "Открыть результат с этим номером из последнего показа"},
            "index": {"type": "INTEGER", "description": "То же, что open_number (для action=open_result)"},
        },
    },
}

SETTINGS = {"title": "Поиск фильмов"}

DEFAULT_SERVICES = "lazy\nzona\nзона\nrezka\nрезка\nkinopub\nlampa\nvimu\nivi\nokko\nkion\nwink"
DEFAULT_SOURCE_NAMES = "4=Encyclopedia\n13=Zona\n23=Eneyida"
DEFAULTS = {
    "services": DEFAULT_SERVICES,       # ключевые слова сервисов
    "all_tv": False,                    # если не нашлись — искать во всех ТВ-приложениях
    "use_adb": True,                    # запасной путь: ADB (`content query`, `dumpsys`)
    "use_root": False,                  # запасной путь: su
    "show_source": True,                # подписывать источник внутри приложения (Zona, Eneyida…)
    "use_tunnel": False,                # искать и в Tunnel при обычном поиске (медленнее: до 15 с)
    "source_names": DEFAULT_SOURCE_NAMES,
    "per_source": 6,                    # сколько результатов с каждого источника внутри приложения
    "max_total": 60,                    # всего плиток на экране
    "fetch_limit": 50,                  # сколько просить у провайдера (в ATV Поиск — 50)
    "timeout": 12,                      # секунд ждать до первого показа
    "late_wait": 30,                    # сколько секунд дособирать медленные сервисы и добавлять плитки (0 = выкл)
    "open_how": "apk",                  # apk | atv | normal | clean | twice — как открывать результат
    "reopen_delay": 3,                  # для twice: через сколько секунд повторить ссылку
}
OPEN_MODES = ("apk", "atv", "normal", "clean", "twice")
OPEN_MODE_NAMES = {"apk": "точно как ATV Поиск (по его APK)", "atv": "как ATV Поиск (точное окно + чистый запуск)", "normal": "обычно", "clean": "чистый перезапуск приложения",
                   "twice": "запуск, потом ссылка повторно"}

ALIASES = {"зона": "zona", "зону": "zona", "резка": "rezka", "рэзка": "rezka", "резку": "rezka", "лейзи": "lazy",
           "лази": "lazy", "лэйзи": "lazy", "кинопаб": "kinopub", "лампа": "lampa", "иви": "ivi", "окко": "okko"}
ACTION_ALIASES = {
    "поиск": "search", "найти": "search", "найди": "search",
    "номер": "open_result", "результат": "open_result", "включи": "open_result",
    "приложения": "apps", "сервисы": "apps",
    "запуск": "open", "запусти": "open",
    "источники": "sources",
    "экран": "screen",
    "отладка": "debug", "разбор": "debug",
    "ссылки": "links",
    "запись": "trace_start", "старт": "trace_start",
    "запуски": "trace_show", "итог": "trace_show", "покажи": "trace_show",
}
# authority -> пакет приложения (таблица из ATV Поиск); эти провайдеры опрашиваются, даже если система их не показала
AUTH_PKG = {
    "com.lazycatsoftware.lmd.tvsearch": "com.lazycatsoftware.lmd",
    "com.lazycatsoftware.lmd.searchable": "com.lazycatsoftware.lmd",
    "mobi.zona.TvSearchProvider": "mobi.zona",
    "ru.zona.app.android.tv.search": "mobi.zona",
    "free.zona.TvSearchProvider": "free.zona",
    "com.hdrezka.compose.search": "com.hdrezka.compose",
    "com.seena.app.search": "com.seena.app",
    "ru.vokino.web": "ru.vokino.web",
    "app.tunnel.tv.search": "app.tunnel.tv",          # Tunnel (патч-версия APK)
}
KNOWN_AUTHORITIES = tuple(AUTH_PKG)
VIEW = "android.intent.action.VIEW"
F_NEW_TASK = 0x10000000                  # FLAG_ACTIVITY_NEW_TASK
F_NEW_CLEAR = 0x10008000                 # NEW_TASK | CLEAR_TASK (268468224) — так ATV Поиск открывает Zona
LMD_PKG = "com.lazycatsoftware.lmd"
LMD_DEEP = "tvhomechannels://com.lazycatsoftware.lmd/article/"
ZONA_PKGS = ("free.zona", "mobi.zona")
TUNNEL_PKG = "app.tunnel.tv"                 # Tunnel (патч-версия с ссылкой tunnel://search?q=…)
TUNNEL_WORDS = ("tunnel", "тунел", "туннел", "тоннел", "тонел", "танел", "таннел")


def _is_tunnel(text):
    t = (text or "").strip().lower()
    return bool(t) and any(w in t for w in TUNNEL_WORDS)
ZONA_HOME = "https://mobi.zona/home_screen/"
ZONA_BASE = "https://mobi.zona/"
SKIP_PKGS = ("com.tvvoicesearch.app", "com.android.", "com.google.", "com.mitv", "com.xiaomi", "com.mi.", "android")
LABELS = {"lazycatsoftware": "Lazy Media", "hdrezka": "HDRezka", "kinopub": "KinoPub",
          "season2hit": "Seasonvar", "greenline": "Greenline", "seena": "Seena", "tunnel": "Tunnel"}
CHROME = {"поиск", "search", "меню", "menu", "назад", "back", "ok", "ок", "home", "домой"}
DUMP = "/data/local/tmp/mark_ui.xml"
_PKG_RE = re.compile(r"^[A-Za-z0-9_.]+$")
_AUTH_RE = re.compile(r"^[A-Za-z0-9_.\-]+$")
_KV_RE = re.compile(r"([A-Za-z_][A-Za-z0-9_]*)=(.*?)(?=, [A-Za-z_][A-Za-z0-9_]*=|$)")
_FAIL = ("error", "unable to resolve", "does not exist", "exception", "permission denial")

_last = []            # плитки последнего показа — для «открой номер N»
_last_rows = []       # все строки последнего опроса — для «источники»
_last_shown = []      # строки, показанные плитками (под теми же номерами) — для «отладка»
_provs_cache = []     # найденные провайдеры
_gen = 0              # номер последнего поиска (чтобы старый «досбор» не трогал новые плитки)
_done = {}            # gen -> {(authority, label)} — кто уже ответил
LATE_GRACE = 4        # секунд после первых результатов, потом показываем, остальных дособираем
_lock = threading.Lock()
_tmdb_cache = {}
_TMDB_API_KEY = "9b7ece6d144182b6c6cd9c7fef358b82"  # ключ из APK, ранее предоставленный пользователем


# ── настройки ───────────────────────────────────────────────────────────────
def _file():
    try:
        return os.path.join(android.data_dir() or ".", "movie_search.json")
    except Exception:
        return "movie_search.json"


def _int(v, lo, hi, d):
    try:
        return max(lo, min(hi, int(float(str(v).strip()))))
    except (TypeError, ValueError):
        return d


def _cfg():
    try:
        with open(_file(), encoding="utf-8") as f:
            c = json.load(f)
        if not isinstance(c, dict):
            c = {}
    except Exception:
        c = {}
    out = dict(DEFAULTS)
    out.update({k: v for k, v in c.items() if k in DEFAULTS})
    out["per_source"] = _int(out["per_source"], 1, 30, 6)
    out["max_total"] = _int(out["max_total"], 5, 200, 60)
    out["fetch_limit"] = _int(out["fetch_limit"], 10, 500, 200)
    out["timeout"] = _int(out["timeout"], 4, 60, 12)
    out["late_wait"] = _int(out["late_wait"], 0, 120, 30)
    out["reopen_delay"] = _int(out["reopen_delay"], 1, 15, 3)
    if out["open_how"] not in OPEN_MODES:
        out["open_how"] = "apk"
    return out


def _save(c):
    try:
        with open(_file(), "w", encoding="utf-8") as f:
            json.dump(c, f, ensure_ascii=False, indent=1)
    except Exception as e:
        _log("movie_search: не сохранить: %s" % e)


REPORT = "movie_search_report.txt"


def _report(title, text):
    """Полный текст отладки — в файл <Jarvis>/movie_search_report.txt (его можно забрать и прислать целиком)."""
    try:
        home = os.environ.get("JARVIS_HOME") or "."
        with open(os.path.join(home, REPORT), "a", encoding="utf-8") as f:
            f.write("=== %s  %s ===\n%s\n\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), title, text))
    except Exception:
        pass


def _log(t):
    try:
        android.log(t)
    except Exception:
        pass


def _service_poster_available(image):
    """Проверить в фоне, доступен ли постер провайдера; локальные URI оставить сервису."""
    if not image:
        return False
    try:
        parsed = urllib.parse.urlparse(str(image))
        if parsed.scheme in ("content", "file"):
            return True
        if parsed.scheme not in ("http", "https"):
            return False
        req = urllib.request.Request(str(image), headers={
            "Range": "bytes=0-0", "User-Agent": "JarvisTV/1.0",
            "Accept": "image/*,*/*;q=0.8",
        })
        with urllib.request.urlopen(req, timeout=3) as response:
            content_type = str(response.headers.get("Content-Type", "")).lower()
            return response.status < 400 and content_type.startswith("image/") and bool(response.read(1))
    except Exception:
        return False


def _tmdb_poster(title, year=""):
    """Искать постер в TMDB только если постер видеосервиса отсутствует/недоступен."""
    title = str(title or "").strip()
    if not title:
        return ""
    key = (" ".join(re.findall(r"[a-zа-яё0-9]+", title.lower().replace("ё", "е"))), str(year or ""))
    with _lock:
        if key in _tmdb_cache:
            return _tmdb_cache[key]
    params = urllib.parse.urlencode({"api_key": _TMDB_API_KEY, "query": title, "language": "ru-RU", "page": 1})
    url = "https://api.themoviedb.org/3/search/multi?" + params
    poster = ""
    try:
        req = urllib.request.Request(url, headers={"Accept": "application/json", "User-Agent": "JarvisTV/1.0"})
        with urllib.request.urlopen(req, timeout=5) as response:
            payload = json.loads(response.read(1024 * 1024).decode("utf-8", "replace"))
        wanted = key[0]
        candidates = []
        for item in payload.get("results", []) if isinstance(payload, dict) else []:
            if not isinstance(item, dict) or item.get("media_type") not in ("movie", "tv"):
                continue
            path = str(item.get("poster_path") or "").strip()
            candidate_title = str(item.get("title") or item.get("name") or "")
            if not path.startswith("/") or not candidate_title:
                continue
            normalized = " ".join(re.findall(r"[a-zа-яё0-9]+", candidate_title.lower().replace("ё", "е")))
            score = difflib.SequenceMatcher(None, wanted, normalized).ratio()
            date = str(item.get("release_date") or item.get("first_air_date") or "")
            if wanted == normalized:
                score += 0.25
            elif wanted in normalized or normalized in wanted:
                score += 0.10
            if year and date[:4] == str(year):
                score += 0.12
            candidates.append((score, path))
        candidates.sort(reverse=True)
        if candidates and candidates[0][0] >= 0.48:
            poster = "https://image.tmdb.org/t/p/w342" + candidates[0][1]
    except Exception as e:
        _log("movie_search: TMDB постер «%s»: %s" % (title[:70], str(e)[:120]))
    with _lock:
        _tmdb_cache[key] = poster
    return poster


def _tmdb_poster_worker(gen, query, cards):
    """Заменить только пустые/недоступные картинки; не трогать данные открытия карточек."""
    changed = False
    for card in list(cards)[:24]:
        if gen != _gen:
            return
        old_image = card.get("image", "")
        if _service_poster_available(old_image):
            continue
        poster = _tmdb_poster(card.get("title", ""), card.get("year", ""))
        if not poster:
            continue
        with _lock:
            if gen != _gen or not any(item is card for item in _last):
                continue
            if card.get("image", "") != old_image:
                continue
            card["image"] = poster
            changed = True
    if changed and gen == _gen:
        with _lock:
            all_cards = list(_last)
        try:
            android.show_results("Поиск: " + query, all_cards)
        except Exception as e:
            _log("movie_search: не обновить постеры: %s" % e)


def _keywords(c):
    words = [x.strip().lower() for x in re.split(r"[\n,;]+", str(c.get("services", ""))) if x.strip()]
    if c.get("use_tunnel") and "tunnel" not in words:
        words.append("tunnel")
    return words


def _source_names(c):
    out = {}
    for line in re.split(r"[\n,;]+", str(c.get("source_names", ""))):
        m = re.match(r"^\s*([^=:\s]+)\s*[=:\s]\s*(.+?)\s*$", line)
        if m:
            out[m.group(1)] = m.group(2)
    return out


# ── общие мелочи ────────────────────────────────────────────────────────────
def _sh(cmd):
    return str(android.shell(cmd))


def _body(res):
    return res[3:].strip() if res.startswith("ok:") else ("" if res == "ok" else res)


def _g(row, *keys):
    for k in keys:
        v = row.get(k)
        if v and str(v).strip() and str(v).strip().lower() != "null":
            return str(v).strip()
    return ""


def _label_of(pkg, labels=None):
    if labels and labels.get(pkg):
        return labels[pkg]
    for k, v in LABELS.items():
        if k in pkg.lower():
            return v
    last = pkg.split(".")[-1]
    return pkg if last in ("app", "tv", "android") else last


def _skipped(pkg):
    return any(pkg == s or pkg.startswith(s) for s in SKIP_PKGS)


# ── поиск провайдеров ───────────────────────────────────────────────────────
def _adb_providers():
    """[(authority, package)] через ADB (dumpsys/pm). Пусто, если ADB недоступен."""
    out = _body(_sh("dumpsys package providers"))
    if out.startswith("ADB:"):
        return []
    found, cur = [], None
    for line in out.splitlines():
        m = re.match(r"^\s*\[([^\]]+)\]:\s*$", line)
        if m:
            cur = m.group(1)
            continue
        m = re.search(r"Provider\{\w+ ([A-Za-z0-9_.]+)/", line)
        if m and cur:
            pkg, auth = m.group(1), cur
            if "search" in auth.lower() and _AUTH_RE.match(auth) and not _skipped(pkg):
                found.append((auth, pkg))
            cur = None
    have = {a for a, _ in found}
    for p in re.findall(r"package:([A-Za-z0-9_.]+)", _body(_sh("pm list packages"))):
        if any(h in p.lower() for h in LABELS) and not _skipped(p):
            cands = [p + ".searchable"] + re.findall(r"([A-Za-z0-9_.]+\.(?:searchable|search|suggest))\b",
                                                      _sh("dumpsys package %s" % p))
            for a in cands:
                if a not in have:
                    have.add(a)
                    found.append((a, p))
    return found


def _providers(service="", c=None):
    """[(authority, pkg, label)] — кого опрашивать. None — список получить не удалось."""
    c = c or _cfg()
    labels, tv = {}, set()
    try:
        for a in (android.list_apps() or []):
            labels[a.get("pkg")] = a.get("label", "")
            if a.get("tv"):
                tv.add(a.get("pkg"))
    except Exception:
        pass
    allp = None
    if android.in_app_search():
        allp = android.provider_list()
    if (allp is None or not allp) and c["use_adb"]:
        adb = _adb_providers()
        if adb:
            allp = adb
    if allp is None:
        return None
    allp = [(a, AUTH_PKG.get(a, p)) for a, p in allp if not _skipped(p)]
    have = {a for a, _ in allp}
    for auth in KNOWN_AUTHORITIES:                     # известные, даже если система их не показала
        if auth not in have and (not labels or AUTH_PKG[auth] in labels):
            allp.append((auth, AUTH_PKG[auth]))
    service = (service or "").strip().lower()
    words = [service, ALIASES.get(service, service)] if service else _keywords(c)
    out, seen = [], set()
    for auth, pkg in allp:
        label = _label_of(pkg, labels)
        hay = ("%s %s %s" % (pkg, labels.get(pkg, ""), auth)).lower() + " " + label.lower()
        if any(w and w in hay for w in words):
            out.append((auth, pkg, label))
            seen.add(auth)
    if not out and c["all_tv"] and not service:
        for auth, pkg in allp:
            if (pkg in tv or not tv) and auth not in seen:
                out.append((auth, pkg, _label_of(pkg, labels)))
    return out


# ── опрос ───────────────────────────────────────────────────────────────────
def _parse_rows(text):
    rows = []
    for line in text.splitlines():
        m = re.match(r"^\s*Row:\s*\d+\s+(.*)$", line)
        if m:
            row = {k: v.strip() for k, v in _KV_RE.findall(m.group(1))}
            if row.get("suggest_text_1"):
                rows.append(row)
    return rows


def _shell_rows(auth, q, root, limit):
    diag = ""
    for suffix in ("?limit=%d" % limit, ""):
        cmd = "content query --uri %s" % shlex.quote("content://%s/search_suggest_query/%s%s" % (auth, q, suffix))
        if root:
            cmd = "su -c %s" % shlex.quote(cmd)
        out = _sh(cmd)
        if out.startswith("ADB:"):
            return [], out[:140]
        body = _body(out)
        rows = _parse_rows(body)
        if rows:
            return rows, ""
        diag = (body.splitlines()[0] if body else "пустой ответ")[:120]
        if "no result found" in body.lower():
            break
    return [], diag


def _src(row):
    sid = _g(row, "suggest_source_id")
    if sid:
        return sid[:30]
    d = row.get("suggest_intent_data") or ""
    mm = re.match(r"^(\d{1,3}),", d)
    if mm:
        return mm.group(1)
    try:
        u = urllib.parse.urlparse(d)
        key = u.netloc or u.scheme
        return key if len(key) <= 30 else ""
    except Exception:
        return ""


def _tag(rows, pkg, label, names, limit, query="", auth=""):
    out = []
    for r in rows:
        if not _g(r, "suggest_text_1", "text1"):
            continue
        r["suggest_text_1"] = _g(r, "suggest_text_1", "text1")
        r["_pkg"], r["_app"], r["_uq"], r["_auth"] = pkg, label, query, auth
        r["_src"] = _src(r)
        r["_src_name"] = (names.get(r["_src"]) or (r["_src"] if not r["_src"].isdigit() else "источник " + r["_src"])) if r["_src"] else ""
        out.append(r)
    return out[:limit]


def _query_one(auth, pkg, label, query, c, names):
    """Пробует способы по очереди, пока не появятся результаты. Возвращает (rows, заметка)."""
    q = urllib.parse.quote(query, safe="")
    lim = c["fetch_limit"]
    notes = []
    if android.in_app_search():
        rows, err = android.provider_query(auth, query, lim)           # как системный поиск
        if rows:
            return _tag(rows, pkg, label, names, lim, query, auth), ""
        notes.append("searchable: " + (err or "пусто"))
        base = "content://%s/search_suggest_query" % auth
        for uri, sel, arg in ((base + "/" + q + "?limit=%d" % lim, None, None), (base + "/" + q, None, None),
                              (base + "?limit=%d" % lim, "?", query), (base + "?limit=%d" % lim, " ?", query),
                              (base, "?", query)):
            rows, err = android.query_uri(uri, sel, arg)
            if rows:
                return _tag(rows, pkg, label, names, lim, query, auth), ""
            if err:
                notes.append(err[:90])
                if "securityexception" in err.lower() or "permission" in err.lower():
                    break
    for root in ((False, True) if c["use_root"] else (False,)):
        if not c["use_adb"] and not root:
            continue
        rows, diag = _shell_rows(auth, q, root, lim)
        if rows:
            return _tag(rows, pkg, label, names, lim, query, auth), ""
        notes.append(("root: " if root else "adb: ") + diag)
    return [], " | ".join(dict.fromkeys(notes))[:300]


def _diversify(rows, c):
    """С каждого приложения — по несколько результатов с каждого источника; приложения с источниками — первыми."""
    byapp = {}
    for r in rows:
        byapp.setdefault(r["_pkg"], []).append(r)
    multi, single = [], []
    for rs in byapp.values():
        groups = {}
        for r in rs:
            groups.setdefault(r.get("_src", ""), []).append(r)
        if len(groups) >= 2:
            for g in groups.values():
                for r in g[:c["per_source"]]:
                    r["_show_src"] = True
                    multi.append(r)
        else:
            single += rs[:max(8, c["per_source"])]
    return (multi + single)[:c["max_total"]]


def _distribution(rows):
    cnt = {}
    for r in rows:
        k = "%s / %s" % (r.get("_app", "?"), r.get("_src_name") or "—")
        cnt[k] = cnt.get(k, 0) + 1
    return ["%s: %d" % (k, v) for k, v in cnt.items()]


# ── открытие ────────────────────────────────────────────────────────────────
def _full_data(row):
    data = _g(row, "suggest_intent_data", "_default_data")
    did = _g(row, "suggest_intent_data_id")
    return (data.rstrip("/") + "/" + urllib.parse.quote(did, safe="")) if data and did else data


def _t2(row):
    """suggest_text_2 как в ATV Поиск: SERIAL/MOVIE -> по-русски, ENCYCLOPEDIA убирается."""
    t = _g(row, "suggest_text_2")
    u = t.strip().upper()
    if u == "SERIAL":
        return "Сериал"
    if u == "MOVIE":
        return "Фильм"
    return t.replace("ENCYCLOPEDIA", "").strip()


def _apk_spec(row):
    """Интент открытия результата — ровно как в ATV Поиск (VoiceSearchActivity.w6).
    Возвращает dict: action, data, pkg, comp, flags, extras. data == '' — ссылки нет."""
    pkg = row.get("_pkg", "")
    v = _g(row, "suggest_intent_data")           # intent data строки
    x = _g(row, "suggest_intent_data_id")        # data id
    y = _g(row, "suggest_intent_extra_data")     # extra data
    w = _g(row, "suggest_intent_action")         # action строки
    if pkg == LMD_PKG and (v or x):                 # Lazy Media: deep link на статью
        return {"action": VIEW, "data": LMD_DEEP + urllib.parse.quote(v or x, safe="!'()*"),
                "pkg": pkg, "comp": "", "flags": F_NEW_TASK, "extras": {}, "kind": "lmd"}
    if pkg in ZONA_PKGS and v.startswith(ZONA_HOME):   # Zona: home_screen/<x> -> https://mobi.zona/<x>
        return {"action": VIEW, "data": ZONA_BASE + v[len(ZONA_HOME):], "pkg": pkg, "comp": "",
                "flags": F_NEW_CLEAR, "extras": {}, "kind": "zona"}
    if pkg == TUNNEL_PKG and v.startswith("tunnel://"):   # Tunnel: поиск по названию + адрес карточки -> сразу страница фильма
        return {"action": VIEW, "data": v, "pkg": pkg, "comp": "", "flags": F_NEW_CLEAR, "extras": {}, "kind": "tunnel"}
    comp = _g(row, "_component")                  # окно поиска приложения (searchable)
    cdata = _g(row, "_default_data")              # intent data по умолчанию у searchable
    data = ""
    if v and "://" in v:
        data = v
        if x:
            data = (v + x) if v.endswith("/") else (v + "/" + x)
    elif cdata:
        data = cdata + "/" + x
    elif x:
        data = "content://%s/%s" % (row.get("_auth", ""), x)
    extras = {"intent_extra_data_key": y} if y else {}
    return {"action": w or _g(row, "_default_action") or VIEW, "data": data, "pkg": pkg,
            "comp": comp if (comp and re.match(r"^[A-Za-z0-9_.$/]+$", comp)) else "",
            "flags": F_NEW_TASK, "extras": extras, "kind": "generic"}


def _spec_intent(sp, with_comp=True):
    """dict для android.open_intents (внутри приложения)."""
    it = {"name": "apk-" + sp.get("kind", "?"), "action": sp["action"], "data": sp["data"],
          "flags": sp["flags"], "extras": dict(sp["extras"])}
    if with_comp and sp["comp"]:
        it["comp"] = sp["comp"]
    else:
        it["pkg"] = sp["pkg"]
    return it


def _spec_cmd(sp, with_comp=True):
    """Та же команда для `am start` (ADB)."""
    cmd = "am start -a %s -d %s" % (shlex.quote(sp["action"]), shlex.quote(sp["data"]))
    if with_comp and sp["comp"]:
        cmd += " -n %s" % sp["comp"]
    elif sp["pkg"] and _PKG_RE.match(sp["pkg"]):
        cmd += " -p %s" % sp["pkg"]
    for k, val in sp["extras"].items():
        cmd += " --es %s %s" % (shlex.quote(k), shlex.quote(val))
    return cmd + " -f %d" % sp["flags"]


def _intents(row):
    pkg = row.get("_pkg", "")
    action = _g(row, "suggest_intent_action", "_default_action") or "android.intent.action.VIEW"
    full = _full_data(row)
    did = _g(row, "suggest_intent_data_id")
    ex = {}
    if _g(row, "suggest_intent_extra_data"):
        ex["intent_extra_data_key"] = _g(row, "suggest_intent_extra_data")
    uq = row.get("_uq", "")
    if uq:
        ex["user_query"] = uq                                   # то, что набрал пользователь (как у системного поиска)
    if _g(row, "suggest_intent_query") or uq:
        ex["query"] = _g(row, "suggest_intent_query") or uq
    out = []
    if pkg.startswith("com.lazycatsoftware.lmd") and did:           # deep link, как у «ATV поиск»
        out.append({"name": "lmd-deeplink", "action": "android.intent.action.VIEW", "pkg": pkg,
                    "data": "tvhomechannels://com.lazycatsoftware.lmd/article/" + urllib.parse.quote(did, safe="")})
    comp = _g(row, "_component")
    if comp:
        out.append({"name": "search-activity", "action": action, "data": full, "comp": comp, "extras": ex})
    if pkg:
        out.append({"name": "package", "action": action, "data": full, "pkg": pkg, "extras": ex})
    if full:
        out.append({"name": "view", "action": "android.intent.action.VIEW", "data": full, "pkg": pkg})
    return out


def _cmds(row):
    pkg = row.get("_pkg", "")
    action = _g(row, "suggest_intent_action", "_default_action") or "android.intent.action.VIEW"
    data = _full_data(row)
    extras = ""
    if _g(row, "suggest_intent_extra_data"):
        extras += " --es intent_extra_data_key %s" % shlex.quote(_g(row, "suggest_intent_extra_data"))
    if row.get("_uq"):
        extras += " --es user_query %s" % shlex.quote(row["_uq"])
    if _g(row, "suggest_intent_query") or row.get("_uq"):
        extras += " --es query %s" % shlex.quote(_g(row, "suggest_intent_query") or row["_uq"])
    d = (" -d %s" % shlex.quote(data)) if data else ""
    a = " -a %s" % shlex.quote(action)
    cmds = []
    comp = _g(row, "_component")
    if comp and re.match(r"^[A-Za-z0-9_.$/]+$", comp):
        cmds.append("am start%s%s -n %s%s" % (a, d, comp, extras))
    if pkg and _PKG_RE.match(pkg):
        cmds.append("am start%s%s -p %s%s" % (a, d, pkg, extras))
        if data:
            cmds.append("am start -a android.intent.action.VIEW%s -p %s" % (d, pkg))
    if data:
        cmds.append("am start%s%s%s" % (a, d, extras))
    return cmds


def _card(row, c):
    sub = [x for x in (_g(row, "suggest_production_year"), _t2(row)) if x]
    rating = ("★" + _g(row, "suggest_rating_score")) if _g(row, "suggest_rating_score") else ""
    if rating:
        sub.append(rating)
    image = _g(row, "suggest_result_card_image", "suggest_icon_1", "icon1")
    if not image.startswith(("http://", "https://", "content://", "file://")):
        image = ""
    app = row.get("_app", "")
    if c["show_source"] and row.get("_show_src") and row.get("_src_name"):
        app += " · " + row["_src_name"]
    atv = ""
    if c["open_how"] == "atv" and c.get("_adb"):
        try:
            atv = _atv_cmd(row.get("_pkg", ""), _g(row, "suggest_intent_action", "_default_action"),
                           _full_data(row), _g(row, "_component"))
        except Exception:
            atv = ""
    spec = _apk_spec(row)
    if c["open_how"] == "apk":
        intents = [_spec_intent(spec)] + ([_spec_intent(spec, False)] if spec["comp"] else [])
        cmds = [_spec_cmd(spec)] + ([_spec_cmd(spec, False)] if spec["comp"] else [])
    else:
        intents, cmds = ([] if atv else _intents(row)), ([atv] if atv else []) + _cmds(row)
    return {"title": row.get("suggest_text_1", "?"), "sub": ", ".join(str(x) for x in sub)[:60],
            "year": _g(row, "suggest_production_year"), "rating": rating,
            "desc": _t2(row), "image": image, "spec": spec,
            "intents": intents, "cmds": cmds, "atv": atv,
            "app": app, "pkg": row.get("_pkg", ""),
            "action": _g(row, "suggest_intent_action", "_default_action") or "android.intent.action.VIEW",
            "data": _full_data(row), "comp": _g(row, "_component")}


def _text_line(card):
    extra = [x for x in (card.get("year"), card.get("desc"), card.get("rating")) if x]
    return "[%s] %s%s" % (card["app"], card["title"], (" — " + ", ".join(extra)) if extra else "")


_comp_cache = {}


def _resolve_component(pkg, action, data):
    """Окно приложения, которое принимает эту ссылку (как это делает система), через ADB."""
    key = (pkg, action, data.split("/")[2] if "://" in data else data)
    if key in _comp_cache:
        return _comp_cache[key]
    out = _body(_sh("cmd package resolve-activity --brief -a %s -d %s -p %s" % (
        shlex.quote(action), shlex.quote(data), shlex.quote(pkg))))
    comp = ""
    for ln in reversed(out.splitlines()):
        ln = ln.strip()
        if re.match(r"^[A-Za-z0-9_.]+/[A-Za-z0-9_.$]+$", ln):
            comp = ln
            break
    if not comp:                                           # запасной путь: из фильтров пакета
        dump = _body(_sh("dumpsys package %s" % pkg))
        m = re.search(r"\s(%s/[A-Za-z0-9_.$]+) filter" % re.escape(pkg), dump)
        comp = m.group(1) if m else ""
    if comp:
        _comp_cache[key] = comp
    return comp


def _atv_cmd(pkg, action, data, comp=""):
    """Команда как у «ATV Поиск»: VIEW + ссылка + окно приложения + NEW_TASK|CLEAR_TASK, без extras. '' — не получилось."""
    if not (pkg and data and _PKG_RE.match(pkg)) or pkg.startswith("com.lazycatsoftware.lmd"):
        return ""
    action = action or "android.intent.action.VIEW"
    comp = comp or _resolve_component(pkg, action, data)
    if not comp or not re.match(r"^[A-Za-z0-9_.$/]+$", comp):
        return ""
    return "am start -a %s -d %s -n %s -f 268468224" % (shlex.quote(action), shlex.quote(data), comp)


def _adb_ok():
    try:
        return _sh("echo ok").strip().endswith("ok")
    except Exception:
        return False


def _open_atv(it, c):
    """Как «ATV Поиск» (по записи запусков): VIEW + ссылка + конкретное окно приложения + NEW_TASK|CLEAR_TASK, без extras."""
    if not c["use_adb"]:
        return "ERR: ADB выключен"
    cmd = it.get("atv") or _atv_cmd(it.get("pkg", ""), it.get("action", ""), it.get("data", ""), it.get("comp", ""))
    if not cmd:
        return "ERR: не для этого приложения"
    out = _sh(cmd)
    low = out.lower()
    if low.startswith("adb:") or any(w in low for w in _FAIL):
        return "ERR: " + out[:100]
    return "ok:atv"


def _launch_spec(it, sp, c, with_comp):
    """Один запуск по spec: сначала ADB `am start` (точные флаги), затем изнутри приложения."""
    res = "ERR: нет связи"
    if not sp.get("data"):
        return "ERR: у результата нет ссылки"
    if c["use_adb"]:
        out = _sh(_spec_cmd(sp, with_comp))
        low = out.lower()
        if not (low.startswith("adb:") or any(w in low for w in _FAIL)):
            return "ok:adb"
        res = "ERR: " + out[:100]
    r2 = android.open_intents(it["title"], [_spec_intent(sp, with_comp)]) or "ERR: нет связи"
    return r2 if r2.startswith("ok") else (res if res != "ERR: нет связи" else r2)


def _open_apk(it, c):
    """Как ATV Поиск: интент по spec; не вышло — без окна (только пакет); не вышло — запуск самого приложения."""
    sp = it.get("spec")
    if not sp:
        return "ERR: нет данных результата"
    res = _launch_spec(it, sp, c, True)
    if not res.startswith("ok") and sp["comp"]:
        res = _launch_spec(it, sp, c, False)
    if not res.startswith("ok") and sp.get("pkg") and _launch(sp["pkg"]):
        return "ok:launcher"
    return res


def _open_once(it, c, flags=""):
    """Один заход: интенты изнутри приложения, затем (если можно) командами ADB. -> 'ok...' или 'ERR...'."""
    res = "ERR: нет связи"
    if not flags:                                   # флаги (чистый запуск) умеет только ADB
        res = android.open_intents(it["title"], it["intents"]) or "ERR: нет связи"
    if not res.startswith("ok") and c["use_adb"]:
        for cmd in it.get("cmds", []):
            if flags:
                cmd = cmd.replace("am start", "am start " + flags, 1)
            out = _sh(cmd)
            low = out.lower()
            if not (low.startswith("adb:") or any(w in low for w in _FAIL)):
                return "ok:shell"
            res = "ERR: " + out[:100]
    return res


def _tunnel_search(query, c):
    """Tunnel: у него нет поискового провайдера, поэтому открываем его окно поиска ссылкой tunnel://search?q=…
    (нужна патч-версия APK). NEW_TASK|CLEAR_TASK — чтобы приложение стартовало заново с этой ссылкой."""
    data = "tunnel://search?q=" + urllib.parse.quote(query, safe="")
    sp = {"action": VIEW, "data": data, "pkg": TUNNEL_PKG, "comp": "", "flags": F_NEW_CLEAR, "extras": {}, "kind": "tunnel"}
    it = {"title": query}
    res = _launch_spec(it, sp, c, False)
    if not res.startswith("ok"):
        return "Не открылось в Tunnel: %s. Нужна патч-версия Tunnel со ссылкой tunnel://search." % res[:100]
    _log("movie_search: Tunnel поиск «%s»: %s" % (query, res))
    return "Ищу «%s» в Tunnel и открою страницу фильма." % query


def _open(n, c):
    with _lock:
        items = list(_last)
    if not items:
        return "Сначала найдите фильм — результатов на экране нет."
    if n < 1 or n > len(items):
        return "Есть номера с 1 по %d." % len(items)
    it = items[n - 1]
    mode = c["open_how"]
    if mode == "apk":
        res = _open_apk(it, c)
    elif mode == "atv":
        res = _open_atv(it, c)
        if not res.startswith("ok"):
            res = _open_once(it, c)                         # не вышло — обычным способом
    elif mode == "clean" and c["use_adb"] and it.get("pkg"):
        _sh("am force-stop %s" % it["pkg"])
        time.sleep(0.6)
        res = _open_once(it, c, flags="-f 268468224")        # NEW_TASK | CLEAR_TASK
        if not res.startswith("ok"):
            res = _open_once(it, c)
    else:
        res = _open_once(it, c)
        if mode == "twice" and res.startswith("ok"):
            time.sleep(c["reopen_delay"])
            _open_once(it, c)
    _log("movie_search: открыто «%s» (режим %s): %s" % (it["title"], mode, res[:80]))
    if res.startswith("ok"):
        return "Открываю «%s» в %s." % (it["title"], it["app"].split(" · ")[0])
    return "Не открылось «%s»: %s" % (it["title"], res[:120])


def _trace_start():
    out = _sh("logcat -b all -c")
    if out.startswith("ADB:"):
        return "Нужен ADB: %s" % out[:100]
    return ("Журнал очищен. Теперь откройте нужный результат в «ATV Поиск» (где он открывается правильно), потом "
            "здесь же откройте тот же результат из Джарвиса, и скажите «запуски».")


def _trace_show(app=""):
    """Какие запуски приложений видела система: действие, ссылка, флаги, компонент, кто запустил."""
    out = _body(_sh("logcat -b all -d -v time | grep -E ' START u0 | START u[0-9]+ '"))
    if not out or out.startswith("ADB:"):
        return "Журнал пуст или нет ADB (%s). Сначала запись, потом откройте результат." % out[:80]
    lines = []
    for ln in out.splitlines():
        m = re.search(r"(\d\d:\d\d:\d\d)\.\d+.*START u\d+ \{(.*?)\}(?: from uid (\d+))?", ln)
        if not m:
            continue
        body = m.group(2)
        if "android.intent.category.HOME" in body or "com.android.systemui" in body:
            continue
        if app and app not in body:
            continue
        lines.append("%s uid=%s %s" % (m.group(1), m.group(3) or "?", body[:230]))
    if not lines:
        return "Запусков не нашлось%s." % ((" для «%s»" % app) if app else "")
    text = " || ".join(lines[-8:])
    _log("movie_search trace: " + text)
    _report("trace" + ((" " + app) if app else ""), "\n".join(lines))
    return "Запуски (старое → новое): " + text[:1500] + " Полный список в файле " + REPORT + " в папке Jarvis."


def _links(pkg):
    """Какие ссылки/действия принимает приложение (его intent-фильтры) — через ADB."""
    out = _body(_sh("dumpsys package %s" % pkg))
    if not out or out.startswith("ADB:"):
        return "Не удалось получить данные (нужен ADB): %s" % out[:100]
    keep, grab = [], 0
    for line in out.splitlines():
        t = line.strip()
        if "Scheme:" in t or "Authority:" in t or "Path:" in t or "PathPrefix:" in t or "PathPattern:" in t \
                or ("android.intent.action." in t and t.endswith(":")) or re.search(r"[0-9a-f]+ %s/\S+ filter" % re.escape(pkg), t):
            keep.append(t[:110])
    text = " | ".join(dict.fromkeys(keep))[:1800]
    _log("movie_search links %s: %s" % (pkg, text))
    _report("links " + pkg, "\n".join(dict.fromkeys(keep)))
    return "Приложение %s принимает: %s" % (pkg, text or "ничего не найдено")


# ── экран / запуск приложений ───────────────────────────────────────────────
def _launch(pkg):
    try:
        if android.launch_app(pkg).startswith("ok"):
            return True
    except Exception:
        pass
    for cat in ("LEANBACK_LAUNCHER", "LAUNCHER"):
        if "Events injected: 1" in _sh("monkey -p %s -c android.intent.category.%s 1" % (pkg, cat)):
            return True
    return False


def _screen_texts():
    out = ""
    for _ in range(2):
        out = _body(_sh("uiautomator dump %s >/dev/null 2>&1; cat %s" % (DUMP, DUMP)))
        if "<hierarchy" in out:
            break
        time.sleep(1.5)
    a, b = out.find("<hierarchy"), out.rfind("</hierarchy>")
    if a < 0 or b < 0:
        return None
    try:
        root = ET.fromstring(out[a:b + len("</hierarchy>")])
    except ET.ParseError:
        return None
    seen, items = set(), []
    for node in root.iter("node"):
        for attr in ("text", "content-desc"):
            v = (node.get(attr) or "").strip()
            if len(v) >= 2 and v.lower() not in CHROME and v not in seen:
                seen.add(v)
                items.append(v)
    return items


def _show(title, lines, player):
    if player is not None and hasattr(player, "show_content"):
        player.show_content(title, "\n".join("%d. %s" % (i + 1, t) for i, t in enumerate(lines[:60])))


def _debug(n):
    with _lock:
        rows = list(_last_shown)
        cards = list(_last)
    if not rows:
        return "Сначала выполните поиск."
    if not 1 <= n <= len(rows):
        n = 1
    r, card = rows[n - 1], cards[n - 1]
    skip = ("suggest_icon_1", "suggest_result_card_image")
    fields = "; ".join("%s=%s" % (k, str(v)[:90]) for k, v in r.items() if v and k not in skip and not k.startswith("_u"))
    variants = "; ".join(
        "%s[%s%s%s%s%s]" % (i["name"], i.get("action", "").rsplit(".", 1)[-1], (" " + i["data"][:90]) if i.get("data") else "",
                            (" comp=" + i["comp"]) if i.get("comp") else (" pkg=" + i["pkg"]) if i.get("pkg") else "",
                            (" f=%x" % i["flags"]) if i.get("flags") else "",
                            (" +" + ",".join(i["extras"])) if i.get("extras") else "") for i in card["intents"])
    text = "Результат %d «%s» (%s). Поля: %s. Варианты открытия по порядку: %s." % (
        n, card["title"], card["app"], fields, variants or "нет")
    _log("movie_search debug: " + text)
    _report("debug #%d" % n, text.replace("; ", "\n  ").replace(". Варианты", ".\nВарианты"))
    return text[:1500] + " Полный текст сохранён в файл " + REPORT + " в папке Jarvis."


# ── инструмент ──────────────────────────────────────────────────────────────
def _search(query, service, player):
    global _last, _last_rows, _last_shown, _gen
    c = _cfg()
    if not android.in_app_search() and not c["use_adb"]:
        return "Эта сборка не умеет искать в приложениях, а ADB в настройках выключен."
    provs = _providers(service, c)
    if provs is None:
        return "Не удалось получить список поисковых провайдеров."
    if not provs and service:
        return "Не нашёл сервис «%s» среди приложений с поиском. Скажите «какие приложения умеют искать»." % service
    if not provs:
        return ("Не нашёл установленных видеосервисов с поиском (Lazy Media Deluxe, Zona и др.). Установите их "
                "или добавьте название в Меню → Настройки плагинов → Поиск фильмов.")
    if service:                                         # конкретный сервис («в зоне»): ждать дольше, ждать больше некого
        c["timeout"] = max(c["timeout"], 25)
    elif c.get("use_tunnel"):
        c["timeout"] = max(c["timeout"], 15)
    names = _source_names(c)
    rows, diags, lock = [], [], threading.Lock()
    pending = set(p[2] for p in provs)                 # кто ещё не ответил (по названию)
    _gen += 1
    gen = _gen

    def work(auth, pkg, label):
        try:
            r, note = _query_one(auth, pkg, label, query, c, names)
        except Exception as e:
            r, note = [], "%s: %s" % (type(e).__name__, e)
        with lock:
            rows.extend(r)
            if not r:
                diags.append("%s: %s" % (label, note or "пусто"))
            left = [x for x in provs if x[2] == label]
            _done.setdefault(gen, set()).add((auth, label))
            if all((x[0], x[2]) in _done[gen] for x in left):
                pending.discard(label)

    threads = [threading.Thread(target=work, args=p, daemon=True) for p in provs]
    for t in threads:
        t.start()
    t0 = time.monotonic()
    hard = t0 + c["timeout"]
    late = c["late_wait"]
    first = None
    while True:                                          # первый показ: когда все ответили / есть результаты и прошло GRACE / таймаут
        with lock:
            n, left = len(rows), len(pending)
        now = time.monotonic()
        if left == 0 or now >= hard:
            break
        if n and first is None:
            first = now
        if late > 0 and first is not None and now - first >= LATE_GRACE:
            break
        time.sleep(0.2)
    with lock:
        rows0 = list(rows)
        left_names = sorted(pending)
        diags0 = list(diags)
    _done.pop(gen - 3, None)
    if not rows0:
        _show("Поиск «%s»: диагностика" % query, ["Опрошено: %d" % len(provs)] + diags0, player)
        return "По запросу «%s» ничего не нашлось (опрошено: %s). %s" % (
            query, ", ".join(sorted({p[2] for p in provs})), ("Ответ: " + "; ".join(diags0))[:400])
    with _lock:
        _last_rows = list(rows0)
    dist = _distribution(rows0)
    _log("movie_search: всего %d; по источникам: %s" % (len(rows0), "; ".join(dist)))
    seen, picked = set(), []
    for r in _diversify(rows0, c):                              # без дублей внутри приложения
        k = (r["_pkg"], r["suggest_text_1"].lower(), _g(r, "suggest_text_2").lower())
        if k not in seen:
            seen.add(k)
            picked.append(r)
    c["_adb"] = c["use_adb"] and c["open_how"] == "atv" and _adb_ok()
    cards = [_card(r, c) for r in picked]
    with _lock:
        _last = cards
        _last_shown = list(picked)
    if not android.show_results("Поиск: " + query, cards):
        _show("Поиск: " + query, [_text_line(x) for x in cards], player)
    threading.Thread(target=_tmdb_poster_worker, args=(gen, query, cards), daemon=True).start()

    if left_names and late > 0:                                  # медленные сервисы дособираем и добавляем плитки в конец
        def finisher():
            global _last, _last_rows, _last_shown
            used = len(rows0)
            deadline = t0 + max(c["timeout"], late)
            while time.monotonic() < deadline:
                time.sleep(0.5)
                if _gen != gen:
                    return
                with lock:
                    new, left = rows[used:], len(pending)
                if new:
                    used += len(new)
                    add = []
                    for r in _diversify(new, c):
                        k = (r["_pkg"], r["suggest_text_1"].lower(), _g(r, "suggest_text_2").lower())
                        if k not in seen:
                            seen.add(k)
                            add.append(r)
                    with _lock:
                        if _gen != gen:
                            return
                        add = add[:max(0, c["max_total"] - len(_last))]
                        _last_rows = _last_rows + new
                        if add:
                            _last = _last + [_card(r, c) for r in add]
                            new_cards = list(_last[-len(add):])
                            _last_shown = _last_shown + add
                            allc = list(_last)
                        else:
                            allc = None
                    if allc is not None:
                        _log("movie_search: добавлено %d плиток (всего %d)" % (len(add), len(allc)))
                        try:
                            if not android.show_results("Поиск: " + query, allc):
                                _show("Поиск: " + query, [_text_line(x) for x in allc], player)
                        except Exception as e:
                            _log("movie_search: не обновить плитки: %s" % e)
                        threading.Thread(target=_tmdb_poster_worker,
                                         args=(gen, query, new_cards), daemon=True).start()
                if left == 0:
                    return
        threading.Thread(target=finisher, daemon=True).start()

    per = {}
    for x in cards:
        a = x["app"].split(" · ")[0]
        per[a] = per.get(a, 0) + 1
    head = "; ".join("%d. %s%s" % (i + 1, x["title"], " (%s)" % x["year"] if x["year"] else "")
                     for i, x in enumerate(cards[:5]))
    more = (" Ещё ищу в: %s — добавлю плитки на экран сами, когда ответят; номера уже показанных не изменятся."
            % ", ".join(left_names)) if (left_names and late > 0) else ""
    return ("Показал на экране %d результатов (%s). Первые: %s.%s Скажи пользователю кратко и предложи "
            "открыть по номеру." % (len(cards), ", ".join("%s — %d" % kv for kv in per.items()), head, more))


def run(parameters, player=None, session_memory=None):
    p = parameters or {}
    action = str(p.get("action") or "").lower().strip()
    query = str(p.get("query") or "").strip()
    query = re.sub(r"<<<[^>]*>>>", " ", query).strip()                 # служебные метки вокруг текста пользователя
    service = str(p.get("service") or p.get("app") or "").strip()
    if _is_tunnel(action):                                              # модель иногда пишет action="tunnel" вместо service
        service = "tunnel"
        action = "search" if query else "open"
    action = ACTION_ALIASES.get(action, action)
    if _is_tunnel(service) and action in ("", "search"):               # «найди фильм в туннель»: слово «туннель» — не название
        q2 = " ".join(w for w in query.split() if not _is_tunnel(w) and w.lower() not in ("в", "во", "через", "на", "in", "найди", "фильм", "тв"))
        query = q2.strip() if q2.strip() else ("" if _is_tunnel(query) or len(query.split()) <= 3 else query)
    try:
        n = int(p.get("open_number") or p.get("index") or 0)
    except (TypeError, ValueError):
        n = 0
    try:
        if action == "open_result" or (n and action in ("", "search")):
            return _open(n, _cfg()) if n else "Не понял номер результата."
        if action in ("debug", "row", "отладка"):
            return _debug(n)
        if action == "trace_start":
            return _trace_start()
        if action == "trace_show":
            return _trace_show(service)
        if action == "links":
            pkg = service
            if not pkg and _last_shown:
                pkg = _last_shown[min(max(n, 1), len(_last_shown)) - 1].get("_pkg", "")
            if not pkg or not _PKG_RE.match(pkg):
                return "Скажите пакет приложения или сначала выполните поиск."
            return _links(pkg)
        if action == "screen":
            items = _screen_texts()
            if not items:
                return "Не удалось прочитать экран (нужен ADB)."
            _show("На экране", items, player)
            return "Прочитал экран: %d элементов, показал на экране." % len(items)
        if action == "apps":
            provs = _providers("", _cfg())
            if provs is None:
                return "Не удалось получить провайдеры."
            if not provs:
                return "Приложений с поиском не найдено."
            _show("Приложения с поиском", ["%s (%s)" % (lb, a) for a, _p, lb in provs], player)
            return "Умеют искать: %s." % ", ".join(sorted({lb for _a, _p, lb in provs}))
        if action == "open" and _is_tunnel(service):
            return "Открыл Tunnel." if _launch(TUNNEL_PKG) else "Не удалось запустить Tunnel."
        if action == "open":
            provs = _providers(service, _cfg()) if service else None
            if not provs:
                return "Не нашёл приложение «%s»." % service if service else "Какое приложение открыть?"
            return "Открыл %s." % provs[0][2] if _launch(provs[0][1]) else "Не удалось запустить %s." % provs[0][1]
        if action == "sources":
            if query:
                _search(query, service, player)
            with _lock:
                rows = list(_last_rows)
            if not rows:
                return "Сначала выполните поиск."
            dist = _distribution(rows)
            _show("Источники", dist, player)
            return "Всего %d результатов. По источникам: %s." % (len(rows), "; ".join(dist)[:400])
        if action not in ("", "search"):
            return "Неизвестное действие: %s" % action
        if not query:
            return "Что искать? Назовите фильм или сериал."
        for w in TUNNEL_WORDS:                               # «Матрица в Tunnel» -> сервис tunnel, запрос «Матрица»
            m = re.search(r"\s+(?:в|во|через|на|in)?\s*[\w\-]*%s[\w\-]*(?:\s+тв)?\s*$" % w, query, re.I)
            if m and not service:
                query, service = query[:m.start()].strip() or query, "tunnel"
                break
        if _is_tunnel(service) or _is_tunnel(p.get("service")) or _is_tunnel(p.get("app")):
            res = _search(query, "tunnel", player)             # плитки на экране Джарвиса, как у Zona/Lazy
            if res.startswith(("Не нашёл сервис", "Не удалось получить", "По запросу")):
                _report("tunnel provider", res)                # что ответил провайдер — в movie_search_report.txt
                return _tunnel_search(query, _cfg()) + " (список в плитках не получен: " + res[:160] + ")"
            return res
        return _search(query, service, player)
    except Exception as e:
        return "Ошибка: %s: %s" % (type(e).__name__, e)


# ── страница настроек ───────────────────────────────────────────────────────
def _onoff(v):
    return "ВКЛ" if v else "ВЫКЛ"


def _flat(v):
    """Многострочное значение -> одна строка через запятую (поле в одну строку не ловит фокус пульта)."""
    return ", ".join(x.strip() for x in re.split(r"[\n,;]+", str(v)) if x.strip())


def settings_items():
    c = _cfg()
    return [
        {"type": "label", "text": "Кнопки и числа — сверху; поля со списками — ниже. Списки пишите через запятую."},
        {"type": "button", "id": "all_tv", "label": "Если сервисы не нашлись — искать во всех ТВ-приложениях: " + _onoff(c["all_tv"])},
        {"type": "button", "id": "use_tunnel", "label": "Искать и в Tunnel при обычном поиске (дольше): " + _onoff(c["use_tunnel"])},
        {"type": "button", "id": "show_source", "label": "Подписывать источник на плитке: " + _onoff(c["show_source"])},
        {"type": "button", "id": "use_adb", "label": "Запасной путь ADB (content query, am start): " + _onoff(c["use_adb"])},
        {"type": "button", "id": "use_root", "label": "Запасной путь root (su), только если ТВ рутован: " + _onoff(c["use_root"])},
        {"type": "button", "id": "open_how", "label": "Как открывать результат: " + OPEN_MODE_NAMES[c["open_how"]]},
        {"type": "text", "id": "reopen_delay", "label": "Для «запуск, потом ссылка повторно»: пауза, секунд (1–15)", "value": str(c["reopen_delay"])},
        {"type": "text", "id": "per_source", "label": "Результатов с каждого источника (1–30)", "value": str(c["per_source"])},
        {"type": "text", "id": "max_total", "label": "Всего плиток на экране (5–200)", "value": str(c["max_total"])},
        {"type": "text", "id": "fetch_limit", "label": "Сколько просить у провайдера (10–500)", "value": str(c["fetch_limit"])},
        {"type": "text", "id": "timeout", "label": "Ждать ответов до первого показа, секунд (4–60)", "value": str(c["timeout"])},
        {"type": "text", "id": "late_wait", "label": "Дособирать медленные сервисы и добавлять плитки, секунд (0 = выкл, до 120)", "value": str(c["late_wait"])},
        {"type": "text", "id": "services", "label": "Сервисы (слова из названия или пакета, через запятую)",
         "value": _flat(c["services"]), "hint": "lazy, zona, rezka"},
        {"type": "text", "id": "source_names", "label": "Названия источников (номер=название, через запятую)",
         "value": _flat(c["source_names"]), "hint": "13=Zona, 23=Eneyida"},
        {"type": "button", "id": "scan", "label": "Показать, какие провайдеры найдены сейчас"},
        {"type": "button", "id": "reset", "label": "Сбросить всё к стандартным"},
        {"type": "button", "id": "save", "label": "Сохранить"},
    ]


def _apply_values(c, values):
    v = values or {}
    if "services" in v:
        c["services"] = str(v["services"])
    if "source_names" in v:
        c["source_names"] = str(v["source_names"])
    for k, lo, hi in (("per_source", 1, 30), ("max_total", 5, 200), ("fetch_limit", 10, 500), ("timeout", 4, 60), ("late_wait", 0, 120), ("reopen_delay", 1, 15)):
        if k in v:
            c[k] = _int(v[k], lo, hi, DEFAULTS[k])
    return c


def settings_event(event, values):
    if event == "reset":
        _save(dict(DEFAULTS))
        return {"message": "Сброшено к стандартным", "refresh": True}
    c = _apply_values(_cfg(), values)
    if event == "open_how":
        c["open_how"] = OPEN_MODES[(OPEN_MODES.index(c["open_how"]) + 1) % len(OPEN_MODES)]
        _save(c)
        return {"message": "Открывать: " + OPEN_MODE_NAMES[c["open_how"]], "refresh": True}
    if event in ("all_tv", "show_source", "use_adb", "use_root", "use_tunnel"):
        c[event] = not c[event]
        _save(c)
        return {"message": "%s: %s" % (event, _onoff(c[event])), "refresh": True}
    _save(c)
    if event == "scan":
        provs = _providers("", c)
        if provs is None:
            return {"message": "Не удалось получить провайдеры.", "refresh": False}
        names = sorted({lb for _a, _p, lb in provs})
        return {"message": ("Будут опрошены: " + ", ".join(names)) if names else "Подходящих приложений не найдено.",
                "refresh": False}
    if event == "__leave__":
        return None
    return {"message": "Сохранено", "refresh": False}
