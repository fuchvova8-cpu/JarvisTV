"""
tv_memory — what Jarvis remembers about you: look at it, delete the wrong or old entries, add one by hand.

Jarvis already saves facts by himself ("запомни мой адрес", "я живу в ..."): the model calls save_memory and the
fact goes to memory/long_term.json. On the PC there was a panel "What JARVIS remembers" with a cross to forget an
entry. This is the same for the TV.

Screen:   Menu > Plugin settings > "Что помнит Джарвис"
          every stored fact with a tick box (newest first), "Удалить отмеченные", "Вернуть удалённое",
          "Добавить запись" (category, key, value).
Voice:    "покажи, что ты помнишь" -> action=list (shows the entries on screen),
          "забудь мой адрес"       -> action=forget with `query`; if several entries fit, nothing is deleted and
                                       the candidates are listed so you can say which one,
          "верни забытое"          -> action=restore (the last deletion, until Jarvis is restarted).
Reading facts out loud while talking is still done by Jarvis' own recall_memory; this plugin is for looking at the
store and for deleting.
Note: a fact deleted here is gone for new sessions at once; in the conversation that is running right now the model
may still remember it until it reconnects.
One self-contained file; uses the original memory/memory_manager.py unchanged.
"""
from __future__ import annotations

import re
import threading

PLUGIN = {
    "name": "tv_memory",
    "description": (
        "Shows and edits the long-term memory (what Jarvis has remembered about the user). "
        "action=list: show every stored fact on screen ('покажи, что ты помнишь', 'что записано в памяти'). "
        "action=forget with query (a word from the fact's name or text; names are stored in English, e.g. 'address', "
        "so if a Russian word finds nothing the result lists everything and you pick the right name): delete that fact "
        "('забудь мой адрес', 'удали из памяти день рождения'); if several facts match, nothing is deleted and "
        "the candidates are returned - ask the user which one. "
        "action=restore: bring back the facts deleted last ('верни забытое'). action=count: how many facts. "
        "Saving a new fact is NOT done here: use save_memory for that. To answer a question from memory use "
        "recall_memory."
    ),
    "brief": "Show / delete what Jarvis remembers.",
    "tier": "extra",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING", "description": "list | forget | restore | count"},
            "query": {"type": "STRING", "description": "For forget: a word from the fact's name or text"},
        },
        "required": [],
    },
}

SETTINGS = {"title": "Что помнит Джарвис"}

CATEGORIES = ("identity", "preferences", "projects", "relationships", "wishes", "notes")
CAT_NAMES = {"identity": "обо мне", "preferences": "предпочтения", "projects": "проекты",
             "relationships": "люди", "wishes": "планы", "notes": "заметки"}

_lock = threading.Lock()
_sel: set = set()            # ticked entries: "category/key"
_trash: list = []            # last deleted entries, for "restore"
_draft = {"cat": "notes", "key": "", "value": ""}


def _mm():
    from memory import memory_manager as mm
    return mm


def _rows() -> list:
    try:
        return _mm().all_entries_for_ui()
    except Exception:
        return []


def _id(r: dict) -> str:
    return "%s/%s" % (r["category"], r["key"])


def _pretty(key: str) -> str:
    return str(key).replace("_", " ").strip()


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[_\-]+", " ", str(s).lower().replace("ё", "е"))).strip()


def _ui_check() -> bool:
    try:
        from tvshim import plugins_ext
        return bool(getattr(plugins_ext, "UI_CHECK", False))
    except Exception:
        return False


def _split_id(i: str):
    cat, _, key = i.partition("/")
    return cat, key


# ── deleting / restoring / adding ───────────────────────────────────────────
def _delete(ids) -> int:
    """Delete entries by 'category/key'. The removed ones are kept for 'restore'. Returns how many were deleted."""
    mm = _mm()
    rows = {_id(r): r for r in _rows()}
    done = []
    for i in ids:
        r = rows.get(i)
        if not r:
            continue
        cat, key = _split_id(i)
        res = mm.forget(key, cat)
        if str(res).startswith("Forgotten"):
            done.append(r)
    if done:
        with _lock:
            _trash[:] = done
            _sel.difference_update(_id(r) for r in done)
    return len(done)


def _restore() -> int:
    with _lock:
        items = list(_trash)
        _trash.clear()
    mm = _mm()
    try:
        memory = mm.load_memory()
        for r in items:
            cat = r["category"]
            if not isinstance(memory.get(cat), dict):
                memory[cat] = {}
            memory[cat][r["key"]] = {"value": r["value"], "updated": r.get("updated") or ""}
        mm.save_memory(memory)
    except Exception:
        for r in items:                                   # fallback: the date becomes today's
            try:
                mm.remember(r["key"], r["value"], r["category"] if r["category"] in CATEGORIES else "notes")
            except Exception:
                pass
    return len(items)


def _find(query: str) -> list:
    q = _norm(query)
    if not q:
        return []
    rows = _rows()
    exact = [r for r in rows if _norm(r["key"]) == q]
    if exact:
        return exact
    words = q.split()
    hit = [r for r in rows if all(w in _norm(r["key"]) for w in words)]
    if hit:
        return hit
    return [r for r in rows if all(w in _norm(r["key"] + " " + r["value"]) for w in words)]


def _line(r: dict) -> str:
    return "%s — %s   [%s · %s]" % (_pretty(r["key"]), r["value"], CAT_NAMES.get(r["category"], r["category"]),
                                    r.get("updated") or "—")


# ── tool ────────────────────────────────────────────────────────────────────
def run(parameters: dict, player=None) -> str:
    p = parameters or {}
    action = str(p.get("action") or "list").lower().strip()
    try:
        rows = _rows()
        if action == "count":
            return "В памяти %d записей." % len(rows)

        if action == "list":
            if not rows:
                return "В памяти пока ничего нет."
            text = "\n".join("%d. %s" % (i + 1, _line(r)) for i, r in enumerate(rows[:60]))
            if player is not None:
                try:
                    player.show_content("Что я помню (%d)" % len(rows), text)
                except Exception:
                    pass
            return ("В памяти %d записей, показал на экране. Удалять можно голосом («забудь …») или в "
                    "Меню → Настройки плагинов → «Что помнит Джарвис»." % len(rows))

        if action == "restore":
            n = _restore()
            return ("Вернул записей: %d." % n) if n else "Нечего возвращать."

        if action == "forget":
            q = str(p.get("query") or "").strip()
            if not q:
                return "Что забыть? Назовите запись, например «адрес»."
            found = _find(q)
            if not found:
                allrows = _rows()
                if not allrows:
                    return "В памяти ничего нет."
                return ("По запросу «%s» точного совпадения нет (названия записей хранятся по-английски). Вот что "
                        "записано: " % q + "; ".join("%s — %s" % (_pretty(r["key"]), r["value"][:50])
                                                     for r in allrows[:20]) +
                        ". Выбери подходящую и повтори с её названием, либо уточни у пользователя.")
            if len(found) > 1:
                return ("Подходит несколько записей, ничего не удалил: " + "; ".join(
                    "%s — %s" % (_pretty(r["key"]), r["value"][:60]) for r in found[:6]) +
                    ". Спроси пользователя, какую именно, и повтори с точным названием.")
            r = found[0]
            if _delete([_id(r)]):
                return "Забыл: %s — %s." % (_pretty(r["key"]), r["value"][:80])
            return "Не получилось удалить «%s»." % _pretty(r["key"])

        return "Неизвестное действие: %s. Есть: list, forget, restore, count." % action
    except Exception as e:
        return "tv_memory: %s: %s" % (type(e).__name__, e)


# ── settings page ───────────────────────────────────────────────────────────
def settings_items():
    rows = _rows()
    with _lock:
        sel = set(_sel)
        has_trash = len(_trash)
    sel &= {_id(r) for r in rows}
    check = _ui_check()
    items = [
        {"type": "label", "text": "Здесь всё, что Джарвис запомнил о вас (новые сверху). Отметьте лишнее и "
                                  "нажмите «Удалить отмеченные». Записи хранятся только на этом ТВ."},
        {"type": "button", "id": "delete", "label": "Удалить отмеченные (%d)" % len(sel)},
        {"type": "button", "id": "restore", "label": "Вернуть удалённое%s" % ((" (%d)" % has_trash) if has_trash else "")},
        {"type": "button", "id": "sel_all", "label": "Отметить все"},
        {"type": "button", "id": "sel_none", "label": "Снять отметки"},
        {"type": "button", "id": "refresh", "label": "Обновить список"},
        {"type": "label", "text": "── Записей: %d ──" % len(rows)},
    ]
    if not rows:
        items.append({"type": "label", "text": "Пока ничего не записано. Скажите, например: «запомни мой адрес — …»."})
    for r in rows:
        i = _id(r)
        if check:
            items.append({"type": "check", "id": "chk:" + i, "label": _line(r), "checked": i in sel})
        else:
            items.append({"type": "button", "id": "tgl:" + i, "label": ("☑ " if i in sel else "☐ ") + _line(r)})
    items += [
        {"type": "label", "text": "── Добавить запись вручную ──"},
        {"type": "button", "id": "cat", "label": "Раздел: %s  — переключить" % CAT_NAMES[_draft["cat"]]},
        {"type": "text", "id": "new_key", "label": "Название (например: адрес)", "value": _draft["key"], "hint": "address"},
        {"type": "text", "id": "new_value", "label": "Что запомнить", "value": _draft["value"], "hint": "г. Киев, ул. …"},
        {"type": "button", "id": "add", "label": "Добавить запись"},
    ]
    return items


def _sync(values: dict) -> None:
    """Tick boxes and the draft fields -> module state (called first on every event)."""
    v = values or {}
    with _lock:
        for k, val in v.items():
            if k.startswith("chk:"):
                (_sel.add if str(val) in ("1", "true", "True") else _sel.discard)(k[4:])
        if "new_key" in v:
            _draft["key"] = str(v["new_key"])
        if "new_value" in v:
            _draft["value"] = str(v["new_value"])


def settings_event(event, values):
    _sync(values)
    if event == "__leave__":
        return None
    try:
        if event == "delete":
            with _lock:
                ids = list(_sel)
            if not ids:
                return {"message": "Ничего не отмечено", "refresh": False}
            n = _delete(ids)
            return {"message": "Удалено: %d (можно вернуть кнопкой «Вернуть удалённое»)" % n, "refresh": True}
        if event == "restore":
            n = _restore()
            return {"message": ("Возвращено: %d" % n) if n else "Нечего возвращать", "refresh": True}
        if event == "sel_all":
            with _lock:
                _sel.update(_id(r) for r in _rows())
            return {"message": "Отмечено всё", "refresh": True}
        if event == "sel_none":
            with _lock:
                _sel.clear()
            return {"message": "Отметки сняты", "refresh": True}
        if event == "refresh":
            return {"message": "Записей: %d" % len(_rows()), "refresh": True}
        if event.startswith("tgl:"):                                   # old APK without tick boxes
            i = event[4:]
            with _lock:
                _sel.symmetric_difference_update({i})
            return {"message": "", "refresh": True}
        if event == "cat":
            _draft["cat"] = CATEGORIES[(CATEGORIES.index(_draft["cat"]) + 1) % len(CATEGORIES)]
            return {"message": "Раздел: " + CAT_NAMES[_draft["cat"]], "refresh": True}
        if event == "add":
            key = re.sub(r"[^\w]+", "_", _draft["key"].strip().lower(), flags=re.U).strip("_")
            val = _draft["value"].strip()
            if not key or not val:
                return {"message": "Заполните название и текст записи", "refresh": False}
            _mm().remember(key, val, _draft["cat"])
            _draft["key"] = _draft["value"] = ""
            return {"message": "Записано: %s" % _pretty(key), "refresh": True}
    except Exception as e:
        return {"message": "Ошибка: %s: %s" % (type(e).__name__, e), "refresh": False}
    return {"message": "", "refresh": False}
