"""
tv_micdiag — who is holding the TV's microphone? Runs a fixed set of READ-ONLY diagnostic
commands through the TV's own ADB (no PC needed), shows the result on the Jarvis screen and saves
it to Jarvis/micdiag.txt. One self-contained file; it cannot run arbitrary commands.
"""
from __future__ import annotations

import os
import re
import time
from pathlib import Path

HOME = Path(os.environ.get("JARVIS_HOME") or Path(__file__).resolve().parent.parent)

PLUGIN = {
    "name": "tv_micdiag",
    "description": (
        "Diagnoses the microphone problem on this TV: finds which app or service is holding the microphone "
        "('microphone is busy'), which speech recognizer is set, and who has microphone permission. "
        "Use when the user says the microphone does not work, is busy, or asks who is using it. "
        "Reads only; changes nothing. Needs ADB on. Say the short result aloud; the full report is on screen "
        "and in micdiag.txt. Run it WHILE the problem is happening."
    ),
    "brief": "Find what is holding the TV microphone.",
    "tier": "extra",
    "parameters": {"type": "OBJECT", "properties": {}, "required": []},
}

_NO_ADB = ("ADB is not connected. On the TV: Settings > Device preferences > About, tap Build 7 times, "
           "then Developer options > USB debugging and network debugging; accept the prompt for this app.")


def _sh(cmd: str) -> str:
    from tvshim.bridge import kt
    out = kt().adbShell(cmd)
    if out is None:
        raise RuntimeError(_NO_ADB)
    return str(out)


def _try(cmd: str) -> str:
    try:
        return _sh(cmd).strip()
    except RuntimeError:
        raise
    except Exception as e:
        return f"(failed: {type(e).__name__}: {e})"


def run(parameters: dict, player=None) -> str:
    try:
        flinger = _try("dumpsys media.audio_flinger")
    except RuntimeError as e:
        return str(e)
    except Exception as e:
        return f"{_NO_ADB} ({e})"

    # Input-side section: from the first "Input thread" up to the next output section.
    m = re.search(r"(?is)(input thread.*?)(?=\n\s*(?:output thread|standby|notification)|\Z)", flinger)
    inp = (m.group(1) if m else "").strip()
    pids = sorted(set(re.findall(r"(?i)\bpid[:= ]+(\d+)", inp)))
    holders = []
    for pid in pids[:6]:
        name = _try(f"ps -p {pid} -o NAME").splitlines()
        holders.append(f"{pid}: {name[-1].strip() if name else '?'}")
    active = bool(re.search(r"(?i)active|state:?\s*active|STATE_ACTIVE", inp)) or bool(pids)

    recognizer = _try("settings get secure voice_recognition_service")
    assistant = _try("settings get secure assistant")
    appops = _try("dumpsys appops --op RECORD_AUDIO")

    report = [
        f"Microphone diagnostics, {time.strftime('%Y-%m-%d %H:%M')}",
        "",
        "== Holders of the audio input (pid: process) ==",
        "\n".join(holders) if holders else "none found in audio_flinger",
        "",
        "== audio_flinger input section ==",
        inp[:2500] or "(no input thread section)",
        "",
        f"== Speech recognizer ==\n{recognizer}",
        f"== Assistant ==\n{assistant}",
        "",
        "== appops RECORD_AUDIO ==",
        appops[:2500],
    ]
    text = "\n".join(report)
    try:
        (HOME / "micdiag.txt").write_text(text, encoding="utf-8")
    except Exception:
        pass
    if player:
        try:
            player.show_content("Microphone diagnostics", text[:3500])
            player.write_log("JARVIS: microphone diagnostics ready")
        except Exception:
            pass

    if holders:
        verdict = "Something is recording right now: " + "; ".join(holders) + "."
    elif active:
        verdict = "The audio input looks active but I could not read which process."
    else:
        verdict = "Nobody is recording at this moment — the microphone is free."
    rec = "" if recognizer and recognizer not in ("null", "") else \
          " No speech recognizer is set on this TV, so the Voice button cannot work."
    return verdict + rec + " Full report is on screen and in micdiag.txt."
