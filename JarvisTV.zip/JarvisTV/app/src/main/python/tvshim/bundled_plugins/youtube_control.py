"""Управление SmartTube и TizenTube на Android TV (JarvisTV).

Голосом: «открой smart», «включи tizen», «найди на ютубе котиков»,
«пауза», «дальше», «перемотай назад 3 раза», «громче», «закрой smart».

ADB берётся у самого Джарвиса (android_bridge → tvshim.adbio → adbd на 127.0.0.1),
поэтому системный adb и адрес ТВ не нужны. Если приложение не нашлось само —
Меню → Настройки плагинов → «SmartTube / TizenTube» и впишите имя пакета.
"""
import json
import os
import re
import urllib.parse

import android_bridge as android

APPS = {
    "smarttube": {
        "title": "SmartTube",
        "names": ["smart", "smarttube", "smart tube", "смарт", "смарттюб", "смарт тюб", "смарт тьюб"],
        "packages": [
            "com.teamsmart.videomanager.tv",    # stable
            "com.liskovsoft.smarttubetv.beta",  # beta
            "com.liskovsoft.smarttubetv",
        ],
        "keyword": "smarttube",
    },
    "tizentube": {
        "title": "TizenTube",
        "names": ["tizen", "tizentube", "tizen tube", "тизен", "тизентюб", "тизен тюб", "тизен тьюб"],
        "packages": [],
        "keyword": "tizentube",
    },
}

KEYS = {
    "play_pause": 85, "play": 126, "pause": 127, "stop": 86,
    "next": 87, "prev": 88, "forward": 90, "rewind": 89,
    "up": 19, "down": 20, "left": 21, "right": 22, "ok": 23,
    "back": 4, "home": 3, "menu": 82,
    "vol_up": 24, "vol_down": 25, "mute": 164,
}

PLUGIN = {
    "name": "youtube_control",
    "description": (
        "Управляет YouTube-клиентами SmartTube (слово «smart») и TizenTube (слово «tizen») на ТВ. "
        "Вызывай на: «открой smart/tizen», «найди на ютубе <запрос>», «включи видео <id или ссылка>», "
        "«пауза», «продолжи», «дальше», «назад», «перемотай», «громче/тише», «закрой smart». "
        "Параметр app: 'smarttube' или 'tizentube'."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": (
                    "'open' запустить приложение, 'search' найти видео, 'play' включить по id/ссылке, "
                    "'key' нажать кнопку (см. control), 'close' закрыть приложение, "
                    "'status' что установлено. По умолчанию 'open'."
                ),
                "enum": ["open", "search", "play", "key", "close", "status"],
            },
            "app": {
                "type": "STRING",
                "description": "'smarttube' или 'tizentube'. Если не сказано — тот, что использовали последним.",
                "enum": ["smarttube", "tizentube"],
            },
            "query": {"type": "STRING", "description": "Что искать."},
            "video_id": {"type": "STRING", "description": "ID видео YouTube или полная ссылка."},
            "control": {
                "type": "STRING",
                "description": (
                    "Для action 'key': play_pause, play, pause, stop, next, prev, forward, rewind, "
                    "up, down, left, right, ok, back, home, menu, vol_up, vol_down, mute."
                ),
                "enum": list(KEYS.keys()),
            },
            "times": {"type": "INTEGER", "description": "Сколько раз нажать (например, перемотать 3 раза). По умолчанию 1."},
        },
        "required": [],
    },
}

SETTINGS = {"title": "SmartTube / TizenTube"}
STATUS = "youtube"

_last_app = "smarttube"
_pkg_cache = {}
_PKG_RE = re.compile(r"^[A-Za-z0-9_.]+$")


# ── ADB (канал Джарвиса) ──────────────────────────────────────────────────────

def _sh(cmd):
    out = str(android.shell(cmd))
    if out.startswith("ADB:"):
        raise RuntimeError(
            "Нет связи с ADB Джарвиса. На ТВ включите «Отладка по USB» и «Отладка по сети» "
            "и подтвердите запрос «Разрешить отладку». (%s)" % out[4:].strip()[:120])
    return out.strip()


def _am_failed(out):
    low = out.lower()
    return "error" in low or "exception" in low or "unable to resolve" in low


# ── настройки: ручное имя пакета ──────────────────────────────────────────────

def _file():
    return os.path.join(android.data_dir() or ".", "youtube_control.json")


def _load():
    try:
        with open(_file(), encoding="utf-8") as f:
            d = json.load(f)
        if isinstance(d, dict):
            return d
    except Exception:
        pass
    return {}


def _save(d):
    try:
        with open(_file(), "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=1)
    except Exception as e:
        android.log("youtube_control: не сохранить: %s" % e)


def settings_items():
    d = _load()
    items = [{"type": "label", "text": "Обычно ничего вводить не нужно — приложения находятся сами. "
                                       "Имя пакета нужно, только если «не найден»."}]
    for key, info in APPS.items():
        items.append({"type": "text", "id": "pkg:" + key, "label": info["title"] + " — пакет",
                      "value": d.get(key, ""), "hint": "например com.teamsmart.videomanager.tv"})
    items.append({"type": "button", "id": "save", "label": "Сохранить"})
    return items


def _store(values):
    d = _load()
    for key in APPS:
        v = str((values or {}).get("pkg:" + key, "")).strip()
        if not v:
            d.pop(key, None)
        elif _PKG_RE.match(v):
            d[key] = v
    _save(d)
    _pkg_cache.clear()


def settings_event(event, values):
    _store(values)
    if event == "__leave__":
        return None
    return {"message": "Сохранено", "refresh": False}


# ── поиск приложения ──────────────────────────────────────────────────────────

def _flat(s):
    return re.sub(r"[^a-z0-9]", "", str(s).lower())


def _find_package(app):
    if app in _pkg_cache:
        return _pkg_cache[app]
    info = APPS[app]
    manual = _load().get(app)
    if manual:
        _pkg_cache[app] = manual
        return manual

    pkgs, labels = set(), {}
    for a in (android.list_apps() or []):
        p = a.get("pkg")
        if p:
            pkgs.add(p)
            labels[p] = a.get("label") or ""
    if not pkgs:   # запасной путь, если список приложений недоступен
        for line in _sh("pm list packages").splitlines():
            if line.startswith("package:"):
                pkgs.add(line.split(":", 1)[1].strip())

    for p in info["packages"]:
        if p in pkgs:
            _pkg_cache[app] = p
            return p
    kw = info["keyword"]
    for p in sorted(pkgs):
        if kw in _flat(p) or kw in _flat(labels.get(p, "")):
            _pkg_cache[app] = p
            return p
    return None


def _resolve_app(raw):
    global _last_app
    if raw:
        r = str(raw).strip().lower()
        for key, info in APPS.items():
            if r == key or r in info["names"]:
                _last_app = key
                return key
    return _last_app


# ── действия ──────────────────────────────────────────────────────────────────

def _panel(player, title, text):
    if player:
        try:
            player.show_content(title, text)
        except Exception:
            pass


def _video_id(raw):
    raw = str(raw).strip()
    m = re.search(r"(?:v=|youtu\.be/|shorts/|embed/)([\w-]{11})", raw)
    if m:
        return m.group(1)
    return raw if re.fullmatch(r"[\w-]{11}", raw) else ""


def _launch(pkg):
    res = str(android.launch_app(pkg))
    if res.startswith("ok"):
        return True
    return not _am_failed(_sh("monkey -p %s -c android.intent.category.LAUNCHER 1" % pkg))


def _view(pkg, url):
    out = _sh("am start -a android.intent.action.VIEW -d '%s' -p %s" % (url, pkg))
    return not _am_failed(out), out


def _press(code, times):
    times = max(1, min(20, times))
    _sh("input keyevent " + " ".join([str(code)] * times))


def run(parameters, player=None, session_memory=None):
    action = (parameters.get("action") or "open").strip().lower()
    app = _resolve_app(parameters.get("app"))
    title = APPS[app]["title"]

    try:
        if action == "status":
            lines = ["%s: %s" % (i["title"], _find_package(k) or "не установлен") for k, i in APPS.items()]
            _panel(player, "📺 YOUTUBE — СТАТУС", "\n".join(lines))
            return "; ".join(lines)

        if action == "key":
            ctrl = (parameters.get("control") or "").strip().lower()
            if ctrl not in KEYS:
                return "Какую кнопку нажать: пауза, дальше, назад, громче?"
            try:
                times = int(parameters.get("times") or 1)
            except (TypeError, ValueError):
                times = 1
            _press(KEYS[ctrl], times)
            return "Готово."

        pkg = _find_package(app)
        if not pkg:
            return ("%s не найден на телевизоре. Установите его или впишите имя пакета в "
                    "Меню → Настройки плагинов → «SmartTube / TizenTube»." % title)

        if action == "close":
            _sh("am force-stop " + pkg)
            return "%s закрыт." % title

        if action == "open":
            if _launch(pkg):
                _panel(player, "📺 " + title.upper(), "Запущено")
                return "Открываю %s." % title
            return "Не удалось открыть %s." % title

        if action == "search":
            q = (parameters.get("query") or "").strip()
            if not q:
                return "Что искать на YouTube?"
            ok, out = _view(pkg, "https://www.youtube.com/results?search_query=" + urllib.parse.quote(q))
            if not ok:
                return "%s не принял поиск: %s" % (title, out[:100])
            _panel(player, "📺 %s — ПОИСК" % title.upper(), q)
            return "Ищу в %s: %s." % (title, q)

        if action == "play":
            vid = _video_id(parameters.get("video_id") or "")
            if not vid:
                return "Назовите ID видео или дайте ссылку."
            ok, out = _view(pkg, "https://www.youtube.com/watch?v=" + vid)
            if not ok:
                return "%s не принял видео: %s" % (title, out[:100])
            _panel(player, "📺 %s — ВОСПРОИЗВЕДЕНИЕ" % title.upper(), vid)
            return "Включаю видео в %s." % title

        return "Могу открыть SmartTube или TizenTube, найти видео и управлять воспроизведением."

    except RuntimeError as e:
        return str(e)
    except Exception as e:
        return "Не получилось выполнить «%s»: %s" % (action, e)
