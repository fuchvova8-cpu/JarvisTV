"""Внешний вид главного экрана и окна результатов — в стиле Google TV.

Плагин ничего не рисует сам в Jarvis, он пишет файл plugin_data/screen_layout.json, а приложение
читает его и переставляет/перекрашивает элементы (Skin.kt). Три режима:

    off     — как раньше, классический экран
    layout  — раскладка из JSON: положение, размер, цвета, текст каждого элемента
    frame   — то же + полноэкранный фон, который плагин рисует кадрами (плавающие цветные пятна
              и «четыре точки» Google Assistant внизу, реагирующие на голос)

Настройка: Меню → Настройки плагинов → «Экран (стиль Google)». После правок вернитесь на главный
экран — он перестроится сам (в течение пары секунд). Голосом: «включи экран гугл»,
«выключи стиль гугл», «светлая тема экрана».

Дополнительно:
    • «Кнопки из меню на главном экране» — любой пункт сервисного меню становится кнопкой на экране;
    • «Редактор» — элементы перетаскиваются мышью, угол меняет размер, положение сохраняется само;
    • цвета подбираются эквалайзером (R, G, B, прозрачность) или вводятся кодом;
    • «Оверлей микрофона» — нижняя панель в стиле Google: поиск, результаты или оба сразу;
    • тема применяется ко всем меню, подменю, окнам настроек и результатов.

Единицы в полях: x, y, w, h — проценты экрана (w/h = 0 → по содержимому); textSize — sp;
radius, strokeWidth — dp (radius -1 → «таблетка»); цвета — #RRGGBB или #AARRGGBB.
Пустое поле = значение по умолчанию.
"""
from __future__ import annotations

import copy
import base64
import base64
import json
import math
import os
import threading
import time

PLUGIN = {
    "name": "screen_style",
    "description": (
        "Сменить внешний вид главного экрана Jarvis на ТВ: включить или выключить стиль Google, "
        "выбрать тёмную или светлую тему, включить анимированный фон. Вызывай на фразы «включи экран "
        "гугл», «стиль гугл», «верни старый экран», «светлая тема экрана», «тёмная тема экрана»."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING", "description": "off (классика), layout (стиль Google) или frame (стиль Google + анимированный фон)"},
            "theme": {"type": "STRING", "description": "dark или light (необязательно)"},
            "overlay_mode": {"type": "STRING", "description": "режим оверлея микрофона: search (поиск), results (результаты) или both (оба)"},
            "edit": {"type": "STRING", "description": "on — включить редактор перетаскивания элементов, off — выключить"},
        },
        "required": [],
    },
}

SETTINGS = {"title": "Экран (стиль Google)"}

# ── пресеты ──────────────────────────────────────────────────────────────────
THEMES = {
    "dark": {"bg": "#202124", "surface": "#303134", "focus": "#3C4043", "text": "#E8EAED",
             "muted": "#9AA0A6", "accent": "#8AB4F8", "radius": 24},
    "light": {"bg": "#F8F9FA", "surface": "#E8EAED", "focus": "#D2E3FC", "text": "#202124",
              "muted": "#5F6368", "accent": "#1A73E8", "radius": 24},
}

# id: (подпись, вид)   вид: leaf = одна надпись/кнопка (textSize), panel = контейнер (textScale), hud
ELEMENTS = {
    "hud": ("Центр (сфера / кольца)", "hud"),
    "name": ("Имя ассистента", "leaf"),
    "state": ("Состояние", "leaf"),
    "clock": ("Часы", "leaf"),
    "log": ("Журнал (слева)", "panel"),
    "content": ("Панель ответа (справа)", "panel"),
    "input": ("Строка ввода", "leaf"),
    "btn_send": ("Кнопка «Отправить»", "leaf"),
    "btn_voice": ("Кнопка «Голос»", "leaf"),
    "btn_mute": ("Кнопка «Микрофон»", "leaf"),
    "btn_stop": ("Кнопка «Стоп»", "leaf"),
    "btn_results": ("Кнопка «Результаты»", "leaf"),
    "btn_plugins": ("Кнопка «Плагины»", "leaf"),
    "btn_menu": ("Кнопка «Меню»", "leaf"),
    "confirm": ("Окно подтверждения", "panel"),
    "quiz": ("Окно квиза", "panel"),
}

DEFAULT_MAIN = {
    "hud": {"visible": True, "x": 28, "y": 9, "w": 44, "h": 66},
    "name": {"visible": True, "x": 3, "y": 3.2, "textSize": 22, "bold": True},
    "state": {"visible": True, "x": 44, "y": 3.9, "textSize": 14},
    "clock": {"visible": True, "x": 91, "y": 3.2, "textSize": 20},
    "log": {"visible": True, "x": 2, "y": 11, "w": 24, "h": 64, "textScale": 1.0},
    "content": {"visible": True, "x": 74, "y": 11, "w": 24, "h": 64, "textScale": 1.0},
    "input": {"visible": True, "x": 3, "y": 84, "w": 33.5, "h": 8.5, "textSize": 16},
    "btn_send": {"visible": True, "x": 37.5, "y": 84, "w": 7.2, "h": 8.5, "textSize": 13},
    "btn_voice": {"visible": True, "x": 45.3, "y": 84, "w": 6.5, "h": 8.5, "textSize": 13},
    "btn_mute": {"visible": True, "x": 52.4, "y": 84, "w": 11, "h": 8.5, "textSize": 13},
    "btn_stop": {"visible": True, "x": 64.0, "y": 84, "w": 6, "h": 8.5, "textSize": 13},
    "btn_results": {"visible": True, "x": 70.6, "y": 84, "w": 9, "h": 8.5, "textSize": 13},
    "btn_plugins": {"visible": True, "x": 80.2, "y": 84, "w": 8.2, "h": 8.5, "textSize": 13},
    "btn_menu": {"visible": True, "x": 89.0, "y": 84, "w": 6.5, "h": 8.5, "textSize": 13},
    "confirm": {"visible": True, "x": 25, "y": 36, "w": 50, "h": 0, "textScale": 1.0},
    "quiz": {"visible": True, "x": 19, "y": 18, "w": 62, "h": 0, "textScale": 1.0},
}

DEFAULT_RESULTS = {
    "x": 7, "y": 7, "w": 86, "h": 86, "dim": 55, "autoClose": 120,
    "panelRadius": 28, "columns": 0, "posterRatio": 1.5, "cardRadius": 14, "posterRadius": 12,
    "titleBarSize": 22, "titleSize": 14, "subSize": 12, "appSize": 11,
    "showBadge": 1, "showSub": 1, "showApp": 1, "listDefault": 0,
    "listPosterW": 8.5, "listTitleSize": 20, "listMetaSize": 14, "listDescSize": 15, "descLines": 4,
}

# поля окна результатов: ключ → (подпись, подсказка)
RESULT_FIELDS = [
    ("x", "Окно: X, % слева", "7"),
    ("y", "Окно: Y, % сверху", "7"),
    ("w", "Окно: ширина, %", "86"),
    ("h", "Окно: высота, % (0 = по умолчанию)", "86"),
    ("dim", "Затемнение фона за окном, % (0–100)", "55"),
    ("panelFill", "Цвет окна (пусто = из темы)", "#303134"),
    ("panelStroke", "Цвет рамки окна (пусто = нет)", ""),
    ("panelStrokeWidth", "Толщина рамки, dp", "0"),
    ("panelRadius", "Скругление окна, dp", "28"),
    ("columns", "Колонок плиток (0 = авто)", "0"),
    ("posterRatio", "Высота постера к ширине (1.5 = 2:3)", "1.5"),
    ("cardRadius", "Скругление рамки фокуса, dp", "14"),
    ("posterRadius", "Скругление постера, dp", "12"),
    ("titleBarSize", "Размер заголовка окна, sp", "22"),
    ("titleSize", "Плитки: размер названия, sp", "14"),
    ("subSize", "Плитки: размер подписи, sp", "12"),
    ("appSize", "Плитки: размер названия приложения, sp", "11"),
    ("showBadge", "Показывать номер на постере (1/0)", "1"),
    ("showSub", "Показывать подпись под названием (1/0)", "1"),
    ("showApp", "Показывать приложение (1/0)", "1"),
    ("listDefault", "Вид по умолчанию: 0 плитки, 1 список", "0"),
    ("listPosterW", "Список: ширина постера, % экрана", "8.5"),
    ("listTitleSize", "Список: размер названия, sp", "20"),
    ("listMetaSize", "Список: размер года/рейтинга, sp", "14"),
    ("listDescSize", "Список: размер описания, sp", "15"),
    ("descLines", "Список: строк описания", "4"),
    ("autoClose", "Автозакрытие окна через, сек", "120"),
]
_RES_BOOL = {"showBadge", "showSub", "showApp"}
_RES_STR = {"panelFill", "panelStroke"}
_RES_INT = {"panelRadius", "columns", "cardRadius", "posterRadius", "listDefault", "descLines", "autoClose"}

DEFAULT_OVERLAY = {"mode": "both", "w": 92, "bottom": 4, "radius": 28, "textSize": 22,
                   "posterH": 150, "posterRatio": 1.5, "cardTextSize": 13, "dim": 35, "dots": 1,
                   "listDefault": 0, "listPosterH": 96, "numbers": 1, "showApp": 1, "mic": 1}

OVERLAY_MODES = (("search", "Только поиск (панель с точками Google)"),
                 ("results", "Только результаты (лента вместо панели)"),
                 ("both", "Поиск и результаты вместе"))

OVERLAY_FIELDS = [
    ("w", "Ширина панели, % экрана", "92"),
    ("bottom", "Отступ снизу, % экрана", "4"),
    ("h", "Высота (толщина) панели, dp (0 = по содержимому; без результатов ~100, больше — толще)", "0"),
    ("headH", "Высота шапки (точки и «Слушаю»), dp — меньше = уже панель", "52"),
    ("padV", "Отступ сверху и снизу внутри панели, dp — меньше = уже панель", "16"),
    ("radius", "Скругление панели, dp", "28"),
    ("textSize", "Размер текста запроса, sp", "22"),
    ("posterH", "Высота постера в ленте, dp", "150"),
    ("posterRatio", "Высота постера к ширине (1.5 = 2:3)", "1.5"),
    ("cardTextSize", "Размер названия под постером, sp", "13"),
    ("dim", "Затемнение экрана за панелью, % (0–100)", "35"),
    ("dots", "Четыре точки Google (1/0)", "1"),
    ("strokeWidth", "Толщина рамки панели, dp", "0"),
    ("listDefault", "Вид результатов: 0 плитки, 1 список (дальше запоминается выбор кнопкой)", "0"),
    ("listPosterH", "Высота постера в списке, dp", "96"),
    ("numbers", "Номер результата на постере (1/0)", "1"),
    ("showApp", "Название видеосервиса под фильмом (1/0)", "1"),
    ("mic", "Кнопка микрофона (1/0). Микрофон, точки и надпись «Слушаю» двигаются мышью, положение запоминается отдельно для каждого окна", "1"),
    ("silenceHide", "Оверлей «слушать»: спрятать, если молчите, через N сек (0 = не прятать). Полоса микрофона не прячется", "6"),
]
_OVL_INT = {"headH", "padV", "h", "radius", "dots", "listDefault", "numbers", "showApp", "mic", "silenceHide"}

# пункты сервисного меню, которые можно вынести на главный экран: ключ → подпись
MENU_ITEMS = [
    ("gemini_key", "Ключ Gemini API"), ("names", "Имена (ассистент / вы)"), ("voice", "Голос Gemini"),
    ("plugins", "Плагины (вкл/выкл)"), ("plugin_settings", "Настройки плагинов"),
    ("plugin_dir", "Папка плагинов"), ("mic_mode", "Режим микрофона (по кнопке / постоянно)"),
    ("mic_live", "Постоянное прослушивание"), ("mic_bg", "Микрофон в фоне"),
    ("mic_indicator", "Индикатор микрофона"), ("adb", "Проверить ADB"),
    ("autostart", "Автозапуск при включении ТВ"), ("folder_info", "Где папка Jarvis"),
    ("edit_screen", "Редактор экрана"), ("exit", "Выйти полностью"),
]
_MENU_LABEL = dict(MENU_ITEMS)

THEME_FIELDS = [
    ("bg", "Фон экрана"), ("surface", "Панели и кнопки"), ("focus", "Нажатая кнопка"),
    ("text", "Основной текст"), ("muted", "Второстепенный текст"), ("accent", "Акцент (рамка фокуса, заголовки)"),
    ("radius", "Скругление панелей, dp"),
]

# поля одного элемента: ключ → подпись
EL_FIELDS = [
    ("x", "X, % слева"), ("y", "Y, % сверху"), ("w", "Ширина, % (0 = по тексту)"),
    ("h", "Высота, % (0 = по тексту)"),
]


def _einfo(eid):
    """(подпись, вид) элемента; mb_<ключ> — кнопка пункта меню."""
    if eid in ELEMENTS:
        return ELEMENTS[eid]
    if eid.startswith("mb_plugin_"):
        try:
            raw = eid[len("mb_plugin_"):]
            decoded = base64.urlsafe_b64decode(raw + "=" * (-len(raw) % 4)).decode("utf-8")
            plugin, section, event = decoded.split("\0", 2)
            return ("Кнопка настройки: %s / %s" % (plugin, event), "leaf")
        except Exception:
            return ("Кнопка настройки плагина", "leaf")
    if eid.startswith("mb_"):
        return ("Кнопка меню: " + _MENU_LABEL.get(eid[3:], eid[3:]), "leaf")
    return (eid, "leaf")


def _default_el(eid):
    if eid in DEFAULT_MAIN:
        return copy.deepcopy(DEFAULT_MAIN[eid])
    n = sum(1 for k in _cfg["main"] if k.startswith("mb_") and k != eid)
    return {"visible": True, "x": round(2 + (n % 6) * 16, 1), "y": round(76.5 + (n // 6) * 6.5, 1),
            "w": 15, "h": 6, "textSize": 13}


def _el_extra(kind):
    out = []
    if kind == "leaf":
        out.append(("textSize", "Размер текста, sp (0 = по умолчанию)"))
    elif kind == "panel":
        out.append(("textScale", "Масштаб текста (1 = как есть)"))
    if kind != "hud":
        out += [("radius", "Скругление, dp (-1 = таблетка)"), ("fill", "Цвет заливки"),
                ("stroke", "Цвет рамки"), ("strokeWidth", "Толщина рамки, dp"), ("textColor", "Цвет текста")]
    if kind == "leaf":
        out.append(("focusColor", "Цвет рамки при фокусе (кнопка)"))
    return out


# ── окно видео ───────────────────────────────────────────────────────────────
# Видео играет в плавающем окне поверх экрана (работает и при свёрнутом Джарвисе).
# Положение и размер в % экрана; окно можно двигать/менять мышью — приложение само пишет сюда.
DEFAULT_VIDEO = {"mode": "window", "x": 20, "y": 14, "w": 60, "h": 62, "radius": 14, "opacity": 100,
                 "iconSize": 34, "autoHide": 3,
                 "showSeek": 1, "showVolume": 1, "showScale": 1, "showFull": 1, "showTitle": 1}
VIDEO_MODES = (("window", "Окно (двигать и менять размер мышью)"),
               ("full", "Во весь экран (окно поверх всего)"),
               ("legacy", "Старый режим: внутри экрана Джарвиса"))
VIDEO_FIELDS = [
    ("x", "Левый край, % экрана", "20"), ("y", "Верхний край, % экрана", "14"),
    ("w", "Ширина окна, % экрана", "60"), ("h", "Высота окна, % экрана", "62"),
    ("radius", "Скругление окна, dp", "14"), ("opacity", "Непрозрачность окна, % (20–100)", "100"),
    ("iconSize", "Размер кнопок управления, dp", "34"),
    ("autoHide", "Прятать кнопки через, сек (0 = не прятать)", "3"),
    ("showSeek", "Кнопки «назад/вперёд 10 с» (1/0)", "1"),
    ("showVolume", "Кнопка звука (1/0)", "1"),
    ("showScale", "Кнопки масштаба «−» «+» (1/0)", "1"),
    ("showFull", "Кнопка «на весь экран» (1/0)", "1"),
    ("showTitle", "Название сверху (1/0)", "1"),
]
_VID_INT = {"radius", "opacity", "autoHide", "showSeek", "showVolume", "showScale", "showFull", "showTitle"}
_VID_COLORS = (("accent", "Цвет полосы перемотки (как красная у YouTube)", "#FF0000"),
               ("iconColor", "Цвет значков", "#FFFFFF"),
               ("barColor", "Цвет затемнения под кнопками", "#B3000000"),
               ("titleColor", "Цвет названия", "#FFFFFF"),
               ("frameColor", "Цвет рамки окна", "#00000000"))

# ── микрофон, номера и кнопки окна результатов (общий вид для оверлея, полосы и окна результатов) ──
# Пустое значение = берётся из темы.
WIDGET_FIELDS = [
    ("micSize", "Микрофон: размер, dp", "44"),
    ("badgeSize", "Номер на постере: высота плашки, dp", "22"),
    ("btnH", "Кнопки окна результатов: высота, dp (0 = по тексту)", "0"),
    ("btnTextSize", "Кнопки окна результатов: размер текста, sp (пусто = по умолчанию)", ""),
    ("btnRadius", "Кнопки окна результатов: скругление, dp (пусто = по теме)", ""),
    ("btnStrokeWidth", "Кнопки окна результатов: толщина рамки, dp", ""),
]
_WID_INT = {"btnRadius"}
# ключ, подпись, функция значения по умолчанию из темы
WIDGET_COLORS = [
    ("micIcon", "Микрофон: цвет значка", lambda th: th.get("text", "#E8EAED")),
    ("micPlate", "Микрофон: цвет круга", lambda th: "#30" + th.get("accent", "#8AB4F8").lstrip("#")[-6:]),
    ("micActive", "Микрофон: цвет круга при прослушивании", lambda th: th.get("accent", "#8AB4F8")),
    ("badgeFill", "Номер: цвет плашки", lambda th: th.get("accent", "#8AB4F8")),
    ("badgeInk", "Номер: цвет цифры", lambda th: th.get("bg", "#202124")),
    ("btnFill", "Кнопки окна результатов: заливка", lambda th: th.get("surface", "#303134")),
    ("btnStroke", "Кнопки окна результатов: рамка", lambda th: "#00000000"),
    ("btnText", "Кнопки окна результатов: цвет текста", lambda th: th.get("text", "#E8EAED")),
    ("btnFocus", "Кнопки окна результатов: цвет рамки при фокусе", lambda th: th.get("accent", "#8AB4F8")),
]

# ── конфиг ───────────────────────────────────────────────────────────────────
_lock = threading.RLock()
_cfg = {"mode": "off", "preset": "dark", "dots": False, "edit": False, "theme": {}, "main": {}, "results": {}, "overlay": {}, "pos": {}, "widgets": {},
        "video": {}}
_mt = {"t": 0.0}
_st = {"sec": "home", "el": "log", "nav": []}


def _android():
    try:
        import android_bridge as android
        return android
    except Exception:
        return None


def _file():
    a = _android()
    base = ""
    try:
        base = (a.data_dir() if a else "") or ""
    except Exception:
        pass
    return os.path.join(base or ".", "screen_layout.json")


def _log(text):
    a = _android()
    try:
        if a:
            a.log("screen_style: " + text)
    except Exception:
        pass


def _fresh(preset="dark"):
    return {"mode": _cfg.get("mode", "off"), "preset": preset, "theme": copy.deepcopy(THEMES[preset]),
            "main": copy.deepcopy(DEFAULT_MAIN), "results": copy.deepcopy(DEFAULT_RESULTS),
            "overlay": copy.deepcopy(DEFAULT_OVERLAY)}


def _load():
    try:
        with open(_file(), encoding="utf-8") as f:
            d = json.load(f)
        if isinstance(d, dict):
            for k in ("mode", "preset"):
                if isinstance(d.get(k), str):
                    _cfg[k] = d[k]
            _cfg["dots"] = bool(d.get("dots", False))
            _cfg["edit"] = bool(d.get("edit", False))
            for k in ("theme", "main", "results", "overlay", "video", "pos", "widgets"):
                if isinstance(d.get(k), dict):
                    _cfg[k] = d[k]
    except Exception:
        pass
    if not _cfg["main"]:
        _cfg.update({k: v for k, v in _fresh(_cfg.get("preset", "dark")).items() if k != "mode"})
    if not _cfg.get("overlay"):
        _cfg["overlay"] = copy.deepcopy(DEFAULT_OVERLAY)
    if not _cfg.get("video"):
        _cfg["video"] = copy.deepcopy(DEFAULT_VIDEO)
    try:
        _mt["t"] = os.path.getmtime(_file())
    except OSError:
        pass


def _reload_if_changed():
    """Приложение само пишет в файл (редактор: перетаскивание, «Готово») — подхватываем эти правки."""
    try:
        if os.path.getmtime(_file()) != _mt["t"]:
            with _lock:
                _load()
    except OSError:
        pass


def _save():
    with _lock:
        try:
            tmp = _file() + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(_cfg, f, ensure_ascii=False, indent=1)
            os.replace(tmp, _file())
            _mt["t"] = os.path.getmtime(_file())
        except Exception as e:
            _log("не удалось сохранить: %s" % e)


# ── значения полей ───────────────────────────────────────────────────────────
def _num(s):
    s = str(s).strip().replace(",", ".")
    if not s:
        return None
    try:
        v = float(s)
        return int(v) if v == int(v) and "." not in s else v
    except ValueError:
        return None


def _color(s):
    s = str(s).strip()
    if not s:
        return ""
    if not s.startswith("#"):
        s = "#" + s
    body = s[1:]
    if len(body) in (6, 8) and all(c in "0123456789abcdefABCDEF" for c in body):
        return s.upper()
    return None


def _fmt(v):
    if v is None:
        return ""
    if isinstance(v, bool):
        return "1" if v else "0"
    if isinstance(v, float) and v == int(v):
        return str(int(v))
    return str(v)


def _apply_values(values):
    """Переносит поля текущей страницы в конфиг. Пустое поле = убрать ключ (значение по умолчанию)."""
    sec = _st["sec"]
    if not isinstance(values, dict) or not values:
        return
    with _lock:
        if sec == "theme":
            for k, _l in THEME_FIELDS:
                if ("t_" + k) not in values:
                    continue
                raw = values["t_" + k]
                if k == "radius":
                    n = _num(raw)
                    if n is not None:
                        _cfg["theme"][k] = int(n)
                else:
                    c = _color(raw)
                    if c:
                        _cfg["theme"][k] = c
                    elif c == "":
                        _cfg["theme"].pop(k, None)           # пусто = цвет по умолчанию
        elif sec.startswith("el:"):
            eid = sec[3:]
            kind = _einfo(eid)[1]
            el = _cfg["main"].setdefault(eid, {})
            for k, _l in EL_FIELDS + _el_extra(kind):
                key = "e_" + k
                if key not in values:
                    continue
                raw = values[key]
                if k in ("fill", "stroke", "textColor", "focusColor"):
                    c = _color(raw)
                    if c is None:
                        continue
                    if c:
                        el[k] = c
                    else:
                        el.pop(k, None)
                else:
                    n = _num(raw)
                    if n is None:
                        if str(raw).strip() == "":
                            el.pop(k, None)
                        continue
                    el[k] = n
        elif sec == "widgets":
            wd = _cfg["widgets"]
            for k in [f[0] for f in WIDGET_FIELDS] + [c[0] for c in WIDGET_COLORS]:
                key = "w_" + k
                if key not in values:
                    continue
                raw = values[key]
                if k in [c[0] for c in WIDGET_COLORS]:
                    c = _color(raw)
                    if c is None:
                        continue
                    if c:
                        wd[k] = c
                    else:
                        wd.pop(k, None)
                else:
                    n = _num(raw)
                    if n is None:
                        if str(raw).strip() == "":
                            wd.pop(k, None)
                        continue
                    wd[k] = int(n) if k in _WID_INT else n
        elif sec == "video":
            vd = _cfg["video"]
            for k in [f[0] for f in VIDEO_FIELDS] + [c[0] for c in _VID_COLORS]:
                key = "v_" + k
                if key not in values:
                    continue
                raw = values[key]
                if k in [c[0] for c in _VID_COLORS]:
                    c = _color(raw)
                    if c is None:
                        continue
                    if c:
                        vd[k] = c
                    else:
                        vd.pop(k, None)
                else:
                    n = _num(raw)
                    if n is None:
                        if str(raw).strip() == "":
                            vd.pop(k, None)
                        continue
                    vd[k] = int(n) if k in _VID_INT else n
        elif sec == "overlay":
            ov = _cfg["overlay"]
            for k in [f[0] for f in OVERLAY_FIELDS] + ["fill", "stroke", "textColor"]:
                key = "o_" + k
                if key not in values:
                    continue
                raw = values[key]
                if k in ("fill", "stroke", "textColor", "focusColor"):
                    c = _color(raw)
                    if c is None:
                        continue
                    if c:
                        ov[k] = c
                    else:
                        ov.pop(k, None)
                else:
                    n = _num(raw)
                    if n is None:
                        if str(raw).strip() == "":
                            ov.pop(k, None)
                        continue
                    ov[k] = int(n) if k in _OVL_INT else n
        elif sec == "results":
            for k, _l, _h in RESULT_FIELDS:
                key = "r_" + k
                if key not in values:
                    continue
                raw = values[key]
                if k in _RES_STR:
                    c = _color(raw)
                    if c is None:
                        continue
                    if c:
                        _cfg["results"][k] = c
                    else:
                        _cfg["results"].pop(k, None)
                else:
                    n = _num(raw)
                    if n is None:
                        if str(raw).strip() == "":
                            _cfg["results"].pop(k, None)
                        continue
                    if k in _RES_BOOL:
                        n = 1 if n else 0
                    elif k in _RES_INT:
                        n = int(n)
                    _cfg["results"][k] = n
    _save()


# ── страница настроек ────────────────────────────────────────────────────────
_MODES = (("off", "Классический экран"), ("layout", "Стиль Google (раскладка из JSON)"),
          ("frame", "Стиль Google + анимированный фон от плагина"))


def _btn(i, label):
    return {"type": "button", "id": i, "label": label, "section": _st.get("sec", "home")}


def _lbl(t):
    return {"type": "label", "text": t}


def _field(i, label, value, hint=""):
    return {"type": "text", "id": i, "label": label, "value": _fmt(value), "hint": hint}


def _color_item(i, label, value, default):
    """Эквалайзер цвета (R, G, B, прозрачность) + код. Пустое значение = по умолчанию."""
    return {"type": "color", "id": i, "label": label, "value": _fmt(value), "default": default}


_COLOR_KEYS = ("fill", "stroke", "textColor", "focusColor")


def _theme_default(key):
    th = _cfg.get("theme") or {}
    return {"fill": th.get("surface", "#303134"), "stroke": "#00000000",
            "textColor": th.get("text", "#E8EAED"), "focusColor": th.get("accent", "#8AB4F8")}.get(key, "#FFFFFF")


def _element_ids():
    ids = list(ELEMENTS)
    ids += [k for k in _cfg["main"] if k.startswith("mb_") and k not in ids]
    return ids


def settings_items():
    _reload_if_changed()
    sec = _st["sec"]
    c = _cfg
    items = []
    if sec == "home":
        items.append(_lbl("Режим: %s. Тема: %s.%s" % (
            dict(_MODES).get(c["mode"], c["mode"]), "светлая" if c["preset"] == "light" else "тёмная",
            "  РЕДАКТОР ВКЛЮЧЁН." if c.get("edit") else "")))
        items.append(_lbl("Изменения применяются, когда вы вернётесь на главный экран (кнопка «Назад»)."))
        for m, t in _MODES:
            items.append(_btn("mode:" + m, ("● " if c["mode"] == m else "○ ") + t))
        if c["mode"] == "frame":
            items.append(_btn("dots", "Четыре точки Google внизу: " + ("ВКЛ → выключить" if c.get("dots") else "ВЫКЛ → включить")))
        items.append(_btn("edit_on", "Редактор: перетаскивать элементы мышью"))
        items.append(_lbl("Готовые пресеты (сбрасывают раскладку, цвета, окно результатов и оверлей; кнопки меню остаются):"))
        items.append(_btn("preset:dark", "Пресет: Google, тёмная тема"))
        items.append(_btn("preset:light", "Пресет: Google, светлая тема"))
        items.append(_lbl("Тонкая настройка:"))
        items.append(_btn("nav:theme", "Цвета и скругление темы (для всех меню)"))
        items.append(_btn("nav:elements", "Главный экран: все элементы"))
        items.append(_btn("nav:menubtns", "Кнопки из меню на главном экране"))
        items.append(_btn("nav:results", "Окно результатов поиска"))
        items.append(_btn("nav:overlay", "Оверлей микрофона (как у Google)"))
        items.append(_btn("nav:video", "Окно видео: положение, размер, кнопки как у YouTube"))
        items.append(_btn("nav:widgets", "Микрофон, номера, кнопки результатов: цвет и размер"))
    elif sec == "theme":
        items.append(_lbl("Цвета подбираются эквалайзером: R, G, B и прозрачность. Кнопка OK на полосе — менять "
                          "вверх/вниз, ещё раз OK — выйти. Мышью — потянуть полосу. Тема действует во всех меню."))
        for k, l in THEME_FIELDS:
            if k == "radius":
                items.append(_field("t_" + k, l, c["theme"].get(k, THEMES["dark"].get(k)), "24"))
            else:
                items.append(_color_item("t_" + k, l, c["theme"].get(k), THEMES["dark"].get(k, "#FFFFFF")))
        items.append(_btn("save", "Сохранить"))
        items.append(_btn("nav:back", "← Назад"))
    elif sec == "elements":
        items.append(_lbl("Выберите элемент главного экрана:"))
        for eid in _element_ids():
            label = _einfo(eid)[0]
            on = c["main"].get(eid, {}).get("visible", True)
            items.append(_btn("nav:el:" + eid, label + ("" if on else "  (скрыт)")))
        items.append(_btn("nav:back", "← Назад"))
    elif sec == "menubtns":
        items.append(_lbl("Отметьте пункты сервисного меню, которые станут кнопками на главном экране "
                          "(✔ — уже на экране, нажмите ещё раз, чтобы убрать). Двигать и менять размер — "
                          "в редакторе или в «Главный экран: все элементы»."))
        for key, label in MENU_ITEMS:
            on = ("mb_" + key) in c["main"]
            items.append(_btn("mbt:" + key, ("✔ " if on else "＋ ") + label))
        items.append(_btn("nav:back", "← Назад"))
    elif sec.startswith("el:"):
        eid = sec[3:]
        label, kind = _einfo(eid)
        el = c["main"].setdefault(eid, _default_el(eid))
        items.append(_lbl("%s — X %s%%, Y %s%%, ширина %s%%, высота %s%%" % (
            label, _fmt(el.get("x", 0)), _fmt(el.get("y", 0)), _fmt(el.get("w", 0)), _fmt(el.get("h", 0)))))
        items.append(_btn("vis", "Скрыть элемент" if el.get("visible", True) else "Показать элемент"))
        items.append(_lbl("Двигать (шаг 1%):"))
        for i, t in (("mv:l", "← влево"), ("mv:r", "вправо →"), ("mv:u", "↑ вверх"), ("mv:d", "вниз ↓")):
            items.append(_btn(i, t))
        items.append(_lbl("Размер (шаг 1%):"))
        for i, t in (("sz:w+", "шире"), ("sz:w-", "уже"), ("sz:h+", "выше"), ("sz:h-", "ниже")):
            items.append(_btn(i, t))
        if kind in ("leaf", "panel"):
            items.append(_btn("tx:+", "Текст крупнее"))
            items.append(_btn("tx:-", "Текст мельче"))
        items.append(_lbl("Точные значения:"))
        for k, l in EL_FIELDS + _el_extra(kind):
            if k in _COLOR_KEYS:
                items.append(_color_item("e_" + k, l, el.get(k), _theme_default(k)))
            else:
                items.append(_field("e_" + k, l, el.get(k), ""))
        items.append(_btn("save", "Сохранить"))
        if eid.startswith("mb_"):
            items.append(_btn("rm_mb", "Убрать кнопку с главного экрана"))
        items.append(_btn("reset_el", "Сбросить элемент к пресету"))
        items.append(_btn("nav:elements", "← К списку элементов"))
    elif sec == "results":
        items.append(_lbl("Окно результатов поиска (плитки и список). Пустое поле — значение по умолчанию."))
        for k, l, h in RESULT_FIELDS:
            if k in _RES_STR:
                items.append(_color_item("r_" + k, l, c["results"].get(k), (c.get("theme") or {}).get(
                    "surface", "#303134") if k == "panelFill" else "#00000000"))
            else:
                items.append(_field("r_" + k, l, c["results"].get(k), h))
        items.append(_btn("save", "Сохранить"))
        items.append(_btn("reset_res", "Сбросить окно к пресету"))
        items.append(_btn("nav:back", "← Назад"))
    elif sec == "widgets":
        wd = c["widgets"]
        th = c.get("theme") or {}
        items.append(_lbl("Общий вид для оверлея, полосы и окна результатов. Пусто — как в теме. Положение микрофона и кнопок "
                          "двигается мышью прямо на экране."))
        for k, l, h in WIDGET_FIELDS:
            items.append(_field("w_" + k, l, wd.get(k), h))
        for k, l, fn in WIDGET_COLORS:
            items.append(_color_item("w_" + k, l, wd.get(k), fn(th)))
        items.append(_btn("save", "Сохранить"))
        items.append(_btn("reset_widgets", "Сбросить к теме"))
        items.append(_btn("nav:back", "← Назад"))
    elif sec == "video":
        vd = c["video"]
        items.append(_lbl("Видео играет в плавающем окне поверх экрана — и когда Джарвис свёрнут. Мышью: тащите окно "
                          "за видео, правый нижний угол — размер, колесо — масштаб, клик — пауза. Если окно не появляется — "
                          "включите разрешение «Поверх других окон» (меню → Индикатор микрофона). Режим:"))
        for m, t in VIDEO_MODES:
            items.append(_btn("vmode:" + m, ("● " if vd.get("mode", "window") == m else "○ ") + t))
        for k, l, h in VIDEO_FIELDS:
            items.append(_field("v_" + k, l, vd.get(k), h))
        for k, l, dflt in _VID_COLORS:
            items.append(_color_item("v_" + k, l, vd.get(k), dflt))
        items.append(_btn("save", "Сохранить"))
        items.append(_btn("vscale:-10", "Окно меньше на 10 %"))
        items.append(_btn("vscale:10", "Окно больше на 10 %"))
        items.append(_btn("vcenter", "Поставить окно по центру"))
        items.append(_btn("reset_video", "Сбросить окно видео"))
        items.append(_btn("nav:back", "← Назад"))
    elif sec == "overlay":
        o = c["overlay"]
        items.append(_lbl("Оверлей микрофона — нижняя панель поверх любого приложения (быстрое действие «Микрофон-полоса»). "
                          "Работает в режимах «Стиль Google». Режим показа:"))
        for m, t in OVERLAY_MODES:
            items.append(_btn("omode:" + m, ("● " if o.get("mode", "both") == m else "○ ") + t))
        for k, l, h in OVERLAY_FIELDS:
            items.append(_field("o_" + k, l, o.get(k), h))
        th = c.get("theme") or {}
        items.append(_color_item("o_fill", "Цвет панели (пусто = из темы)", o.get("fill"), th.get("surface", "#303134")))
        items.append(_color_item("o_stroke", "Цвет рамки панели", o.get("stroke"), "#00000000"))
        items.append(_color_item("o_textColor", "Цвет текста запроса (пусто = из темы)", o.get("textColor"), th.get("text", "#E8EAED")))
        items.append(_btn("save", "Сохранить"))
        items.append(_btn("reset_ov", "Сбросить оверлей к пресету"))
        items.append(_btn("reset_pos", "Сбросить положение микрофона, точек, надписи и кнопок (оверлей, полоса, результаты)"))
        items.append(_btn("nav:back", "← Назад"))
    return items


def _step(el, key, delta, lo=0.0, hi=100.0):
    cur = float(el.get(key, 0) or 0)
    el[key] = round(max(lo, min(hi, cur + delta)), 2)


def settings_event(event, values):
    _reload_if_changed()
    event = str(event)
    _apply_values(values)
    if event == "__leave__":
        with _lock:
            _st["sec"] = "home"
            _st["nav"] = []
        return ""
    if event.startswith(("pin_add:", "pin_remove:")):
        adding = event.startswith("pin_add:")
        eid = event.split(":", 1)[1]
        if not eid.startswith("mb_plugin_"):
            return {"message": "", "refresh": False}
        with _lock:
            if adding:
                if eid not in _cfg["main"]:
                    _cfg["main"][eid] = _default_el(eid)
                if _cfg["mode"] == "off":
                    _cfg["mode"] = "layout"
            else:
                _cfg["main"].pop(eid, None)
        _save()
        return {"message": "", "refresh": True}
    if event == "__reset_nav__":
        with _lock:
            _st["sec"] = "home"
            _st["nav"] = []
        return {"message": "", "refresh": False}
    if event == "__back__":
        with _lock:
            if _st.get("nav"):
                _st["sec"] = _st["nav"].pop()
                return {"message": "", "refresh": True, "close": False}
            _st["sec"] = "home"
            return {"message": "", "refresh": False, "close": True}
    msg, sec = "", _st["sec"]
    with _lock:
        if event.startswith("nav:"):
            tgt = event[4:]
            if tgt == "back":
                _st["sec"] = _st["nav"].pop() if _st.get("nav") else "home"
            else:
                current = _st.get("sec", "home")
                if tgt != current:
                    _st.setdefault("nav", []).append(current)
                if tgt.startswith("el:"):
                    _st["el"] = tgt[3:]
                _st["sec"] = tgt
        elif event == "dots":
            _cfg["dots"] = not _cfg.get("dots")
            msg = "Точки включены." if _cfg["dots"] else "Точки выключены."
        elif event == "edit_on":
            if _cfg["mode"] == "off":
                _cfg["mode"] = "layout"
            _cfg["edit"] = True
            msg = "Редактор включён. Нажмите «Назад» — на главном экране тащите элементы мышью."
        elif event.startswith("mbt:"):
            key, eid = event[4:], "mb_" + event[4:]
            if eid in _cfg["main"]:
                del _cfg["main"][eid]
                msg = "Кнопка убрана с главного экрана."
            elif key in _MENU_LABEL:
                _cfg["main"][eid] = _default_el(eid)
                if _cfg["mode"] == "off":
                    _cfg["mode"] = "layout"
                msg = "Кнопка добавлена на главный экран."
        elif event.startswith("omode:"):
            if event[6:] in dict(OVERLAY_MODES):
                _cfg["overlay"]["mode"] = event[6:]
                msg = "Режим оверлея изменён."
        elif event.startswith("vmode:"):
            if event[6:] in dict(VIDEO_MODES):
                _cfg["video"]["mode"] = event[6:]
                msg = "Режим видео изменён."
        elif event.startswith("vscale:"):
            vd = _cfg["video"]
            try:
                f = 1.0 + float(event[7:]) / 100.0
            except ValueError:
                f = 1.0
            cx = float(vd.get("x", 20)) + float(vd.get("w", 60)) / 2
            cy = float(vd.get("y", 14)) + float(vd.get("h", 62)) / 2
            w = max(10.0, min(100.0, float(vd.get("w", 60)) * f))
            h = max(8.0, min(100.0, float(vd.get("h", 62)) * f))
            vd.update({"w": round(w, 1), "h": round(h, 1),
                       "x": round(max(0.0, min(100.0 - w, cx - w / 2)), 1),
                       "y": round(max(0.0, min(100.0 - h, cy - h / 2)), 1)})
            msg = "Размер окна: %.0f × %.0f %%." % (w, h)
        elif event == "vcenter":
            vd = _cfg["video"]
            vd["x"] = round((100.0 - float(vd.get("w", 60))) / 2, 1)
            vd["y"] = round((100.0 - float(vd.get("h", 62))) / 2, 1)
            msg = "Окно по центру."
        elif event == "reset_video":
            _cfg["video"] = copy.deepcopy(DEFAULT_VIDEO)
            msg = "Окно видео сброшено."
        elif event == "reset_widgets":
            _cfg["widgets"] = {}
            msg = "Вид микрофона, номеров и кнопок сброшен к теме."
        elif event == "reset_pos":
            _cfg["pos"] = {}
            msg = "Положение микрофона и кнопок сброшено."
        elif event == "reset_ov":
            _cfg["overlay"] = copy.deepcopy(DEFAULT_OVERLAY)
            msg = "Оверлей сброшен."
        elif event.startswith("mode:"):
            set_mode(event[5:])
            msg = "Режим изменён. Вернитесь на главный экран."
        elif event.startswith("preset:"):
            apply_preset(event[7:])
            msg = "Пресет применён. Вернитесь на главный экран."
        elif sec.startswith("el:"):
            eid = sec[3:]
            el = _cfg["main"].setdefault(eid, _default_el(eid))
            kind = _einfo(eid)[1]
            if event == "vis":
                el["visible"] = not el.get("visible", True)
            elif event.startswith("mv:"):
                d = event[3:]
                _step(el, "x" if d in "lr" else "y", (-1 if d in "lu" else 1))
            elif event.startswith("sz:"):
                k, sgn = event[3], event[4]
                _step(el, k, 1 if sgn == "+" else -1)
            elif event.startswith("tx:"):
                up = event[3] == "+"
                if kind == "panel":
                    cur = float(el.get("textScale", 1.0) or 1.0)
                    el["textScale"] = round(max(0.5, min(3.0, cur + (0.1 if up else -0.1))), 2)
                else:
                    cur = float(el.get("textSize", 0) or _default_el(eid).get("textSize", 14))
                    el["textSize"] = round(max(6.0, min(60.0, cur + (1 if up else -1))), 1)
            elif event == "reset_el":
                _cfg["main"][eid] = _default_el(eid)
                msg = "Элемент сброшен."
            elif event == "rm_mb" and eid.startswith("mb_"):
                _cfg["main"].pop(eid, None)
                _st["sec"] = "elements"
                msg = "Кнопка убрана с главного экрана."
        elif event == "reset_res" and sec == "results":
            _cfg["results"] = copy.deepcopy(DEFAULT_RESULTS)
            msg = "Окно результатов сброшено."
    _save()
    return {"message": msg, "refresh": True}


# ── режимы / пресеты ─────────────────────────────────────────────────────────
def set_mode(mode):
    if mode not in ("off", "layout", "frame"):
        return
    with _lock:
        _cfg["mode"] = mode
        if mode != "off" and not _cfg["main"]:
            _cfg.update({k: v for k, v in _fresh(_cfg.get("preset", "dark")).items() if k != "mode"})
    _save()
    if mode == "frame":
        _start()
    else:
        _halt()


def apply_preset(name):
    name = "light" if name == "light" else "dark"
    with _lock:
        mode = _cfg["mode"] if _cfg["mode"] != "off" else "layout"
        dots = _cfg.get("dots", False)
        keep = {k: v for k, v in _cfg["main"].items() if k.startswith("mb_")}
        _cfg.update(_fresh(name))
        _cfg["main"].update(keep)
        _cfg["dots"] = dots
        _cfg["mode"] = mode
    _save()
    if mode == "frame":
        _start()


# ── кадр фона (режим frame) ──────────────────────────────────────────────────
_BLOBS = (  # цвета Google: синий, красный, жёлтый, зелёный
    ((66, 133, 244), 0.0, 0.31, 0.23), ((234, 67, 53), 1.7, 0.27, 0.31),
    ((251, 188, 5), 3.3, 0.37, 0.19), ((52, 168, 83), 5.0, 0.23, 0.35),
)
_DOT_COLORS = ((66, 133, 244), (234, 67, 53), (251, 188, 5), (52, 168, 83))
_FW, _FH, _FPS = 640, 360, 10

_thread = None
_stop = threading.Event()
_lv = {"at": None, "t": 0.0}


def _kt():
    from tvshim.bridge import kt
    return kt()


def _read_state():
    k = _kt()
    try:
        state = str(k.getCurState() or "SLEEPING").upper()
    except Exception:
        state = "SLEEPING"
    level = 0.0
    try:
        at = int(k.getLevelAt())
        now = time.monotonic()
        if at != _lv["at"]:
            _lv["at"], _lv["t"] = at, now
        if now - _lv["t"] < 0.3:
            level = float(k.getLevel())
    except Exception:
        pass
    try:
        vis = bool(k.getAppVisible())
    except Exception:
        vis = True
    return state, level, vis


def _hex(c, d):
    try:
        c = c.lstrip("#")
        return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))
    except Exception:
        return d


def render_frame(t, amp, state, theme, np, Image, ImageDraw, dots=False):
    """Один кадр фона: RGBA bytes _FW*_FH*4."""
    bg = _hex(theme.get("bg", "#202124"), (32, 33, 36))
    light = sum(bg) > 384
    sw, sh = _FW // 4, _FH // 4
    ys, xs = np.mgrid[0:sh, 0:sw].astype(np.float32)
    xs /= sw
    ys /= sh
    base = np.empty((sh, sw, 3), np.float32)
    grad = (ys * 0.5)[..., None]
    shade = np.array(bg, np.float32)
    base[:] = shade * (1.0 - grad * (0.10 if light else -0.25))      # к низу чуть светлее/темнее
    gain = 0.20 if light else 0.26
    speed = 1.0 + 1.5 * amp
    for col, ph, bx, by in _BLOBS:
        cx = bx + 0.22 * math.sin(t * 0.16 * speed + ph)
        cy = by + 0.18 * math.cos(t * 0.13 * speed + ph * 1.3)
        d2 = ((xs - cx) * (16 / 9)) ** 2 + (ys - cy) ** 2
        a = np.exp(-d2 / (0.045 + 0.02 * amp)) * (gain + 0.22 * amp)
        base += a[..., None] * (np.array(col, np.float32) - base)
    img = Image.fromarray(np.clip(base, 0, 255).astype(np.uint8), "RGB").resize((_FW, _FH), Image.BILINEAR)
    d = ImageDraw.Draw(img)
    if not dots:
        return img.convert("RGBA").tobytes()
    # четыре точки Google Assistant (по желанию): ждут → дышат, говорят/слушают → столбики по уровню
    live = state in ("LISTENING", "SPEAKING", "THINKING", "PROCESSING")
    cx0, cy0 = _FW / 2.0, _FH * 0.93
    gap, w = _FW * 0.035, _FW * 0.022
    for i, col in enumerate(_DOT_COLORS):
        if state in ("THINKING", "PROCESSING"):
            k = 0.5 + 0.5 * math.sin(t * 5.0 - i * 0.9)
        elif live:
            k = min(1.0, amp * (0.55 + 0.45 * math.sin(t * 9.0 + i * 1.7)) * 1.6)
        else:
            k = 0.0
        h = w + k * _FH * 0.075
        x = cx0 + (i - 1.5) * gap
        d.rounded_rectangle((x - w / 2, cy0 - h / 2, x + w / 2, cy0 + h / 2), radius=w / 2, fill=col)
    return img.convert("RGBA").tobytes()


def _loop():
    import numpy as np
    from PIL import Image, ImageDraw
    k = _kt()
    t0 = time.monotonic()
    smooth = 0.0
    try:
        while not _stop.is_set():
            ts = time.monotonic()
            state, level, vis = _read_state()
            if not vis:
                _stop.wait(0.5)
                continue
            smooth += (level - smooth) * 0.5
            with _lock:
                theme = dict(_cfg.get("theme") or THEMES["dark"])
                dots = bool(_cfg.get("dots"))
            try:
                k.bgFrame(render_frame(ts - t0, smooth, state, theme, np, Image, ImageDraw, dots), _FW, _FH)
            except Exception as e:
                _log("кадр фона: %s: %s" % (type(e).__name__, e))
                _stop.wait(2.0)
            _stop.wait(max(0.0, 1.0 / _FPS - (time.monotonic() - ts)))
    finally:
        try:
            k.bgFrameClear()
        except Exception:
            pass


def _start():
    global _thread
    with _lock:
        if _thread is not None and _thread.is_alive():
            return
        _stop.clear()
        _thread = threading.Thread(target=_loop, name="screen-style-bg", daemon=True)
        _thread.start()


def _halt():
    global _thread
    with _lock:
        t, _thread = _thread, None
    if t is not None:
        _stop.set()
        t.join(timeout=2.0)


# ── голосовой инструмент ─────────────────────────────────────────────────────
def run(parameters: dict, player=None, session_memory=None) -> str:
    p = parameters or {}
    _reload_if_changed()
    mode = str(p.get("mode") or "").strip().lower()
    theme = str(p.get("theme") or "").strip().lower()
    ovm = str(p.get("overlay_mode") or "").strip().lower()
    edit = str(p.get("edit") or "").strip().lower()
    try:
        if ovm in dict(OVERLAY_MODES):
            _cfg["overlay"]["mode"] = ovm
            _save()
            if not (mode or theme or edit):
                return "Режим оверлея: %s, сэр." % dict(OVERLAY_MODES)[ovm].split(" (")[0].lower()
        if edit in ("on", "off"):
            if edit == "on" and _cfg["mode"] == "off":
                _cfg["mode"] = "layout"
            _cfg["edit"] = edit == "on"
            _save()
            return "Редактор экрана включён, сэр. Тащите элементы мышью." if edit == "on" else "Редактор выключен."
        if theme in ("light", "светлая", "светлый"):
            apply_preset("light")
        elif theme in ("dark", "тёмная", "темная", "тёмный", "темный"):
            apply_preset("dark")
        if mode in ("off", "выкл", "классика", "classic"):
            set_mode("off")
            return "Вернул классический экран, сэр. Он обновится через пару секунд."
        if mode in ("layout", "frame"):
            set_mode(mode)
        elif not theme:
            set_mode("layout" if _cfg["mode"] == "off" else "off")
    except Exception as e:
        return "Сэр, экран не удалось изменить: %s" % e
    return ("Готово, сэр. Экран обновится через пару секунд." if _cfg["mode"] != "off"
            else "Вернул классический экран, сэр.")


# ── автозапуск ───────────────────────────────────────────────────────────────
try:
    _load()
    if _cfg["mode"] == "frame":
        _start()
except Exception:
    pass
