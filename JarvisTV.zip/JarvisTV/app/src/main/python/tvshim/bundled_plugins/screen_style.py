"""Внешний вид главного экрана и окна результатов — в стиле Google TV.

Плагин ничего не рисует сам в Jarvis, он пишет файл plugin_data/screen_layout.json, а приложение
читает его и переставляет/перекрашивает элементы (Skin.kt). Три режима:

    off     — как раньше, классический экран
    layout  — раскладка из JSON: положение, размер, цвета, текст каждого элемента
    frame   — то же + полноэкранный фон, который плагин рисует кадрами (плавающие цветные пятна
              и «четыре точки» Google Assistant внизу, реагирующие на голос)

Настройка: Меню → Настройки плагинов → «Экран (стиль Google)». После правок вернитесь на главный
экран — он перестроится сам (в течение пары секунд). Голосом: «включи экран гугл»,
«выключи стиль гугл», «светлая тема экрана».

Единицы в полях: x, y, w, h — проценты экрана (w/h = 0 → по содержимому); textSize — sp;
radius, strokeWidth — dp (radius -1 → «таблетка»); цвета — #RRGGBB или #AARRGGBB.
Пустое поле = значение по умолчанию.
"""
from __future__ import annotations

import copy
import json
import math
import os
import threading
import time

PLUGIN = {
    "name": "screen_style",
    "description": (
        "Сменить внешний вид главного экрана Jarvis на ТВ: включить или выключить стиль Google, "
        "выбрать тёмную или светлую тему, включить анимированный фон. Вызывай на фразы «включи экран "
        "гугл», «стиль гугл», «верни старый экран», «светлая тема экрана», «тёмная тема экрана»."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING", "description": "off (классика), layout (стиль Google) или frame (стиль Google + анимированный фон)"},
            "theme": {"type": "STRING", "description": "dark или light (необязательно)"},
        },
        "required": [],
    },
}

SETTINGS = {"title": "Экран (стиль Google)"}

# ── пресеты ──────────────────────────────────────────────────────────────────
THEMES = {
    "dark": {"bg": "#202124", "surface": "#303134", "focus": "#3C4043", "text": "#E8EAED",
             "muted": "#9AA0A6", "accent": "#8AB4F8", "radius": 24},
    "light": {"bg": "#F8F9FA", "surface": "#E8EAED", "focus": "#D2E3FC", "text": "#202124",
              "muted": "#5F6368", "accent": "#1A73E8", "radius": 24},
}

# id: (подпись, вид)   вид: leaf = одна надпись/кнопка (textSize), panel = контейнер (textScale), hud
ELEMENTS = {
    "hud": ("Центр (сфера / кольца)", "hud"),
    "name": ("Имя ассистента", "leaf"),
    "state": ("Состояние", "leaf"),
    "clock": ("Часы", "leaf"),
    "log": ("Журнал (слева)", "panel"),
    "content": ("Панель ответа (справа)", "panel"),
    "input": ("Строка ввода", "leaf"),
    "btn_send": ("Кнопка «Отправить»", "leaf"),
    "btn_voice": ("Кнопка «Голос»", "leaf"),
    "btn_mute": ("Кнопка «Микрофон»", "leaf"),
    "btn_stop": ("Кнопка «Стоп»", "leaf"),
    "btn_results": ("Кнопка «Результаты»", "leaf"),
    "btn_plugins": ("Кнопка «Плагины»", "leaf"),
    "btn_menu": ("Кнопка «Меню»", "leaf"),
    "confirm": ("Окно подтверждения", "panel"),
    "quiz": ("Окно квиза", "panel"),
}

DEFAULT_MAIN = {
    "hud": {"visible": True, "x": 28, "y": 9, "w": 44, "h": 66},
    "name": {"visible": True, "x": 3, "y": 3.2, "textSize": 22, "bold": True},
    "state": {"visible": True, "x": 44, "y": 3.9, "textSize": 14},
    "clock": {"visible": True, "x": 91, "y": 3.2, "textSize": 20},
    "log": {"visible": True, "x": 2, "y": 11, "w": 24, "h": 64, "textScale": 1.0},
    "content": {"visible": True, "x": 74, "y": 11, "w": 24, "h": 64, "textScale": 1.0},
    "input": {"visible": True, "x": 3, "y": 84, "w": 33.5, "h": 8.5, "textSize": 16},
    "btn_send": {"visible": True, "x": 37.5, "y": 84, "w": 7.2, "h": 8.5, "textSize": 13},
    "btn_voice": {"visible": True, "x": 45.3, "y": 84, "w": 6.5, "h": 8.5, "textSize": 13},
    "btn_mute": {"visible": True, "x": 52.4, "y": 84, "w": 11, "h": 8.5, "textSize": 13},
    "btn_stop": {"visible": True, "x": 64.0, "y": 84, "w": 6, "h": 8.5, "textSize": 13},
    "btn_results": {"visible": True, "x": 70.6, "y": 84, "w": 9, "h": 8.5, "textSize": 13},
    "btn_plugins": {"visible": True, "x": 80.2, "y": 84, "w": 8.2, "h": 8.5, "textSize": 13},
    "btn_menu": {"visible": True, "x": 89.0, "y": 84, "w": 6.5, "h": 8.5, "textSize": 13},
    "confirm": {"visible": True, "x": 25, "y": 36, "w": 50, "h": 0, "textScale": 1.0},
    "quiz": {"visible": True, "x": 19, "y": 18, "w": 62, "h": 0, "textScale": 1.0},
}

DEFAULT_RESULTS = {
    "x": 7, "y": 7, "w": 86, "h": 86, "dim": 55, "autoClose": 120,
    "panelRadius": 28, "columns": 0, "posterRatio": 1.5, "cardRadius": 14, "posterRadius": 12,
    "titleBarSize": 22, "titleSize": 14, "subSize": 12, "appSize": 11,
    "showBadge": 1, "showSub": 1, "showApp": 1, "listDefault": 0,
    "listPosterW": 8.5, "listTitleSize": 20, "listMetaSize": 14, "listDescSize": 15, "descLines": 4,
}

# поля окна результатов: ключ → (подпись, подсказка)
RESULT_FIELDS = [
    ("x", "Окно: X, % слева", "7"),
    ("y", "Окно: Y, % сверху", "7"),
    ("w", "Окно: ширина, %", "86"),
    ("h", "Окно: высота, % (0 = по умолчанию)", "86"),
    ("dim", "Затемнение фона за окном, % (0–100)", "55"),
    ("panelFill", "Цвет окна (пусто = из темы)", "#303134"),
    ("panelStroke", "Цвет рамки окна (пусто = нет)", ""),
    ("panelStrokeWidth", "Толщина рамки, dp", "0"),
    ("panelRadius", "Скругление окна, dp", "28"),
    ("columns", "Колонок плиток (0 = авто)", "0"),
    ("posterRatio", "Высота постера к ширине (1.5 = 2:3)", "1.5"),
    ("cardRadius", "Скругление рамки фокуса, dp", "14"),
    ("posterRadius", "Скругление постера, dp", "12"),
    ("titleBarSize", "Размер заголовка окна, sp", "22"),
    ("titleSize", "Плитки: размер названия, sp", "14"),
    ("subSize", "Плитки: размер подписи, sp", "12"),
    ("appSize", "Плитки: размер названия приложения, sp", "11"),
    ("showBadge", "Показывать номер на постере (1/0)", "1"),
    ("showSub", "Показывать подпись под названием (1/0)", "1"),
    ("showApp", "Показывать приложение (1/0)", "1"),
    ("listDefault", "Вид по умолчанию: 0 плитки, 1 список", "0"),
    ("listPosterW", "Список: ширина постера, % экрана", "8.5"),
    ("listTitleSize", "Список: размер названия, sp", "20"),
    ("listMetaSize", "Список: размер года/рейтинга, sp", "14"),
    ("listDescSize", "Список: размер описания, sp", "15"),
    ("descLines", "Список: строк описания", "4"),
    ("autoClose", "Автозакрытие окна через, сек", "120"),
]
_RES_BOOL = {"showBadge", "showSub", "showApp"}
_RES_STR = {"panelFill", "panelStroke"}
_RES_INT = {"panelRadius", "columns", "cardRadius", "posterRadius", "listDefault", "descLines", "autoClose"}

THEME_FIELDS = [
    ("bg", "Фон экрана"), ("surface", "Панели и кнопки"), ("focus", "Нажатая кнопка"),
    ("text", "Основной текст"), ("muted", "Второстепенный текст"), ("accent", "Акцент (рамка фокуса, заголовки)"),
    ("radius", "Скругление панелей, dp"),
]

# поля одного элемента: ключ → подпись
EL_FIELDS = [
    ("x", "X, % слева"), ("y", "Y, % сверху"), ("w", "Ширина, % (0 = по тексту)"),
    ("h", "Высота, % (0 = по тексту)"),
]


def _el_extra(kind):
    out = []
    if kind == "leaf":
        out.append(("textSize", "Размер текста, sp (0 = по умолчанию)"))
    elif kind == "panel":
        out.append(("textScale", "Масштаб текста (1 = как есть)"))
    if kind != "hud":
        out += [("radius", "Скругление, dp (-1 = таблетка)"), ("fill", "Цвет заливки"),
                ("stroke", "Цвет рамки"), ("strokeWidth", "Толщина рамки, dp"), ("textColor", "Цвет текста")]
    return out


# ── конфиг ───────────────────────────────────────────────────────────────────
_lock = threading.RLock()
_cfg = {"mode": "off", "preset": "dark", "theme": {}, "main": {}, "results": {}}
_st = {"sec": "home", "el": "log"}


def _android():
    try:
        import android_bridge as android
        return android
    except Exception:
        return None


def _file():
    a = _android()
    base = ""
    try:
        base = (a.data_dir() if a else "") or ""
    except Exception:
        pass
    return os.path.join(base or ".", "screen_layout.json")


def _log(text):
    a = _android()
    try:
        if a:
            a.log("screen_style: " + text)
    except Exception:
        pass


def _fresh(preset="dark"):
    return {"mode": _cfg.get("mode", "off"), "preset": preset, "theme": copy.deepcopy(THEMES[preset]),
            "main": copy.deepcopy(DEFAULT_MAIN), "results": copy.deepcopy(DEFAULT_RESULTS)}


def _load():
    try:
        with open(_file(), encoding="utf-8") as f:
            d = json.load(f)
        if isinstance(d, dict):
            for k in ("mode", "preset"):
                if isinstance(d.get(k), str):
                    _cfg[k] = d[k]
            for k in ("theme", "main", "results"):
                if isinstance(d.get(k), dict):
                    _cfg[k] = d[k]
    except Exception:
        pass
    if not _cfg["main"]:
        _cfg.update({k: v for k, v in _fresh(_cfg.get("preset", "dark")).items() if k != "mode"})


def _save():
    with _lock:
        try:
            tmp = _file() + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(_cfg, f, ensure_ascii=False, indent=1)
            os.replace(tmp, _file())
        except Exception as e:
            _log("не удалось сохранить: %s" % e)


# ── значения полей ───────────────────────────────────────────────────────────
def _num(s):
    s = str(s).strip().replace(",", ".")
    if not s:
        return None
    try:
        v = float(s)
        return int(v) if v == int(v) and "." not in s else v
    except ValueError:
        return None


def _color(s):
    s = str(s).strip()
    if not s:
        return ""
    if not s.startswith("#"):
        s = "#" + s
    body = s[1:]
    if len(body) in (6, 8) and all(c in "0123456789abcdefABCDEF" for c in body):
        return s.upper()
    return None


def _fmt(v):
    if v is None:
        return ""
    if isinstance(v, bool):
        return "1" if v else "0"
    if isinstance(v, float) and v == int(v):
        return str(int(v))
    return str(v)


def _apply_values(values):
    """Переносит поля текущей страницы в конфиг. Пустое поле = убрать ключ (значение по умолчанию)."""
    sec = _st["sec"]
    if not isinstance(values, dict) or not values:
        return
    with _lock:
        if sec == "theme":
            for k, _l in THEME_FIELDS:
                if ("t_" + k) not in values:
                    continue
                raw = values["t_" + k]
                if k == "radius":
                    n = _num(raw)
                    if n is not None:
                        _cfg["theme"][k] = int(n)
                else:
                    c = _color(raw)
                    if c:
                        _cfg["theme"][k] = c
        elif sec.startswith("el:"):
            eid = sec[3:]
            kind = ELEMENTS.get(eid, ("", "leaf"))[1]
            el = _cfg["main"].setdefault(eid, {})
            for k, _l in EL_FIELDS + _el_extra(kind):
                key = "e_" + k
                if key not in values:
                    continue
                raw = values[key]
                if k in ("fill", "stroke", "textColor"):
                    c = _color(raw)
                    if c is None:
                        continue
                    if c:
                        el[k] = c
                    else:
                        el.pop(k, None)
                else:
                    n = _num(raw)
                    if n is None:
                        if str(raw).strip() == "":
                            el.pop(k, None)
                        continue
                    el[k] = n
        elif sec == "results":
            for k, _l, _h in RESULT_FIELDS:
                key = "r_" + k
                if key not in values:
                    continue
                raw = values[key]
                if k in _RES_STR:
                    c = _color(raw)
                    if c is None:
                        continue
                    if c:
                        _cfg["results"][k] = c
                    else:
                        _cfg["results"].pop(k, None)
                else:
                    n = _num(raw)
                    if n is None:
                        if str(raw).strip() == "":
                            _cfg["results"].pop(k, None)
                        continue
                    if k in _RES_BOOL:
                        n = 1 if n else 0
                    elif k in _RES_INT:
                        n = int(n)
                    _cfg["results"][k] = n
    _save()


# ── страница настроек ────────────────────────────────────────────────────────
_MODES = (("off", "Классический экран"), ("layout", "Стиль Google (раскладка из JSON)"),
          ("frame", "Стиль Google + анимированный фон от плагина"))


def _btn(i, label):
    return {"type": "button", "id": i, "label": label}


def _lbl(t):
    return {"type": "label", "text": t}


def _field(i, label, value, hint=""):
    return {"type": "text", "id": i, "label": label, "value": _fmt(value), "hint": hint}


def settings_items():
    sec = _st["sec"]
    c = _cfg
    items = []
    if sec == "home":
        items.append(_lbl("Режим: %s. Тема: %s." % (dict(_MODES).get(c["mode"], c["mode"]),
                                                     "светлая" if c["preset"] == "light" else "тёмная")))
        items.append(_lbl("Изменения применяются, когда вы вернётесь на главный экран (кнопка «Назад»)."))
        for m, t in _MODES:
            items.append(_btn("mode:" + m, ("● " if c["mode"] == m else "○ ") + t))
        items.append(_lbl("Готовые пресеты (сбрасывают раскладку, цвета и окно результатов):"))
        items.append(_btn("preset:dark", "Пресет: Google, тёмная тема"))
        items.append(_btn("preset:light", "Пресет: Google, светлая тема"))
        items.append(_lbl("Тонкая настройка:"))
        items.append(_btn("nav:theme", "Цвета и скругление темы"))
        items.append(_btn("nav:elements", "Главный экран: все элементы"))
        items.append(_btn("nav:results", "Окно результатов поиска"))
    elif sec == "theme":
        items.append(_lbl("Цвета: #RRGGBB. Сохраняются при нажатии любой кнопки и при выходе."))
        for k, l in THEME_FIELDS:
            items.append(_field("t_" + k, l, c["theme"].get(k, THEMES["dark"].get(k)), "#RRGGBB"))
        items.append(_btn("save", "Сохранить"))
        items.append(_btn("nav:home", "← Назад"))
    elif sec == "elements":
        items.append(_lbl("Выберите элемент главного экрана:"))
        for eid, (label, _k) in ELEMENTS.items():
            on = c["main"].get(eid, {}).get("visible", True)
            items.append(_btn("nav:el:" + eid, label + ("" if on else "  (скрыт)")))
        items.append(_btn("nav:home", "← Назад"))
    elif sec.startswith("el:"):
        eid = sec[3:]
        label, kind = ELEMENTS.get(eid, (eid, "leaf"))
        el = c["main"].setdefault(eid, copy.deepcopy(DEFAULT_MAIN.get(eid, {})))
        items.append(_lbl("%s — X %s%%, Y %s%%, ширина %s%%, высота %s%%" % (
            label, _fmt(el.get("x", 0)), _fmt(el.get("y", 0)), _fmt(el.get("w", 0)), _fmt(el.get("h", 0)))))
        items.append(_btn("vis", "Скрыть элемент" if el.get("visible", True) else "Показать элемент"))
        items.append(_lbl("Двигать (шаг 1%):"))
        for i, t in (("mv:l", "← влево"), ("mv:r", "вправо →"), ("mv:u", "↑ вверх"), ("mv:d", "вниз ↓")):
            items.append(_btn(i, t))
        items.append(_lbl("Размер (шаг 1%):"))
        for i, t in (("sz:w+", "шире"), ("sz:w-", "уже"), ("sz:h+", "выше"), ("sz:h-", "ниже")):
            items.append(_btn(i, t))
        if kind == "leaf":
            items.append(_btn("tx:+", "Текст крупнее"))
            items.append(_btn("tx:-", "Текст мельче"))
        elif kind == "panel":
            items.append(_btn("tx:+", "Текст крупнее"))
            items.append(_btn("tx:-", "Текст мельче"))
        items.append(_lbl("Точные значения:"))
        for k, l in EL_FIELDS + _el_extra(kind):
            hint = "#RRGGBB" if k in ("fill", "stroke", "textColor") else ""
            items.append(_field("e_" + k, l, el.get(k), hint))
        items.append(_btn("save", "Сохранить"))
        items.append(_btn("reset_el", "Сбросить элемент к пресету"))
        items.append(_btn("nav:elements", "← К списку элементов"))
    elif sec == "results":
        items.append(_lbl("Окно результатов поиска (плитки и список). Пустое поле — значение по умолчанию."))
        for k, l, h in RESULT_FIELDS:
            items.append(_field("r_" + k, l, c["results"].get(k), h))
        items.append(_btn("save", "Сохранить"))
        items.append(_btn("reset_res", "Сбросить окно к пресету"))
        items.append(_btn("nav:home", "← Назад"))
    return items


def _step(el, key, delta, lo=0.0, hi=100.0):
    cur = float(el.get(key, 0) or 0)
    el[key] = round(max(lo, min(hi, cur + delta)), 2)


def settings_event(event, values):
    event = str(event)
    _apply_values(values)
    if event == "__leave__":
        return ""
    msg, sec = "", _st["sec"]
    with _lock:
        if event.startswith("nav:"):
            tgt = event[4:]
            if tgt.startswith("el:"):
                _st["el"] = tgt[3:]
            _st["sec"] = tgt
        elif event.startswith("mode:"):
            set_mode(event[5:])
            msg = "Режим изменён. Вернитесь на главный экран."
        elif event.startswith("preset:"):
            apply_preset(event[7:])
            msg = "Пресет применён. Вернитесь на главный экран."
        elif sec.startswith("el:"):
            eid = sec[3:]
            el = _cfg["main"].setdefault(eid, copy.deepcopy(DEFAULT_MAIN.get(eid, {})))
            kind = ELEMENTS.get(eid, ("", "leaf"))[1]
            if event == "vis":
                el["visible"] = not el.get("visible", True)
            elif event.startswith("mv:"):
                d = event[3:]
                _step(el, "x" if d in "lr" else "y", (-1 if d in "lu" else 1))
            elif event.startswith("sz:"):
                k, sgn = event[3], event[4]
                _step(el, k, 1 if sgn == "+" else -1)
            elif event.startswith("tx:"):
                up = event[3] == "+"
                if kind == "panel":
                    cur = float(el.get("textScale", 1.0) or 1.0)
                    el["textScale"] = round(max(0.5, min(3.0, cur + (0.1 if up else -0.1))), 2)
                else:
                    cur = float(el.get("textSize", 0) or DEFAULT_MAIN.get(eid, {}).get("textSize", 14))
                    el["textSize"] = round(max(6.0, min(60.0, cur + (1 if up else -1))), 1)
            elif event == "reset_el":
                _cfg["main"][eid] = copy.deepcopy(DEFAULT_MAIN.get(eid, {}))
                msg = "Элемент сброшен."
        elif event == "reset_res" and sec == "results":
            _cfg["results"] = copy.deepcopy(DEFAULT_RESULTS)
            msg = "Окно результатов сброшено."
    _save()
    return {"message": msg, "refresh": True}


# ── режимы / пресеты ─────────────────────────────────────────────────────────
def set_mode(mode):
    if mode not in ("off", "layout", "frame"):
        return
    with _lock:
        _cfg["mode"] = mode
        if mode != "off" and not _cfg["main"]:
            _cfg.update({k: v for k, v in _fresh(_cfg.get("preset", "dark")).items() if k != "mode"})
    _save()
    if mode == "frame":
        _start()
    else:
        _halt()


def apply_preset(name):
    name = "light" if name == "light" else "dark"
    with _lock:
        mode = _cfg["mode"] if _cfg["mode"] != "off" else "layout"
        _cfg.update(_fresh(name))
        _cfg["mode"] = mode
    _save()
    if mode == "frame":
        _start()


# ── кадр фона (режим frame) ──────────────────────────────────────────────────
_BLOBS = (  # цвета Google: синий, красный, жёлтый, зелёный
    ((66, 133, 244), 0.0, 0.31, 0.23), ((234, 67, 53), 1.7, 0.27, 0.31),
    ((251, 188, 5), 3.3, 0.37, 0.19), ((52, 168, 83), 5.0, 0.23, 0.35),
)
_DOT_COLORS = ((66, 133, 244), (234, 67, 53), (251, 188, 5), (52, 168, 83))
_FW, _FH, _FPS = 640, 360, 10

_thread = None
_stop = threading.Event()
_lv = {"at": None, "t": 0.0}


def _kt():
    from tvshim.bridge import kt
    return kt()


def _read_state():
    k = _kt()
    try:
        state = str(k.getCurState() or "SLEEPING").upper()
    except Exception:
        state = "SLEEPING"
    level = 0.0
    try:
        at = int(k.getLevelAt())
        now = time.monotonic()
        if at != _lv["at"]:
            _lv["at"], _lv["t"] = at, now
        if now - _lv["t"] < 0.3:
            level = float(k.getLevel())
    except Exception:
        pass
    try:
        vis = bool(k.getAppVisible())
    except Exception:
        vis = True
    return state, level, vis


def _hex(c, d):
    try:
        c = c.lstrip("#")
        return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))
    except Exception:
        return d


def render_frame(t, amp, state, theme, np, Image, ImageDraw):
    """Один кадр фона: RGBA bytes _FW*_FH*4."""
    bg = _hex(theme.get("bg", "#202124"), (32, 33, 36))
    light = sum(bg) > 384
    sw, sh = _FW // 4, _FH // 4
    ys, xs = np.mgrid[0:sh, 0:sw].astype(np.float32)
    xs /= sw
    ys /= sh
    base = np.empty((sh, sw, 3), np.float32)
    grad = (ys * 0.5)[..., None]
    shade = np.array(bg, np.float32)
    base[:] = shade * (1.0 - grad * (0.10 if light else -0.25))      # к низу чуть светлее/темнее
    gain = 0.20 if light else 0.26
    speed = 1.0 + 1.5 * amp
    for col, ph, bx, by in _BLOBS:
        cx = bx + 0.22 * math.sin(t * 0.16 * speed + ph)
        cy = by + 0.18 * math.cos(t * 0.13 * speed + ph * 1.3)
        d2 = ((xs - cx) * (16 / 9)) ** 2 + (ys - cy) ** 2
        a = np.exp(-d2 / (0.045 + 0.02 * amp)) * (gain + 0.22 * amp)
        base += a[..., None] * (np.array(col, np.float32) - base)
    img = Image.fromarray(np.clip(base, 0, 255).astype(np.uint8), "RGB").resize((_FW, _FH), Image.BILINEAR)
    d = ImageDraw.Draw(img)
    # четыре точки Google Assistant: ждут → дышат, говорят/слушают → столбики по уровню
    live = state in ("LISTENING", "SPEAKING", "THINKING", "PROCESSING")
    cx0, cy0 = _FW / 2.0, _FH * 0.93
    gap, w = _FW * 0.035, _FW * 0.022
    for i, col in enumerate(_DOT_COLORS):
        if state in ("THINKING", "PROCESSING"):
            k = 0.5 + 0.5 * math.sin(t * 5.0 - i * 0.9)
        elif live:
            k = min(1.0, amp * (0.55 + 0.45 * math.sin(t * 9.0 + i * 1.7)) * 1.6)
        else:
            k = 0.0
        h = w + k * _FH * 0.075
        x = cx0 + (i - 1.5) * gap
        d.rounded_rectangle((x - w / 2, cy0 - h / 2, x + w / 2, cy0 + h / 2), radius=w / 2, fill=col)
    return img.convert("RGBA").tobytes()


def _loop():
    import numpy as np
    from PIL import Image, ImageDraw
    k = _kt()
    t0 = time.monotonic()
    smooth = 0.0
    try:
        while not _stop.is_set():
            ts = time.monotonic()
            state, level, vis = _read_state()
            if not vis:
                _stop.wait(0.5)
                continue
            smooth += (level - smooth) * 0.5
            with _lock:
                theme = dict(_cfg.get("theme") or THEMES["dark"])
            try:
                k.bgFrame(render_frame(ts - t0, smooth, state, theme, np, Image, ImageDraw), _FW, _FH)
            except Exception as e:
                _log("кадр фона: %s: %s" % (type(e).__name__, e))
                _stop.wait(2.0)
            _stop.wait(max(0.0, 1.0 / _FPS - (time.monotonic() - ts)))
    finally:
        try:
            k.bgFrameClear()
        except Exception:
            pass


def _start():
    global _thread
    with _lock:
        if _thread is not None and _thread.is_alive():
            return
        _stop.clear()
        _thread = threading.Thread(target=_loop, name="screen-style-bg", daemon=True)
        _thread.start()


def _halt():
    global _thread
    with _lock:
        t, _thread = _thread, None
    if t is not None:
        _stop.set()
        t.join(timeout=2.0)


# ── голосовой инструмент ─────────────────────────────────────────────────────
def run(parameters: dict, player=None, session_memory=None) -> str:
    p = parameters or {}
    mode = str(p.get("mode") or "").strip().lower()
    theme = str(p.get("theme") or "").strip().lower()
    try:
        if theme in ("light", "светлая", "светлый"):
            apply_preset("light")
        elif theme in ("dark", "тёмная", "темная", "тёмный", "темный"):
            apply_preset("dark")
        if mode in ("off", "выкл", "классика", "classic"):
            set_mode("off")
            return "Вернул классический экран, сэр. Он обновится через пару секунд."
        if mode in ("layout", "frame"):
            set_mode(mode)
        elif not theme:
            set_mode("layout" if _cfg["mode"] == "off" else "off")
    except Exception as e:
        return "Сэр, экран не удалось изменить: %s" % e
    return ("Готово, сэр. Экран обновится через пару секунд." if _cfg["mode"] != "off"
            else "Вернул классический экран, сэр.")


# ── автозапуск ───────────────────────────────────────────────────────────────
try:
    _load()
    if _cfg["mode"] == "frame":
        _start()
except Exception:
    pass
