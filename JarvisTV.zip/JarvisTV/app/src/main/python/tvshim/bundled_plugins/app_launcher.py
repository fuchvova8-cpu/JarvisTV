"""Запуск приложений на ТВ по названию или по своим командам.

Настройки (Меню → Настройки плагинов → «Приложения и команды»): список приложений ТВ,
напротив каждого — поле с командами (по одной на строку), например для «Lazy Media Deluxe»:
    лейзи
    ленивое медиа
Тогда фраза «открой лейзи» запустит это приложение.
"""
import difflib
import json
import os
import re

import android_bridge as android

PLUGIN = {
    "name": "app_launcher",
    "description": (
        "Запустить приложение на ТВ по названию или по заданной пользователем команде. "
        "Вызывай на фразы «открой/запусти/включи <приложение>», когда речь о приложении, "
        "а не о сайте или файле."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "name": {"type": "STRING", "description": "Название приложения или команда, как сказал пользователь"},
        },
        "required": ["name"],
    },
}

SETTINGS = {"title": "Приложения и команды"}

_FILLER = re.compile(r"^(открой|запусти|включи|покажи|пожалуйста|приложение|программу)\s+", re.I)


def _file():
    return os.path.join(android.data_dir() or ".", "app_launcher.json")


def _load():
    try:
        with open(_file(), encoding="utf-8") as f:
            d = json.load(f)
        if isinstance(d.get("apps"), dict):
            return d
    except Exception:
        pass
    return {"apps": {}}


def _save(d):
    try:
        with open(_file(), "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=1)
    except Exception as e:
        android.log("app_launcher: не сохранить: %s" % e)


def _refresh(d):
    apps = android.list_apps()
    if apps is None:
        return 0
    old = d["apps"]
    new = {}
    for a in apps:
        pkg = a.get("pkg")
        if not pkg:
            continue
        new[pkg] = {"label": a.get("label") or pkg, "tv": bool(a.get("tv")),
                    "cmds": (old.get(pkg) or {}).get("cmds", [])}
    d["apps"] = new
    _save(d)
    return len(new)


def _norm(s):
    s = str(s).strip().lower()
    prev = None
    while prev != s:
        prev = s
        s = _FILLER.sub("", s).strip()
    return s


_TR = dict(zip("абвгдезийклмнопрстуфыэ", "abvgdezijklmnoprstufye"))
_TR.update({"ё": "e", "ж": "zh", "х": "h", "ц": "c", "ч": "ch", "ш": "sh", "щ": "sh",
            "ъ": "", "ь": "", "ю": "yu", "я": "ya"})


def _tr(s):
    """Russian speech of a Latin app name: «зона» -> «zona»."""
    return "".join(_TR.get(ch, ch) for ch in s.lower())


def _find(d, q):
    q = _norm(q)
    if not q:
        return None
    qs = {q, _tr(q)}
    names = []   # (text, pkg, priority) — every name also in transliterated form
    for pkg, a in d["apps"].items():
        for c in a.get("cmds", []):
            if c.strip():
                names.append((_norm(c), pkg, 0))
        names.append((_norm(a.get("label", "")), pkg, 1))
    names += [(_tr(t), pkg, p) for t, pkg, p in names]
    ordered = sorted(names, key=lambda x: x[2])
    for t, pkg, _p in ordered:
        if t in qs:
            return pkg
    for t, pkg, _p in ordered:
        for x in qs:
            if t and (x in t or t in x) and min(len(x), len(t)) >= 3:
                return pkg
    for x in qs:
        best = difflib.get_close_matches(x, [n[0] for n in names], n=1, cutoff=0.75)
        if best:
            for t, pkg, _p in names:
                if t == best[0]:
                    return pkg
    return None


def run(parameters, player=None, session_memory=None):
    q = str(parameters.get("name", "")).strip()
    if not q:
        return "Не понял, какое приложение открыть."
    d = _load()
    if not d["apps"]:
        _refresh(d)
    pkg = _find(d, q)
    if pkg is None:
        _refresh(d)
        pkg = _find(d, q)
    if pkg is None:
        return "Не нашёл приложение «%s». Добавьте команду в Меню → Настройки плагинов." % q
    label = d["apps"][pkg].get("label", pkg)
    res = android.launch_app(pkg)
    if str(res).startswith("ok"):
        return "Открываю %s." % label
    return "Не удалось открыть %s: %s" % (label, res)


def _store_values(d, values):
    for k, v in (values or {}).items():
        if k.startswith("p:") and k[2:] in d["apps"]:
            d["apps"][k[2:]]["cmds"] = [x.strip() for x in str(v).splitlines() if x.strip()]
    _save(d)


def settings_items():
    d = _load()
    if not d["apps"]:
        _refresh(d)
    items = [
        {"type": "label", "text": "Напротив приложения — команды (по одной на строку), которыми его можно открыть голосом."},
        {"type": "button", "id": "refresh_apps", "label": "Обновить список приложений"},
        {"type": "button", "id": "save", "label": "Сохранить"},
    ]
    apps = sorted(d["apps"].items(), key=lambda kv: (not kv[1].get("tv"), kv[1].get("label", "").lower()))
    for pkg, a in apps:
        items.append({"type": "text", "id": "p:" + pkg,
                      "label": a.get("label", pkg) + ("  (ТВ)" if a.get("tv") else ""),
                      "value": "\n".join(a.get("cmds", [])), "hint": "команды, по одной на строку",
                      "multiline": True})
    return items


def settings_event(event, values):
    d = _load()
    if event == "__leave__":
        _store_values(d, values)
        return None
    _store_values(d, values)
    if event == "refresh_apps":
        n = _refresh(d)
        return {"message": "Приложений: %d" % n, "refresh": True}
    return {"message": "Сохранено", "refresh": False}
