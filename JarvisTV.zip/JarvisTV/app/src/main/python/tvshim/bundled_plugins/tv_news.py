"""
tv_news — latest headlines from RSS feeds. No DuckDuckGo (not available on Android) and no
Gemini quota needed, so it works when web_search cannot.

One self-contained file. Your own feeds: config/tv_news.json, e.g.
  {"feeds": {"УП": "https://www.pravda.com.ua/rus/rss/", "BBC": "https://feeds.bbci.co.uk/russian/rss.xml"}}
(your list replaces the default one).
"""
from __future__ import annotations

import json
import os
import re
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor
from email.utils import parsedate_to_datetime
from html import unescape
from pathlib import Path

import requests

HOME = Path(os.environ.get("JARVIS_HOME") or Path(__file__).resolve().parent.parent)

PLUGIN = {
    "name": "tv_news",
    "description": (
        "Reads the latest news headlines from RSS feeds (Ukrainska Pravda, BBC Russian, BBC World by default). "
        "Use for 'what's the news', 'latest headlines', 'news about <topic>', 'news from BBC'. "
        "'topic' filters headlines by a word (in the feed's language); 'source' picks one feed by name "
        "(УП, BBC, BBC World); 'count' is how many (default 7). Prefer this over web_search for plain headlines; "
        "use web_search to dig into one story."
    ),
    "brief": "Latest news headlines from RSS.",
    "tier": "core",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "topic": {"type": "STRING", "description": "Word or phrase to filter headlines by"},
            "source": {"type": "STRING", "description": "Feed name, e.g. УП, BBC, BBC World"},
            "count": {"type": "INTEGER", "description": "Number of headlines, default 7, max 20"},
        },
        "required": [],
    },
}

DEFAULT_FEEDS = {
    "УП": "https://www.pravda.com.ua/rus/rss/",
    "BBC": "https://feeds.bbci.co.uk/russian/rss.xml",
    "BBC World": "https://feeds.bbci.co.uk/news/world/rss.xml",
}


def _feeds() -> dict:
    try:
        f = json.loads((HOME / "config" / "tv_news.json").read_text(encoding="utf-8")).get("feeds")
        if isinstance(f, dict) and f:
            return {str(k): str(v) for k, v in f.items()}
    except Exception:
        pass
    return dict(DEFAULT_FEEDS)


def _clean(t: str) -> str:
    return re.sub(r"\s+", " ", unescape(re.sub(r"<[^>]+>", " ", t or ""))).strip()


def _fetch(item):
    name, url = item
    r = requests.get(url, timeout=10, headers={"User-Agent": "Mozilla/5.0 (Android TV) Jarvis"})
    r.raise_for_status()
    root = ET.fromstring(r.content)
    out = []
    for it in root.iter("item"):
        title = _clean(it.findtext("title") or "")
        if not title:
            continue
        when = 0.0
        try:
            when = parsedate_to_datetime(it.findtext("pubDate") or "").timestamp()
        except Exception:
            pass
        out.append((when, name, title, _clean(it.findtext("description") or "")))
    return out


def run(parameters: dict, player=None) -> str:
    p = parameters or {}
    topic = str(p.get("topic") or "").strip().lower()
    source = str(p.get("source") or "").strip().lower()
    try:
        count = max(1, min(20, int(p.get("count") or 7)))
    except (TypeError, ValueError):
        count = 7
    feeds = _feeds()
    if source:
        picked = {k: v for k, v in feeds.items() if source in k.lower()}
        if not picked:
            return "No such source. Available: " + ", ".join(feeds) + "."
        feeds = picked
    items, failed = [], []
    with ThreadPoolExecutor(max_workers=4) as ex:
        futs = {ex.submit(_fetch, kv): kv[0] for kv in feeds.items()}
        for fut, name in futs.items():
            try:
                items += fut.result()
            except Exception as e:
                failed.append(name)
                print(f"[tv_news] {name} failed: {type(e).__name__}: {e}")
    if not items:
        return "Could not load any news feed (" + ", ".join(failed) + "). Check the TV's internet connection."
    if topic:
        items = [i for i in items if topic in (i[2] + " " + i[3]).lower()]
        if not items:
            return f"No headlines about '{topic}' right now in: " + ", ".join(k for k in feeds if k not in failed) + "."
    items.sort(key=lambda i: i[0], reverse=True)
    seen, rows = set(), []
    for _, name, title, _d in items:
        key = re.sub(r"\W+", "", title.lower())[:50]
        if key in seen:
            continue
        seen.add(key)
        rows.append(f"[{name}] {title}")
        if len(rows) >= count:
            break
    text = "\n".join(rows)
    if player:
        try:
            player.show_content("News", text)
            player.write_log(f"JARVIS: {len(rows)} headlines")
        except Exception:
            pass
    note = f"\n(Unavailable: {', '.join(failed)})" if failed else ""
    return text + note
