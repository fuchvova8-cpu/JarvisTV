"""
tv_micfix — automatic test-and-fix for the periodic microphone dropouts (the "STALL" every ~33 s).

Suspect: the Google voice service (com.google.android.katniss) grabbing the microphone in parallel.
The plugin, over the TV's own ADB:
  1. measures the dropouts for a while (baseline) and records who starts/stops audio input (logcat);
  2. stops Katniss and measures again;
  3. if that is not conclusive: a short TRIAL where Katniss is denied the microphone, then gives the permission back;
  4. NEVER keeps any change — Google's microphone and the Voice button are left exactly as they were;
  5. writes micfix_report.txt in the Jarvis folder, shows it on screen and tells you the result.
Runs in the background (about 5-6 minutes); keep Jarvis on screen. "revert" is only a safety net.
One self-contained file. During the short trial (about 2 minutes) the Voice button does not work.
"""
from __future__ import annotations

import os
import re
import threading
import time
from pathlib import Path

HOME = Path(os.environ.get("JARVIS_HOME") or Path(__file__).resolve().parent.parent)
PKG = "com.google.android.katniss"
REPORT = HOME / "micfix_report.txt"

PLUGIN = {
    "name": "tv_micfix",
    "description": (
        "Diagnoses the periodic microphone dropouts ('microphone did not deliver sound — reopening' every ~30 s) "
        "by testing whether the Google voice service (Katniss) causes them. It changes nothing permanently: "
        "Google's microphone and the Voice button stay as they were. "
        "Takes ~5-6 minutes in the background; the full report appears on screen and in micfix_report.txt. "
        "action: run (default) | status | revert (safety net: give Katniss the microphone permission back). "
        "Use when the user asks to diagnose / fix the microphone cutting out. Needs ADB on. "
        "Tell the user it is running and that the Voice button may not work for ~2 minutes during a trial."
    ),
    "brief": "Auto-test microphone dropouts (is Katniss the cause?).",
    "tier": "extra",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING", "description": "run | status | revert"},
            "seconds": {"type": "INTEGER", "description": "Length of each measurement, default 100 (min 20, max 300)"},
        },
        "required": [],
    },
}

_lock = threading.Lock()
_state = {"running": False, "phase": "", "last": ""}


# ── adb ─────────────────────────────────────────────────────────────────────
class NoAdb(RuntimeError):
    pass


def sh(cmd: str) -> str:
    from tvshim.bridge import kt
    out = kt().adbShell(cmd)
    if out is None:
        raise NoAdb("ADB is not connected. On the TV: Settings > Developer options > USB debugging and "
                    "network debugging, and accept the prompt for this app.")
    return str(out)


def safe(cmd: str) -> str:
    try:
        return sh(cmd).strip()
    except NoAdb:
        raise
    except Exception as e:
        return f"(failed: {type(e).__name__}: {e})"


# ── finding the app's own diagnostic log and counting dropouts in it ──────────
_MARKS = ("STALL:", "Микрофон не отдавал звук")


def _candidates() -> list[Path]:
    roots = [HOME, HOME.parent, HOME / "logs", HOME.parent / "logs", HOME.parent / "diag",
             Path("/data/data/com.jarvis.tv/files"), Path("/data/data/com.jarvis.tv/cache"),
             Path("/sdcard/Android/data/com.jarvis.tv/files")]
    seen, out = set(), []
    for r in roots:
        try:
            for f in list(r.glob("*.log")) + list(r.glob("*/*.log")) + list(r.glob("*diag*")):
                if f.is_file() and f not in seen:
                    seen.add(f)
                    out.append(f)
        except Exception:
            pass
    return out


def _tail(f: Path, n=60000) -> str:
    try:
        with open(f, "rb") as fh:
            fh.seek(0, 2)
            size = fh.tell()
            fh.seek(max(0, size - n))
            return fh.read().decode("utf-8", "replace")
    except Exception:
        return ""


def find_log() -> Path | None:
    best, best_t = None, 0.0
    for f in _candidates():
        try:
            t = f.stat().st_mtime
        except Exception:
            continue
        if t > best_t and any(m in _tail(f) for m in _MARKS + ("[MIC] hb",)):
            best, best_t = f, t
    return best


def _size(f: Path) -> int:
    try:
        return f.stat().st_size
    except Exception:
        return 0


def _count_since(f: Path, offset: int) -> tuple[int, list[str]]:
    try:
        with open(f, "rb") as fh:
            fh.seek(offset)
            text = fh.read().decode("utf-8", "replace")
    except Exception:
        return 0, []
    lines = [ln for ln in text.splitlines() if "STALL:" in ln]
    if not lines:                                    # logs without the [MIC] diagnostics
        lines = [ln for ln in text.splitlines() if "Микрофон не отдавал звук" in ln]
    return len(lines), [ln[:12] for ln in lines]


def measure(seconds: int, logf: Path | None, label: str, report: list[str]) -> int | None:
    """Wait `seconds`, return the number of dropouts seen in the app log (None = cannot count)."""
    _state["phase"] = label
    off = _size(logf) if logf else 0
    time.sleep(seconds)
    if not logf:
        report.append(f"{label}: waited {seconds} s — no app log found, dropouts NOT counted")
        return None
    n, stamps = _count_since(logf, off)
    report.append(f"{label}: {n} dropout(s) in {seconds} s" + (f" at {', '.join(stamps)}" if stamps else ""))
    return n


def audio_events(limit=60) -> str:
    out = safe("logcat -d -v time")
    rows = [ln for ln in out.splitlines()
            if re.search(r"startInput|stopInput|AudioRecord|hotword|katniss|openInput|closeInput", ln, re.I)]
    return "\n".join(rows[-limit:]) or "(no audio-input events in logcat)"


def katniss_running() -> bool:
    return bool(re.search(r"\d", safe(f"pidof {PKG}")))


def appop() -> str:
    m = re.search(r"RECORD_AUDIO:\s*(\w+)", safe(f"appops get {PKG} RECORD_AUDIO"))
    return m.group(1) if m else "unknown"


# ── the experiment (always leaves the system exactly as it found it) ─────────
def experiment(seconds: int, player) -> None:
    rep = [f"tv_micfix report — {time.strftime('%Y-%m-%d %H:%M:%S')}", ""]
    verdict = ""
    original_mode = "allow"
    try:
        logf = find_log()
        rep.append(f"App log used for counting: {logf if logf else 'NOT FOUND'}")
        original_mode = appop()
        rep.append(f"Katniss running: {katniss_running()}; its RECORD_AUDIO mode: {original_mode}")
        safe("logcat -c")

        base = measure(seconds, logf, "1. Baseline (nothing changed)", rep)
        rep += ["", "Audio-input events during the baseline (logcat):", audio_events(), ""]

        if base is None:
            verdict = "Could not count dropouts (no app log found). Nothing was changed. Tell me where the diagnostic log is."
        elif base == 0:
            verdict = ("No dropouts during the baseline, so the problem did not show up in this window. "
                       "Nothing was changed. Run it again while the microphone is cutting out.")
        else:
            safe(f"am force-stop {PKG}")
            time.sleep(2)
            a = measure(seconds, logf, "2. Katniss stopped (it may restart)", rep)
            back = katniss_running()
            rep.append(f"   Katniss restarted by itself: {back}")
            b = None
            if a != 0:                                   # stopping alone was not conclusive: short trial block
                safe(f"appops set {PKG} RECORD_AUDIO ignore")
                safe(f"am force-stop {PKG}")
                time.sleep(2)
                b = measure(seconds, logf, "3. TRIAL ONLY: Katniss denied the microphone", rep)
                safe(f"appops set {PKG} RECORD_AUDIO {original_mode if original_mode != 'unknown' else 'allow'}")
                rep.append("   Trial over: Katniss has its microphone permission back.")
            if a == 0 or b == 0:
                verdict = ("CONFIRMED: Katniss (Google voice service) causes the dropouts — they stop when it is not "
                           "listening. Nothing was kept: its microphone permission is as it was, the Voice button works. "
                           "To keep the button and remove the cause, switch off ONLY the always-listening part: "
                           "TV Settings > Google Assistant > 'Ok Google' / voice access from any screen. "
                           "Then run this test once more to confirm.")
            else:
                verdict = ("NOT the Google voice service: the dropouts continued with Katniss stopped and even denied. "
                           "Nothing was kept, everything is as before. The logcat audio events above show who else "
                           "touches the microphone around the dropouts; send me this report.")
    except NoAdb as e:
        verdict = str(e)
    except Exception as e:
        verdict = f"tv_micfix stopped: {type(e).__name__}: {e}"
        try:                                              # never leave a trial block behind
            safe(f"appops set {PKG} RECORD_AUDIO {original_mode if original_mode != 'unknown' else 'allow'}")
        except Exception:
            pass
    rep += ["", "RESULT: " + verdict, "", f"Katniss now running: {_safe_running()}; RECORD_AUDIO mode: {_safe_mode()}"]
    text = "\n".join(rep)
    try:
        REPORT.write_text(text, encoding="utf-8")
    except Exception:
        pass
    _state.update(running=False, phase="", last=verdict)
    if player:
        for fn, arg in (("show_content", ("Mic fix report", text[:3800])),
                        ("write_log", (f"JARVIS: micfix: {verdict}",)),
                        ("request_say", (f"Tell the user, briefly and in their language: the microphone test finished. {verdict}",))):
            try:
                getattr(player, fn)(*arg)
            except Exception:
                pass


def _safe_running():
    try:
        return katniss_running()
    except Exception:
        return "?"


def _safe_mode():
    try:
        return appop()
    except Exception:
        return "?"


def run(parameters: dict, player=None) -> str:
    p = parameters or {}
    action = str(p.get("action") or "run").lower().strip()
    try:
        if action == "status":
            if _state["running"]:
                return f"Running: {_state['phase']}."
            return (f"Not running. Last result: {_state['last'] or 'none yet'}. "
                    f"Katniss RECORD_AUDIO mode: {appop()}.")
        if action == "revert":
            sh(f"appops set {PKG} RECORD_AUDIO allow")
            return f"Katniss has its microphone permission back (mode: {appop()}). The Voice button works."
        if action != "run":
            return f"Unknown action '{action}'. Use run, status or revert."
        with _lock:
            if _state["running"]:
                return f"Already running: {_state['phase']}."
            sh("echo ok")                                 # fail fast if ADB is off
            _state.update(running=True, phase="starting")
        try:
            secs = max(20, min(300, int(p.get("seconds") or 100)))
        except (TypeError, ValueError):
            secs = 100
        threading.Thread(target=experiment, args=(secs, player), name="tv-micfix", daemon=True).start()
        return (f"Started. About {3 * secs // 60 + 1} minutes: measuring dropouts, then testing Katniss. "
                "Keep Jarvis on screen and talk as usual. The result will appear on screen and in micfix_report.txt.")
    except NoAdb as e:
        return str(e)
    except Exception as e:
        _state["running"] = False
        return f"tv_micfix failed: {type(e).__name__}: {e}"
