"""
tv_chatter — turn Jarvis's unprompted speech on and off.

Three things in Jarvis speak without being asked, and they are separate routines in the built-in scheduler:
  briefing    the opening/morning briefing, once after the app starts
  checkin     the spontaneous check-in after a long silence ("how is the project going?")
  news_watch  new headlines said aloud on the topics you watch
This plugin switches them. The choice is saved by Jarvis itself (routines store), so it survives a restart.
One self-contained file; no changes to the app.
"""
from __future__ import annotations

PLUGIN = {
    "name": "tv_chatter",
    "description": (
        "Turns the morning briefing and Jarvis's spontaneous talking on or off. "
        "target: briefing (morning summary) | talk (spontaneous check-ins and spoken news alerts) | all (both). "
        "state: on | off | status. Example: 'turn off the morning summary' -> target=briefing, state=off; "
        "'stop talking on your own' -> target=talk, state=off; 'be quiet completely' -> target=all, state=off."
    ),
    "brief": "Morning briefing and spontaneous talk: on/off.",
    "tier": "extra",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "target": {"type": "STRING", "description": "briefing | talk | all (default all)"},
            "state": {"type": "STRING", "description": "on | off | status (default status)"},
        },
        "required": [],
    },
}

GROUPS = {
    "briefing": ("briefing",),
    "talk": ("checkin", "news_watch"),
    "all": ("briefing", "checkin", "news_watch"),
}
LABEL = {"briefing": "morning briefing", "checkin": "spontaneous check-ins", "news_watch": "spoken news alerts"}
NEVER = 10 ** 9


def _live(player=None):
    ui = player
    if ui is None:
        try:
            from tvshim import ui_android
            ui = ui_android.CURRENT
        except Exception:
            return None
    fn = getattr(ui, "request_say", None)
    return getattr(fn, "__self__", None)


def _set_fallback(live, name: str, on: bool) -> str:
    """Used only when the routine scheduler did not load: the older fixed behaviour."""
    if name == "briefing":
        from memory.config_manager import save_brief_enabled
        save_brief_enabled(bool(on))
        return "saved in config"
    if name == "checkin":
        pe = getattr(live, "_proactive", None)
        if pe is None:
            return "no proactive engine"
        pe.min_silence_secs = 900 if on else NEVER
        return "until restart"
    return "not available without the scheduler"


def _state_of(live, eng, name: str):
    if eng is not None:
        r = eng.find_builtin(name)
        return None if r is None else bool(r.get("enabled"))
    if name == "briefing":
        try:
            from memory.config_manager import get_brief_enabled
            return bool(get_brief_enabled())
        except Exception:
            return None
    if name == "checkin":
        pe = getattr(live, "_proactive", None)
        return None if pe is None else pe.min_silence_secs < NEVER
    return None


def run(parameters: dict, player=None) -> str:
    p = parameters or {}
    target = str(p.get("target") or "all").lower().strip()
    state = str(p.get("state") or "status").lower().strip()
    if target not in GROUPS:
        return "Unknown target '%s'. Use briefing, talk or all." % target
    if state not in ("on", "off", "status"):
        return "Unknown state '%s'. Use on, off or status." % state

    live = _live(player)
    if live is None:
        return "I could not reach the assistant."
    eng = getattr(live, "_routines", None)

    notes = []
    if state != "status":
        want = state == "on"
        for name in GROUPS[target]:
            try:
                if eng is not None:
                    r = eng.find_builtin(name)
                    if r is None:
                        notes.append(f"{LABEL[name]}: routine not found")
                        continue
                    eng.update(r["id"], enabled=want)
                else:
                    notes.append(f"{LABEL[name]}: {_set_fallback(live, name, want)}")
            except Exception as e:
                notes.append(f"{LABEL[name]}: error {type(e).__name__}: {e}")

    lines = []
    for name in GROUPS["all"]:
        s = _state_of(live, eng, name)
        lines.append(f"{LABEL[name]}: " + ("unknown" if s is None else "ON" if s else "OFF"))
    head = "Done. " if state != "status" else ""
    return head + "; ".join(lines) + "." + (" (" + "; ".join(notes) + ")" if notes else "")
