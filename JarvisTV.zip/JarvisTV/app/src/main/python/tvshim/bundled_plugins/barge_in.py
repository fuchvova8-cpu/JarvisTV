"""Перебивание Джарвиса: вы заговорили — он замолчал.

Два режима (Меню → Настройки плагинов → «Перебивание»):
  • «Просто перебивание» (по умолчанию) — как только вы начали говорить поверх Джарвиса
    (дольше ~0,3 с), он останавливается и слушает.
  • «По слову» — Джарвис останавливается, только если вы сказали одно из слов-команд
    («стоп», «хватит» и т.п.; список редактируется). Обычный разговор поверх него его не прерывает.

Как это устроено (ядро и main.py не изменены). Пока Джарвис говорит, ядро микрофон не слушает. Плагин
берёт тот же поток микрофона, сам решает по EchoGuard (своя копия, как в версии для ПК), что это ваш голос,
обрывает воспроизведение и отдаёт Джарвису последние ~0,5 с вашей речи, чтобы начало фразы не потерялось.
Режим «по слову» отправляет короткий фрагмент вашего голоса (только когда вы говорите поверх
Джарвиса) в Gemini на распознавание — нужен тот же ключ Gemini и интернет.

Работает в режиме микрофона «постоянно» (в режиме «по кнопке» микрофон во время ответа выключен).
"""
import base64
import io
import json
import os
import re
import threading
import time
import wave
from collections import deque

import numpy as np

import android_bridge as android

PLUGIN = {
    "name": "barge_in",
    "description": (
        "Перебивание Джарвиса. Обычно работает само: когда пользователь говорит поверх ответа, "
        "речь прерывается. Вызывай только по прямой просьбе: «замолчи», «хватит говорить» "
        "(action=stop), «перебивание включено?» (action=status), «перебивай по слову» (action=word), «перебивай просто голосом» (action=voice), "
        "«выключи перебивание» (action=off), «включи перебивание» (action=on)."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING", "description": "stop | word | voice | on | off"},
        },
    },
}

SETTINGS = {"title": "Перебивание"}

RATE = 16000
DEFAULT_WORDS = "стоп\nхватит\nдостаточно\nподожди\nзамолчи\nтихо"
_MODELS = ("gemini-flash-lite-latest", "gemini-flash-latest")
_LEVEL_FLOOR = 35.0     # чувствительность как в barge_in v2 для ПК
_LEVEL_FULL = 2200.0
_NEED_MAX = 3           # блоков подряд (≈0,2 с) для быстрого отклика
_DROP_WINDOW = 0.7      # сколько секунд после обрыва ядро отбрасывает остаток старого ответа
_PREROLL = 8            # блоков (≈0,5 с) звука до начала фразы
_START_BLOCKS = 2       # блоков «чужого голоса» подряд, чтобы начать фрагмент
_END_QUIET = 8          # блоков тишины, после которых фраза считается законченной
_MAX_BLOCKS = 64        # ≈4 с — дольше фрагмент не копим
_RESEND_BLOCKS = 24     # ≈1,5 с — в длинной фразе проверяем промежуточный кусок
_MIN_VOICED = 3         # меньше этого — кашель/щелчок, не проверяем

_C = None               # конфиг в памяти
_sys_on = (True, 0.0)   # (включён ли плагин в меню плагинов, когда проверяли)
_J = None               # экземпляр ядра (JarvisLive)
_last_text = ""
_last_fire = ""
_S = {"run": 0, "cool": 0.0, "pre": deque(maxlen=_PREROLL), "seg": None, "quiet": 0,
      "sent": 0, "voiced": 0, "busy": False, "n": 0, "gate": None, "hooked": False, "ready": False}
_guard = None           # своя копия EchoGuard (штатный остаётся ядру)
_buf = deque(maxlen=8)  # последние блоки микрофона: уйдут Джарвису после обрыва


# ── config ──────────────────────────────────────────────────────────────────
def _file():
    return os.path.join(android.data_dir() or ".", "barge_in.json")


def _conf():
    global _C
    if _C is None:
        try:
            with open(_file(), encoding="utf-8") as f:
                c = json.load(f)
        except Exception:
            c = {}
        c["enabled"] = bool(c.get("enabled", True))
        c["mode"] = "word" if c.get("mode") == "word" else "voice"
        c["words"] = str(c.get("words") or DEFAULT_WORDS)
        c["debug"] = bool(c.get("debug", True))
        _C = c
    return _C


def _save():
    try:
        with open(_file(), "w", encoding="utf-8") as f:
            json.dump(_conf(), f, ensure_ascii=False, indent=1)
    except Exception as e:
        android.log("barge_in: не сохранить: %s" % e)


def _words():
    return [_norm(w) for w in _conf()["words"].splitlines() if _norm(w)]


def _norm(s):
    s = str(s).lower().replace("ё", "е")
    return re.sub(r"[^\w\s]", " ", s).strip()


def _plugin_on():
    """Галочка плагина в меню «Плагины (вкл/выкл)»; читаем не чаще раза в 2 с."""
    global _sys_on
    now = time.monotonic()
    if now - _sys_on[1] > 2.0:
        try:
            from memory.config_manager import get_plugin_enabled
            _sys_on = (bool(get_plugin_enabled("barge_in")), now)
        except Exception:
            _sys_on = (True, now)
    return _sys_on[0]


# ── core access ─────────────────────────────────────────────────────────────
def _jl():
    """Экземпляр ядра (JarvisLive). Штатная кнопка «Стоп» привязана к его методу."""
    global _J
    if _J is None:
        try:
            from tvshim import ui_android
            _J = getattr(getattr(ui_android.CURRENT, "on_interrupt", None), "__self__", None)
        except Exception:
            _J = None
    if _J is None:
        try:
            import gc
            for o in gc.get_objects():
                if type(o).__name__ == "JarvisLive" and hasattr(o, "_echo"):
                    _J = o
                    break
        except Exception:
            pass
    return _J


def _hook(jl):
    """Копия EchoGuard получает то же, что играет ядро (note_output), как в версии для ПК."""
    global _guard
    if _S["hooked"]:
        return
    from core.echo import EchoGuard
    _guard = EchoGuard()
    orig = jl._echo.note_output

    def _note(*a, **k):
        orig(*a, **k)
        try:
            _guard.note_output(*a, **k)
        except Exception:
            pass

    jl._echo.note_output = _note
    _S["hooked"] = True
    _S["ready"] = True
    _dbg("JarvisLive найден, микрофон подключён")


def _dbg(msg):
    if _conf()["debug"]:
        print("[barge_in] %s" % msg, flush=True)


def _level(pcm):
    rms = float(np.sqrt(np.mean(pcm.astype(np.float32) ** 2))) if pcm.size else 0.0
    return 0.0 if rms <= _LEVEL_FLOOR else min(1.0, (rms - _LEVEL_FLOOR) / (_LEVEL_FULL - _LEVEL_FLOOR))


def _mono16(indata):
    a = np.asarray(indata)
    if a.dtype.kind == "f":
        a = np.clip(a, -1.0, 1.0) * 32767.0
    return a.reshape(-1).astype(np.int16)


# ── mic tap ─────────────────────────────────────────────────────────────────
def _reset():
    _S["run"] = 0
    _S["seg"] = None
    _S["quiet"] = _S["sent"] = _S["voiced"] = 0
    _S["pre"].clear()
    _buf.clear()


def _barge(jv, pre):
    """Обрыв речи (как в версии для ПК). Выполняется в цикле asyncio ядра."""
    try:
        _dbg("TRIGGER — обрываю воспроизведение")
        q = jv.audio_in_queue
        while q is not None:
            try:
                q.get_nowait()
            except Exception:
                break
        jv._visemes.reset()
        jv._play_cursor = 0.0
        jv._out_level = 0.0
        jv.set_speaking(False)
        jv._interrupted = True
        if jv._turn_done_event:
            jv._turn_done_event.clear()
        jv._loop.call_later(_DROP_WINDOW, lambda: setattr(jv, "_interrupted", False))
        for b in pre:               # начало вашей фразы — Джарвису, чтобы оно не потерялось
            try:
                jv.out_queue.put_nowait({"data": b, "mime_type": "audio/pcm"})
            except Exception:
                break
        jv.ui.write_log("SYS: Interrupted — listening...")
    except Exception as e:
        print("[barge_in] _barge error: %s" % e, flush=True)


def _fire(jl, why, pre=()):
    global _last_fire
    _S["cool"] = time.monotonic() + 1.5
    _reset()
    _last_fire = why
    android.log("barge_in: перебил (%s)" % why)
    try:
        jl._loop.call_soon_threadsafe(_barge, jl, list(pre))
    except Exception:
        threading.Thread(target=_stop, args=(jl,), daemon=True).start()


def _stop(jl):
    try:
        jl.interrupt()
    except Exception as e:
        android.log("barge_in: interrupt: %s" % e)


def _on_block(indata):
    c = _conf()
    if not c["enabled"] or not _plugin_on():
        return
    jl = _jl()
    if jl is None:
        return
    if not _S["hooked"]:
        try:
            _hook(jl)
        except Exception as e:
            _S["hooked"] = True          # не пытаться снова
            print("[barge_in] disabled: %s" % e, flush=True)
            return
    if _guard is None:
        return
    with jl._speaking_lock:
        speaking = jl._is_speaking
    gate = None
    if not speaking:
        gate = "не говорит"
    elif getattr(getattr(jl, "ui", None), "muted", False):
        gate = "ui.muted"
    elif getattr(jl, "_phone_active", False):
        gate = "phone_active"
    elif getattr(jl, "_wake_enabled", False) and not getattr(jl, "_awake", True):
        gate = "wake: спит"
    elif getattr(jl, "_ptt_enabled", False) and not getattr(jl, "_ptt_held", False):
        gate = "push-to-talk включён, клавиша не зажата"
    if gate:
        if speaking and gate != _S["gate"]:
            _dbg("заблокировано: %s" % gate)
        _S["gate"] = gate
        if _S["run"] or _S["seg"] is not None or _S["pre"] or _buf:
            _reset()
        if _guard._hist and not speaking:
            _guard.reset()
        return
    _S["gate"] = None
    if time.monotonic() < _S["cool"]:
        return

    pcm = _mono16(indata)
    lvl = _level(pcm)
    try:
        user = bool(_guard.is_user_speech(pcm, RATE, lvl))
    except Exception:
        user = False
    _buf.append(pcm.tobytes())
    need = max(1, min(int(getattr(_guard, "required_blocks", 5)), _NEED_MAX))

    _S["n"] += 1
    if _S["n"] % 8 == 0:
        _dbg("mic=%.2f hit=%d run=%d/%d sim=%.2f thr=%.2f floor=%.2f warm=%d/16 hist=%d" % (
            lvl, int(user), _S["run"], need, _guard.last_similarity, _guard.threshold,
            _guard.floor, len(_guard._residuals), len(_guard._hist)))

    if c["mode"] == "voice":
        _S["run"] = _S["run"] + 1 if user else 0
        if _S["run"] >= need:
            _fire(jl, "голос", list(_buf))
        return
    _word_block(jl, pcm, user)


def _word_block(jl, pcm, user):
    S = _S
    S["pre"].append(pcm)
    if S["seg"] is None:
        S["run"] = S["run"] + 1 if user else 0
        if S["run"] >= _START_BLOCKS:
            S["seg"] = list(S["pre"])
            S["quiet"] = S["sent"] = 0
            S["voiced"] = S["run"]
        return
    S["seg"].append(pcm)
    if user:
        S["quiet"] = 0
        S["voiced"] += 1
    else:
        S["quiet"] += 1
    n = len(S["seg"])
    if S["quiet"] >= _END_QUIET or n >= _MAX_BLOCKS:
        seg, voiced = S["seg"], S["voiced"]
        S["seg"] = None
        S["run"] = 0
        S["pre"].clear()
        if voiced >= _MIN_VOICED:
            _submit(jl, seg)
    elif n >= _RESEND_BLOCKS and n - S["sent"] >= _RESEND_BLOCKS:
        S["sent"] = n
        if S["voiced"] >= _MIN_VOICED:
            _submit(jl, list(S["seg"]))


# ── recognition (word mode) ─────────────────────────────────────────────────
def _submit(jl, blocks):
    if _S["busy"]:
        return                      # предыдущая проверка ещё идёт — этот кусок пропускаем
    _S["busy"] = True
    audio = np.concatenate(blocks).astype(np.int16)
    threading.Thread(target=_check, args=(jl, audio), daemon=True).start()


def _wav(audio):
    b = io.BytesIO()
    with wave.open(b, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(audio.tobytes())
    return b.getvalue()


def _transcribe(audio):
    import requests
    from memory.config_manager import get_gemini_key
    key = get_gemini_key()
    if not key:
        raise RuntimeError("нет ключа Gemini")
    payload = {
        "contents": [{"parts": [
            {"text": "Дословно запиши речь из аудио (язык: русский). Если речи нет — верни пустую строку. "
                     "Только текст, без пояснений."},
            {"inline_data": {"mime_type": "audio/wav", "data": base64.b64encode(_wav(audio)).decode()}},
        ]}],
        "generationConfig": {"temperature": 0, "maxOutputTokens": 60},
    }
    last = None
    for model in _MODELS:
        r = requests.post(
            "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent" % model,
            headers={"x-goog-api-key": key}, json=payload, timeout=8)
        if r.status_code == 404:
            last = "модель %s недоступна" % model
            continue
        r.raise_for_status()
        try:
            parts = r.json()["candidates"][0]["content"]["parts"]
            return "".join(p.get("text", "") for p in parts)
        except Exception:
            return ""
    raise RuntimeError(last or "нет ответа")


def _match(text):
    t = _norm(text)
    if not t:
        return ""
    for w in _words():
        if re.search(r"(?<!\w)" + re.escape(w), t):
            return w
    return ""


def _check(jl, audio):
    global _last_text
    try:
        text = _transcribe(audio)
        _last_text = text.strip()
        hit = _match(text)
        if hit and getattr(jl, "_is_speaking", False) and _conf()["enabled"] and _conf()["mode"] == "word":
            _fire(jl, "слово «%s»" % hit, ())
    except Exception as e:
        android.log("barge_in: распознавание не удалось: %s" % e)
    finally:
        _S["busy"] = False


# ── install the tap between the microphone and the core ────────────────────
def _install():
    try:
        import sounddevice as sd
        base = sd._InputBase
        if getattr(base, "_barge_patched", False):
            return
        orig = base.start

        def start(self, *a, **k):
            cb = getattr(self, "callback", None)
            if (cb is not None and not getattr(cb, "_barge", False)
                    and not getattr(self, "_raw", False)
                    and int(getattr(self, "samplerate", 0) or 0) == RATE):
                def wrapped(indata, frames, t, status, _cb=cb):
                    try:
                        _on_block(indata)
                    except Exception:
                        pass
                    return _cb(indata, frames, t, status)
                wrapped._barge = True
                self.callback = wrapped
            return orig(self, *a, **k)

        base.start = start
        base._barge_patched = True
    except Exception as e:
        android.log("barge_in: не удалось подключиться к микрофону: %s" % e)


_install()


# ── tool ────────────────────────────────────────────────────────────────────
def run(parameters, player=None, session_memory=None):
    a = str((parameters or {}).get("action") or "stop").strip().lower()
    c = _conf()
    if a == "word":
        c["mode"] = "word"
        _save()
        return "Теперь перебиваю по слову: " + ", ".join(_words())
    if a == "voice":
        c["mode"] = "voice"
        _save()
        return "Теперь перебиваю, как только вы заговорите."
    if a in ("on", "off"):
        c["enabled"] = a == "on"
        _save()
        return "Перебивание " + ("включено." if c["enabled"] else "выключено.")
    if a == "status":
        return "Перебивание %s, режим: %s%s." % (
            "включено" if c["enabled"] else "выключено", "по слову" if c["mode"] == "word" else "просто",
            "" if _S["ready"] else " (микрофон для него ещё не подключён)")
    jl = _jl()
    if jl is None:
        return "Ядро ещё не готово."
    threading.Thread(target=_stop, args=(jl,), daemon=True).start()
    return "Замолкаю."


# ── settings page ───────────────────────────────────────────────────────────
def settings_items():
    c = _conf()
    return [
        {"type": "label", "text": "Перебивание работает в режиме микрофона «постоянно»: пока Джарвис говорит, "
                                  "плагин слушает вас и останавливает его."},
        {"type": "button", "id": "enabled", "label": "Перебивание: " + ("ВКЛ" if c["enabled"] else "ВЫКЛ"),
         "pin": "act", "pin_title": "Перебивание: вкл/выкл"},
        {"type": "button", "id": "mode",
         "label": "Режим: " + ("ПО СЛОВУ" if c["mode"] == "word" else "ПРОСТО (как заговорили)") + "  — переключить",
         "pin": "act", "pin_title": "Режим перебивания"},
        {"type": "label", "text": "Слова для режима «по слову» (по одному на строку; слово засчитывается и "
                                  "с окончанием). Распознаётся через Gemini, нужен интернет."},
        {"type": "text", "id": "words", "label": "Слова-команды", "value": c["words"],
         "hint": "стоп, хватит…", "multiline": True},
        {"type": "button", "id": "debug", "label": "Отладка в журнал: " + ("ВКЛ" if c["debug"] else "ВЫКЛ")},
        {"type": "button", "id": "status", "label": "Показать состояние", "pin": "act", "pin_title": "Состояние перебивания"},
        {"type": "button", "id": "save", "label": "Сохранить"},
    ]


def settings_event(event, values):
    c = _conf()
    if "words" in (values or {}):
        c["words"] = str(values["words"]) or DEFAULT_WORDS
    if event == "enabled":
        c["enabled"] = not c["enabled"]
        _save()
        return {"message": "Перебивание " + ("включено" if c["enabled"] else "выключено"), "refresh": True}
    if event == "debug":
        c["debug"] = not c["debug"]
        _save()
        return {"message": "Отладка " + ("включена: строки [barge_in] в diag/jarvis.log" if c["debug"] else "выключена"),
                "refresh": True}
    if event == "mode":
        c["mode"] = "voice" if c["mode"] == "word" else "word"
        _reset()
        _save()
        return {"message": "Режим: " + ("по слову" if c["mode"] == "word" else "просто перебивание"),
                "refresh": True}
    _save()
    if event == "status":
        jl = _jl()
        if jl is None:
            return {"message": "Ядро ещё не готово.", "refresh": False}
        e = _guard
        msg = ("Режим: %s. Эхо: %s, шум комнаты %.2f, %s. Последнее услышанное: «%s». Последнее перебивание: %s." % (
            "по слову" if c["mode"] == "word" else "просто",
            "откалибровано" if getattr(e, "calibrated", False) else "ещё калибруется",
            getattr(e, "floor", 0.0),
            "комната нормальная" if getattr(e, "reliable", True) else "комната шумная (нужно дольше говорить)",
            _last_text or "—", _last_fire or "—"))
        return {"message": msg, "refresh": False}
    if event == "__leave__":
        return None
    return {"message": "Сохранено", "refresh": False}
