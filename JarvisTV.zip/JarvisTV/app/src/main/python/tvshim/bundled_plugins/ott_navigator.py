"""OTT Navigator: управление IPTV-плеером OTT Navigator на Android TV голосом через Mark.

У приложения нет публичного API, поэтому плагин управляет им так же, как пульт: запускает приложение
и шлёт клавиши через ADB (`input keyevent`). Выбор канала по названию — через чтение экрана
(uiautomator) и нажатие на найденный пункт.

Действия: open, channel_number, channel_name, next, prev, last, play, pause, stop, forward, rewind,
volume_up, volume_down, mute, menu, guide, info, ok, back, up, down, left, right, screen, key.
"""
import re
import time
import xml.etree.ElementTree as ET

import android_bridge as android

PKG = "studio.scillarium.ottnavigator"
DUMP = "/data/local/tmp/mark_ott_ui.xml"

PLUGIN = {
    "name": "ott_navigator",
    "description": (
        "Управление IPTV-плеером OTT Navigator на ТВ. action=open — запустить приложение; "
        "action=channel_number с number — переключить на канал по номеру («включи 15 канал»); "
        "action=channel_name с name — найти канал по названию в списке и включить («включи канал Футбол»); "
        "action=next / prev — следующий / предыдущий канал (times — сколько раз); action=last — прошлый канал; "
        "action=play / pause / stop / forward / rewind — воспроизведение; "
        "action=volume_up / volume_down / mute (times — сколько раз); "
        "action=menu / guide (программа передач) / info / ok / back / up / down / left / right — кнопки пульта; "
        "action=screen — прочитать, что на экране; action=key с code — нажать любой Android keycode. "
        "Вызывай на «открой оттнавигатор», «включи 15 канал», «следующий канал», «пауза», «программа передач»."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING", "description": "open | channel_number | channel_name | next | prev | last | "
                                                       "play | pause | stop | forward | rewind | volume_up | volume_down | "
                                                       "mute | menu | guide | info | ok | back | up | down | left | right | "
                                                       "screen | key"},
            "number": {"type": "INTEGER", "description": "Номер канала (для channel_number)"},
            "name": {"type": "STRING", "description": "Название канала (для channel_name)"},
            "times": {"type": "INTEGER", "description": "Сколько раз нажать (next/prev/volume_*/up/down), по умолчанию 1"},
            "code": {"type": "INTEGER", "description": "Android keycode (для action=key)"},
        },
        "required": ["action"],
    },
}

# Клавиши пульта. Если в вашей версии приложения кнопка делает другое — поправьте здесь.
KEYS = {
    "next": 166,         # CHANNEL_UP (если у вас наоборот — поменяйте местами с prev)
    "prev": 167,         # CHANNEL_DOWN
    "last": 229,         # LAST_CHANNEL
    "play": 126,         # MEDIA_PLAY
    "pause": 127,        # MEDIA_PAUSE
    "stop": 86,          # MEDIA_STOP
    "forward": 90,       # MEDIA_FAST_FORWARD
    "rewind": 89,        # MEDIA_REWIND
    "volume_up": 24,
    "volume_down": 25,
    "mute": 164,
    "menu": 82,
    "guide": 172,        # GUIDE
    "info": 165,         # INFO
    "ok": 66,            # ENTER
    "back": 4,
    "up": 19,
    "down": 20,
    "left": 21,
    "right": 22,
}
KEY_NAMES = {
    "next": "следующий канал", "prev": "предыдущий канал", "last": "прошлый канал", "play": "воспроизведение",
    "pause": "пауза", "stop": "стоп", "forward": "перемотка вперёд", "rewind": "перемотка назад",
    "volume_up": "громче", "volume_down": "тише", "mute": "звук выкл/вкл", "menu": "меню",
    "guide": "программа передач", "info": "информация", "ok": "OK", "back": "назад",
    "up": "вверх", "down": "вниз", "left": "влево", "right": "вправо",
}
REPEATABLE = {"next", "prev", "volume_up", "volume_down", "up", "down", "left", "right", "forward", "rewind"}
DIGIT_DELAY = 0.0      # пауза между цифрами номера канала, сек (0 — все цифры одной командой)
LIST_SETTLE = 1.5      # сколько ждать появления списка каналов, сек
MAX_PAGES = 8          # сколько страниц списка пролистать при поиске канала по названию
OPEN_CACHE = 60        # сколько секунд после команды не перепроверять, что OTT Navigator на экране (тяжёлый dumpsys)
_BOUNDS = re.compile(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]")


def _sh(cmd):
    return str(android.shell(cmd))


def _failed(res):
    low = res.lower()
    return res.startswith("ADB:") or "error" in low or "exception" in low


def _keys(codes, delay=0.0):
    """Нажать клавиши по очереди. Возвращает текст ошибки или ''."""
    if not delay:
        # одной командой: на слабом ТВ каждый запуск `input` занимает секунды, и цифры номера канала
        # приходят с большими паузами (включается канал 1, потом 5 вместо 15)
        res = _sh("input keyevent " + " ".join(str(c) for c in codes))
        if not _failed(res):
            return ""
    sep = "; sleep %.2f; " % delay if delay else "; "
    res = _sh(sep.join("input keyevent %d" % c for c in codes))
    return res[:120] if _failed(res) else ""


def _is_running():
    out = _sh("dumpsys window windows | grep -E 'mCurrentFocus|mFocusedApp'")
    return PKG in out


def _launch():
    for cat in ("LEANBACK_LAUNCHER", "LAUNCHER"):
        if "Events injected: 1" in _sh("monkey -p %s -c android.intent.category.%s 1" % (PKG, cat)):
            return True
    return False


def _start():
    """Запустить приложение (без проверки, что оно уже открыто). Возвращает ошибку или ''."""
    if "package:" + PKG not in _sh("pm list packages %s" % PKG):
        return "OTT Navigator не установлен на ТВ."
    if not _launch():
        return "Не удалось запустить OTT Navigator."
    time.sleep(3.0)
    return ""


def _ensure_open(mem):
    """Приложение должно быть на переднем плане. Возвращает ошибку или ''."""
    if mem.get("ott_until", 0) > time.time() or _is_running():
        mem["ott_until"] = time.time() + OPEN_CACHE
        return ""
    err = _start()
    if not err:
        mem["ott_until"] = time.time() + OPEN_CACHE
    return err


def _press(codes, mem, need_app=True):
    """Нажать клавиши с минимумом обращений к ТВ: проверка «приложение открыто» и нажатие — одной командой,
    а сразу после успешной команды проверка пропускается (OPEN_CACHE сек). Возвращает ошибку или ''."""
    keys = " ".join(str(c) for c in codes)
    if not need_app or mem.get("ott_until", 0) > time.time():
        res = _sh("input keyevent " + keys)
    else:
        res = _sh('if dumpsys window windows | grep -q "mCurrentFocus.*%s"; then input keyevent %s; '
                  'else echo NOTOPEN; fi' % (PKG, keys))
        if "NOTOPEN" in res:
            err = _start()
            if err:
                return err
            res = _sh("input keyevent " + keys)
    if _failed(res):
        return "Ошибка: " + res[:120]
    if need_app:
        mem["ott_until"] = time.time() + OPEN_CACHE
    return ""


def _nodes():
    """Элементы экрана: [{text, cx, cy}] с координатами центра."""
    out = ""
    for _ in range(2):
        out = _sh("uiautomator dump %s >/dev/null 2>&1; cat %s" % (DUMP, DUMP))
        if "<hierarchy" in out:
            break
        time.sleep(1.2)
    a, b = out.find("<hierarchy"), out.rfind("</hierarchy>")
    if a < 0 or b < 0:
        return []
    try:
        root = ET.fromstring(out[a:b + len("</hierarchy>")])
    except ET.ParseError:
        return []
    items = []
    for n in root.iter("node"):
        if n.get("package") != PKG:
            continue
        t = (n.get("text") or n.get("content-desc") or "").strip()
        m = _BOUNDS.match(n.get("bounds") or "")
        if t and m:
            x1, y1, x2, y2 = map(int, m.groups())
            items.append({"text": t, "cx": (x1 + x2) // 2, "cy": (y1 + y2) // 2})
    return items


def _show(title, lines, player):
    if player is not None and lines:
        player.show_content(title, "\n".join("%d. %s" % (i + 1, t) for i, t in enumerate(lines[:60])))


def _channel_number(number, mem):
    digits = [int(c) for c in str(number) if c.isdigit()]
    if not digits:
        return "Не понял номер канала."
    codes = [7 + d for d in digits]  # KEYCODE_0 = 7
    err = _keys(codes, DIGIT_DELAY) if DIGIT_DELAY else _press(codes, mem)
    return err or "Включаю канал %s." % number


def _channel_name(name, mem):
    err = _ensure_open(mem)
    if err:
        return err
    want = name.strip().lower()
    err = _keys([KEYS["ok"]])  # OK на экране с видео открывает список каналов
    if err:
        return "Ошибка: " + err
    time.sleep(LIST_SETTLE)
    seen = set()
    for _ in range(MAX_PAGES):
        items = _nodes()
        hit = next((n for n in items if want in n["text"].lower()), None)
        if hit:
            _sh("input tap %d %d" % (hit["cx"], hit["cy"]))
            time.sleep(0.4)
            _keys([KEYS["ok"]])  # подтвердить выбор, если после тапа канал только выделился
            return "Включаю канал %s." % hit["text"]
        texts = {n["text"] for n in items}
        if not texts or texts <= seen:  # экран не меняется — дальше листать нечего
            break
        seen |= texts
        _keys([93])  # PAGE_DOWN
        time.sleep(0.8)
    return "Не нашёл канал «%s» в списке. Скажи «что на экране», чтобы я посмотрел, что открыто." % name


def run(parameters, player=None, session_memory=None):
    action = str(parameters.get("action") or "").lower()
    mem = session_memory if isinstance(session_memory, dict) else {}
    try:
        times = max(1, min(int(parameters.get("times") or 1), 20))
    except (TypeError, ValueError):
        times = 1
    try:
        if action == "open":
            if _is_running():
                return "OTT Navigator уже открыт."
            err = _ensure_open(mem)
            return err or "Открыл OTT Navigator."

        if action == "channel_number":
            try:
                return _channel_number(int(parameters.get("number")), mem)
            except (TypeError, ValueError):
                return "Не понял номер канала."

        if action == "channel_name":
            name = str(parameters.get("name") or "").strip()
            return _channel_name(name, mem) if name else "Не понял название канала."

        if action == "screen":
            items = _nodes()
            if not items:
                return "На экране OTT Navigator ничего не прочитал (приложение закрыто?)."
            texts = list(dict.fromkeys(n["text"] for n in items))
            _show("OTT Navigator: на экране", texts, player)
            return "На экране: %s." % "; ".join(texts[:8])

        if action == "key":
            try:
                code = int(parameters.get("code"))
            except (TypeError, ValueError):
                return "Не понял код клавиши."
            err = _keys([code])
            return ("Ошибка: " + err) if err else "Нажал клавишу %d." % code

        if action in KEYS:
            codes = [KEYS[action]] * (times if action in REPEATABLE else 1)
            err = _press(codes, mem, need_app=action not in ("volume_up", "volume_down", "mute"))  # громкость ТВ — без приложения
            if err:
                return err
            return "Сделал: %s%s." % (KEY_NAMES[action], (" ×%d" % times) if times > 1 and action in REPEATABLE else "")

        return "Неизвестное действие: %s" % action
    except Exception as e:
        return "Ошибка: %s" % e
