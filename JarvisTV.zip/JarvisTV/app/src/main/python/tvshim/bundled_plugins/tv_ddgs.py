"""
tv_ddgs — gives Jarvis's own web search and news (actions/web_search.py) the `ddgs` package it is missing on Android.

web_search.py does `from ddgs import DDGS`; the package has no Android build, so every DuckDuckGo search returned
nothing and the morning briefing / news alerts said "news unavailable". This plugin installs a small pure-Python
stand-in named `ddgs` (class DDGS with .text() and .news()), so the app's own code works unchanged:
the briefing, the news watch and the "news" voice request all use it again.

Order of tries, per request (each with a short timeout, so the briefing's 8 s wait is respected):
  news:  1. DuckDuckGo news (the same endpoint the real package uses)
         2. Bing News (full snippet, source, link) - only if DuckDuckGo refuses or is empty
  text:  1. DuckDuckGo html  2. DuckDuckGo lite
Action 'status' shows which source answered last and any error; 'test' runs a live news search right now.
One self-contained file. Does nothing if a real `ddgs` package is present.
"""
from __future__ import annotations

import html as _html
import json
import re
import sys
import time
import types
import urllib.parse
import urllib.request

PLUGIN = {
    "name": "tv_ddgs",
    "description": (
        "Makes Jarvis's built-in news/web search work (DuckDuckGo, with Bing News as backup). It installs itself "
        "automatically. Use only for checking: action status = which source answered last; action test = run a "
        "live news search now and show the headlines."
    ),
    "brief": "DuckDuckGo news/search for Jarvis without the ddgs package.",
    "tier": "extra",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING", "description": "status | test"},
            "query": {"type": "STRING", "description": "Search words for action=test (default: top world news today)"},
        },
        "required": [],
    },
}

UA = ("Mozilla/5.0 (Linux; Android 9; Mi TV) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/120.0 Safari/537.36")
TIMEOUT = 5.0
STATE = {"last_source": "-", "last_error": "", "calls": 0, "ok": 0}


# ── http ────────────────────────────────────────────────────────────────────────

def _fetch(url: str, data: dict | None = None, headers: dict | None = None, timeout: float = TIMEOUT) -> str:
    h = {"User-Agent": UA, "Accept-Language": "en-US,en;q=0.8,ru;q=0.6", "Accept": "*/*"}
    h.update(headers or {})
    body = urllib.parse.urlencode(data).encode() if data is not None else None
    req = urllib.request.Request(url, data=body, headers=h)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", "replace")


def _clean(s: str) -> str:
    s = re.sub(r"<[^>]+>", "", s or "")
    return re.sub(r"\s+", " ", _html.unescape(s)).strip()


# ── DuckDuckGo news (news.js with the vqd token) ───────────────────────────────

def _ddg_news(query: str, n: int, region: str = "wt-wt") -> list[dict]:
    page = _fetch("https://duckduckgo.com/?" + urllib.parse.urlencode({"q": query, "iar": "news", "ia": "news"}))
    m = re.search(r'vqd=["\']?([\d-]+)', page)
    if not m:
        raise RuntimeError("DuckDuckGo gave no vqd token")
    url = "https://duckduckgo.com/news.js?" + urllib.parse.urlencode(
        {"l": region, "o": "json", "noamp": "1", "q": query, "vqd": m.group(1), "p": "-1"})
    raw = _fetch(url, headers={"Referer": "https://duckduckgo.com/", "Accept": "application/json"})
    return _parse_ddg_news_json(raw, n)


def _parse_ddg_news_json(raw: str, n: int) -> list[dict]:
    out = []
    for r in (json.loads(raw).get("results") or []):
        if not r.get("title"):
            continue
        out.append({"title": _clean(r.get("title")), "body": _clean(r.get("excerpt") or r.get("body")),
                    "url": r.get("url", ""), "source": r.get("source", ""), "date": r.get("date", "")})
        if len(out) >= n:
            break
    return out


# ── Bing News RSS (backup) ─────────────────────────────────────────────────────

def _bing_news(query: str, n: int) -> list[dict]:
    raw = _fetch("https://www.bing.com/news/search?" + urllib.parse.urlencode({"q": query, "format": "RSS"}))
    return _parse_bing_rss(raw, n)


def _parse_bing_rss(raw: str, n: int) -> list[dict]:
    out = []
    for item in re.findall(r"<item>(.*?)</item>", raw, re.S):
        def tag(t):
            m = re.search(rf"<{t}[^>]*>(.*?)</{t}>", item, re.S)
            return _clean(re.sub(r"<!\[CDATA\[|\]\]>", "", m.group(1))) if m else ""
        link = tag("link")
        q = urllib.parse.parse_qs(urllib.parse.urlparse(link).query).get("url")
        if q:
            link = q[0]
        title = tag("title")
        if title:
            out.append({"title": title, "body": tag("description"), "url": link,
                        "source": tag("News:Source"), "date": tag("pubDate")})
        if len(out) >= n:
            break
    return out


# ── DuckDuckGo text ────────────────────────────────────────────────────────────

def _unwrap(href: str) -> str:
    href = _html.unescape(href)
    if href.startswith("//"):
        href = "https:" + href
    q = urllib.parse.parse_qs(urllib.parse.urlparse(href).query).get("uddg")
    return q[0] if q else href


def _parse_ddg_html(raw: str, n: int) -> list[dict]:
    links = re.findall(r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>', raw, re.S)
    snips = re.findall(r'<a[^>]+class="result__snippet"[^>]*>(.*?)</a>', raw, re.S)
    out = []
    for i, (href, title) in enumerate(links[:n]):
        out.append({"title": _clean(title), "body": _clean(snips[i]) if i < len(snips) else "", "href": _unwrap(href)})
    return out


def _parse_ddg_lite(raw: str, n: int) -> list[dict]:
    links = []
    for tag in re.findall(r"<a\b[^>]*result-link[^>]*>.*?</a>", raw, re.S):
        h = re.search(r"href=['\"]([^'\"]+)['\"]", tag)
        if h:
            links.append((h.group(1), tag))
    snips = re.findall(r"<td[^>]+class=['\"]result-snippet['\"][^>]*>(.*?)</td>", raw, re.S)
    return [{"title": _clean(t), "body": _clean(snips[i]) if i < len(snips) else "", "href": _unwrap(h)}
            for i, (h, t) in enumerate(links[:n])]


def _ddg_text(query: str, n: int) -> list[dict]:
    try:
        r = _parse_ddg_html(_fetch("https://html.duckduckgo.com/html/", data={"q": query}), n)
        if r:
            return r
    except Exception as e:
        STATE["last_error"] = f"html: {type(e).__name__}: {e}"
    return _parse_ddg_lite(_fetch("https://lite.duckduckgo.com/lite/", data={"q": query}), n)


# ── the stand-in for the `ddgs` package ────────────────────────────────────────

class DDGS:
    def __init__(self, *a, **k):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def news(self, query, region="wt-wt", safesearch="moderate", timelimit=None, max_results=10, **kw):
        STATE["calls"] += 1
        last = None
        for name, fn in (("DuckDuckGo news", lambda: _ddg_news(query, max_results, region)),
                         ("Bing News", lambda: _bing_news(query, max_results))):
            try:
                res = fn()
                if res:
                    STATE.update(last_source=name, last_error="" if name == "DuckDuckGo news" else STATE["last_error"])
                    STATE["ok"] += 1
                    return res
            except Exception as e:
                last = f"{name}: {type(e).__name__}: {e}"
                STATE["last_error"] = last
        raise RuntimeError(last or "no news found")

    def text(self, query, region="wt-wt", safesearch="moderate", timelimit=None, max_results=10, **kw):
        STATE["calls"] += 1
        try:
            res = _ddg_text(query, max_results)
        except Exception as e:
            STATE["last_error"] = f"text: {type(e).__name__}: {e}"
            raise
        if res:
            STATE["last_source"] = "DuckDuckGo text"
            STATE["ok"] += 1
        return res


def _install() -> str:
    try:
        import ddgs as _real                                  # a real package exists: leave it alone
        if not getattr(_real, "__tv_shim__", False):
            return "real ddgs package found - not replaced"
    except ImportError:
        pass
    mod = types.ModuleType("ddgs")
    mod.DDGS = DDGS
    mod.__tv_shim__ = True
    sys.modules["ddgs"] = mod
    return "installed"


_WHAT = _install()


def run(parameters: dict, player=None) -> str:
    p = parameters or {}
    action = str(p.get("action") or "status").lower().strip()
    if action == "test":
        q = str(p.get("query") or "top world news today")
        t0 = time.monotonic()
        try:
            res = DDGS().news(q, max_results=5)
        except Exception as e:
            return f"Search failed after {time.monotonic() - t0:.1f} s: {e}"
        head = f"{STATE['last_source']} answered in {time.monotonic() - t0:.1f} s:\n"
        return head + "\n".join(f"{i}. {r['title']}" + (f" [{r['source']}]" if r.get("source") else "")
                                for i, r in enumerate(res, 1))
    return (f"ddgs stand-in: {_WHAT}. Requests: {STATE['calls']}, successful: {STATE['ok']}, "
            f"last source: {STATE['last_source']}" + (f"; last error: {STATE['last_error']}" if STATE["last_error"] else "") + ".")
