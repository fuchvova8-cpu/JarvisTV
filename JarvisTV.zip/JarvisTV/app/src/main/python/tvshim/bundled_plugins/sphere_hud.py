"""Сфера с кольцами из Mark LVII (gui/reactor.py) — центр HUD на ТВ.

Плагин сам рисует голографическую сферу: платформа, два гироскопных кольца,
орбита с тремя «трассерами», меридианы и пылинки. Кадры (numpy + Pillow) уходят
в Kotlin-мост `Bridge.hudFrame`, а HudView рисует их вместо обычных колец.
Ядро Jarvis не затрагивается: выключил плагин — вернулся прежний HUD.

Управление:
    голосом     «включи сферу» / «выключи сферу»  (инструмент sphere_hud)
    в меню      Настройки плагинов → «Сфера HUD»  (вкл/выкл, качество)

Что означает движение (как в оригинале):
    цвет            — состояние (слушает / говорит / думает / mute / сон)
    скорость вращения — состояние
    ядро, шипы платформы — реальный уровень звука
"""
from __future__ import annotations

import json
import math
import os
import threading
import time

import numpy as np
from PIL import Image, ImageDraw, ImageFont

PLUGIN = {
    "name": "sphere_hud",
    "description": (
        "Включить, выключить или переключить анимированную сферу с кольцами в центре "
        "экрана Jarvis на ТВ. Вызывай на фразы «включи сферу», «выключи сферу», "
        "«верни старый интерфейс», «сфера с кольцами»."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING", "description": "on, off или toggle (по умолчанию toggle)"},
        },
        "required": [],
    },
}

SETTINGS = {"title": "Сфера HUD"}

# ── геометрия (из reactor.py) ────────────────────────────────────────────────
_PITCH = math.radians(17.0)
_CAM_D = 4.2
_N_RING = 60
_N_GLOBE = 40
_FLOOR_Y = -1.02
_SPHERE = 0.46
_SS = 2                      # суперсэмплинг: рисуем в 2x, уменьшаем в 1x

_QUALITY = {"light": (320, 12), "normal": (400, 15), "high": (512, 20)}   # (px, fps)

_STATE_COLORS = {
    "LISTENING": (0, 214, 255),
    "SPEAKING": (255, 176, 40),
    "THINKING": (170, 110, 255),
    "PROCESSING": (170, 110, 255),
    "MUTED": (255, 70, 70),
}
_IDLE_COLOR = (60, 110, 130)


def _rx(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])


def _ry(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])


def _rz(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])


def _lighten(col, k):
    return tuple(int(c + (255 - c) * k) for c in col)


def _font(px):
    try:
        return ImageFont.load_default(size=px)
    except Exception:
        return ImageFont.load_default()


def _rgba(col, a):
    return (col[0], col[1], col[2], int(max(0.0, min(1.0, a)) * 255))


# ── градиенты как спрайты ────────────────────────────────────────────────────
def _stops_to_img(t, stops, mask=None):
    """t — массив 0..1; stops — [(pos, (r,g,b,a 0..1))]. Возвращает RGBA Image."""
    pos = [s[0] for s in stops]
    out = np.empty(t.shape + (4,), np.float32)
    for ch in range(4):
        out[..., ch] = np.interp(t, pos, [s[1][ch] for s in stops])
    if mask is not None:
        out[..., 3] *= mask
    img = np.dstack([np.clip(out[..., :3], 0, 255), np.clip(out[..., 3] * 255.0, 0, 255)]).astype(np.uint8)
    return Image.fromarray(img, "RGBA")


def _radial(size, stops):
    h = w = size
    y, x = np.mgrid[0:h, 0:w].astype(np.float32)
    c = (size - 1) / 2.0
    t = np.sqrt((x - c) ** 2 + (y - c) ** 2) / max(c, 1.0)
    return _stops_to_img(np.clip(t, 0, 1), stops)


def _radial_ellipse(w, h, ry_scale, stops):
    y, x = np.mgrid[0:h, 0:w].astype(np.float32)
    cx, cy = (w - 1) / 2.0, (h - 1) / 2.0
    t = np.sqrt(((x - cx) / max(cx, 1.0)) ** 2 + ((y - cy) / max(cy, 1.0)) ** 2)
    return _stops_to_img(np.clip(t, 0, 1), stops)


def _focal_sphere(size, fx, fy, stops):
    """Круг радиуса size/2 с градиентом из смещённой точки (как QRadialGradient с фокусом)."""
    R = size / 2.0
    y, x = np.mgrid[0:size, 0:size].astype(np.float32)
    px, py = x - R + 0.5, y - R + 0.5
    qx, qy = px - fx, py - fy
    dist = np.sqrt(qx * qx + qy * qy)
    dx, dy = qx / np.maximum(dist, 1e-6), qy / np.maximum(dist, 1e-6)
    b = dx * (fx) + dy * (fy)
    cc = fx * fx + fy * fy - R * R
    L = -b + np.sqrt(np.maximum(b * b - cc, 1e-6))
    t = np.clip(dist / np.maximum(L, 1e-6), 0, 1)
    inside = (px * px + py * py <= R * R).astype(np.float32)
    return _stops_to_img(t, stops, inside)


class Sphere:
    """Состояние и рендерер одного кадра."""

    def __init__(self, px: int):
        self.px = px
        self.W = px * _SS
        t = np.linspace(0.0, 2 * math.pi, _N_RING, endpoint=False)
        self._ring = np.vstack([np.cos(t), np.zeros_like(t), np.sin(t)])
        g = np.linspace(0.0, 2 * math.pi, _N_GLOBE, endpoint=False)
        self._glat = []
        for lat in (-58, -30, 0, 30, 58):
            la = math.radians(lat)
            self._glat.append(np.vstack([np.cos(g) * math.cos(la),
                                         np.full_like(g, math.sin(la)),
                                         np.sin(g) * math.cos(la)]))
        self._glon = []
        for k in range(6):
            lo = k * math.pi / 6
            self._glon.append(np.vstack([np.cos(g) * math.cos(lo), np.sin(g),
                                         np.cos(g) * math.sin(lo)]))
        rng = np.random.default_rng(57)
        self._motes = [(float(rng.uniform(1.18, 1.55)), float(rng.uniform(0, 2 * math.pi)),
                        float(rng.uniform(-0.55, 0.55)), float(rng.uniform(0.25, 0.9)))
                       for _ in range(22)]
        self.spin = 0.0
        self._view = _rx(_PITCH)
        self.cx = self.W / 2.0
        self.cy = self.W * 0.385
        self.r = self.W * 0.29
        self._layers = {}       # цвет → (under, lat_front)
        self._sprites = {}

    # ── движение ─────────────────────────────────────────────────────────────
    def step(self, dt, speaking, thinking, muted, amp=0.0):
        dt = min(0.10, max(0.0, dt))
        rate = 0.12 if muted else 0.38 + (1.5 if thinking else 0.0) + (0.8 if speaking else 0.0) + 2.2 * amp
        self.spin += dt * rate

    # ── проекция ─────────────────────────────────────────────────────────────
    def _project(self, pts):
        v = self._view @ pts
        s = _CAM_D / (_CAM_D - v[2])
        return self.cx + v[0] * s * self.r, self.cy - v[1] * s * self.r, v[2]

    @staticmethod
    def _curve(d, X, Y, Z, col, a_front, a_back, width, part):
        zm = (Z + np.roll(Z, -1)) * 0.5
        if part == "back":
            idx = np.flatnonzero(zm < 0)
            alpha = a_back * (0.35 + 0.65 * np.maximum(1.0 + zm, 0.0))
        else:
            idx = np.flatnonzero(zm >= 0)
            alpha = a_front * (0.55 + 0.45 * np.minimum(zm, 1.0))
        if not idx.size:
            return
        xe, ye = np.roll(X, -1), np.roll(Y, -1)
        w = max(1, int(round(width * _SS)))
        for i in idx.tolist():
            d.line((float(X[i]), float(Y[i]), float(xe[i]), float(ye[i])),
                   fill=_rgba(col, float(alpha[i])), width=w)

    # ── то, что не меняет форму, рисуется один раз на цвет ───────────────────
    def _build_layers(self, main):
        W, r, cx, cy = self.W, self.r, self.cx, self.cy
        under = Image.new("RGBA", (W, W), (0, 0, 0, 0))
        d = ImageDraw.Draw(under, "RGBA")
        fx, fy, _ = self._project(np.array([[0.0], [_FLOOR_Y], [0.0]]))
        fx, fy = float(fx[0]), float(fy[0])
        gw = int(r * 2.6)
        gh = max(2, int(gw * math.sin(_PITCH) * 1.25))
        glow = _radial_ellipse(gw, gh, 1.0, [
            (0.0, (*main, 0.24)), (0.45, (*main, 0.08)), (1.0, (*main, 0.0))])
        under.alpha_composite(glow, (int(fx - gw / 2), int(fy - gh / 2)))
        for rr, a, w in ((1.20, 0.55, 1.4), (1.02, 0.32, 1.0), (0.74, 0.40, 1.2), (0.46, 0.22, 1.0)):
            pts = self._ring * rr
            pts[1] += _FLOOR_Y
            X, Y, Z = self._project(pts)
            self._curve(d, X, Y, Z, main, a, a * 0.75, w, "back")
            self._curve(d, X, Y, Z, main, a, a * 0.75, w, "front")
        lats = [self._project(p * _SPHERE) for p in self._glat]
        for X, Y, Z in lats:
            self._curve(d, X, Y, Z, main, 0.5, 0.16, 1.0, "back")
        front = Image.new("RGBA", (W, W), (0, 0, 0, 0))
        d2 = ImageDraw.Draw(front, "RGBA")
        for X, Y, Z in lats:
            self._curve(d2, X, Y, Z, main, 0.46, 0.16, 1.0, "front")
        return under, front

    def _layers_for(self, main):
        got = self._layers.get(main)
        if got is None:
            if len(self._layers) >= 6:
                self._layers.pop(next(iter(self._layers)))
            got = self._layers[main] = self._build_layers(main)
        return got

    def _sprite(self, key, make):
        s = self._sprites.get(key)
        if s is None:
            if len(self._sprites) > 80:
                self._sprites.clear()
            s = self._sprites[key] = make()
        return s

    # ── кадр ─────────────────────────────────────────────────────────────────
    def render(self, main, amp, live, name="") -> bytes:
        """Возвращает RGBA (предумноженный) px*px*4 байт."""
        W, r, cx, cy, spin = self.W, self.r, self.cx, self.cy, self.spin
        amp = max(0.0, min(1.0, amp))
        ab = int(round(amp * 7))                 # 8 ступеней для спрайтов
        acc = _lighten(main, 0.35)
        white = (255, 255, 255)
        under, lat_front = self._layers_for(main)

        img = under.copy()
        d = ImageDraw.Draw(img, "RGBA")

        # шипы спектра на ободе платформы
        n_t = 64
        ang = np.linspace(0, 2 * math.pi, n_t, endpoint=False) + spin * 0.25
        wob = 0.5 + 0.5 * np.sin(ang * 5.0 + spin * 6.0) * np.cos(ang * 3.0 - spin * 2.3)
        h = 0.03 + ((0.20 * amp * wob + 0.25 * amp * amp) if live else 0.0)
        base = np.vstack([np.cos(ang) * 1.20, np.full(n_t, _FLOOR_Y), np.sin(ang) * 1.20])
        tip = base.copy()
        tip[1] += h
        bX, bY, bZ = self._project(base)
        tX, tY, _ = self._project(tip)
        col_t = acc if live else main
        w_t = max(1, int(round(1.4 * _SS)))
        for want, a in ((False, 0.25), (True, 0.65)):
            fill = _rgba(col_t, a * (0.5 + amp))
            for i in range(n_t):
                if (bZ[i] >= 0) == want:
                    d.line((float(bX[i]), float(bY[i]), float(tX[i]), float(tY[i])), fill=fill, width=w_t)

        # луч от платформы к ядру
        fx, fy, _ = self._project(np.array([[0.0], [_FLOOR_Y], [0.0]]))
        fx, fy = float(fx[0]), float(fy[0])
        beam_w = int(r * 0.30)
        top = cy - r * 0.05
        hgt = max(2, int(fy - top))

        def make_beam():
            x = np.linspace(0, 1, 2 * beam_w, dtype=np.float32)
            prof = np.where(x < 0.5, x * 2, (1 - x) * 2) * (0.16 + 0.40 * amp)
            rows = np.arange(hgt, dtype=np.float32)
            k = np.floor(rows / hgt * 8.0) + 1.0
            vf = (k / 8.0) ** 1.6
            a = prof[None, :] * vf[:, None]
            out = np.zeros((hgt, 2 * beam_w, 4), np.uint8)
            out[..., 0], out[..., 1], out[..., 2] = main
            out[..., 3] = np.clip(a * 255, 0, 255).astype(np.uint8)
            return Image.fromarray(out, "RGBA")
        img.alpha_composite(self._sprite(("beam", main, ab), make_beam), (int(fx - beam_w), int(top)))

        # гироскопные кольца и орбита
        rings = (
            (self._project(_ry(spin * 0.9) @ _rz(math.radians(64)) @ (self._ring * 0.90)), acc, 0.80, 1.7),
            (self._project(_ry(-spin * 1.25) @ _rx(math.radians(58)) @ (self._ring * 0.78)), main, 0.62, 1.3),
            (self._project(self._ring * 1.08), main, 0.45, 1.1),
        )
        spin_g = _ry(spin * 0.6)
        meridians = [self._project(spin_g @ (p * _SPHERE)) for p in self._glon]
        for (X, Y, Z), col, a, w in rings:
            self._curve(d, X, Y, Z, col, a, a * 0.55, w, "back")
        for X, Y, Z in meridians:
            self._curve(d, X, Y, Z, main, 0.5, 0.16, 1.0, "back")

        # сфера — голограмма, свет сверху-слева
        sr = r * _SPHERE * (1.0 + 0.07 * amp)
        ssz = int(sr * 2) + 2

        def make_sphere():
            return _focal_sphere(ssz, -sr * 0.38, -sr * 0.42, [
                (0.0, (*white, 0.55 + 0.3 * amp)),
                (0.18, (*main, 0.55 + 0.25 * amp)),
                (0.70, (*main, 0.16)),
                (1.0, (*main, 0.05))])
        img.alpha_composite(self._sprite(("sph", main, ab), make_sphere), (int(cx - ssz / 2), int(cy - ssz / 2)))
        d.ellipse((cx - sr, cy - sr, cx + sr, cy + sr), outline=_rgba(main, 0.65), width=max(1, int(1.3 * _SS)))

        # сердце ядра: светлее и больше вместе с голосом
        hr = sr * (0.20 + 0.34 * amp) * 2.4
        hsz = int(hr * 2) + 2
        hc = acc if live else main

        def make_heart():
            return _radial(hsz, [(0.0, (*white, 0.95)), (0.25, (*hc, 0.75)), (1.0, (*main, 0.0))])
        img.alpha_composite(self._sprite(("hrt", main, hc, ab), make_heart), (int(cx - hsz / 2), int(cy - hsz / 2)))

        img.alpha_composite(lat_front)
        for X, Y, Z in meridians:
            self._curve(d, X, Y, Z, main, 0.46, 0.16, 1.0, "front")
        for (X, Y, Z), col, a, w in rings:
            self._curve(d, X, Y, Z, col, a, a * 0.55, w, "front")

        # трассеры на орбите
        X, Y, Z = rings[2][0]
        for k in range(3):
            i = int((k * _N_RING / 3 + spin * 7.0) % _N_RING)
            depth = float(Z[i])
            rad = (2.2 + 1.6 * max(0.0, depth)) * 3 * _SS * 0.7
            x, y = float(X[i]), float(Y[i])
            front = depth >= 0
            for f, a, col in ((1.0, 0.18, acc), (0.55, 0.35, acc), (0.25, 0.9 if front else 0.35, white)):
                rr = rad * f
                d.ellipse((x - rr, y - rr, x + rr, y + rr), fill=_rgba(col, a if col is white else a * (1 if front else 0.4)))

        # пылинки вокруг ядра
        a = np.array([ph + spin * sp for _r0, ph, _y, sp in self._motes])
        r0 = np.array([m[0] for m in self._motes])
        pts = np.vstack([np.cos(a) * r0, np.array([m[2] for m in self._motes]), np.sin(a) * r0])
        MX, MY, MZ = self._project(pts)
        for x, y, dz in zip(MX.tolist(), MY.tolist(), MZ.tolist()):
            dz = max(0.0, dz)
            rr = (1.1 + 0.8 * dz) * _SS
            d.ellipse((x - rr, y - rr, x + rr, y + rr), fill=_rgba(main, 0.25 + 0.35 * dz))

        # имя на передней кромке платформы
        if name:
            nx, ny, _ = self._project(np.array([[0.0], [_FLOOR_Y], [1.2]]))
            px = max(10, int(r * 0.11))
            font = self._sprite(("font", px), lambda: _font(px))
            gap = max(2.0 * _SS, round(r * 0.035))
            widths = [d.textlength(ch, font=font) for ch in name]
            x = float(nx[0]) - (sum(widths) + gap * (len(name) - 1)) / 2.0
            y = float(ny[0]) + r * 0.10
            fill = _rgba(white, 0.78 + 0.2 * min(1.0, amp * 2))
            for ch, wch in zip(name, widths):
                d.text((x, y), ch, font=font, fill=fill)
                x += wch + gap

        out = img.reduce(_SS)
        arr = np.asarray(out, dtype=np.uint16)
        a8 = arr[..., 3:4]
        prem = np.concatenate([arr[..., :3] * a8 // 255, a8], axis=-1).astype(np.uint8)
        return prem.tobytes()


# ── потоки и состояние плагина ───────────────────────────────────────────────
_lock = threading.Lock()
_thread = None
_stop = threading.Event()
_cfg = {"on": False, "quality": "normal"}
_lv = {"at": None, "t": 0.0, "err": False, "seen": False, "peak": 0.25}


def _android():
    try:
        import android_bridge as android
        return android
    except Exception:
        return None


def _cfg_file():
    a = _android()
    base = ""
    try:
        base = (a.data_dir() if a else "") or ""
    except Exception:
        pass
    return os.path.join(base or ".", "sphere_hud.json")


def _load():
    try:
        with open(_cfg_file(), encoding="utf-8") as f:
            d = json.load(f)
        _cfg["on"] = bool(d.get("on"))
        if d.get("quality") in _QUALITY:
            _cfg["quality"] = d["quality"]
    except Exception:
        pass


def _save():
    try:
        with open(_cfg_file(), "w", encoding="utf-8") as f:
            json.dump(_cfg, f)
    except Exception:
        pass


def _kt():
    from tvshim.bridge import kt
    return kt()


def _read_state():
    """(state, level 0..1, appVisible) из Kotlin-моста; вне устройства — заглушки."""
    k = _kt()
    try:
        state = str(k.getCurState() or "SLEEPING").upper()
    except Exception:
        state = "SLEEPING"
    level = 0.0
    try:
        at = int(k.getLevelAt())
        now = time.monotonic()
        if at != _lv["at"]:                  # Kotlin записал новое значение
            _lv["at"], _lv["t"] = at, now
        if now - _lv["t"] < 0.3:
            level = float(k.getLevel())
    except Exception as e:
        if not _lv["err"]:
            _lv["err"] = True
            _log("уровень звука недоступен: %s: %s" % (type(e).__name__, e))
    try:
        vis = bool(k.getAppVisible())
    except Exception:
        vis = True
    return state, level, vis


def _loop(quality):
    px, fps = _QUALITY[quality]
    sph = Sphere(px)
    k = _kt()
    smooth = 0.0
    last = time.monotonic()
    try:
        while not _stop.is_set():
            t0 = time.monotonic()
            state, level, visible = _read_state()
            if not visible:
                _stop.wait(0.5)
                last = time.monotonic()
                continue
            if level > 0.0 and not _lv["seen"]:
                _lv["seen"] = True
                _log("уровень звука поступает (%.2f)" % level)
            # авто-усиление: тихий микрофон всё равно даёт заметное движение
            _lv["peak"] = max(0.25, _lv["peak"] * 0.997, level)
            level = min(1.0, level / _lv["peak"])
            smooth += (level - smooth) * 0.5
            sph.step(t0 - last, state == "SPEAKING", state in ("THINKING", "PROCESSING"), state == "MUTED", smooth)
            last = t0
            main = _STATE_COLORS.get(state, _IDLE_COLOR)
            live = state in ("LISTENING", "SPEAKING")
            try:
                try:
                    name = str(k.getAssistantName() or "")
                except Exception:
                    name = ""
                k.hudFrame(sph.render(main, smooth, live, name.upper()), px, px)
            except Exception as e:
                _log("кадр не отправлен: %s: %s" % (type(e).__name__, e))
                _stop.wait(2.0)
            _stop.wait(max(0.0, 1.0 / fps - (time.monotonic() - t0)))
    finally:
        try:
            k.hudFrameClear()
        except Exception:
            pass


def _log(text):
    a = _android()
    try:
        if a:
            a.log("sphere_hud: " + text)
    except Exception:
        pass


def _start():
    global _thread
    with _lock:
        if _thread is not None and _thread.is_alive():
            return
        _stop.clear()
        _thread = threading.Thread(target=_loop, args=(_cfg["quality"],), name="sphere-hud", daemon=True)
        _thread.start()


def _halt():
    global _thread
    with _lock:
        t, _thread = _thread, None
    if t is not None:
        _stop.set()
        t.join(timeout=2.0)


def set_enabled(on: bool) -> None:
    _cfg["on"] = bool(on)
    _save()
    if on:
        _start()
    else:
        _halt()


def _set_quality(q: str) -> None:
    _cfg["quality"] = q
    _save()
    if _cfg["on"]:
        _halt()
        _start()


# ── инструмент для голоса ────────────────────────────────────────────────────
def run(parameters: dict, player=None, session_memory=None) -> str:
    mode = str((parameters or {}).get("mode") or "toggle").strip().lower()
    want = {"on": True, "вкл": True, "включить": True, "off": False, "выкл": False,
            "выключить": False}.get(mode, not _cfg["on"])
    try:
        set_enabled(want)
    except Exception as e:
        return "Сэр, сфера не запустилась: %s" % e
    return "Сфера включена, сэр." if want else "Сфера выключена, вернул прежний интерфейс."


# ── страница настроек ────────────────────────────────────────────────────────
def settings_items():
    q = _cfg["quality"]
    items = [{"type": "label", "text": "Сфера: %s. Качество: %s." % (
        "включена" if _cfg["on"] else "выключена", {"light": "лёгкое", "normal": "обычное", "high": "высокое"}[q])}]
    items.append({"type": "button", "id": "off" if _cfg["on"] else "on",
                  "label": "Выключить сферу" if _cfg["on"] else "Включить сферу",
                  "pin": "act", "pin_title": "Сфера: выключить" if _cfg["on"] else "Сфера: включить"})
    items.append({"type": "label", "text": "Качество (если ТВ тормозит — выбери лёгкое):"})
    for key, label in (("light", "Лёгкое"), ("normal", "Обычное"), ("high", "Высокое")):
        if key != q:
            items.append({"type": "button", "id": "q_" + key, "label": label,
                          "pin": "act", "pin_title": "Сфера: качество — " + label.lower()})
    return items


def settings_event(event, values):
    if event == "on":
        set_enabled(True)
        return {"message": "Сфера включена.", "refresh": True}
    if event == "off":
        set_enabled(False)
        return {"message": "Сфера выключена.", "refresh": True}
    if event.startswith("q_") and event[2:] in _QUALITY:
        _set_quality(event[2:])
        return {"message": "Качество изменено.", "refresh": True}
    return ""


# ── автозапуск, если сфера была включена ─────────────────────────────────────
try:
    _load()
    if _cfg["on"]:
        _start()
except Exception:
    pass
