"""
tv_meminfo — how much RAM Jarvis uses on this TV.

Reads (nothing is changed):
  * the whole app via the TV's own ADB: `dumpsys meminfo com.jarvis.tv` -> total PSS and the split
    (Java heap, native heap, code, graphics...). This is the number Android itself counts;
  * the Python side of Jarvis from /proc (no ADB needed): RSS and PSS of this process;
  * the TV as a whole: /proc/meminfo (total, available).

Actions:
  now    (default) one measurement, shown on screen and saved to meminfo.txt
  watch  measure every N seconds for M minutes in the background and report min / average / PEAK.
         Use Jarvis as usual meanwhile (search films, talk) - the peak is what matters on a 1 GB TV.
  stop   stop watching and report what was collected
  top    the heaviest processes on the whole TV (who eats the RAM besides Jarvis)
  all    EVERY process on the TV with its memory, plus all apps you installed yourself (running or not) -
         saved to meminfo_all.txt, to decide what can be switched off
  auto   Jarvis frees memory by himself: when the available RAM drops below a limit he closes the apps from
         the same list (at most once per cooldown). Switch: "включи/выключи автоосвобождение памяти".
  free   close the background apps from your list (Menu > Plugin settings > "Memory"); the app on screen,
         Jarvis and system services are never touched. Reports how much RAM was gained.
  status is watching now?
Full text is saved to <Jarvis>/meminfo.txt. One self-contained file, read-only.
"""
from __future__ import annotations

import os
import re
import threading
import time
from pathlib import Path

HOME = Path(os.environ.get("JARVIS_HOME") or Path(__file__).resolve().parent.parent)
REPORT = HOME / "meminfo.txt"
PKG = "com.jarvis.tv"

PLUGIN = {
    "name": "tv_meminfo",
    "description": (
        "Measures how much RAM Jarvis uses on this TV. action=now (default): one measurement of the whole app "
        "(total, Java, native, graphics) plus the same process as /proc sees it and the free memory of the TV. "
        "action=watch: measure in the background every `interval` seconds for `minutes` minutes and report "
        "the minimum, average and peak; tell the user to use Jarvis normally meanwhile. "
        "action=stop: stop and report. action=status. action=top: list the heaviest processes (apps) on the whole TV "
        "- use for 'what eats the memory', 'why does the TV lag'. action=auto with state on/off/status (and optional threshold in MB): "
        "Jarvis closes the listed background apps by himself when the TV runs low on RAM; "
        "action=all: full list of every process and every user-installed app, saved to meminfo_all.txt; "
        "action=free: close the background apps from "
        "the user's list to free RAM ('free the memory', 'close background apps'); optional `apps` = package "
        "names separated by commas to use instead of the saved list. Say the short result aloud; the full report is on screen "
        "and in meminfo.txt. Use for 'how much memory does Jarvis use', 'measure memory', 'check RAM'."
    ),
    "brief": "Measure Jarvis RAM use on the TV.",
    "tier": "extra",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING", "description": "now | watch | stop | status | top | all | free | auto"},
            "state": {"type": "STRING", "description": "For auto: on | off | status"},
            "threshold": {"type": "INTEGER", "description": "For auto: close apps when available RAM is below this many MB (default 120)"},
            "apps": {"type": "STRING", "description": "For free: package names separated by commas (default: saved list)"},
            "minutes": {"type": "INTEGER", "description": "For watch: how long, default 5 (1-60)"},
            "interval": {"type": "INTEGER", "description": "For watch: seconds between measurements, default 10 (3-120)"},
        },
        "required": [],
    },
}

_lock = threading.Lock()
_watch = {"running": False, "stop": False, "samples": [], "started": 0.0, "minutes": 0}


# ── helpers ─────────────────────────────────────────────────────────────────
def _mb(kb) -> str:
    try:
        return "%.0f MB" % (float(kb) / 1024.0)
    except (TypeError, ValueError):
        return "?"


def _adb(cmd: str):
    """Output of a shell command through Jarvis's own ADB, or None when ADB is not available."""
    try:
        import android_bridge as android
        out = str(android.shell(cmd))
    except Exception:
        return None
    if out.startswith("ADB:"):
        return None
    return out[3:].strip() if out.startswith("ok:") else out


def parse_dumpsys(text: str) -> dict:
    """Numbers (KB) from `dumpsys meminfo <pkg>`. Missing ones are simply absent."""
    r = {}
    m = re.search(r"^\s*TOTAL\s+(\d+)", text, re.M)          # classic table: first column is total PSS
    if m:
        r["total"] = int(m.group(1))
    m = re.search(r"TOTAL PSS:\s*(\d+)", text)                # newer one-line form
    if m:
        r["total"] = int(m.group(1))
    for key, label in (("java", "Java Heap"), ("native", "Native Heap"), ("code", "Code"), ("stack", "Stack"),
                       ("graphics", "Graphics"), ("private_other", "Private Other"), ("system", "System")):
        m = re.search(r"^\s*%s:\s+(\d+)" % re.escape(label), text, re.M)
        if m:
            r[key] = int(m.group(1))
    m = re.search(r"Views:\s+(\d+)", text)
    if m:
        r["views"] = int(m.group(1))
    return r


def _proc_self() -> dict:
    """RSS / PSS of this (Python) process in KB, read straight from /proc."""
    r = {}
    try:
        for ln in open("/proc/self/status", encoding="utf-8", errors="replace"):
            if ln.startswith("VmRSS:"):
                r["rss"] = int(ln.split()[1])
            elif ln.startswith("Threads:"):
                r["threads"] = int(ln.split()[1])
    except Exception:
        pass
    try:
        for ln in open("/proc/self/smaps_rollup", encoding="utf-8", errors="replace"):
            if ln.startswith("Pss:"):
                r["pss"] = int(ln.split()[1])
                break
    except Exception:
        pass
    return r


def _proc_meminfo() -> dict:
    r = {}
    try:
        for ln in open("/proc/meminfo", encoding="utf-8", errors="replace"):
            k, _, v = ln.partition(":")
            if k in ("MemTotal", "MemAvailable", "MemFree", "SwapTotal", "SwapFree"):
                r[k] = int(v.split()[0])
    except Exception:
        pass
    return r


def sample() -> dict:
    """One measurement. 'app' is None when ADB is not connected."""
    app = None
    out = _adb("dumpsys meminfo %s" % PKG)
    if out and "TOTAL" in out:
        app = parse_dumpsys(out)
        if not app.get("total"):
            app = None
    return {"t": time.time(), "app": app, "py": _proc_self(), "sys": _proc_meminfo()}


def _line(s: dict) -> str:
    a, p, y = s["app"], s["py"], s["sys"]
    parts = []
    py_kind = "PSS" if p.get("pss") else "RSS, overstated"
    if a:
        parts.append("Jarvis uses %s in total (Java %s, native %s, graphics %s); the same process also reads as "
                     "%s by /proc (%s): that is the same memory counted another way, not an extra part" % (
                         _mb(a.get("total")), _mb(a.get("java")), _mb(a.get("native")), _mb(a.get("graphics")),
                         _mb(p.get("pss") or p.get("rss")), py_kind))
    else:
        parts.append("Jarvis process by /proc: %s (%s); the exact total needs ADB" % (
            _mb(p.get("pss") or p.get("rss")), py_kind))
    if y.get("MemAvailable"):
        parts.append("TV free %s of %s" % (_mb(y["MemAvailable"]), _mb(y.get("MemTotal"))))
    return "; ".join(parts)


def _report_now(s: dict) -> str:
    a, p, y = s["app"], s["py"], s["sys"]
    rows = ["Jarvis memory, %s" % time.strftime("%Y-%m-%d %H:%M:%S"), ""]
    if a:
        rows += ["== Whole app (%s) - what Android counts ==" % PKG,
                 "Total PSS:      %s" % _mb(a.get("total")),
                 "Java heap:      %s" % _mb(a.get("java")),
                 "Native heap:    %s" % _mb(a.get("native")),
                 "Code:           %s" % _mb(a.get("code")),
                 "Graphics:       %s" % _mb(a.get("graphics")),
                 "Private other:  %s" % _mb(a.get("private_other")),
                 "System:         %s" % _mb(a.get("system"))]
        if a.get("views") is not None:
            rows.append("Views:          %d" % a["views"])
    else:
        rows += ["== Whole app ==",
                 "ADB is not connected, so the total could not be read. On the TV: Settings > Developer options > "
                 "USB debugging and network debugging, and accept the prompt for this app."]
    rows += ["", "== The same process measured from /proc (Python runs inside the app process; this is NOT an extra part) ==",
             "PSS: %s   RSS: %s   threads: %s" % (
                 _mb(p.get("pss")) if p.get("pss") else "not available on this Android", _mb(p.get("rss")),
                 p.get("threads", "?")),
             "(RSS counts shared system libraries in full, so it is larger than the real share; the app total above is the true number.)",
             "", "== The TV ==",
             "Total RAM:      %s" % _mb(y.get("MemTotal")),
             "Available:      %s" % _mb(y.get("MemAvailable")),
             "Free (unused):  %s" % _mb(y.get("MemFree"))]
    if y.get("SwapTotal"):
        rows.append("Swap used:      %s of %s" % (_mb(y["SwapTotal"] - y.get("SwapFree", 0)), _mb(y["SwapTotal"])))
    return "\n".join(rows)


def _save(text: str, mode: str = "w") -> None:
    try:
        with open(REPORT, mode, encoding="utf-8") as f:
            f.write(text + ("\n\n" if mode == "a" else "\n"))
    except Exception:
        pass


def _show(player, title: str, text: str, log: str = "") -> None:
    if not player:
        return
    for fn, arg in (("show_content", (title, text[:3800])), ("write_log", ("JARVIS: " + (log or title),))):
        try:
            getattr(player, fn)(*arg)
        except Exception:
            pass


# ── heaviest processes on the TV ─────────────────────────────────────────────
_PROC = re.compile(r"^\s*([\d.,]+)K:\s+(.+?)\s+\(pid\s+(\d+)")


def parse_top(text: str, n: int = 15) -> tuple[list, dict]:
    """([(kb, name, pid)], {'total':kb,'free':kb,'used':kb,'lost':kb}) from `dumpsys meminfo`."""
    procs, inside = [], False
    for ln in text.splitlines():
        if ln.startswith("Total PSS by process"):
            inside = True
            continue
        if inside and ln.startswith("Total PSS by"):
            break
        if inside:
            m = _PROC.match(ln)
            if m:
                procs.append((int(re.sub(r"\D", "", m.group(1))), m.group(2).strip(), m.group(3)))
    ram = {}
    for key, label in (("total", "Total RAM"), ("free", "Free RAM"), ("used", "Used RAM"), ("lost", "Lost RAM")):
        m = re.search(r"^\s*%s:\s+([\d.,]+)K" % label, text, re.M)
        if m:
            ram[key] = int(re.sub(r"\D", "", m.group(1)))
    procs.sort(reverse=True)
    return procs[:n], ram


_KERNEL_KEYS = ("MemTotal", "MemFree", "MemAvailable", "Buffers", "Cached", "SwapCached", "Active", "Inactive",
                "Shmem", "Mapped", "Slab", "SReclaimable", "SUnreclaim", "KernelStack", "PageTables",
                "VmallocUsed", "CmaTotal", "CmaFree", "SwapTotal", "SwapFree")


def _proc_meminfo_full() -> dict:
    r = {}
    try:
        for ln in open("/proc/meminfo", encoding="utf-8", errors="replace"):
            k, _, v = ln.partition(":")
            if k in _KERNEL_KEYS:
                try:
                    r[k] = int(v.split()[0])
                except (ValueError, IndexError):
                    pass
    except Exception:
        pass
    return r


def _section(text: str, start: str, stop_prefixes: tuple, limit: int = 40) -> list:
    """Raw lines of one dumpsys block, from the line starting with `start` up to the next blank / stop line."""
    out, on = [], False
    for ln in text.splitlines():
        if not on and ln.startswith(start):
            on = True
        elif on and (not ln.strip() or ln.startswith(stop_prefixes)):
            break
        if on:
            out.append(ln.rstrip())
            if len(out) >= limit:
                break
    return out


def _breakdown(dump: str) -> list:
    """Where the RAM goes besides the processes: kernel, cache, zram, hardware reserve."""
    k = _proc_meminfo_full()
    rows = ["", "== Beyond the processes: kernel, cache, swap (from /proc/meminfo) =="]
    names = (("MemTotal", "Total RAM visible to Android"), ("MemFree", "Truly free (unused)"),
             ("MemAvailable", "Available (free + reclaimable cache)"), ("Cached", "File cache"),
             ("Buffers", "Buffers"), ("Shmem", "Shared memory (incl. graphics buffers)"),
             ("Slab", "Kernel slab"), ("SReclaimable", "  of which reclaimable"),
             ("SUnreclaim", "  of which not reclaimable"), ("KernelStack", "Kernel stacks"),
             ("PageTables", "Page tables"), ("VmallocUsed", "Kernel vmalloc"), ("CmaTotal", "CMA reserve (video etc.)"),
             ("CmaFree", "  of which free"), ("SwapTotal", "Swap size"))
    for key, label in names:
        if key in k:
            rows.append("%-42s %s" % (label, _mb(k[key])))
    if "SwapTotal" in k and k["SwapTotal"]:
        rows.append("%-42s %s" % ("Swap in use", _mb(k["SwapTotal"] - k.get("SwapFree", 0))))
    kern = sum(k.get(x, 0) for x in ("Slab", "KernelStack", "PageTables", "VmallocUsed"))
    if kern:
        rows.append("%-42s %s   (estimate: slab + stacks + page tables + vmalloc)" % ("Kernel memory, approx.", _mb(kern)))
    cat = _section(dump, "Total PSS by category", ("Total PSS by", "Total RAM"))
    if cat:
        rows += ["", "== dumpsys: by category (as the TV prints it) =="] + cat[1:]
    tail = _section(dump, "Total RAM", ("Total PSS by",), 20)
    if tail:
        rows += ["", "== dumpsys: RAM summary (as the TV prints it) =="] + tail
    return rows


def _all(player) -> str:
    """Every process with PSS + user-installed apps (running or not), to meminfo_all.txt."""
    out = _adb("dumpsys meminfo")
    if not out:
        return ("ADB is not connected. On the TV: Settings > Developer options > USB debugging and network "
                "debugging, and accept the prompt for this app.")
    procs, ram = parse_top(out, 500)
    if not procs:
        return "Could not read the process list from dumpsys on this TV."
    third = sorted(set(re.findall(r"package:([A-Za-z0-9_.]+)", _adb("pm list packages -3") or "")))
    disabled = set(re.findall(r"package:([A-Za-z0-9_.]+)", _adb("pm list packages -d") or ""))
    running = {n.split(":")[0] for _kb, n, _p in procs}
    rows = ["All processes on the TV, %s" % time.strftime("%Y-%m-%d %H:%M:%S"), ""]
    if ram:
        rows += ["RAM: total %s, free %s" % (_mb(ram.get("total")), _mb(ram.get("free"))), ""]
    rows.append("== Every process, heaviest first (%d, together %s) ==" % (len(procs), _mb(sum(k for k, _n, _p in procs))))
    for i, (kb, name, pid) in enumerate(procs, 1):
        tag = "  <- Jarvis" if name.startswith(PKG) else ("  [your app]" if name.split(":")[0] in third else "")
        rows.append("%3d. %6s  %s (pid %s)%s" % (i, _mb(kb), name, pid, tag))
    rows += ["", "== Apps you installed yourself (%d) ==" % len(third)]
    for pkg in third:
        st = "disabled" if pkg in disabled else ("RUNNING" if pkg in running else "not running")
        mem = next((k for k, n, _p in procs if n.split(":")[0] == pkg), 0)
        rows.append("%-14s %s%s" % (st, pkg, ("  " + _mb(mem)) if mem else ""))
    rows += _breakdown(out)
    text = "\n".join(rows)
    try:
        with open(HOME / "meminfo_all.txt", "w", encoding="utf-8") as f:
            f.write(text + "\n")
    except Exception:
        pass
    _show(player, "All processes", text[:3800], "process list ready")
    return ("Found %d processes and %d apps you installed. The full list is in meminfo_all.txt in the Jarvis "
            "folder, and the first part is on screen." % (len(procs), len(third)))


def _top(player) -> str:
    out = _adb("dumpsys meminfo")
    if not out:
        return ("ADB is not connected. On the TV: Settings > Developer options > USB debugging and network "
                "debugging, and accept the prompt for this app.")
    procs, ram = parse_top(out)
    if not procs:
        return "Could not read the process list from dumpsys on this TV."
    rows = ["Heaviest processes on the TV, %s" % time.strftime("%Y-%m-%d %H:%M:%S"), ""]
    if ram:
        rows.append("RAM: total %s, free %s" % (_mb(ram.get("total")), _mb(ram.get("free"))))
        rows.append("")
    mine = 0
    for i, (kb, name, pid) in enumerate(procs, 1):
        tag = "   <- Jarvis" if name.startswith(PKG) else ""
        mine += kb if tag else 0
        rows.append("%2d. %6s  %s (pid %s)%s" % (i, _mb(kb), name, pid, tag))
    shown = sum(kb for kb, _n, _p in procs)
    rows += ["", "The %d listed processes together: %s." % (len(procs), _mb(shown))]
    text = "\n".join(rows)
    _save(text)
    _show(player, "Memory: heaviest processes", text, "top processes ready")
    names = ", ".join("%s %s" % ("Jarvis" if n.startswith(PKG) else n.split(":")[0].split(".")[-1], _mb(kb))
                      for kb, n, _p in procs[:5])
    return "Heaviest on the TV: %s. Full list is on screen and in meminfo.txt." % names


# ── freeing memory: close background apps from the user's list ──────────────
SETTINGS = {"title": "Память"}
DEFAULT_APPS = ("com.medhaapps.wififtpserver,free.zona,mobi.zona,app.tunnel.tv,com.lazycatsoftware.lmd,"
                "org.smarttube.beta,com.liskovsoft.smarttubetv,com.liskovsoft.smarttubetv.beta,"
                "com.teamsmart.videomanager.tv")
_PKG_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z0-9_]+)+$")
# never closed, whatever the list says: Jarvis itself, Android, Google TV core, vendor system services
_PROTECTED = ("com.jarvis.tv", "android", "com.android.", "com.google.android.tvlauncher", "com.google.android.gms",
              "com.google.android.gsf", "com.google.android.katniss", "com.google.android.inputmethod",
              "com.mediatek.", "com.xiaomi.", "xiaomi.", "com.mitv.", "dtv_svc", "system")


def _cfg_file() -> str:
    try:
        import android_bridge as android
        return os.path.join(android.data_dir() or str(HOME), "tv_meminfo.json")
    except Exception:
        return str(HOME / "tv_meminfo.json")


AUTO_DEFAULTS = {"auto": True, "threshold_mb": 120, "cooldown_min": 10, "announce": False}


def _cfg() -> dict:
    import json
    try:
        with open(_cfg_file(), encoding="utf-8") as f:
            c = json.load(f)
        if not isinstance(c, dict):
            c = {}
    except Exception:
        c = {}
    out = dict(AUTO_DEFAULTS)
    out["apps"] = c["apps"] if isinstance(c.get("apps"), str) else DEFAULT_APPS
    out["auto"] = bool(c.get("auto", AUTO_DEFAULTS["auto"]))
    out["announce"] = bool(c.get("announce", AUTO_DEFAULTS["announce"]))
    out["threshold_mb"] = _int(c.get("threshold_mb"), 40, 600, AUTO_DEFAULTS["threshold_mb"])
    out["cooldown_min"] = _int(c.get("cooldown_min"), 1, 120, AUTO_DEFAULTS["cooldown_min"])
    out["filter"] = c.get("filter") if c.get("filter") in ("my", "running", "all") else "my"
    return out


def _cfg_save(c: dict) -> None:
    import json
    try:
        with open(_cfg_file(), "w", encoding="utf-8") as f:
            json.dump(c, f, ensure_ascii=False)
    except Exception:
        pass


def _load_apps() -> str:
    return _cfg()["apps"]


def _save_apps(v: str) -> None:
    c = _cfg()
    c["apps"] = v
    _cfg_save(c)


def _split(v: str) -> list:
    return [x.strip() for x in re.split(r"[\s,;]+", str(v or "")) if x.strip()]


def _protected(pkg: str) -> bool:
    return any(pkg == p or (p.endswith(".") and pkg.startswith(p)) for p in _PROTECTED)


def _free(player, apps_override: str = "", quiet: bool = False) -> str:
    if _adb("echo ok") is None:
        return ("ADB is not connected. On the TV: Settings > Developer options > USB debugging and network "
                "debugging, and accept the prompt for this app.")
    wanted = _split(apps_override) or _split(_load_apps())
    focus = _adb("dumpsys window windows | grep -E 'mCurrentFocus|mFocusedApp'") or ""
    run_now = set(re.findall(r"package:([A-Za-z0-9_.]+)", _adb("pm list packages") or ""))
    todo, skipped = [], []
    for pkg in dict.fromkeys(wanted):
        if not _PKG_RE.match(pkg):
            skipped.append("%s (not a package name)" % pkg)
        elif _protected(pkg):
            skipped.append("%s (protected)" % pkg)
        elif pkg in focus:
            skipped.append("%s (on screen now)" % pkg)
        elif run_now and pkg not in run_now:
            continue                                      # not installed on this TV
        else:
            todo.append(pkg)
    if not todo:
        return "Nothing to close: " + ("; ".join(skipped) if skipped else "the list is empty") + "."
    before = _proc_meminfo().get("MemAvailable", 0)
    _adb("; ".join("am force-stop %s" % p for p in todo))
    time.sleep(2.0)
    after = _proc_meminfo().get("MemAvailable", 0)
    gained = after - before
    rows = ["Closed background apps, %s" % time.strftime("%Y-%m-%d %H:%M:%S"), "",
            "Closed: " + ", ".join(todo)]
    if skipped:
        rows.append("Not touched: " + "; ".join(skipped))
    rows += ["", "Available RAM: %s -> %s (%s%s)" % (_mb(before), _mb(after), "+" if gained >= 0 else "-", _mb(abs(gained))),
             "(Android may restart some of these on its own later.)"]
    text = "\n".join(rows)
    _save(text)
    if not quiet:
        _show(player, "Memory freed", text, "background apps closed")
    return "Closed %d apps; available RAM %s -> %s." % (len(todo), _mb(before), _mb(after))


# ── scanner of installed apps + tick boxes ──────────────────────────────────
_FILTERS = ("my", "running", "all")
_FILTER_NAMES = {"my": "мои (установленные мной)", "running": "только запущенные", "all": "все приложения"}
_scan = {"t": 0.0, "apps": {}, "adb": False, "hidden": 0}


def _ui_check() -> bool:
    """True when this APK's settings page can draw tick boxes (older builds: buttons with a mark instead)."""
    try:
        from tvshim import plugins_ext
        return bool(getattr(plugins_ext, "UI_CHECK", False))
    except Exception:
        return False


def scan_apps() -> dict:
    """Every app on the TV: launchable ones + the ones you installed yourself, with 'running' and memory (MB)."""
    apps = {}
    try:
        import android_bridge as android
        listing = android.list_apps() or []
    except Exception:
        listing = []
    for a in listing:
        pkg = a.get("pkg")
        if pkg and _PKG_RE.match(pkg):
            apps[pkg] = {"label": a.get("label") or pkg, "tv": bool(a.get("tv")), "user": False, "mb": 0.0}
    adb = _adb("echo ok") is not None
    if adb:
        for pkg in re.findall(r"package:([A-Za-z0-9_.]+)", _adb("pm list packages -3") or ""):
            if _PKG_RE.match(pkg):
                apps.setdefault(pkg, {"label": pkg, "tv": False, "user": True, "mb": 0.0})["user"] = True
        procs, _ram = parse_top(_adb("dumpsys meminfo") or "", 800)
        for kb, name, _pid in procs:
            base = name.split(":")[0]
            if base in apps:
                apps[base]["mb"] += kb / 1024.0
    _scan.update(t=time.time(), apps=apps, adb=adb)
    return apps


def _apps_cached(force: bool = False) -> dict:
    if force or not _scan["apps"]:
        scan_apps()
    return _scan["apps"]


def _app_line(pkg: str, a: dict) -> str:
    st = ("  — запущено, %.0f МБ" % a["mb"]) if a.get("mb", 0) > 0 else ""
    return "%s   [%s]%s" % (a.get("label") or pkg, pkg, st)


def _visible(c: dict, apps: dict, sel: set) -> list:
    mode = c.get("filter", "my")
    out, hidden = [], 0
    for pkg, a in apps.items():
        if _protected(pkg):
            hidden += 1
            continue
        keep = (pkg in sel or mode == "all" or (mode == "my" and a.get("user"))
                or (mode == "running" and a.get("mb", 0) > 0))
        if keep:
            out.append(pkg)
    _scan["hidden"] = hidden
    out.sort(key=lambda k: (-apps[k].get("mb", 0), (apps[k].get("label") or k).lower()))
    return out


def settings_items():
    c = _cfg()
    apps = _apps_cached()
    sel = set(_split(c["apps"]))
    items = [
        {"type": "label", "text": "«Освободи память» закрывает приложения, отмеченные галочкой ниже. Приложение на "
                                  "экране, Джарвис и системные службы не трогаются."},
        {"type": "button", "id": "auto", "label": "Джарвис сам освобождает память: " + ("ВКЛ" if c["auto"] else "ВЫКЛ"),
         "pin": "act", "pin_title": "Автоосвобождение памяти: вкл/выкл"},
        {"type": "text", "id": "threshold_mb", "label": "Освобождать, когда доступно меньше (МБ, 40–600)",
         "value": str(c["threshold_mb"]), "hint": "120"},
        {"type": "text", "id": "cooldown_min", "label": "Не чаще раза в (минут, 1–120)",
         "value": str(c["cooldown_min"]), "hint": "10"},
        {"type": "button", "id": "announce", "label": "Говорить голосом, когда освободил: " + ("ВКЛ" if c["announce"] else "ВЫКЛ"),
         "pin": "act", "pin_title": "Голос при освобождении памяти"},
        {"type": "button", "id": "free", "label": "Освободить память сейчас", "pin": "act", "pin_title": "Освободить память"},
        {"type": "button", "id": "top", "label": "Показать самые тяжёлые процессы", "pin": "act", "pin_title": "Тяжёлые процессы"},
        {"type": "button", "id": "all", "label": "Список ВСЕХ процессов и приложений (в файл meminfo_all.txt)"},
        {"type": "button", "id": "now", "label": "Показать, сколько занимает Джарвис", "pin": "act", "pin_title": "Память Джарвиса"},
        {"type": "label", "text": "── Приложения для очистки ──"},
        {"type": "button", "id": "scan", "label": "Сканировать приложения заново"},
        {"type": "button", "id": "filter", "label": "Показывать: " + _FILTER_NAMES[c["filter"]] + "  — переключить"},
        {"type": "button", "id": "sel_running", "label": "Отметить все мои запущенные"},
        {"type": "button", "id": "sel_none", "label": "Снять все отметки"},
        {"type": "button", "id": "reset", "label": "Список по умолчанию"},
    ]
    if not apps:
        items.append({"type": "label", "text": "Список приложений получить не удалось (приложение ещё не готово)."})
    vis = _visible(c, apps, sel)
    stamp = time.strftime("%H:%M:%S", time.localtime(_scan["t"])) if _scan["t"] else "—"
    items.append({"type": "label", "text": "Найдено приложений: %d, показано: %d, отмечено: %d. Скан в %s%s. Защищённые "
                                           "системные скрыты (%d)." % (
                                               len(apps), len(vis), len(sel & set(apps)), stamp,
                                               "" if _scan["adb"] else ", без ADB: нет данных о памяти и «моих»",
                                               _scan["hidden"])})
    check = _ui_check()
    for pkg in vis:
        line = _app_line(pkg, apps[pkg])
        if check:
            items.append({"type": "check", "id": "chk:" + pkg, "label": line, "checked": pkg in sel})
        else:
            items.append({"type": "button", "id": "tgl:" + pkg, "label": ("☑ " if pkg in sel else "☐ ") + line})
    extra = sorted(p for p in sel if p not in apps)
    items += [
        {"type": "text", "id": "extra", "label": "Другие пакеты, которых нет в списке (через запятую)",
         "value": ", ".join(extra), "hint": "com.example.app"},
        {"type": "button", "id": "save", "label": "Сохранить"},
    ]
    return items


def _apply_selection(c: dict, v: dict) -> None:
    """Tick boxes ('chk:<pkg>' = '1'/'0') and the extra-packages field -> c['apps']."""
    sel = set(_split(c["apps"]))
    apps = _scan["apps"]
    for k, val in v.items():
        if k.startswith("chk:"):
            pkg = k[4:]
            if str(val) in ("1", "true", "True"):
                sel.add(pkg)
            else:
                sel.discard(pkg)
    if "extra" in v and apps:
        sel = {p for p in sel if p in apps} | {p for p in _split(v["extra"]) if _PKG_RE.match(p)}
    c["apps"] = ", ".join(sorted(p for p in sel if not _protected(p)))


def settings_event(event, values):
    v = values or {}
    if event == "reset":
        _save_apps(DEFAULT_APPS)
        return {"message": "Список по умолчанию", "refresh": True}
    c = _cfg()
    _apply_selection(c, v)
    if "threshold_mb" in v:
        c["threshold_mb"] = _int(v["threshold_mb"], 40, 600, c["threshold_mb"])
    if "cooldown_min" in v:
        c["cooldown_min"] = _int(v["cooldown_min"], 1, 120, c["cooldown_min"])
    _cfg_save(c)
    if event == "__leave__":
        return None
    if event in ("auto", "announce"):
        c[event] = not c[event]
        _cfg_save(c)
        return {"message": "%s: %s" % ("Автоосвобождение" if event == "auto" else "Голос", "ВКЛ" if c[event] else "ВЫКЛ"),
                "refresh": True}
    if event == "scan":
        apps = _apps_cached(True)
        return {"message": "Найдено приложений: %d%s" % (len(apps), "" if _scan["adb"] else " (без ADB нет данных о памяти)"),
                "refresh": True}
    if event == "filter":
        c["filter"] = _FILTERS[(_FILTERS.index(c["filter"]) + 1) % len(_FILTERS)]
        _cfg_save(c)
        return {"message": "Показываю: " + _FILTER_NAMES[c["filter"]], "refresh": True}
    if event in ("sel_none", "sel_running"):
        apps = _apps_cached()
        sel = set(_split(c["apps"]))
        if event == "sel_none":
            sel -= set(apps)
        else:
            sel |= {p for p, a in apps.items() if a.get("user") and a.get("mb", 0) > 0 and not _protected(p)}
        c["apps"] = ", ".join(sorted(sel))
        _cfg_save(c)
        return {"message": "Отмечено: %d" % len(sel & set(apps)), "refresh": True}
    if event.startswith("tgl:"):                                   # old APK without tick boxes
        pkg = event[4:]
        sel = set(_split(c["apps"]))
        sel.symmetric_difference_update({pkg})
        c["apps"] = ", ".join(sorted(sel))
        _cfg_save(c)
        return {"message": ("Отмечено: " if pkg in sel else "Снято: ") + pkg, "refresh": True}
    if event == "free":
        return {"message": _free(None), "refresh": False}
    if event == "top":
        return {"message": _top(None)[:160], "refresh": False}
    if event == "all":
        return {"message": _all(None)[:200], "refresh": False}
    if event == "now":
        return {"message": _line(sample())[:200], "refresh": False}
    return {"message": "Сохранено", "refresh": False}


# ── automatic freeing ───────────────────────────────────────────────────────
_auto = {"last": 0.0, "warned": False, "count": 0, "gained": 0, "last_msg": ""}


def _auto_tick(now: float) -> str:
    """One check. Returns what was done ('' = nothing). Needs no ADB until memory is actually low."""
    c = _cfg()
    if not c["auto"]:
        return ""
    avail = _proc_meminfo().get("MemAvailable", 0)
    if not avail or avail >= c["threshold_mb"] * 1024:
        return ""
    if now - _auto["last"] < c["cooldown_min"] * 60:
        return ""
    _auto["last"] = now
    before = avail
    res = _free(None, "", quiet=True)
    after = _proc_meminfo().get("MemAvailable", before)
    if res.startswith("Closed"):
        _auto["count"] += 1
        _auto["gained"] += max(0, after - before)
    _auto["last_msg"] = "%s: %s" % (time.strftime("%H:%M:%S"), res)
    try:
        import android_bridge as android
        android.log("tv_meminfo auto: low memory (%s available) -> %s" % (_mb(before), res))
    except Exception:
        pass
    if c["announce"] and res.startswith("Closed"):
        try:
            from tvshim import ui_android
            say = getattr(ui_android.CURRENT, "request_say", None)
            if say:
                say("Tell the user, in one short sentence in their language: memory was low, so you closed "
                    "background apps and freed some. %s" % res)
        except Exception:
            pass
    return res


def _auto_loop() -> None:
    time.sleep(60)                                   # let Jarvis finish starting
    while True:
        try:
            _auto_tick(time.time())
        except Exception:
            pass
        time.sleep(30)


def _auto_tool(p: dict) -> str:
    c = _cfg()
    state = str(p.get("state") or "status").lower().strip()
    if p.get("threshold") not in (None, ""):
        c["threshold_mb"] = _int(p.get("threshold"), 40, 600, c["threshold_mb"])
    if state in ("on", "off"):
        c["auto"] = state == "on"
    _cfg_save(c)
    last = _auto["last_msg"] or "nothing closed yet"
    return ("Automatic freeing is %s: when available RAM drops below %d MB, the listed background apps are closed "
            "(at most once per %d min). Since start: %d times, about %s freed. Last: %s." % (
                "ON" if c["auto"] else "OFF", c["threshold_mb"], c["cooldown_min"], _auto["count"],
                _mb(_auto["gained"]), last))


import sys as _sys
if not getattr(_sys, "_tv_meminfo_auto_started", False):
    _sys._tv_meminfo_auto_started = True
    threading.Thread(target=_auto_loop, name="tv-meminfo-auto", daemon=True).start()


# ── watching ────────────────────────────────────────────────────────────────
def _summary(samples: list, minutes_planned: int, stopped_early: bool) -> str:
    if not samples:
        return "No measurements were collected."
    tot = [s["app"]["total"] for s in samples if s["app"]]
    py = [(s["py"].get("pss") or s["py"].get("rss") or 0) for s in samples]
    avail = [s["sys"].get("MemAvailable") for s in samples if s["sys"].get("MemAvailable")]
    dur = (samples[-1]["t"] - samples[0]["t"]) / 60.0
    rows = ["Jarvis memory over %.1f min (%d measurements%s)" % (
        dur, len(samples), ", stopped early" if stopped_early else ""), ""]
    if tot:
        rows += ["Whole app, total PSS: min %s, average %s, PEAK %s" % (
                    _mb(min(tot)), _mb(sum(tot) / len(tot)), _mb(max(tot))),
                 "  at the end: %s" % _mb(tot[-1])]
        peak = max(samples, key=lambda s: (s["app"] or {}).get("total", 0))
        rows.append("  peak at %s: %s" % (time.strftime("%H:%M:%S", time.localtime(peak["t"])), _line(peak)))
    else:
        rows.append("Whole app: no ADB, only the /proc reading was taken.")
    kind = "PSS" if all(s["py"].get("pss") for s in samples) else "RSS, overstated"
    rows.append("Same process via /proc (%s): min %s, average %s, PEAK %s" % (kind, _mb(min(py)), _mb(sum(py) / len(py)), _mb(max(py))))
    if avail:
        rows.append("TV available RAM: lowest %s, highest %s" % (_mb(min(avail)), _mb(max(avail))))
    if len(tot) >= 4:
        q = max(1, len(tot) // 4)
        rows.append("Trend: first quarter %s -> last quarter %s (a steady climb means a leak)" % (
            _mb(sum(tot[:q]) / q), _mb(sum(tot[-q:]) / q)))
    return "\n".join(rows)


def _watch_loop(minutes: int, interval: int, player) -> None:
    end = time.time() + minutes * 60
    samples = _watch["samples"]
    _save("watch started %s, %d min every %d s" % (time.strftime("%H:%M:%S"), minutes, interval))
    try:
        while time.time() < end and not _watch["stop"]:
            s = sample()
            samples.append(s)
            _save("%s  %s" % (time.strftime("%H:%M:%S"), _line(s)), "a")
            for _ in range(interval * 2):
                if _watch["stop"] or time.time() >= end:
                    break
                time.sleep(0.5)
    finally:
        text = _summary(samples, minutes, _watch["stop"])
        _save("\n" + text, "a")
        _watch["running"] = False
        _show(player, "Jarvis memory", text, "memory measurement finished")
        if player and hasattr(player, "request_say"):
            try:
                tot = [x["app"]["total"] for x in samples if x["app"]]
                head = ("peak %s" % _mb(max(tot))) if tot else "ADB was off, only the /proc reading taken"
                player.request_say("Tell the user, briefly and in their language: the memory measurement is done, %s. "
                                   "The full report is on screen and in meminfo.txt." % head)
            except Exception:
                pass


def _int(v, lo, hi, d):
    try:
        return max(lo, min(hi, int(float(v))))
    except (TypeError, ValueError):
        return d


# ── tool ────────────────────────────────────────────────────────────────────
def run(parameters: dict, player=None) -> str:
    p = parameters or {}
    action = str(p.get("action") or "now").lower().strip()
    try:
        if action == "status":
            if _watch["running"]:
                n = len(_watch["samples"])
                last = _line(_watch["samples"][-1]) if n else "no data yet"
                return "Watching: %d measurements so far (%d min planned). Latest: %s." % (n, _watch["minutes"], last)
            return "Not watching. Say 'measure memory' for one measurement, or 'watch memory for 5 minutes'."

        if action == "stop":
            if not _watch["running"]:
                return "Nothing is being measured."
            _watch["stop"] = True
            return "Stopping; the result will appear on screen in a moment."

        if action == "watch":
            minutes = _int(p.get("minutes"), 1, 60, 5)
            interval = _int(p.get("interval"), 3, 120, 10)
            with _lock:
                if _watch["running"]:
                    return "Already watching."
                _watch.update(running=True, stop=False, samples=[], started=time.time(), minutes=minutes)
            threading.Thread(target=_watch_loop, args=(minutes, interval, player),
                             name="tv-meminfo", daemon=True).start()
            return ("Started: measuring every %d s for %d min. Use Jarvis as usual - search films, talk, open "
                    "apps. The peak, average and trend will appear on screen and in meminfo.txt." % (interval, minutes))

        if action == "top":
            return _top(player)

        if action == "all":
            return _all(player)

        if action == "auto":
            return _auto_tool(p)

        if action == "free":
            return _free(player, str(p.get("apps") or ""))

        if action != "now":
            return "Unknown action '%s'. Use now, watch, stop, status, top, all, free or auto." % action
        s = sample()
        text = _report_now(s)
        _save(text)
        _show(player, "Jarvis memory", text, "memory measured")
        return (_line(s) + ". Say only the app total as Jarvis's memory; never add the /proc figure to it. "
                "Full report is on screen and in meminfo.txt.")
    except Exception as e:
        return "tv_meminfo failed: %s: %s" % (type(e).__name__, e)
