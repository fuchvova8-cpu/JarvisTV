"""Тишина: Джарвис не заговаривает сам, пока вы его не спросили.

Отключает по пунктам (Меню → Настройки плагинов → «Тишина»):
  • приветствие и утренние новости при запуске («Opening briefing»);
  • проверку «как дела» в тишине («Check-in»);
  • оповещения о новостях по вашим темам («News watch»);
  • системные оповещения (нагрузка, память, температура).
По умолчанию отключено всё; нужное включайте кнопками. Голосом: «не болтай сам»,
«включи утренние новости», «выключи проверку».

Ядро Mark LVII не изменяется: плагин на лету подменяет в работающем ядре только точки, откуда Джарвис
начинает говорить сам. Напоминания, задачи и ваши собственные рутины не затрагиваются.
Пока пункт отключён, новости не помечаются прочитанными — после включения они прозвучат.
"""
import json
import os
import sys
import threading
import time

import android_bridge as android

ITEMS = (
    ("briefing", "Приветствие и утренние новости при запуске"),
    ("checkin", "Проверка «как дела» в тишине"),
    ("news", "Оповещения о новостях по вашим темам"),
    ("system", "Системные оповещения (нагрузка, память, температура)"),
)
_KEYS = tuple(k for k, _ in ITEMS)

PLUGIN = {
    "name": "quiet_mode",
    "description": (
        "Включает и отключает самостоятельные разговоры Джарвиса. Пункты: briefing (приветствие и утренние "
        "новости при запуске), checkin (проверка «как дела» в тишине), news (оповещения о новостях по темам), "
        "system (системные оповещения), all (всё сразу). Вызывай на «не болтай сам», «помолчи», "
        "«отключи утренние новости», «включи проверку». allow=false — запретить, allow=true — разрешить; "
        "без параметров — рассказать, что сейчас разрешено."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "item": {"type": "STRING", "description": "briefing | checkin | news | system | all"},
            "allow": {"type": "BOOLEAN", "description": "true — разрешить говорить самому, false — запретить"},
        },
    },
}

SETTINGS = {"title": "Тишина"}

_C = None
_sys_on = (True, 0.0)
_J = None
_skipped = {k: 0 for k in _KEYS}


# ── config: True = пункту разрешено говорить сам ────────────────────────────
def _file():
    return os.path.join(android.data_dir() or ".", "quiet_mode.json")


def _conf():
    global _C
    if _C is None:
        try:
            with open(_file(), encoding="utf-8") as f:
                c = json.load(f)
        except Exception:
            c = {}
        _C = {k: bool(c.get(k, False)) for k in _KEYS}
    return _C


def _save():
    try:
        with open(_file(), "w", encoding="utf-8") as f:
            json.dump(_conf(), f, ensure_ascii=False, indent=1)
    except Exception as e:
        android.log("quiet_mode: не сохранить: %s" % e)


def _plugin_on():
    """Галочка плагина в меню «Плагины (вкл/выкл)»: выключен плагин — всё разрешено."""
    global _sys_on
    now = time.monotonic()
    if now - _sys_on[1] > 2.0:
        try:
            from memory.config_manager import get_plugin_enabled
            _sys_on = (bool(get_plugin_enabled("quiet_mode")), now)
        except Exception:
            _sys_on = (True, now)
    return _sys_on[0]


def _blocked(key):
    if not _plugin_on() or _conf().get(key, False):
        return False
    _skipped[key] += 1
    android.log("quiet_mode: пропущено самостоятельное: %s" % dict(ITEMS)[key])
    return True


# ── hooks into the running core ─────────────────────────────────────────────
def _find():
    global _J
    if _J is None:
        try:
            from tvshim import ui_android
            _J = getattr(getattr(ui_android.CURRENT, "on_interrupt", None), "__self__", None)
        except Exception:
            _J = None
    if _J is None:
        try:
            import gc
            for o in gc.get_objects():
                if type(o).__name__ == "JarvisLive" and hasattr(o, "_sys_monitor"):
                    _J = o
                    break
        except Exception:
            pass
    return _J


def _wrap_async(jl, attr, key):
    orig = getattr(jl, attr, None)
    if orig is None or getattr(orig, "_quiet", False):
        return

    async def w(*a, **k):
        if _blocked(key):
            return None
        return await orig(*a, **k)

    w._quiet = True
    setattr(jl, attr, w)


def _wrap_sync(obj, attr, key, blocked_value):
    orig = getattr(obj, attr, None)
    if orig is None or getattr(orig, "_quiet", False):
        return

    def w(*a, **k):
        if _blocked(key):
            return blocked_value
        return orig(*a, **k)

    w._quiet = True
    setattr(obj, attr, w)


def _install(jl):
    # приветствие + новости (и по расписанию-рутине, и обычным стартом)
    _wrap_async(jl, "_send_startup_briefing", "briefing")
    # проверка «как дела»: рутина и запасной цикл
    _wrap_async(jl, "_routine_checkin", "checkin")
    if getattr(jl, "_proactive", None) is not None:
        _wrap_sync(jl._proactive, "should_trigger", "checkin", False)
    # новости по темам: рутина и запасной цикл берут их через main.monitor_check_all
    _wrap_async(jl, "_routine_news_watch", "news")
    m = sys.modules.get("main")
    f = getattr(m, "monitor_check_all", None) if m is not None else None
    if f is not None and not getattr(f, "_quiet", False):
        def mca(*a, **k):
            if _blocked("news"):
                return []
            return f(*a, **k)
        mca._quiet = True
        m.monitor_check_all = mca
    # системные оповещения
    if getattr(jl, "_sys_monitor", None) is not None:
        _wrap_sync(jl._sys_monitor, "check", "system", None)
    android.log("quiet_mode: подключён (разрешено: %s)" % (
        ", ".join(k for k in _KEYS if _conf()[k]) or "ничего"))


def _watch():
    """Ядро создаётся одновременно с загрузкой плагинов; ждём его и подменяем до первого разговора."""
    for _ in range(600):                       # до 2 минут
        jl = _find()
        if jl is not None and hasattr(jl, "_sys_monitor") and hasattr(jl, "_proactive"):   # __init__ дошёл до конца нужного
            try:
                _install(jl)
            except Exception as e:
                android.log("quiet_mode: не удалось подключиться: %s" % e)
            return
        time.sleep(0.2)
    android.log("quiet_mode: ядро не найдено")


if not getattr(sys, "_quiet_mode_started", False):
    sys._quiet_mode_started = True
    threading.Thread(target=_watch, daemon=True, name="quiet_mode").start()


# ── tool ────────────────────────────────────────────────────────────────────
def _state_text():
    c = _conf()
    return "; ".join("%s: %s" % (t, "разрешено" if c[k] else "отключено") for k, t in ITEMS)


def run(parameters, player=None, session_memory=None):
    p = parameters or {}
    item = str(p.get("item") or "").strip().lower()
    allow = p.get("allow")
    if not item or allow is None:
        return "Самостоятельные разговоры — " + _state_text() + "."
    keys = _KEYS if item in ("all", "все", "всё") else tuple(k for k in _KEYS if k == item)
    if not keys:
        return "Не знаю пункт «%s». Есть: briefing, checkin, news, system, all." % item
    allow = allow if isinstance(allow, bool) else str(allow).strip().lower() in ("true", "1", "yes", "да")
    for k in keys:
        _conf()[k] = allow
    _save()
    names = ", ".join(dict(ITEMS)[k].lower() for k in keys)
    return ("Разрешил: " if allow else "Отключил: ") + names + "."


# ── settings page ───────────────────────────────────────────────────────────
def settings_items():
    c = _conf()
    out = [{"type": "label", "text": "Что Джарвис может сказать сам, без вашего вопроса. «ОТКЛЮЧЕНО» — молчит. "
                                     "Напоминания и ваши собственные задачи не затрагиваются."}]
    for k, t in ITEMS:
        out.append({"type": "button", "id": k, "label": "%s: %s" % (t, "РАЗРЕШЕНО" if c[k] else "ОТКЛЮЧЕНО"),
                    "pin": "act", "pin_title": t.split(" (")[0]})
    all_off = not any(c.values())
    out.append({"type": "button", "id": "all", "label": "Включить всё" if all_off else "Отключить всё",
                "pin": "act", "pin_title": "Тихий режим: всё вкл/выкл"})
    out.append({"type": "button", "id": "status", "label": "Показать состояние", "pin": "act", "pin_title": "Тихий режим: состояние"})
    return out


def settings_event(event, values):
    c = _conf()
    if event in _KEYS:
        c[event] = not c[event]
        _save()
        return {"message": "%s: %s" % (dict(ITEMS)[event], "разрешено" if c[event] else "отключено"),
                "refresh": True}
    if event == "all":
        to = not any(c.values())
        for k in _KEYS:
            c[k] = to
        _save()
        return {"message": "Всё " + ("разрешено" if to else "отключено"), "refresh": True}
    if event == "status":
        skipped = ", ".join("%s — %d" % (t.split(" (")[0], _skipped[k]) for k, t in ITEMS)
        return {"message": "Подключено к ядру: %s. Пропущено с запуска: %s." % (
            "да" if getattr(getattr(_J, "_send_startup_briefing", None), "_quiet", False)
            else "нет (ядро ещё не готово)", skipped),
            "refresh": False}
    if event == "__leave__":
        return None
    return {"message": "Сохранено", "refresh": False}
