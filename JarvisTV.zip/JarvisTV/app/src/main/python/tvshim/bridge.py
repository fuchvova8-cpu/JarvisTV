"""Python -> Kotlin glue. One place that knows how to reach com.jarvis.tv.Bridge.

On a desktop test run (no Chaquopy) `kt()` returns a recording stub, so the whole
Python layer can be exercised without a device.
"""
from __future__ import annotations

import threading

_lock = threading.Lock()
_kt = None


class _Stub:
    """Desktop stand-in. Records calls; returns neutral values."""

    def __init__(self):
        self.calls: list[tuple] = []
        self.volume = 50
        self.muted = False
        self.clip = ""

    def __getattr__(self, name):
        def _f(*a):
            self.calls.append((name, a))
            return {"volumeGet": self.volume, "muteGet": self.muted,
                    "clipGet": self.clip, "openUrl": True, "launchApp": True,
                    "videoState": "{}", "adbAvailable": False,
                    "screenSize": [1920, 1080]}.get(name)
        return _f


def kt():
    """The Kotlin `Bridge` singleton (or a stub off-device)."""
    global _kt
    if _kt is None:
        with _lock:
            if _kt is None:
                try:
                    from java import jclass  # Chaquopy only
                    _kt = jclass("com.jarvis.tv.Bridge").INSTANCE
                except Exception:
                    _kt = _Stub()
    return _kt


def jclass(name: str):
    from java import jclass as _j
    return _j(name)


def to_bytes(arr) -> bytes:
    """A Java byte[] (or anything bytes-like) as Python bytes."""
    if arr is None:
        return b""
    if isinstance(arr, (bytes, bytearray, memoryview)):
        return bytes(arr)
    try:
        return bytes(arr)
    except Exception:
        return bytes((b & 0xFF) for b in arr)


def safe(fn, default=None):
    try:
        return fn()
    except Exception as e:  # never let a UI call take a worker thread down
        print(f"[tvshim] bridge call failed: {type(e).__name__}: {e}")
        return default
