"""JarvisUI for Android TV — the object main.py builds and every plugin receives
as `player`.

It is registered as the module `ui` before main.py is imported, so the original
`from ui import JarvisUI` finds this class. It keeps the PC class's whole public
surface (same names, same thread-safety promises, same return values); what it
draws, it draws by calling the Kotlin Bridge, because there is no Qt on a TV.
"""
from __future__ import annotations

import json
import os
import threading
import time
import types

from tvshim.bridge import kt, safe


def _read_cfg() -> dict:
    try:
        from memory.config_manager import load_api_keys
        return load_api_keys()
    except Exception:
        return {}


class _Root:
    """What main() calls: `ui.root.mainloop()` blocks until the app is stopped."""

    def __init__(self, ui: "JarvisUI"):
        self._ui = ui
        self._stop = threading.Event()

    def mainloop(self):
        self._stop.wait()

    def quit(self):
        self._stop.set()

    destroy = quit

    def protocol(self, *_):
        pass


class JarvisUI:
    def __init__(self, face_path: str = "face.png", size=None):
        self._lock = threading.RLock()
        self._muted = False
        self._current_file: str | None = None
        self._state = "SLEEPING"
        cfg = _read_cfg()
        self._win = types.SimpleNamespace(
            _ready=self._check_ready(cfg),
            _assistant_name=cfg.get("assistant_name") or "JARVIS",
            _muted=False,
        )
        self.root = _Root(self)

        # Callbacks main.py (JarvisLive) assigns.
        self.on_text_command = None
        self.on_remote_clicked = None
        self.on_interrupt = None
        self.on_voice_change = None
        self.on_audio_device_change = None
        self.get_plugins = None
        self.get_plugin_settings = None
        self.on_wake_toggle = None
        self.on_wake_manual = None
        self.on_wake_install = None
        self.wake_get_state = None
        self.wake_is_ready = None
        self.on_push_to_talk = None
        self.ptt_hold = None
        self.request_say = None
        self.tool_catalog = None
        self.run_tool = None

        # Quiz and video bookkeeping (the Kotlin side only draws).
        self._quiz: dict | None = None
        self._video = {"kind": "", "position": 0.0, "duration": 0.0, "paused": False}

        global CURRENT
        CURRENT = self
        safe(lambda: kt().uiReady(bool(self._win._ready), self._win._assistant_name))

    # ── configuration gate (same rule as the PC window's _check_config) ─────
    @staticmethod
    def _check_ready(d: dict | None = None) -> bool:
        d = d if d is not None else _read_cfg()
        if not d.get("os_system"):
            return False
        providers = d.get("providers") if isinstance(d.get("providers"), dict) else {}
        return bool(d.get("gemini_api_key") or d.get("local_only")
                    or str(providers.get("mode") or "").lower() == "pipeline")

    def wait_for_api_key(self):
        while not self._win._ready:
            time.sleep(0.1)

    def prompt_reconfig(self):
        self._win._ready = False
        safe(lambda: kt().promptKey())

    # ── mute / file ──────────────────────────────────────────────────────────
    @property
    def muted(self) -> bool:
        return self._muted

    @muted.setter
    def muted(self, v: bool):
        v = bool(v)
        if v != self._muted:
            self._muted = v
            self._win._muted = v
            safe(lambda: kt().muted(v))
            if v:
                self.set_state("MUTED")
            elif self._state == "MUTED":
                self.set_state("LISTENING")

    @property
    def current_file(self) -> str | None:
        return self._current_file

    @property
    def assistant_name(self) -> str:
        return self._win._assistant_name

    # ── thread-safe drawing calls ────────────────────────────────────────────
    def write_log(self, text: str):
        safe(lambda: kt().log(str(text)))

    def set_state(self, state: str):
        self._state = str(state)
        safe(lambda: kt().state(self._state))

    def set_audio_level(self, level: float) -> None:
        try:
            kt().level(float(level))
        except Exception:
            pass

    def push_visemes(self, frames, hop: float, at: float) -> None:
        pass                          # the TV HUD animates from the audio level

    def glance(self, dx: float, dy: float, hold: float = 1.1) -> None:
        pass

    def show_content(self, title: str, text: str):
        safe(lambda: kt().content(str(title)[:48], str(text)[:4000]))

    def show_confirm(self, title: str, detail: str) -> None:
        safe(lambda: kt().confirmShow(str(title)[:120], str(detail)[:300]))

    def hide_confirm(self) -> None:
        safe(lambda: kt().confirmHide())

    def notify_phone_connected(self) -> None:
        pass

    def start_speaking(self):
        self.set_state("SPEAKING")

    def stop_speaking(self):
        if not self.muted:
            self.set_state("LISTENING")

    def show_camera_frame(self, img_bytes: bytes):
        safe(lambda: kt().cameraFrame(bytes(img_bytes)))

    def start_camera_stream(self) -> None:
        safe(lambda: kt().cameraStream(True))

    def stop_camera_stream(self) -> None:
        safe(lambda: kt().cameraStream(False))

    # ── code agent panel ─────────────────────────────────────────────────────
    def show_code_job(self, job: dict) -> None:
        j = dict(job or {})
        lines = [f"{j.get('kind', 'job').upper()} · {j.get('folder', '')} · {j.get('status', '')}"]
        if j.get("request"):
            lines.append(str(j["request"])[:300])
        for f, st in (j.get("files") or {}).items():
            lines.append(f"  {st.get('state', '?'):<8} {f}")
        for t, m in (j.get("steps") or [])[-8:]:
            lines.append(f"  [{t}s] {m}")
        if j.get("summary"):
            lines.append("\n" + str(j["summary"])[:600])
        safe(lambda: kt().content("CODING AGENT", "\n".join(lines)[:4000]))

    # ── review panel ─────────────────────────────────────────────────────────
    def show_review(self, title: str, summary: str, findings, unclear=None) -> None:
        order = {"serious": 0, "caution": 1, "note": 2}
        mark = {"serious": "[!!]", "caution": "[! ]", "note": "[i ]"}
        out = [str(summary or "")]
        for f in sorted(list(findings or []), key=lambda f: order.get(str(f.get("severity")), 3)):
            out.append(f"\n{mark.get(str(f.get('severity')), '[  ]')} {f.get('heading', '')}")
            if f.get("detail"):
                out.append(f"    {f['detail']}")
            if f.get("quote"):
                out.append(f"    «{f['quote']}»")
            if f.get("suggestion"):
                out.append(f"    → {f['suggestion']}")
        if unclear:
            out.append("\nUNCLEAR:")
            out.extend(f"  ? {u}" for u in unclear)
        self.show_content(str(title or "REVIEW"), "\n".join(out))

    # ── quiz (same grading and hand-back message as the PC window) ───────────
    def show_quiz(self, topic: str, questions, grade=None) -> None:
        questions = list(questions or [])
        if not questions:
            return
        with self._lock:
            self._quiz = {"topic": topic or "", "questions": questions, "grader": grade,
                          "i": 0, "results": [], "answered": False}
        self._quiz_push()

    def hide_quiz(self) -> None:
        with self._lock:
            self._quiz = None
        safe(lambda: kt().quizHide())

    def _quiz_push(self):
        with self._lock:
            qz = self._quiz
            if qz is None:
                return
            q = qz["questions"][qz["i"]]
            qz["answered"] = False
            payload = {"topic": qz["topic"] or "quiz", "n": qz["i"] + 1,
                       "total": len(qz["questions"]), "question": q.get("question", ""),
                       "options": list(q.get("options") or [])}
        safe(lambda: kt().quizShow(json.dumps(payload, ensure_ascii=False)))

    def quiz_submit(self, given: str) -> str:
        """Kotlin -> Python. Returns JSON {mark, note, last}."""
        with self._lock:
            qz = self._quiz
            if qz is None or qz["answered"]:
                return "{}"
            qz["answered"] = True
            q = qz["questions"][qz["i"]]
            verdict = None
            if callable(qz.get("grader")):
                try:
                    verdict = qz["grader"](q, given)
                except Exception:
                    verdict = None
            qz["results"].append({"question": q.get("question", ""), "type": q.get("type", ""),
                                  "given": str(given or "").strip(), "answer": q.get("answer", ""),
                                  "correct": verdict})
            if verdict is True:
                mark = "✓  correct"
            elif verdict is False:
                mark = "✕  " + str(q.get("answer", ""))
            else:
                mark = "…  noted — I'll go over this one with you"
            note = q.get("note") or ""
            last = qz["i"] >= len(qz["questions"]) - 1
        return json.dumps({"mark": mark + (("\n" + note) if note else ""), "last": last,
                           "verdict": verdict}, ensure_ascii=False)

    def quiz_next(self) -> None:
        with self._lock:
            qz = self._quiz
            if qz is None:
                return
            if qz["i"] < len(qz["questions"]) - 1:
                qz["i"] += 1
                finish = False
            else:
                finish = True
        if finish:
            self._quiz_finish()
        else:
            self._quiz_push()

    def _quiz_finish(self):
        with self._lock:
            qz, self._quiz = self._quiz, None
        if not qz:
            return
        safe(lambda: kt().quizHide())
        topic, results = qz["topic"], qz["results"]
        right = sum(1 for r in results if r["correct"] is True)
        unsure = sum(1 for r in results if r["correct"] is None)
        total = len(results)
        self.write_log(f"QUIZ: {topic or 'quiz'} — {right}/{total} correct")
        lines = [f"[QUIZ_DONE] topic={topic or 'general'} | "
                 f"auto-marked {right}/{total} correct"
                 + (f", {unsure} still need your marking" if unsure else "")]
        for i, r in enumerate(results, 1):
            state = ("correct" if r["correct"] is True
                     else "wrong" if r["correct"] is False else "NEEDS MARKING")
            lines.append(
                f"{i}. [{r['type']}] {r['question']} | they answered: "
                f"{r['given'] or '(blank)'} | expected: {r['answer']} | {state}")
        lines.append(
            "Mark every question flagged NEEDS MARKING yourself — accept an answer "
            "that means the same thing. Then tell them how they did in their own "
            "language: the score, what they got wrong and why, in a couple of "
            "sentences. Offer another round only if it fits. "
            "Remember something only if it would still matter next week — that they "
            "are working through a subject, or keep missing the same thing. A score "
            "from one session is not worth a memory, and a memory per quiz would "
            "bury the things that are.")
        msg = "\n".join(lines)
        if self.on_text_command:
            threading.Thread(target=self.on_text_command, args=(msg,), daemon=True).start()

    # ── video / picture where the avatar sits ────────────────────────────────
    def show_video(self, source: str, title: str = "", muted: bool = True,
                   audio_source: str = "") -> None:
        self._video.update(kind="video", position=0.0, duration=0.0, paused=False)
        safe(lambda: kt().videoOpen(str(source or ""), str(title or ""), bool(muted),
                                    str(audio_source or "")))

    def show_image(self, path: str, title: str = "") -> None:
        self._video.update(kind="image", position=0.0, duration=0.0, paused=False)
        safe(lambda: kt().imageOpen(str(path or ""), str(title or "")))

    def stop_video(self) -> None:
        self._video.update(kind="", position=0.0, duration=0.0, paused=False)
        safe(lambda: kt().videoClose())

    def set_video_muted(self, muted: bool) -> None:
        safe(lambda: kt().videoMute(bool(muted)))

    def video_is_playing(self) -> bool:
        return bool(self.video_state().get("kind"))

    def seek_video(self, seconds: float, relative: bool = True) -> None:
        safe(lambda: kt().videoSeek(float(seconds), bool(relative)))

    def pause_video(self, paused: bool = True) -> None:
        safe(lambda: kt().videoPause(bool(paused)))

    def video_state(self) -> dict:
        """kind ('video' | 'image' | ''), position, duration (seconds), paused."""
        try:
            raw = kt().videoState()
            if raw:
                return dict(json.loads(str(raw)))
        except Exception:
            pass
        return dict(self._video)


CURRENT: JarvisUI | None = None
